"""
YAML-based configuration manager

Allows developers to define a schema (in Python) and use that to read in a YAML configuration file, check
the format, and create a (nested) set of Python objects from the configuration. 
"""

import sys
import traceback
import datetime
import re

import yaml

from . import includer


version = "1.2"

PAT_TYPE_WITH_DEFAULT = re.compile(r"(.*)\((.*)\)")


class NODEFAULT(object):
    pass


class ConfigurationError(Exception):
    """Error in YAML configuration file"""


class SchemaError(Exception):
    """Error in processing a Python schema, etc."""


def configurationError(schema, tree, text):
    """
    Raise a L{ConfigurationError} exception with an indication of the context within the YAML file
    """
    s = "parsing %r: %s" % (schema, text)
    raise ConfigurationError(s)


def indent(s, prefix="  ", stripInitialWhitespace=False):
    """
    Indent a multi-line text string, optionally removing a common whitespace prefix
    @param s: the string to indent
    @param prefix: the indentation to add (usually some spaces or a tab character)
    @param stripInitialWhitespace: if C{True} we will try to find a common whitespace prefix for all the lines
        and if we find one, remove it (blank/whitespace-only lines are not considered for this so they
        won't prevent a prefix common to all non-blank/white lines from being removed)
    @return: the indented string
    """
    lines = s.split("\n")
    nonblank = [line for line in lines if line.strip()]
    toStrip = 0

    if stripInitialWhitespace:
        stop = False
        for x in range(1, len(s) + 1):
            common = nonblank[0][:x]
            if [i for i in common if i not in " \t"]:
                # break out if there are non-whitespace characters in the common prefix
                break
            for line in lines:
                if not line.strip():
                    continue  # ignore blank lines
                if not line.startswith(common):
                    break
            else:
                toStrip = x
                continue
            break

        out = []
        for line in lines:
            if line.strip():
                out.append(prefix + line[toStrip:])
            else:
                out.append(prefix + line)

        return "\n".join(out)
    else:
        return "\n".join([prefix + line for line in lines])


class ConfigurationItem(object):
    """
    Abstract base class of configuration schema items
    """

    @property
    def schema(self):
        return self.parent.schema

    def __repr__(self):
        return "<%s (%s)>" % (self.id, self.__class__.__name__)


class Instance(ConfigurationItem):
    """
    Schema object representing a tag that should instantiate a Python object when the configuration is read
    """

    def __init__(self, id, properties, klass=None, tag=None, required=True, default=NODEFAULT, help=None):
        """
        @param id: the id of the instance (used as the name of the keyword argument via which this instance is
            suppled to the parent when it is instantiated)
        @param klass: the Python class to instantiate when this YAML element is reached
        @param properties: a list of properties of the Python class -
            these are passed in to the Python constructor as keyword arguments
        @param tag: the name of the YAML element (defaults to the same as C{id})
        @param required: iff C{True} a L{ConfigurationError} will be raised if this element/attribute is
            not present in the YAML
        @param default: default (Python) value (required must be C{True} if a default is supplied)
        @param help: help text
        """
        self.id = id
        self.tag = tag or self.id
        self.klass = klass or Configuration
        self.properties = properties
        self.required = required
        self.default = default
        self.help = help

        self.propertiesD = {}
        for item in self.properties:
            if item.id in self.propertiesD:
                raise SchemaError(
                    "Cannot have an item with the same id twice in the same properties list (even if one is a tag and one an element)"
                )
            self.propertiesD[item.tag] = item

    def parse(self, tree, parent=None):
        """
        Parse a tree of YAML nodes

        @param tree: dict of YAML dicts/lists
        @return: the parsed value (a Python instance)
        """
        if parent:
            self.parent = parent

        kargs = {}
        items = [i for i in tree.items()]
        for k, v in items:
            if k == "$include":
                items += [i for i in v.items()]
                continue
            if k not in self.propertiesD:
                configurationError(self, tree, "unrecognised property %r" % k)
            subSchema = self.propertiesD[k]
            o = subSchema.parse(v, parent=self)
            kargs[subSchema.id] = o

        # Set any defaults for properties that have them
        for property in self.properties:
            if (property.default is not NODEFAULT) and (property.id not in kargs):
                kargs[property.id] = property.default

        # Check for missing required properties
        for property in self.properties:
            if property.required and property.id not in kargs:
                configurationError(self, tree, "missing required property %s" % property.tag)

        try:
            o = self.klass(**kargs)
            return o
        except:
            tb = "\n".join(traceback.format_exception(*sys.exc_info()))
            tb = indent(tb, "  ")
            raise Exception("Failed to instantiate %r with %r:\n%s" % (self.klass, kargs, tb))


class GenericInstance(ConfigurationItem):
    """
    Schema object representing a an open sub-schema
    """

    def __init__(self, id, tag=None, required=True, default=NODEFAULT, help=None):
        """
        @param id: the id of the instance (used as the name of the keyword argument via which this instance is
            suppled to the parent when it is instantiated)
        @param tag: the name of the YAML element (defaults to the same as C{id})
        @param required: iff C{True} a L{ConfigurationError} will be raised if this element/attribute is
            not present in the YAML
        @param default: default (Python) value (required must be C{True} if a default is supplied)
        @param help: help text
        """
        self.id = id
        self.tag = tag or self.id
        self.required = required
        self.default = default
        self.help = help

    def parse(self, tree, parent=None):
        """
        Parse a tree of YAML nodes

        @param tree: dict of YAML dicts/lists
        @return: the parsed value (a Python instance)
        """
        return tree


class ConfigurationSchema(Instance):
    """
    Represents a schema for YAML<->python configuration

    This is based on an instance (as the overall configuration will be an instance of a Python class)
    """

    def __init__(self, *args, **kargs):
        if not "id" in kargs:
            kargs["id"] = "config"
        Instance.__init__(self, *args, **kargs)

    def parseFile(self, filename, globalContext=None):
        """
        Read in a file from disk

        We deliberately let YAML exceptions propagate up here so that it is clear from the screen/logs
        that there is an issue with the YAML and where that issue is.

        @param filename: the path to the file to load (relative to the current directory)
        @return: a Python instance (a new instance of the C{klass} argument provided to the constructor)
        """
        if globalContext is None:
            self.globalContext = globals()
        else:
            self.globalContext = globalContext

        tree = yaml.load(open(filename, "rt"), Loader=includer.IncludeLoader)
        rc = self.parse(tree)
        return rc

    @property
    def schema(self):
        return self

    @property
    def parent(self):
        return None


class Array(ConfigurationItem):
    """
    Schema object representing an array

    This represents YAML of the form::

        - myThing
            a: 1
            b: 2
        - myThing
            a: 2
            b: 3

    But can also represent mixed arrays of the form::

        - myThing
            a: 1
        - myOtherThing
            x: 2

    When parsed the result will be a Python list
    """

    def __init__(
        self, id, elements=None, element=None, tag=None, validation=None, required=True, default=NODEFAULT, help=None
    ):
        """
        @param id: the id for the object (when used as a keyword argument) and the XML tag name for the entire array
        @param element: schema object defining the kinds of sub-elements that are contained in the array
        @param elements: a list of config schema objects defining the kinds of sub-elements that can be
            contained in the array
        @param tag: the name of the YAML element (defaults to the same as C{id})
        @param validation: function to run on the result to decide whether it is valid (return C{None} if valid, an error string otherwise)
        @param required: False iff the whole array can be omitted (arrays can always be empty
            unless a user-supplied C{validation} function enforces something else
        @param default: default (Python) value (required must be C{True} is a default is supplied)
        @param help: help text
        """
        self.id = id
        self.tag = tag or self.id
        self.element = element
        self.elements = elements
        self.validation = validation
        self.required = required
        self.default = default
        self.help = help

        if (self.element and self.elements) or not (self.element or self.elements):
            raise SchemaError("%r must have exactly one of element or elements defined" % self)

        if self.elements:
            self.elementsD = {}
            for element in self.elements:
                self.elementsD[element.tag] = element

    def parse(self, tree, parent=None):
        """
        Parse a tree of YAML nodes

        @param tree: L{xml.etree.ElementTree.ElementTree}
        @return: the parsed value (a Python list)
        """

        if parent:
            self.parent = parent

        out = []
        if not isinstance(tree, list):
            configurationError(self, tree, "expected a list of values")
        for e in tree:
            if self.element:
                o = self.element.parse(e, parent=self)
                out.append(o)
            else:
                if not isinstance(e, dict) and len(e) == 1:
                    configurationError(
                        self, e, "array should contain single items (one of %s)" % (",".join(self.subSchemaD.keys()))
                    )
                tagName = e.keys()[0]
                if tagName not in self.elementsD:
                    if self.elementsD:
                        configurationError(
                            self,
                            e,
                            "unrecognised element %s (expecting one of %s)"
                            % (tagName, ", ".join(self.elementsD.keys())),
                        )
                    else:
                        configurationError(self, e, "no subelements expected in %s but got %s" % (tree.tag, tagName))
                subSchema = self.elementsD[tagName]
                o = subSchema.parse(e.values()[0], parent=self)
                out.append(o)

        return out


class Scalar(ConfigurationItem):
    """
    A simple property which by default can be supplied either as a sub-element or as an attribute

    N.B. the parsed object is not necessarily a true scalar since L{Scalar} supports reading Python expressions
    and Python function bodies from the YAML config
    """

    def __init__(
        self,
        id,
        tag=None,
        dataType=None,
        validation=None,
        required=True,
        asAttribute=True,
        asElement=True,
        default=NODEFAULT,
        help=None,
    ):
        """
        @param id: the id for the object (when used as a keyword argument)
        @param tag: the YAML tag name or attribute name for this value
        @param dataType: data type used to parse the text, one of:
            - int - expects an integer
            - float - expects a floating point number
            - str - expects a string
            - bool - expects a boolean expression C{(true,false,True,False,yes,no)}
            - date - expects a date in UK format dd/mm/yyyy
            - expression - expects a python expression; lambda functions are supported
            (they will always take node as a parameter)
            - function - expects python function that returns a value (i.e. the body of a python function
            without the C{def} line; the function will automatically take keyword arguments and make them locals
            - tree - a YAML subree

        @param validation: function to run on the result to decide whether it is valid
        @param required: C{False} iff the element/attribute array can be omitted
        @param asAttribute: C{True} iff this property can be set as an attribute
        @param asElement: C{True} iff this property can be set as a sub-element
        @param default: default (Python) value (required must be C{True} is a default is supplied)
        @param help: help text
        """
        self.id = id
        self.tag = tag or self.id
        self.dataType = dataType or "str"
        self.validation = validation
        self.required = required
        self.asAttribute = asAttribute
        self.asElement = asElement
        self.default = default
        self.help = help

        if dataType not in ("int", "float", "str", "expression", "bool", "date", "function", "tree"):
            raise Exception("Unknown dataType %s" % dataType)

    def parse(self, s, context=None, parent=None):
        """
        Parse a YAML node or a string into the given datatype, etc

        @param s: a string or a L{xml.etree.ElementTree.Element} (in this case the element's text will be used)
        @param context: optionally a parent element that can be passed into L{configurationError}
            to supply more information if an instance of this element can't be parsed
        @return: the parsed value
        """
        if parent:
            self.parent = parent

        out = None

        if self.dataType == "int":
            try:
                out = int(s)
            except ValueError:
                raise ConfigurationError(
                    f'Could not convert {s!r} to an int in {parent.id if parent else ""}.{self.id}'
                )
        elif self.dataType == "str":
            out = s
        elif self.dataType == "float":
            try:
                out = float(s)
            except ValueError:
                raise ConfigurationError(
                    f'Could not convert {s!r} to a float in {parent.id if parent else ""}.{self.id}'
                )
        elif self.dataType == "date":
            try:
                out = datetime.date.strptime(s, "%d/%m/%Y")
            except ValueError:
                raise ConfigurationError(
                    f'Could not convert {s!r} to a date in {parent.id if parent else ""}.{self.id}'
                )
        elif self.dataType == "expression":
            o = eval(s, self.schema.globalContext)
            if hasattr(o, "__doc__"):
                try:
                    o.__doc__ = s
                except:
                    pass
            out = o
        elif self.dataType == "function":
            code = "def userDefinedFunction(**kargs):\n"
            code += "\tglobals().update(kargs)\n"
            code += indent(s, "\t", stripInitialWhitespace=True)
            l = locals().copy()
            exec(code.strip(), self.schema.globalContext, l)
            l["userDefinedFunction"].__doc__ = code
            out = l["userDefinedFunction"]
        elif self.dataType == "bool":
            if s in ("True", "true", "yes"):
                out = True
            elif s in ("False", "false", "no"):
                out = False
            elif s in (True, False):
                out = s
            else:
                raise ConfigurationError("Invalid value for boolean %s: %r" % (self.id, s))
        elif self.dataType == "tree":
            out = s
        else:
            raise SchemaError("Invalid data type %s" % self.dataType)

        if self.validation:
            error = self.validation(value)
            if error:
                configurationError(self, context, error)

        return out


class Configuration(object):
    """
    Simple container to hold the top-level configuration
    """

    def __init__(self, **kargs):
        """
        This constructor just converts keyword arguments to instance attributes so that you can do e.g.::

            >>> Configuration(a=1,b=2)
            >>> Configuration.b
            2
            >>>

        """
        for k, v in kargs.items():
            if k == "$include":
                self.__dict__.update(v)
            else:
                self.__dict__[k] = v

    def asDict(self):
        return self.__dict__


def readSchemaFromFile(f):
    """
    Read a schema from a YAML schema description file
    :param f: stream object
    :return:
    """
    tree = yaml.load(f, Loader=includer.IncludeLoader)
    return _parseSchema(id="config", tree=tree, root=True)


def _parseSchema(id, tree, root=False, forceOptional=False):
    """
    Private function used to recursively parse the YAML schema into a ConfigurationSchema
    """
    if isinstance(tree, str):
        defaultValue = None
        if "(" in tree:
            dataType, defaultValue = PAT_TYPE_WITH_DEFAULT.match(tree).groups()
            dataType = dataType.strip()
        else:
            dataType = tree
        v = Scalar(id=id, dataType=dataType, required=not forceOptional)
        if defaultValue is not None:
            v.default = v.parse(defaultValue)
        return v
    elif "$type" in tree:
        klass = globals()[tree["$type"].capitalize()]
    elif root:
        klass = ConfigurationSchema
    else:
        klass = Instance

    kargs = {"id": id}

    contained = []

    if not isinstance(tree, dict):
        raise SchemaError("sequences are not valid in yaml schemas")

    for k in tree:
        if k.startswith("$"):
            if k in ("$properties", "$elements"):
                kargs[k[1:]] = [_parseSchema(id=i, tree=tree[k][i]) for i in tree[k]]
            elif k == "$type":
                continue
            elif k == "$include":
                contained += _parseSchema(id=id, tree=tree[k]).properties
            else:
                kargs[k[1:]] = tree[k]
        elif k.endswith("@"):
            contained.append(_parseSchema(id=k[:-1], tree=tree[k], forceOptional=True))
        else:
            contained.append(_parseSchema(id=k, tree=tree[k]))

    if klass is Instance or klass is ConfigurationSchema:
        kargs["properties"] = contained
    elif klass is Array:
        if len(contained) == 1:
            kargs["element"] = contained[0]
        else:
            kargs["elements"] = contained

    if forceOptional:
        kargs["required"] = False

    return klass(**kargs)
