import os
from pathlib import Path

from .yconfig import *

from . import readargs

__all__ = ["config"]


class ConfigManager:
    def _setup(self, base=None, config_path=None, schema_path=None, use_args=readargs.parser, use_strict_args=True):
        self.__dict__["base"] = base

        if not schema_path:
            schema_path = os.path.realpath(os.path.join(base, "config_schema.yaml"))

        if use_args:
            if use_strict_args:
                args = use_args.parse_args()
            else:
                args, _ = use_args.parse_known_args()
            if args.config_file:
                config_path = os.path.realpath(args.config_file)
        if not config_path:
            config_path = os.path.realpath(os.path.join(base, "config.yaml"))

        schema = readSchemaFromFile(open(schema_path))

        try:
            config = schema.parseFile(config_path)
        except IOError:
            sys.stderr.write(readargs.parser.format_help())
            sys.stderr.write("\nError reading config file at %s\n" % config_path)
            raise
            # sys.exit(1)

        if "stats" not in config.__dict__:
            try:
                at = base
                while 1:
                    at = os.path.split(at)[:-1]
                    if at == "/":
                        break
                    commitish = open(".git/ORIG_HEAD", "rt").read()[:-1]
                    config.stats = dict(commitish=commitish)
            except:
                config.stats = {}

        if use_args:
            readargs.update_config_from_args(config)

        self.__dict__["_config"] = config

    def __getattr__(self, item):
        if "_config" not in self.__dict__:
            raise ValueError("ConfigManager is not initialized")
        return getattr(self._config, item)

    def __getitem__(self, item):
        if "_config" not in self.__dict__:
            raise ValueError("ConfigManager is not initialized")
        return getattr(self._config, item)

    def __setitem__(self, item, value):
        if "_config" not in self.__dict__:
            raise ValueError("ConfigManager is not initialized")
        return setattr(self._config, item, value)

    def __setattr__(self, item, value):
        if "_config" not in self.__dict__:
            raise ValueError("ConfigManager is not initialized")
        return setattr(self._config, item, value)


config = ConfigManager()
