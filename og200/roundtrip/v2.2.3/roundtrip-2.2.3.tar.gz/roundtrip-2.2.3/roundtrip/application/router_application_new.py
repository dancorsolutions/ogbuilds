import warnings
from typing import *

from ..component.decorators import *
from ..core.javascript import js
from .base_application import BaseApplication
from ..component import component


__all__ = ["RouterApplication", "Route"]


class Route:
    """
    Represents a route in a local router
    """

    def __init__(self, path: str, component: str, **kwargs):
        self.component = component
        self.data = kwargs
        self.args = []

        self.path = ""
        split_path = path.split("/")
        for i in split_path:
            if i.startswith(":"):
                self.args.append(i[1:])
            else:
                if i:
                    self.path += "/" + i

    def match(self, path):
        if not path:
            return False, None
        split_path = path.split("/")
        split_self = self.path.split("/")
        if split_self != split_path[: len(split_self)]:
            return False, None
        else:
            args = dict()
            rest = split_path[len(split_self) :]
            for k in self.args:
                if not rest:
                    break
                v = rest.pop(0)
                args[k] = v
            if len(args) != len(self.args) or rest:
                # not all arguments matched / leftover paths after all arguments matched
                return False, None
            return True, args


class RouterApplication(BaseApplication):
    routes: List[Route] = []

    # language=Vue
    template = r"""
    <MyAppError/>
    <component :is="current_screen" v-if="standalone"/>
    """

    initialData = dict(at_component=None, at_props=dict())

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        didConnect=js(
            """
            function(is_reconnection) {
                if(this.do_connect) 
                    this.do_connect({is_reconnection, path: window.location.pathname});
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        handlePopstate=js(
            """
        function(event) {
            event.preventDefault();
            this.do_popstate({state: event.state});
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        push=js(
            """
        function(location, data) {
            history.pushState(data, null, location);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        back=js(
            """
        function() {
            history.go(-1);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        forward=js(
            """
        function() {
            history.go(1);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        replace=js(
            """
        function(location, data) {
            history.replaceState(data, null, location);
        }"""
        ),
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        beforeMount=js(
            """function() { 
            window.addEventListener('popstate', this.handlePopstate);
            window.addEventListener('load', this.handleLoad);            
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        beforeUnmount=js(
            """function() { 
            window.removeEventListener('popstate', this.handlePopstate);
            window.removeEventListener('load', this.handleLoad);            
        }"""
        ),
    )

    @method
    def do_connect(self, is_reconnection, path):
        """Called when a new websocket connection is opened"""
        self.push(path=path)

    def find_route(self, path, history_state):
        """Find a route matching a URL path"""
        for route in self.routes:
            matched, route_kwargs = route.match(path)
            if not matched:
                continue
            return matched, route_kwargs
        warnings.warn(f"No such route {path}")
        return None, None

    def push(self, path=None, history_state=None):
        path = "/" + path if not path.startswith("/") else path
        route, route_kwargs = self.find_route(path=path, history_state=history_state)
        if route is None:
            return

        if self.before_push(
            from_route=self.session.current_route,
            to_route=route,
            route_kwargs=route_kwargs,
            history_state=history_state,
        ):
            return

        state = dict(path=path) | (history_state or {})
        self.client.push(path, state)
        self.session.current_route = route

    def before_push(self, from_route: Route or None, to_route: Route, route_kwargs: dict, history_state: dict or None):
        """
        Called before we try to navigate to a new route
        :param from_route: the current route (if any) we're navigating away from
        :param to_route: the new route (Route object) we're going towards
        :param route_kwargs: any additional arguments defined on the route
        :param history_state: any additional state that was pushed onto the client history stack
        :return: return True to abort the push or False to keep going
        """
        return False

    def before_pop(self, from_route: Route or None, to_route: Route, route_kwargs: dict, history_state: dict or None):
        """
        Called before a new state is pushed onto the stack
        :param from_route: the current route (if any) we're navigating away from
        :param to_route: the new route (Route object) we're going towards
        :param route_kwargs: any additional arguments defined on the route
        :param history_state: any additional state that was pushed onto the client history stack
        :return: return True to abort the pop or False to keep going
        """
        return False

    def back(self):
        self.client.back()

    def forward(self):
        self.client.forward()

    def show_route(self, route: Route, route_kwargs):
        """
        Navigate to the location represented by a route without changing history state
        :param path: the URL path
        :param kwargs: any keyword args that should be passed into the route target
        :return: None
        """
        self.data.at_props = route_kwargs
        self.data.at_component = route.component

    @method
    def do_popstate(self, state):
        """This is called when the user presses the back or forward button in the browser"""
        path = state["path"]
        history_state = state.get("history_state", dict())
        route, route_kwargs = self.find_route(path=path, history_state=history_state)
        if self.before_pop(
            from_route=self.session.current_route,
            to_route=route,
            route_kwargs=route_kwargs,
            history_state=history_state,
        ):
            return
        self.show_route(route=route, route_kwargs=route_kwargs)
