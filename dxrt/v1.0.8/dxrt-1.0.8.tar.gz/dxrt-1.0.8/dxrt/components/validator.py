# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxValidator', 'DxValidatorAdapter', 'DxValidatorAsyncRule', 'DxValidatorCompareRule',
 'DxValidatorCustomRule', 'DxValidatorEmailRule', 'DxValidatorNumericRule',
 'DxValidatorPatternRule', 'DxValidatorRangeRule', 'DxValidatorRequiredRule',
 'DxValidatorStringLengthRule', 'DxValidatorValidationRule']

common_attrs = ['key']


class DxValidator(External):
    imports = {"import DxValidator from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['adapter', 'elementAttr', 'height', 'name', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'onValidated', 'validationGroup',
        'validationRules', 'width']


class DxValidatorAdapter(External):
    imports = {"import {DxAdapter as DxValidatorAdapter} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['applyValidationResults', 'bypass', 'focus', 'getValue', 'reset',
        'validationRequestsCallbacks']


class DxValidatorAsyncRule(External):
    imports = {"import {DxAsyncRule as DxValidatorAsyncRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxValidatorCompareRule(External):
    imports = {"import {DxCompareRule as DxValidatorCompareRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'message', 'type']


class DxValidatorCustomRule(External):
    imports = {"import {DxCustomRule as DxValidatorCustomRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxValidatorEmailRule(External):
    imports = {"import {DxEmailRule as DxValidatorEmailRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxValidatorNumericRule(External):
    imports = {"import {DxNumericRule as DxValidatorNumericRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxValidatorPatternRule(External):
    imports = {"import {DxPatternRule as DxValidatorPatternRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'pattern', 'type']


class DxValidatorRangeRule(External):
    imports = {"import {DxRangeRule as DxValidatorRangeRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'reevaluate', 'type']


class DxValidatorRequiredRule(External):
    imports = {"import {DxRequiredRule as DxValidatorRequiredRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['message', 'trim', 'type']


class DxValidatorStringLengthRule(External):
    imports = {"import {DxStringLengthRule as DxValidatorStringLengthRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'trim', 'type']


class DxValidatorValidationRule(External):
    imports = {"import {DxValidationRule as DxValidatorValidationRule} from 'devextreme-vue/validator'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'max',
        'message', 'min', 'pattern', 'reevaluate', 'trim', 'type',
        'validationCallback']



