# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDraggable', 'DxDraggableCursorOffset']

common_attrs = ['key']


class DxDraggable(External):
    imports = {"import DxDraggable from 'devextreme-vue/draggable'"}
    attrs = common_attrs + ['autoScroll', 'boundary', 'clone', 'container', 'cursorOffset', 'data',
        'dragDirection', 'dragTemplate', 'elementAttr', 'group', 'handle',
        'height', 'onDisposing', 'onDragEnd', 'onDragMove', 'onDragStart',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'scrollSensitivity',
        'scrollSpeed', 'width']


class DxDraggableCursorOffset(External):
    imports = {"import {DxCursorOffset as DxDraggableCursorOffset} from 'devextreme-vue/draggable'"}
    attrs = common_attrs + ['x', 'y']



