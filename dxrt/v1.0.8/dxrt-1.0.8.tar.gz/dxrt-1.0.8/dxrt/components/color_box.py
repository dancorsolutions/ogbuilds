# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxColorBox', 'DxColorBoxAnimation', 'DxColorBoxAt', 'DxColorBoxBoundaryOffset',
 'DxColorBoxButton', 'DxColorBoxCollision', 'DxColorBoxDropDownOptions', 'DxColorBoxFrom',
 'DxColorBoxHide', 'DxColorBoxMy', 'DxColorBoxOffset', 'DxColorBoxOptions', 'DxColorBoxPosition',
 'DxColorBoxShow', 'DxColorBoxTo', 'DxColorBoxToolbarItem']

common_attrs = ['key']


class DxColorBox(External):
    imports = {"import DxColorBox from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['acceptCustomValue', 'accessKey', 'activeStateEnabled',
        'applyButtonText', 'applyValueMode', 'buttons', 'cancelButtonText',
        'deferRendering', 'disabled', 'dropDownButtonTemplate',
        'dropDownOptions', 'editAlphaChannel', 'elementAttr', 'fieldTemplate',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'inputAttr',
        'isValid', 'keyStep', 'label', 'labelMode', 'name', 'onChange',
        'onClosed', 'onCopy', 'onCut', 'onDisposing', 'onEnterKey', 'onFocusIn',
        'onFocusOut', 'onInitialized', 'onInput', 'onKeyDown', 'onKeyUp',
        'onOpened', 'onOptionChanged', 'onPaste', 'onValueChanged', 'opened',
        'openOnFieldClick', 'placeholder', 'readOnly', 'rtlEnabled',
        'showClearButton', 'showDropDownButton', 'stylingMode', 'tabIndex',
        'text', 'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value', 'visible',
        'width', 'modelValue']


class DxColorBoxAnimation(External):
    imports = {"import {DxAnimation as DxColorBoxAnimation} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['hide', 'show']


class DxColorBoxAt(External):
    imports = {"import {DxAt as DxColorBoxAt} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['x', 'y']


class DxColorBoxBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxColorBoxBoundaryOffset} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['x', 'y']


class DxColorBoxButton(External):
    imports = {"import {DxButton as DxColorBoxButton} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxColorBoxCollision(External):
    imports = {"import {DxCollision as DxColorBoxCollision} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['x', 'y']


class DxColorBoxDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxColorBoxDropDownOptions} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxColorBoxFrom(External):
    imports = {"import {DxFrom as DxColorBoxFrom} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxColorBoxHide(External):
    imports = {"import {DxHide as DxColorBoxHide} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxColorBoxMy(External):
    imports = {"import {DxMy as DxColorBoxMy} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['x', 'y']


class DxColorBoxOffset(External):
    imports = {"import {DxOffset as DxColorBoxOffset} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['x', 'y']


class DxColorBoxOptions(External):
    imports = {"import {DxOptions as DxColorBoxOptions} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxColorBoxPosition(External):
    imports = {"import {DxPosition as DxColorBoxPosition} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxColorBoxShow(External):
    imports = {"import {DxShow as DxColorBoxShow} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxColorBoxTo(External):
    imports = {"import {DxTo as DxColorBoxTo} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxColorBoxToolbarItem(External):
    imports = {"import {DxToolbarItem as DxColorBoxToolbarItem} from 'devextreme-vue/color-box'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



