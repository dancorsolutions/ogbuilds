# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxGantt', 'DxGanttColumn', 'DxGanttColumnHeaderFilter', 'DxGanttColumnHeaderFilterSearch',
 'DxGanttContextMenu', 'DxGanttContextMenuItem', 'DxGanttDependencies', 'DxGanttEditing',
 'DxGanttFilterRow', 'DxGanttFormat', 'DxGanttHeaderFilter', 'DxGanttHeaderFilterSearch',
 'DxGanttItem', 'DxGanttOperationDescriptions', 'DxGanttResourceAssignments', 'DxGanttResources',
 'DxGanttScaleTypeRange', 'DxGanttSearch', 'DxGanttSorting', 'DxGanttStripLine', 'DxGanttTasks',
 'DxGanttTexts', 'DxGanttToolbar', 'DxGanttToolbarItem', 'DxGanttValidation']

common_attrs = ['key']


class DxGantt(External):
    imports = {"import DxGantt from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowSelection', 'columns',
        'contextMenu', 'dependencies', 'disabled', 'editing', 'elementAttr',
        'endDateRange', 'filterRow', 'firstDayOfWeek', 'focusStateEnabled',
        'headerFilter', 'height', 'hint', 'hoverStateEnabled', 'onContentReady',
        'onContextMenuPreparing', 'onCustomCommand', 'onDependencyDeleted',
        'onDependencyDeleting', 'onDependencyInserted', 'onDependencyInserting',
        'onDisposing', 'onInitialized', 'onOptionChanged', 'onResourceAssigned',
        'onResourceAssigning', 'onResourceDeleted', 'onResourceDeleting',
        'onResourceInserted', 'onResourceInserting',
        'onResourceManagerDialogShowing', 'onResourceUnassigned',
        'onResourceUnassigning', 'onScaleCellPrepared', 'onSelectionChanged',
        'onTaskClick', 'onTaskDblClick', 'onTaskDeleted', 'onTaskDeleting',
        'onTaskEditDialogShowing', 'onTaskInserted', 'onTaskInserting',
        'onTaskMoving', 'onTaskUpdated', 'onTaskUpdating',
        'resourceAssignments', 'resources', 'rootValue', 'scaleType',
        'scaleTypeRange', 'selectedRowKey', 'showDependencies', 'showResources',
        'showRowLines', 'sorting', 'startDateRange', 'stripLines', 'tabIndex',
        'taskContentTemplate', 'taskListWidth',
        'taskProgressTooltipContentTemplate', 'tasks',
        'taskTimeTooltipContentTemplate', 'taskTitlePosition',
        'taskTooltipContentTemplate', 'toolbar', 'validation', 'visible',
        'width']


class DxGanttColumn(External):
    imports = {"import {DxColumn as DxGanttColumn} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['alignment', 'allowFiltering', 'allowHeaderFiltering', 'allowSorting',
        'calculateCellValue', 'calculateDisplayValue',
        'calculateFilterExpression', 'calculateSortValue', 'caption',
        'cellTemplate', 'cssClass', 'customizeText', 'dataField', 'dataType',
        'encodeHtml', 'falseText', 'filterOperations', 'filterType',
        'filterValue', 'filterValues', 'format', 'headerCellTemplate',
        'headerFilter', 'minWidth', 'selectedFilterOperation', 'sortIndex',
        'sortingMethod', 'sortOrder', 'trueText', 'visible', 'visibleIndex',
        'width']


class DxGanttColumnHeaderFilter(External):
    imports = {"import {DxColumnHeaderFilter as DxGanttColumnHeaderFilter} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'dataSource', 'groupInterval',
        'height', 'search', 'searchMode', 'width']


class DxGanttColumnHeaderFilterSearch(External):
    imports = {"import {DxColumnHeaderFilterSearch as DxGanttColumnHeaderFilterSearch} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'searchExpr', 'timeout']


class DxGanttContextMenu(External):
    imports = {"import {DxContextMenu as DxGanttContextMenu} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['enabled', 'items']


class DxGanttContextMenuItem(External):
    imports = {"import {DxContextMenuItem as DxGanttContextMenuItem} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'disabled', 'icon', 'items', 'name',
        'selectable', 'selected', 'template', 'text', 'visible']


class DxGanttDependencies(External):
    imports = {"import {DxDependencies as DxGanttDependencies} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['dataSource', 'keyExpr', 'predecessorIdExpr', 'successorIdExpr', 'typeExpr']


class DxGanttEditing(External):
    imports = {"import {DxEditing as DxGanttEditing} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['allowDependencyAdding', 'allowDependencyDeleting',
        'allowResourceAdding', 'allowResourceDeleting', 'allowResourceUpdating',
        'allowTaskAdding', 'allowTaskDeleting', 'allowTaskResourceUpdating',
        'allowTaskUpdating', 'enabled']


class DxGanttFilterRow(External):
    imports = {"import {DxFilterRow as DxGanttFilterRow} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['betweenEndText', 'betweenStartText', 'operationDescriptions',
        'resetOperationText', 'showAllText', 'showOperationChooser', 'visible']


class DxGanttFormat(External):
    imports = {"import {DxFormat as DxGanttFormat} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxGanttHeaderFilter(External):
    imports = {"import {DxGanttHeaderFilter as DxGanttHeaderFilter} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'height', 'search', 'searchTimeout',
        'texts', 'visible', 'width']


class DxGanttHeaderFilterSearch(External):
    imports = {"import {DxGanttHeaderFilterSearch as DxGanttHeaderFilterSearch} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'timeout']


class DxGanttItem(External):
    imports = {"import {DxItem as DxGanttItem} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'cssClass', 'disabled', 'html',
        'icon', 'items', 'locateInMenu', 'location', 'menuItemTemplate', 'name',
        'options', 'selectable', 'selected', 'showText', 'template', 'text',
        'visible', 'widget']


class DxGanttOperationDescriptions(External):
    imports = {"import {DxOperationDescriptions as DxGanttOperationDescriptions} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['between', 'contains', 'endsWith', 'equal', 'greaterThan',
        'greaterThanOrEqual', 'lessThan', 'lessThanOrEqual', 'notContains',
        'notEqual', 'startsWith']


class DxGanttResourceAssignments(External):
    imports = {"import {DxResourceAssignments as DxGanttResourceAssignments} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['dataSource', 'keyExpr', 'resourceIdExpr', 'taskIdExpr']


class DxGanttResources(External):
    imports = {"import {DxResources as DxGanttResources} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['colorExpr', 'dataSource', 'keyExpr', 'textExpr']


class DxGanttScaleTypeRange(External):
    imports = {"import {DxScaleTypeRange as DxGanttScaleTypeRange} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['max', 'min']


class DxGanttSearch(External):
    imports = {"import {DxSearch as DxGanttSearch} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'searchExpr', 'timeout']


class DxGanttSorting(External):
    imports = {"import {DxSorting as DxGanttSorting} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['ascendingText', 'clearText', 'descendingText', 'mode', 'showSortIndexes']


class DxGanttStripLine(External):
    imports = {"import {DxStripLine as DxGanttStripLine} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['cssClass', 'end', 'start', 'title']


class DxGanttTasks(External):
    imports = {"import {DxTasks as DxGanttTasks} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['colorExpr', 'dataSource', 'endExpr', 'keyExpr', 'parentIdExpr',
        'progressExpr', 'startExpr', 'titleExpr']


class DxGanttTexts(External):
    imports = {"import {DxTexts as DxGanttTexts} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['cancel', 'emptyValue', 'ok']


class DxGanttToolbar(External):
    imports = {"import {DxToolbar as DxGanttToolbar} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['items']


class DxGanttToolbarItem(External):
    imports = {"import {DxToolbarItem as DxGanttToolbarItem} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'name', 'options', 'showText', 'template', 'text',
        'visible', 'widget']


class DxGanttValidation(External):
    imports = {"import {DxValidation as DxGanttValidation} from 'devextreme-vue/gantt'"}
    attrs = common_attrs + ['autoUpdateParentTasks', 'enablePredecessorGap', 'validateDependencies']



