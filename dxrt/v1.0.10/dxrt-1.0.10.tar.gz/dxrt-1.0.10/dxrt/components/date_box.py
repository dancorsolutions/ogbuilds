# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDateBox', 'DxDateBoxAnimation', 'DxDateBoxAt', 'DxDateBoxBoundaryOffset', 'DxDateBoxButton',
 'DxDateBoxCalendarOptions', 'DxDateBoxCollision', 'DxDateBoxDisplayFormat',
 'DxDateBoxDropDownOptions', 'DxDateBoxFrom', 'DxDateBoxHide', 'DxDateBoxMy', 'DxDateBoxOffset',
 'DxDateBoxOptions', 'DxDateBoxPosition', 'DxDateBoxShow', 'DxDateBoxTo', 'DxDateBoxToolbarItem']

common_attrs = ['key']


class DxDateBox(External):
    imports = {"import DxDateBox from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['acceptCustomValue', 'accessKey', 'activeStateEnabled',
        'adaptivityEnabled', 'applyButtonText', 'applyValueMode', 'buttons',
        'calendarOptions', 'cancelButtonText', 'dateOutOfRangeMessage',
        'dateSerializationFormat', 'deferRendering', 'disabled',
        'disabledDates', 'displayFormat', 'dropDownButtonTemplate',
        'dropDownOptions', 'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'inputAttr', 'interval', 'invalidDateMessage',
        'isDirty', 'isValid', 'label', 'labelMode', 'max', 'maxLength', 'min',
        'name', 'onChange', 'onClosed', 'onContentReady', 'onCopy', 'onCut',
        'onDisposing', 'onEnterKey', 'onFocusIn', 'onFocusOut', 'onInitialized',
        'onInput', 'onKeyDown', 'onKeyUp', 'onOpened', 'onOptionChanged',
        'onPaste', 'onValueChanged', 'opened', 'openOnFieldClick', 'pickerType',
        'placeholder', 'readOnly', 'rtlEnabled', 'showAnalogClock',
        'showClearButton', 'showDropDownButton', 'spellcheck', 'stylingMode',
        'tabIndex', 'text', 'todayButtonText', 'type', 'useMaskBehavior',
        'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'visible', 'width', 'modelValue']


class DxDateBoxAnimation(External):
    imports = {"import {DxAnimation as DxDateBoxAnimation} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['hide', 'show']


class DxDateBoxAt(External):
    imports = {"import {DxAt as DxDateBoxAt} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateBoxBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxDateBoxBoundaryOffset} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateBoxButton(External):
    imports = {"import {DxButton as DxDateBoxButton} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxDateBoxCalendarOptions(External):
    imports = {"import {DxCalendarOptions as DxDateBoxCalendarOptions} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'cellTemplate',
        'dateSerializationFormat', 'disabled', 'disabledDates', 'elementAttr',
        'firstDayOfWeek', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'isDirty', 'isValid', 'max', 'maxZoomLevel', 'min',
        'minZoomLevel', 'name', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'readOnly', 'rtlEnabled',
        'selectionMode', 'selectWeekOnClick', 'showTodayButton',
        'showWeekNumbers', 'tabIndex', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'visible', 'weekNumberRule', 'width',
        'zoomLevel']


class DxDateBoxCollision(External):
    imports = {"import {DxCollision as DxDateBoxCollision} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateBoxDisplayFormat(External):
    imports = {"import {DxDisplayFormat as DxDateBoxDisplayFormat} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxDateBoxDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxDateBoxDropDownOptions} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'deferRendering', 'disabled',
        'dragAndResizeArea', 'dragEnabled', 'dragOutsideBoundary',
        'enableBodyScroll', 'focusStateEnabled', 'fullScreen', 'height',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onResize', 'onResizeEnd', 'onResizeStart',
        'onShowing', 'onShown', 'onTitleRendered', 'position', 'resizeEnabled',
        'restorePosition', 'rtlEnabled', 'shading', 'shadingColor',
        'showCloseButton', 'showTitle', 'tabIndex', 'title', 'titleTemplate',
        'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxDateBoxFrom(External):
    imports = {"import {DxFrom as DxDateBoxFrom} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDateBoxHide(External):
    imports = {"import {DxHide as DxDateBoxHide} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDateBoxMy(External):
    imports = {"import {DxMy as DxDateBoxMy} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateBoxOffset(External):
    imports = {"import {DxOffset as DxDateBoxOffset} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateBoxOptions(External):
    imports = {"import {DxOptions as DxDateBoxOptions} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxDateBoxPosition(External):
    imports = {"import {DxPosition as DxDateBoxPosition} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxDateBoxShow(External):
    imports = {"import {DxShow as DxDateBoxShow} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDateBoxTo(External):
    imports = {"import {DxTo as DxDateBoxTo} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDateBoxToolbarItem(External):
    imports = {"import {DxToolbarItem as DxDateBoxToolbarItem} from 'devextreme-vue/date-box'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



