# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSplitter', 'DxSplitterItem']

common_attrs = ['key']


class DxSplitter(External):
    imports = {"import DxSplitter from 'devextreme-vue/splitter'"}
    attrs = common_attrs + ['allowKeyboardNavigation', 'dataSource', 'disabled', 'elementAttr',
        'height', 'hoverStateEnabled', 'items', 'itemTemplate',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemCollapsed', 'onItemContextMenu', 'onItemExpanded',
        'onItemRendered', 'onOptionChanged', 'onResize', 'onResizeEnd',
        'onResizeStart', 'orientation', 'rtlEnabled', 'separatorSize',
        'visible', 'width']


class DxSplitterItem(External):
    imports = {"import {DxItem as DxSplitterItem} from 'devextreme-vue/splitter'"}
    attrs = common_attrs + ['collapsed', 'collapsedSize', 'collapsible', 'maxSize', 'minSize',
        'resizable', 'size', 'splitter', 'template', 'text', 'visible']



