# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxProgressBar']

common_attrs = ['key']


class DxProgressBar(External):
    imports = {"import DxProgressBar from 'devextreme-vue/progress-bar'"}
    attrs = common_attrs + ['disabled', 'elementAttr', 'height', 'hint', 'hoverStateEnabled',
        'isDirty', 'isValid', 'max', 'min', 'onComplete', 'onContentReady',
        'onDisposing', 'onInitialized', 'onOptionChanged', 'onValueChanged',
        'readOnly', 'rtlEnabled', 'showStatus', 'statusFormat',
        'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value', 'visible',
        'width']



