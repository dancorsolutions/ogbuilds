# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxToolbar', 'DxToolbarItem']

common_attrs = ['key']


class DxToolbar(External):
    imports = {"import DxToolbar from 'devextreme-vue/toolbar'"}
    attrs = common_attrs + ['dataSource', 'disabled', 'elementAttr', 'hint', 'hoverStateEnabled',
        'itemHoldTimeout', 'items', 'itemTemplate', 'menuItemTemplate',
        'multiline', 'noDataText', 'onContentReady', 'onDisposing',
        'onInitialized', 'onItemClick', 'onItemContextMenu', 'onItemHold',
        'onItemRendered', 'onOptionChanged', 'rtlEnabled', 'visible', 'width']


class DxToolbarItem(External):
    imports = {"import {DxItem as DxToolbarItem} from 'devextreme-vue/toolbar'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'visible', 'widget']



