# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSelectBox', 'DxSelectBoxAnimation', 'DxSelectBoxAt', 'DxSelectBoxBoundaryOffset',
 'DxSelectBoxButton', 'DxSelectBoxCollision', 'DxSelectBoxDropDownOptions', 'DxSelectBoxFrom',
 'DxSelectBoxHide', 'DxSelectBoxItem', 'DxSelectBoxMy', 'DxSelectBoxOffset', 'DxSelectBoxOptions',
 'DxSelectBoxPosition', 'DxSelectBoxShow', 'DxSelectBoxTo', 'DxSelectBoxToolbarItem']

common_attrs = ['key']


class DxSelectBox(External):
    imports = {"import DxSelectBox from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['acceptCustomValue', 'accessKey', 'activeStateEnabled', 'buttons',
        'customItemCreateEvent', 'dataSource', 'deferRendering', 'disabled',
        'displayExpr', 'displayValue', 'dropDownButtonTemplate',
        'dropDownOptions', 'elementAttr', 'fieldTemplate', 'focusStateEnabled',
        'grouped', 'groupTemplate', 'height', 'hint', 'hoverStateEnabled',
        'inputAttr', 'isDirty', 'isValid', 'items', 'itemTemplate', 'label',
        'labelMode', 'maxLength', 'minSearchLength', 'name', 'noDataText',
        'onChange', 'onClosed', 'onContentReady', 'onCopy',
        'onCustomItemCreating', 'onCut', 'onDisposing', 'onEnterKey',
        'onFocusIn', 'onFocusOut', 'onInitialized', 'onInput', 'onItemClick',
        'onKeyDown', 'onKeyUp', 'onOpened', 'onOptionChanged', 'onPaste',
        'onSelectionChanged', 'onValueChanged', 'opened', 'openOnFieldClick',
        'placeholder', 'readOnly', 'rtlEnabled', 'searchEnabled', 'searchExpr',
        'searchMode', 'searchTimeout', 'selectedItem', 'showClearButton',
        'showDataBeforeSearch', 'showDropDownButton', 'showSelectionControls',
        'spellcheck', 'stylingMode', 'tabIndex', 'text', 'useItemTextAsTitle',
        'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'valueExpr', 'visible', 'width', 'wrapItemText',
        'modelValue']


class DxSelectBoxAnimation(External):
    imports = {"import {DxAnimation as DxSelectBoxAnimation} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['hide', 'show']


class DxSelectBoxAt(External):
    imports = {"import {DxAt as DxSelectBoxAt} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['x', 'y']


class DxSelectBoxBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxSelectBoxBoundaryOffset} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['x', 'y']


class DxSelectBoxButton(External):
    imports = {"import {DxButton as DxSelectBoxButton} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxSelectBoxCollision(External):
    imports = {"import {DxCollision as DxSelectBoxCollision} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['x', 'y']


class DxSelectBoxDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxSelectBoxDropDownOptions} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'deferRendering', 'disabled',
        'dragAndResizeArea', 'dragEnabled', 'dragOutsideBoundary',
        'enableBodyScroll', 'focusStateEnabled', 'fullScreen', 'height',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onResize', 'onResizeEnd', 'onResizeStart',
        'onShowing', 'onShown', 'onTitleRendered', 'position', 'resizeEnabled',
        'restorePosition', 'rtlEnabled', 'shading', 'shadingColor',
        'showCloseButton', 'showTitle', 'tabIndex', 'title', 'titleTemplate',
        'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxSelectBoxFrom(External):
    imports = {"import {DxFrom as DxSelectBoxFrom} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxSelectBoxHide(External):
    imports = {"import {DxHide as DxSelectBoxHide} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxSelectBoxItem(External):
    imports = {"import {DxItem as DxSelectBoxItem} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text', 'visible']


class DxSelectBoxMy(External):
    imports = {"import {DxMy as DxSelectBoxMy} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['x', 'y']


class DxSelectBoxOffset(External):
    imports = {"import {DxOffset as DxSelectBoxOffset} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['x', 'y']


class DxSelectBoxOptions(External):
    imports = {"import {DxOptions as DxSelectBoxOptions} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxSelectBoxPosition(External):
    imports = {"import {DxPosition as DxSelectBoxPosition} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxSelectBoxShow(External):
    imports = {"import {DxShow as DxSelectBoxShow} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxSelectBoxTo(External):
    imports = {"import {DxTo as DxSelectBoxTo} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxSelectBoxToolbarItem(External):
    imports = {"import {DxToolbarItem as DxSelectBoxToolbarItem} from 'devextreme-vue/select-box'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



