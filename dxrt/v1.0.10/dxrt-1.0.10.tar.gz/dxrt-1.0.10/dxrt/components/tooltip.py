# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTooltip', 'DxTooltipAnimation', 'DxTooltipAt', 'DxTooltipBoundaryOffset', 'DxTooltipCollision',
 'DxTooltipFrom', 'DxTooltipHide', 'DxTooltipHideEvent', 'DxTooltipMy', 'DxTooltipOffset',
 'DxTooltipPosition', 'DxTooltipShow', 'DxTooltipShowEvent', 'DxTooltipTo']

common_attrs = ['key']


class DxTooltip(External):
    imports = {"import DxTooltip from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['animation', 'closeOnOutsideClick', 'container', 'contentTemplate',
        'deferRendering', 'disabled', 'height', 'hideEvent',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onShowing', 'onShown', 'position', 'rtlEnabled',
        'shading', 'shadingColor', 'showEvent', 'target', 'visible', 'width',
        'wrapperAttr']


class DxTooltipAnimation(External):
    imports = {"import {DxAnimation as DxTooltipAnimation} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['hide', 'show']


class DxTooltipAt(External):
    imports = {"import {DxAt as DxTooltipAt} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['x', 'y']


class DxTooltipBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxTooltipBoundaryOffset} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['x', 'y']


class DxTooltipCollision(External):
    imports = {"import {DxCollision as DxTooltipCollision} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['x', 'y']


class DxTooltipFrom(External):
    imports = {"import {DxFrom as DxTooltipFrom} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxTooltipHide(External):
    imports = {"import {DxHide as DxTooltipHide} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxTooltipHideEvent(External):
    imports = {"import {DxHideEvent as DxTooltipHideEvent} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['delay', 'name']


class DxTooltipMy(External):
    imports = {"import {DxMy as DxTooltipMy} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['x', 'y']


class DxTooltipOffset(External):
    imports = {"import {DxOffset as DxTooltipOffset} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['x', 'y']


class DxTooltipPosition(External):
    imports = {"import {DxPosition as DxTooltipPosition} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxTooltipShow(External):
    imports = {"import {DxShow as DxTooltipShow} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxTooltipShowEvent(External):
    imports = {"import {DxShowEvent as DxTooltipShowEvent} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['delay', 'name']


class DxTooltipTo(External):
    imports = {"import {DxTo as DxTooltipTo} from 'devextreme-vue/tooltip'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']



