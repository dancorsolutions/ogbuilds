# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxButtonGroup', 'DxButtonGroupItem']

common_attrs = ['key']


class DxButtonGroup(External):
    imports = {"import DxButtonGroup from 'devextreme-vue/button-group'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'buttonTemplate', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'items', 'keyExpr', 'onContentReady',
        'onDisposing', 'onInitialized', 'onItemClick', 'onOptionChanged',
        'onSelectionChanged', 'rtlEnabled', 'selectedItemKeys', 'selectedItems',
        'selectionMode', 'stylingMode', 'tabIndex', 'visible', 'width']


class DxButtonGroupItem(External):
    imports = {"import {DxItem as DxButtonGroupItem} from 'devextreme-vue/button-group'"}
    attrs = common_attrs + ['disabled', 'elementAttr', 'hint', 'icon', 'template', 'text', 'type',
        'visible']



