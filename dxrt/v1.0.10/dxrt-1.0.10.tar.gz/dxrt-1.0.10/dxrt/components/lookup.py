# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxLookup', 'DxLookupAnimation', 'DxLookupAt', 'DxLookupBoundaryOffset', 'DxLookupCollision',
 'DxLookupDropDownOptions', 'DxLookupFrom', 'DxLookupHide', 'DxLookupHideEvent', 'DxLookupItem',
 'DxLookupMy', 'DxLookupOffset', 'DxLookupPosition', 'DxLookupShow', 'DxLookupShowEvent',
 'DxLookupTo', 'DxLookupToolbarItem']

common_attrs = ['key']


class DxLookup(External):
    imports = {"import DxLookup from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'applyButtonText', 'applyValueMode',
        'cancelButtonText', 'cleanSearchOnOpening', 'clearButtonText',
        'dataSource', 'deferRendering', 'disabled', 'displayExpr',
        'displayValue', 'dropDownCentered', 'dropDownOptions', 'elementAttr',
        'fieldTemplate', 'focusStateEnabled', 'fullScreen', 'grouped',
        'groupTemplate', 'height', 'hint', 'hoverStateEnabled', 'inputAttr',
        'isDirty', 'isValid', 'items', 'itemTemplate', 'label', 'labelMode',
        'minSearchLength', 'name', 'nextButtonText', 'noDataText', 'onClosed',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onOpened', 'onOptionChanged', 'onPageLoading', 'onPullRefresh',
        'onScroll', 'onSelectionChanged', 'onValueChanged', 'opened',
        'pageLoadingText', 'pageLoadMode', 'placeholder', 'pulledDownText',
        'pullingDownText', 'pullRefreshEnabled', 'refreshingText', 'rtlEnabled',
        'searchEnabled', 'searchExpr', 'searchMode', 'searchPlaceholder',
        'searchStartEvent', 'searchTimeout', 'selectedItem', 'showCancelButton',
        'showClearButton', 'showDataBeforeSearch', 'stylingMode', 'tabIndex',
        'text', 'useItemTextAsTitle', 'useNativeScrolling', 'usePopover',
        'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'valueExpr', 'visible', 'width', 'wrapItemText',
        'modelValue']


class DxLookupAnimation(External):
    imports = {"import {DxAnimation as DxLookupAnimation} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['hide', 'show']


class DxLookupAt(External):
    imports = {"import {DxAt as DxLookupAt} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['x', 'y']


class DxLookupBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxLookupBoundaryOffset} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['x', 'y']


class DxLookupCollision(External):
    imports = {"import {DxCollision as DxLookupCollision} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['x', 'y']


class DxLookupDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxLookupDropDownOptions} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['animation', 'bindingOptions', 'closeOnOutsideClick', 'container',
        'contentTemplate', 'deferRendering', 'disabled', 'enableBodyScroll',
        'height', 'hideEvent', 'hideOnOutsideClick', 'hideOnParentScroll',
        'hint', 'hoverStateEnabled', 'maxHeight', 'maxWidth', 'minHeight',
        'minWidth', 'onContentReady', 'onDisposing', 'onHidden', 'onHiding',
        'onInitialized', 'onOptionChanged', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'rtlEnabled', 'shading', 'shadingColor',
        'showCloseButton', 'showEvent', 'showTitle', 'target', 'title',
        'titleTemplate', 'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxLookupFrom(External):
    imports = {"import {DxFrom as DxLookupFrom} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxLookupHide(External):
    imports = {"import {DxHide as DxLookupHide} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxLookupHideEvent(External):
    imports = {"import {DxHideEvent as DxLookupHideEvent} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['delay', 'name']


class DxLookupItem(External):
    imports = {"import {DxItem as DxLookupItem} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text', 'visible']


class DxLookupMy(External):
    imports = {"import {DxMy as DxLookupMy} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['x', 'y']


class DxLookupOffset(External):
    imports = {"import {DxOffset as DxLookupOffset} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['x', 'y']


class DxLookupPosition(External):
    imports = {"import {DxPosition as DxLookupPosition} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxLookupShow(External):
    imports = {"import {DxShow as DxLookupShow} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxLookupShowEvent(External):
    imports = {"import {DxShowEvent as DxLookupShowEvent} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['delay', 'name']


class DxLookupTo(External):
    imports = {"import {DxTo as DxLookupTo} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxLookupToolbarItem(External):
    imports = {"import {DxToolbarItem as DxLookupToolbarItem} from 'devextreme-vue/lookup'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



