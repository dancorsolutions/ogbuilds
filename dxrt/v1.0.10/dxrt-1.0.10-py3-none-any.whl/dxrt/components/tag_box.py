# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTagBox', 'DxTagBoxAnimation', 'DxTagBoxAt', 'DxTagBoxBoundaryOffset', 'DxTagBoxButton',
 'DxTagBoxCollision', 'DxTagBoxDropDownOptions', 'DxTagBoxFrom', 'DxTagBoxHide', 'DxTagBoxItem',
 'DxTagBoxMy', 'DxTagBoxOffset', 'DxTagBoxOptions', 'DxTagBoxPosition', 'DxTagBoxShow',
 'DxTagBoxTo', 'DxTagBoxToolbarItem']

common_attrs = ['key']


class DxTagBox(External):
    imports = {"import DxTagBox from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['acceptCustomValue', 'accessKey', 'activeStateEnabled',
        'applyValueMode', 'buttons', 'customItemCreateEvent', 'dataSource',
        'deferRendering', 'disabled', 'displayExpr', 'dropDownButtonTemplate',
        'dropDownOptions', 'elementAttr', 'fieldTemplate', 'focusStateEnabled',
        'grouped', 'groupTemplate', 'height', 'hideSelectedItems', 'hint',
        'hoverStateEnabled', 'inputAttr', 'isDirty', 'isValid', 'items',
        'itemTemplate', 'label', 'labelMode', 'maxDisplayedTags',
        'maxFilterQueryLength', 'maxLength', 'minSearchLength', 'multiline',
        'name', 'noDataText', 'onChange', 'onClosed', 'onContentReady',
        'onCustomItemCreating', 'onDisposing', 'onEnterKey', 'onFocusIn',
        'onFocusOut', 'onInitialized', 'onInput', 'onItemClick', 'onKeyDown',
        'onKeyUp', 'onMultiTagPreparing', 'onOpened', 'onOptionChanged',
        'onSelectAllValueChanged', 'onSelectionChanged', 'onValueChanged',
        'opened', 'openOnFieldClick', 'placeholder', 'readOnly', 'rtlEnabled',
        'searchEnabled', 'searchExpr', 'searchMode', 'searchTimeout',
        'selectAllMode', 'selectAllText', 'selectedItems', 'showClearButton',
        'showDataBeforeSearch', 'showDropDownButton', 'showMultiTagOnly',
        'showSelectionControls', 'stylingMode', 'tabIndex', 'tagTemplate',
        'text', 'useItemTextAsTitle', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'valueChangeEvent', 'valueExpr', 'visible',
        'width', 'wrapItemText', 'modelValue']


class DxTagBoxAnimation(External):
    imports = {"import {DxAnimation as DxTagBoxAnimation} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['hide', 'show']


class DxTagBoxAt(External):
    imports = {"import {DxAt as DxTagBoxAt} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['x', 'y']


class DxTagBoxBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxTagBoxBoundaryOffset} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['x', 'y']


class DxTagBoxButton(External):
    imports = {"import {DxButton as DxTagBoxButton} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxTagBoxCollision(External):
    imports = {"import {DxCollision as DxTagBoxCollision} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['x', 'y']


class DxTagBoxDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxTagBoxDropDownOptions} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'deferRendering', 'disabled',
        'dragAndResizeArea', 'dragEnabled', 'dragOutsideBoundary',
        'enableBodyScroll', 'focusStateEnabled', 'fullScreen', 'height',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onResize', 'onResizeEnd', 'onResizeStart',
        'onShowing', 'onShown', 'onTitleRendered', 'position', 'resizeEnabled',
        'restorePosition', 'rtlEnabled', 'shading', 'shadingColor',
        'showCloseButton', 'showTitle', 'tabIndex', 'title', 'titleTemplate',
        'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxTagBoxFrom(External):
    imports = {"import {DxFrom as DxTagBoxFrom} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxTagBoxHide(External):
    imports = {"import {DxHide as DxTagBoxHide} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxTagBoxItem(External):
    imports = {"import {DxItem as DxTagBoxItem} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text', 'visible']


class DxTagBoxMy(External):
    imports = {"import {DxMy as DxTagBoxMy} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['x', 'y']


class DxTagBoxOffset(External):
    imports = {"import {DxOffset as DxTagBoxOffset} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['x', 'y']


class DxTagBoxOptions(External):
    imports = {"import {DxOptions as DxTagBoxOptions} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxTagBoxPosition(External):
    imports = {"import {DxPosition as DxTagBoxPosition} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxTagBoxShow(External):
    imports = {"import {DxShow as DxTagBoxShow} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxTagBoxTo(External):
    imports = {"import {DxTo as DxTagBoxTo} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxTagBoxToolbarItem(External):
    imports = {"import {DxToolbarItem as DxTagBoxToolbarItem} from 'devextreme-vue/tag-box'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



