# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxPolarChart', 'DxPolarChartAdaptiveLayout', 'DxPolarChartAnimation', 'DxPolarChartAnnotation',
 'DxPolarChartAnnotationBorder', 'DxPolarChartArgumentAxis', 'DxPolarChartArgumentAxisMinorTick',
 'DxPolarChartArgumentAxisTick', 'DxPolarChartArgumentFormat', 'DxPolarChartAxisLabel',
 'DxPolarChartBorder', 'DxPolarChartColor', 'DxPolarChartCommonAnnotationSettings',
 'DxPolarChartCommonAxisSettings', 'DxPolarChartCommonAxisSettingsLabel',
 'DxPolarChartCommonAxisSettingsMinorTick', 'DxPolarChartCommonAxisSettingsTick',
 'DxPolarChartCommonSeriesSettings', 'DxPolarChartCommonSeriesSettingsHoverStyle',
 'DxPolarChartCommonSeriesSettingsLabel', 'DxPolarChartCommonSeriesSettingsSelectionStyle',
 'DxPolarChartConnector', 'DxPolarChartConstantLine', 'DxPolarChartConstantLineLabel',
 'DxPolarChartConstantLineStyle', 'DxPolarChartConstantLineStyleLabel',
 'DxPolarChartDataPrepareSettings', 'DxPolarChartExport', 'DxPolarChartFont', 'DxPolarChartFormat',
 'DxPolarChartGrid', 'DxPolarChartHatching', 'DxPolarChartHoverStyle', 'DxPolarChartImage',
 'DxPolarChartLabel', 'DxPolarChartLegend', 'DxPolarChartLegendTitle',
 'DxPolarChartLegendTitleSubtitle', 'DxPolarChartLength', 'DxPolarChartLoadingIndicator',
 'DxPolarChartMargin', 'DxPolarChartMinorGrid', 'DxPolarChartMinorTick',
 'DxPolarChartMinorTickInterval', 'DxPolarChartMinVisualRangeLength', 'DxPolarChartPoint',
 'DxPolarChartPointBorder', 'DxPolarChartPointHoverStyle', 'DxPolarChartPointSelectionStyle',
 'DxPolarChartTitle', 'DxPolarChartTitleSubtitle', 'DxPolarChartSelectionStyle',
 'DxPolarChartSeries', 'DxPolarChartSeriesBorder', 'DxPolarChartSeriesTemplate',
 'DxPolarChartShadow', 'DxPolarChartSize', 'DxPolarChartStrip', 'DxPolarChartStripLabel',
 'DxPolarChartStripStyle', 'DxPolarChartStripStyleLabel', 'DxPolarChartSubtitle',
 'DxPolarChartTick', 'DxPolarChartTickInterval', 'DxPolarChartTooltip', 'DxPolarChartTooltipBorder',
 'DxPolarChartValueAxis', 'DxPolarChartValueErrorBar', 'DxPolarChartVisualRange',
 'DxPolarChartWholeRange']

common_attrs = ['key']


class DxPolarChart(External):
    imports = {"import DxPolarChart from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['adaptiveLayout', 'animation', 'annotations', 'argumentAxis',
        'barGroupPadding', 'barGroupWidth', 'commonAnnotationSettings',
        'commonAxisSettings', 'commonSeriesSettings',
        'containerBackgroundColor', 'customizeAnnotation', 'customizeLabel',
        'customizePoint', 'dataPrepareSettings', 'dataSource', 'disabled',
        'elementAttr', 'export', 'legend', 'loadingIndicator', 'margin',
        'negativesAsZeroes', 'onArgumentAxisClick', 'onDisposing', 'onDone',
        'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onLegendClick',
        'onOptionChanged', 'onPointClick', 'onPointHoverChanged',
        'onPointSelectionChanged', 'onSeriesClick', 'onSeriesHoverChanged',
        'onSeriesSelectionChanged', 'onTooltipHidden', 'onTooltipShown',
        'onZoomEnd', 'onZoomStart', 'palette', 'paletteExtensionMode',
        'pathModified', 'pointSelectionMode', 'redrawOnResize',
        'resolveLabelOverlapping', 'rtlEnabled', 'series',
        'seriesSelectionMode', 'seriesTemplate', 'size', 'theme', 'title',
        'tooltip', 'useSpiderWeb', 'valueAxis']


class DxPolarChartAdaptiveLayout(External):
    imports = {"import {DxAdaptiveLayout as DxPolarChartAdaptiveLayout} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['height', 'keepLabels', 'width']


class DxPolarChartAnimation(External):
    imports = {"import {DxAnimation as DxPolarChartAnimation} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['duration', 'easing', 'enabled', 'maxPointCountSupported']


class DxPolarChartAnnotation(External):
    imports = {"import {DxAnnotation as DxPolarChartAnnotation} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['allowDragging', 'angle', 'argument', 'arrowLength', 'arrowWidth',
        'border', 'color', 'customizeTooltip', 'data', 'description', 'font',
        'height', 'image', 'name', 'offsetX', 'offsetY', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'radius', 'series', 'shadow',
        'template', 'text', 'textOverflow', 'tooltipEnabled', 'tooltipTemplate',
        'type', 'value', 'width', 'wordWrap', 'x', 'y']


class DxPolarChartAnnotationBorder(External):
    imports = {"import {DxAnnotationBorder as DxPolarChartAnnotationBorder} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxPolarChartArgumentAxis(External):
    imports = {"import {DxArgumentAxis as DxPolarChartArgumentAxis} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['allowDecimals', 'argumentType', 'axisDivisionFactor', 'categories',
        'color', 'constantLines', 'constantLineStyle',
        'discreteAxisDivisionMode', 'endOnTick', 'firstPointOnStartAngle',
        'grid', 'hoverMode', 'inverted', 'label', 'linearThreshold',
        'logarithmBase', 'minorGrid', 'minorTick', 'minorTickCount',
        'minorTickInterval', 'opacity', 'originValue', 'period', 'startAngle',
        'strips', 'stripStyle', 'tick', 'tickInterval', 'type', 'visible',
        'width']


class DxPolarChartArgumentAxisMinorTick(External):
    imports = {"import {DxArgumentAxisMinorTick as DxPolarChartArgumentAxisMinorTick} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'shift', 'visible', 'width']


class DxPolarChartArgumentAxisTick(External):
    imports = {"import {DxArgumentAxisTick as DxPolarChartArgumentAxisTick} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'shift', 'visible', 'width']


class DxPolarChartArgumentFormat(External):
    imports = {"import {DxArgumentFormat as DxPolarChartArgumentFormat} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxPolarChartAxisLabel(External):
    imports = {"import {DxAxisLabel as DxPolarChartAxisLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['customizeHint', 'customizeText', 'font', 'format', 'indentFromAxis',
        'overlappingBehavior', 'visible']


class DxPolarChartBorder(External):
    imports = {"import {DxBorder as DxPolarChartBorder} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxPolarChartColor(External):
    imports = {"import {DxColor as DxPolarChartColor} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['base', 'fillId']


class DxPolarChartCommonAnnotationSettings(External):
    imports = {"import {DxCommonAnnotationSettings as DxPolarChartCommonAnnotationSettings} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['allowDragging', 'angle', 'argument', 'arrowLength', 'arrowWidth',
        'border', 'color', 'customizeTooltip', 'data', 'description', 'font',
        'height', 'image', 'offsetX', 'offsetY', 'opacity', 'paddingLeftRight',
        'paddingTopBottom', 'radius', 'series', 'shadow', 'template', 'text',
        'textOverflow', 'tooltipEnabled', 'tooltipTemplate', 'type', 'value',
        'width', 'wordWrap', 'x', 'y']


class DxPolarChartCommonAxisSettings(External):
    imports = {"import {DxCommonAxisSettings as DxPolarChartCommonAxisSettings} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['allowDecimals', 'color', 'constantLineStyle',
        'discreteAxisDivisionMode', 'endOnTick', 'grid', 'inverted', 'label',
        'minorGrid', 'minorTick', 'opacity', 'stripStyle', 'tick', 'visible',
        'width']


class DxPolarChartCommonAxisSettingsLabel(External):
    imports = {"import {DxCommonAxisSettingsLabel as DxPolarChartCommonAxisSettingsLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'indentFromAxis', 'overlappingBehavior', 'visible']


class DxPolarChartCommonAxisSettingsMinorTick(External):
    imports = {"import {DxCommonAxisSettingsMinorTick as DxPolarChartCommonAxisSettingsMinorTick} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'visible', 'width']


class DxPolarChartCommonAxisSettingsTick(External):
    imports = {"import {DxCommonAxisSettingsTick as DxPolarChartCommonAxisSettingsTick} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'visible', 'width']


class DxPolarChartCommonSeriesSettings(External):
    imports = {"import {DxCommonSeriesSettings as DxPolarChartCommonSeriesSettings} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['area', 'argumentField', 'bar', 'barPadding', 'barWidth', 'border',
        'closed', 'color', 'dashStyle', 'hoverMode', 'hoverStyle',
        'ignoreEmptyPoints', 'label', 'line', 'maxLabelCount', 'minBarSize',
        'opacity', 'point', 'scatter', 'selectionMode', 'selectionStyle',
        'showInLegend', 'stack', 'stackedbar', 'tagField', 'type',
        'valueErrorBar', 'valueField', 'visible', 'width']


class DxPolarChartCommonSeriesSettingsHoverStyle(External):
    imports = {"import {DxCommonSeriesSettingsHoverStyle as DxPolarChartCommonSeriesSettingsHoverStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'width']


class DxPolarChartCommonSeriesSettingsLabel(External):
    imports = {"import {DxCommonSeriesSettingsLabel as DxPolarChartCommonSeriesSettingsLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeText', 'displayFormat', 'font', 'format', 'position',
        'rotationAngle', 'showForZeroValues', 'visible']


class DxPolarChartCommonSeriesSettingsSelectionStyle(External):
    imports = {"import {DxCommonSeriesSettingsSelectionStyle as DxPolarChartCommonSeriesSettingsSelectionStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'width']


class DxPolarChartConnector(External):
    imports = {"import {DxConnector as DxPolarChartConnector} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxPolarChartConstantLine(External):
    imports = {"import {DxConstantLine as DxPolarChartConstantLine} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'displayBehindSeries', 'extendAxis', 'label',
        'value', 'width']


class DxPolarChartConstantLineLabel(External):
    imports = {"import {DxConstantLineLabel as DxPolarChartConstantLineLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'text', 'visible']


class DxPolarChartConstantLineStyle(External):
    imports = {"import {DxConstantLineStyle as DxPolarChartConstantLineStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'label', 'width']


class DxPolarChartConstantLineStyleLabel(External):
    imports = {"import {DxConstantLineStyleLabel as DxPolarChartConstantLineStyleLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'visible']


class DxPolarChartDataPrepareSettings(External):
    imports = {"import {DxDataPrepareSettings as DxPolarChartDataPrepareSettings} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['checkTypeForAllData', 'convertToAxisDataType', 'sortingMethod']


class DxPolarChartExport(External):
    imports = {"import {DxExport as DxPolarChartExport} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxPolarChartFont(External):
    imports = {"import {DxFont as DxPolarChartFont} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxPolarChartFormat(External):
    imports = {"import {DxFormat as DxPolarChartFormat} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxPolarChartGrid(External):
    imports = {"import {DxGrid as DxPolarChartGrid} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'opacity', 'visible', 'width']


class DxPolarChartHatching(External):
    imports = {"import {DxHatching as DxPolarChartHatching} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['direction', 'opacity', 'step', 'width']


class DxPolarChartHoverStyle(External):
    imports = {"import {DxHoverStyle as DxPolarChartHoverStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'size', 'width']


class DxPolarChartImage(External):
    imports = {"import {DxImage as DxPolarChartImage} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxPolarChartLabel(External):
    imports = {"import {DxLabel as DxPolarChartLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeHint', 'customizeText', 'displayFormat', 'font', 'format',
        'indentFromAxis', 'overlappingBehavior', 'position', 'rotationAngle',
        'showForZeroValues', 'text', 'visible']


class DxPolarChartLegend(External):
    imports = {"import {DxLegend as DxPolarChartLegend} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'columnCount', 'columnItemSpacing',
        'customizeHint', 'customizeItems', 'customizeText', 'font',
        'horizontalAlignment', 'hoverMode', 'itemsAlignment',
        'itemTextPosition', 'margin', 'markerSize', 'markerTemplate',
        'orientation', 'paddingLeftRight', 'paddingTopBottom', 'rowCount',
        'rowItemSpacing', 'title', 'verticalAlignment', 'visible']


class DxPolarChartLegendTitle(External):
    imports = {"import {DxLegendTitle as DxPolarChartLegendTitle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'verticalAlignment']


class DxPolarChartLegendTitleSubtitle(External):
    imports = {"import {DxLegendTitleSubtitle as DxPolarChartLegendTitleSubtitle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'offset', 'text']


class DxPolarChartLength(External):
    imports = {"import {DxLength as DxPolarChartLength} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxPolarChartLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxPolarChartLoadingIndicator} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxPolarChartMargin(External):
    imports = {"import {DxMargin as DxPolarChartMargin} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxPolarChartMinorGrid(External):
    imports = {"import {DxMinorGrid as DxPolarChartMinorGrid} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'opacity', 'visible', 'width']


class DxPolarChartMinorTick(External):
    imports = {"import {DxMinorTick as DxPolarChartMinorTick} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'shift', 'visible', 'width']


class DxPolarChartMinorTickInterval(External):
    imports = {"import {DxMinorTickInterval as DxPolarChartMinorTickInterval} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxPolarChartMinVisualRangeLength(External):
    imports = {"import {DxMinVisualRangeLength as DxPolarChartMinVisualRangeLength} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxPolarChartPoint(External):
    imports = {"import {DxPoint as DxPolarChartPoint} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'hoverMode', 'hoverStyle', 'image', 'selectionMode',
        'selectionStyle', 'size', 'symbol', 'visible']


class DxPolarChartPointBorder(External):
    imports = {"import {DxPointBorder as DxPolarChartPointBorder} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxPolarChartPointHoverStyle(External):
    imports = {"import {DxPointHoverStyle as DxPolarChartPointHoverStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'size']


class DxPolarChartPointSelectionStyle(External):
    imports = {"import {DxPointSelectionStyle as DxPolarChartPointSelectionStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'size']


class DxPolarChartTitle(External):
    imports = {"import {DxPolarChartTitle as DxPolarChartTitle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxPolarChartTitleSubtitle(External):
    imports = {"import {DxPolarChartTitleSubtitle as DxPolarChartTitleSubtitle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxPolarChartSelectionStyle(External):
    imports = {"import {DxSelectionStyle as DxPolarChartSelectionStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'size', 'width']


class DxPolarChartSeries(External):
    imports = {"import {DxSeries as DxPolarChartSeries} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['argumentField', 'barPadding', 'barWidth', 'border', 'closed', 'color',
        'dashStyle', 'hoverMode', 'hoverStyle', 'ignoreEmptyPoints', 'label',
        'maxLabelCount', 'minBarSize', 'name', 'opacity', 'point',
        'selectionMode', 'selectionStyle', 'showInLegend', 'stack', 'tag',
        'tagField', 'type', 'valueErrorBar', 'valueField', 'visible', 'width']


class DxPolarChartSeriesBorder(External):
    imports = {"import {DxSeriesBorder as DxPolarChartSeriesBorder} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'visible', 'width']


class DxPolarChartSeriesTemplate(External):
    imports = {"import {DxSeriesTemplate as DxPolarChartSeriesTemplate} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['customizeSeries', 'nameField']


class DxPolarChartShadow(External):
    imports = {"import {DxShadow as DxPolarChartShadow} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxPolarChartSize(External):
    imports = {"import {DxSize as DxPolarChartSize} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['height', 'width']


class DxPolarChartStrip(External):
    imports = {"import {DxStrip as DxPolarChartStrip} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'endValue', 'label', 'startValue']


class DxPolarChartStripLabel(External):
    imports = {"import {DxStripLabel as DxPolarChartStripLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'text']


class DxPolarChartStripStyle(External):
    imports = {"import {DxStripStyle as DxPolarChartStripStyle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['label']


class DxPolarChartStripStyleLabel(External):
    imports = {"import {DxStripStyleLabel as DxPolarChartStripStyleLabel} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font']


class DxPolarChartSubtitle(External):
    imports = {"import {DxSubtitle as DxPolarChartSubtitle} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxPolarChartTick(External):
    imports = {"import {DxTick as DxPolarChartTick} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'shift', 'visible', 'width']


class DxPolarChartTickInterval(External):
    imports = {"import {DxTickInterval as DxPolarChartTickInterval} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxPolarChartTooltip(External):
    imports = {"import {DxTooltip as DxPolarChartTooltip} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['argumentFormat', 'arrowLength', 'border', 'color', 'container',
        'contentTemplate', 'cornerRadius', 'customizeTooltip', 'enabled',
        'font', 'format', 'interactive', 'opacity', 'paddingLeftRight',
        'paddingTopBottom', 'shadow', 'shared', 'zIndex']


class DxPolarChartTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxPolarChartTooltipBorder} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxPolarChartValueAxis(External):
    imports = {"import {DxValueAxis as DxPolarChartValueAxis} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['allowDecimals', 'axisDivisionFactor', 'categories', 'color',
        'constantLines', 'constantLineStyle', 'discreteAxisDivisionMode',
        'endOnTick', 'grid', 'inverted', 'label', 'linearThreshold',
        'logarithmBase', 'maxValueMargin', 'minorGrid', 'minorTick',
        'minorTickCount', 'minorTickInterval', 'minValueMargin',
        'minVisualRangeLength', 'opacity', 'showZero', 'strips', 'stripStyle',
        'tick', 'tickInterval', 'type', 'valueMarginsEnabled', 'valueType',
        'visible', 'visualRange', 'visualRangeUpdateMode', 'wholeRange',
        'width']


class DxPolarChartValueErrorBar(External):
    imports = {"import {DxValueErrorBar as DxPolarChartValueErrorBar} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['color', 'displayMode', 'edgeLength', 'highValueField', 'lineWidth',
        'lowValueField', 'opacity', 'type', 'value']


class DxPolarChartVisualRange(External):
    imports = {"import {DxVisualRange as DxPolarChartVisualRange} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['endValue', 'length', 'startValue']


class DxPolarChartWholeRange(External):
    imports = {"import {DxWholeRange as DxPolarChartWholeRange} from 'devextreme-vue/polar-chart'"}
    attrs = common_attrs + ['endValue', 'length', 'startValue']



