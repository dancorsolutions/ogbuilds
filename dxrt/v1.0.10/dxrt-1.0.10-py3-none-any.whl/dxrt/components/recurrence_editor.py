# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxRecurrenceEditor']

common_attrs = ['key']


class DxRecurrenceEditor(External):
    imports = {"import DxRecurrenceEditor from 'devextreme-vue/recurrence-editor'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'isDirty',
        'isValid', 'onContentReady', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'readOnly', 'rtlEnabled',
        'tabIndex', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'visible', 'width', 'modelValue']



