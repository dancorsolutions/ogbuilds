# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTileView', 'DxTileViewItem']

common_attrs = ['key']


class DxTileView(External):
    imports = {"import DxTileView from 'devextreme-vue/tile-view'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'baseItemHeight', 'baseItemWidth',
        'dataSource', 'direction', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'itemHoldTimeout', 'itemMargin', 'items', 'itemTemplate', 'noDataText',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered', 'onOptionChanged',
        'rtlEnabled', 'showScrollbar', 'tabIndex', 'visible', 'width']


class DxTileViewItem(External):
    imports = {"import {DxItem as DxTileViewItem} from 'devextreme-vue/tile-view'"}
    attrs = common_attrs + ['disabled', 'heightRatio', 'html', 'template', 'text', 'visible', 'widthRatio']



