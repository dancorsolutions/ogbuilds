# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTextBox', 'DxTextBoxButton', 'DxTextBoxOptions']

common_attrs = ['key']


class DxTextBox(External):
    imports = {"import DxTextBox from 'devextreme-vue/text-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'buttons', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'inputAttr',
        'isDirty', 'isValid', 'label', 'labelMode', 'mask', 'maskChar',
        'maskInvalidMessage', 'maskRules', 'maxLength', 'mode', 'name',
        'onChange', 'onContentReady', 'onCopy', 'onCut', 'onDisposing',
        'onEnterKey', 'onFocusIn', 'onFocusOut', 'onInitialized', 'onInput',
        'onKeyDown', 'onKeyUp', 'onOptionChanged', 'onPaste', 'onValueChanged',
        'placeholder', 'readOnly', 'rtlEnabled', 'showClearButton',
        'showMaskMode', 'spellcheck', 'stylingMode', 'tabIndex', 'text',
        'useMaskedValue', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'valueChangeEvent', 'visible', 'width',
        'modelValue']


class DxTextBoxButton(External):
    imports = {"import {DxButton as DxTextBoxButton} from 'devextreme-vue/text-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxTextBoxOptions(External):
    imports = {"import {DxOptions as DxTextBoxOptions} from 'devextreme-vue/text-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']



