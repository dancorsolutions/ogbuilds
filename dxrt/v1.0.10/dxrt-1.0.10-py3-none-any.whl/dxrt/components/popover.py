# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxPopover', 'DxPopoverAnimation', 'DxPopoverAt', 'DxPopoverBoundaryOffset', 'DxPopoverCollision',
 'DxPopoverFrom', 'DxPopoverHide', 'DxPopoverHideEvent', 'DxPopoverMy', 'DxPopoverOffset',
 'DxPopoverPosition', 'DxPopoverShow', 'DxPopoverShowEvent', 'DxPopoverTo', 'DxPopoverToolbarItem']

common_attrs = ['key']


class DxPopover(External):
    imports = {"import DxPopover from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['animation', 'closeOnOutsideClick', 'container', 'contentTemplate',
        'deferRendering', 'disabled', 'enableBodyScroll', 'height', 'hideEvent',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onShowing', 'onShown', 'onTitleRendered',
        'position', 'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton',
        'showEvent', 'showTitle', 'target', 'title', 'titleTemplate',
        'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxPopoverAnimation(External):
    imports = {"import {DxAnimation as DxPopoverAnimation} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['hide', 'show']


class DxPopoverAt(External):
    imports = {"import {DxAt as DxPopoverAt} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['x', 'y']


class DxPopoverBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxPopoverBoundaryOffset} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['x', 'y']


class DxPopoverCollision(External):
    imports = {"import {DxCollision as DxPopoverCollision} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['x', 'y']


class DxPopoverFrom(External):
    imports = {"import {DxFrom as DxPopoverFrom} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxPopoverHide(External):
    imports = {"import {DxHide as DxPopoverHide} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxPopoverHideEvent(External):
    imports = {"import {DxHideEvent as DxPopoverHideEvent} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['delay', 'name']


class DxPopoverMy(External):
    imports = {"import {DxMy as DxPopoverMy} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['x', 'y']


class DxPopoverOffset(External):
    imports = {"import {DxOffset as DxPopoverOffset} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['x', 'y']


class DxPopoverPosition(External):
    imports = {"import {DxPosition as DxPopoverPosition} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxPopoverShow(External):
    imports = {"import {DxShow as DxPopoverShow} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxPopoverShowEvent(External):
    imports = {"import {DxShowEvent as DxPopoverShowEvent} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['delay', 'name']


class DxPopoverTo(External):
    imports = {"import {DxTo as DxPopoverTo} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxPopoverToolbarItem(External):
    imports = {"import {DxToolbarItem as DxPopoverToolbarItem} from 'devextreme-vue/popover'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



