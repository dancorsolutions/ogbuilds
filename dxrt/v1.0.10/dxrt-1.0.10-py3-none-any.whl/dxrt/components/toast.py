# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxToast', 'DxToastAnimation', 'DxToastAt', 'DxToastBoundaryOffset', 'DxToastCollision',
 'DxToastFrom', 'DxToastHide', 'DxToastMy', 'DxToastOffset', 'DxToastPosition', 'DxToastShow',
 'DxToastTo']

common_attrs = ['key']


class DxToast(External):
    imports = {"import DxToast from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['accessKey', 'animation', 'closeOnClick', 'closeOnOutsideClick',
        'closeOnSwipe', 'contentTemplate', 'deferRendering', 'displayTime',
        'focusStateEnabled', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'message', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onShowing', 'onShown', 'position', 'rtlEnabled',
        'shading', 'shadingColor', 'tabIndex', 'type', 'visible', 'width',
        'wrapperAttr']


class DxToastAnimation(External):
    imports = {"import {DxAnimation as DxToastAnimation} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['hide', 'show']


class DxToastAt(External):
    imports = {"import {DxAt as DxToastAt} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['x', 'y']


class DxToastBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxToastBoundaryOffset} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['x', 'y']


class DxToastCollision(External):
    imports = {"import {DxCollision as DxToastCollision} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['x', 'y']


class DxToastFrom(External):
    imports = {"import {DxFrom as DxToastFrom} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxToastHide(External):
    imports = {"import {DxHide as DxToastHide} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxToastMy(External):
    imports = {"import {DxMy as DxToastMy} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['x', 'y']


class DxToastOffset(External):
    imports = {"import {DxOffset as DxToastOffset} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['x', 'y']


class DxToastPosition(External):
    imports = {"import {DxPosition as DxToastPosition} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxToastShow(External):
    imports = {"import {DxShow as DxToastShow} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxToastTo(External):
    imports = {"import {DxTo as DxToastTo} from 'devextreme-vue/toast'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']



