# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDropDownButton', 'DxDropDownButtonAnimation', 'DxDropDownButtonAt',
 'DxDropDownButtonBoundaryOffset', 'DxDropDownButtonCollision', 'DxDropDownButtonDropDownOptions',
 'DxDropDownButtonFrom', 'DxDropDownButtonHide', 'DxDropDownButtonItem', 'DxDropDownButtonMy',
 'DxDropDownButtonOffset', 'DxDropDownButtonPosition', 'DxDropDownButtonShow', 'DxDropDownButtonTo',
 'DxDropDownButtonToolbarItem']

common_attrs = ['key']


class DxDropDownButton(External):
    imports = {"import DxDropDownButton from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'dataSource', 'deferRendering',
        'disabled', 'displayExpr', 'dropDownContentTemplate', 'dropDownOptions',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'items', 'itemTemplate', 'keyExpr',
        'noDataText', 'onButtonClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onItemClick', 'onOptionChanged', 'onSelectionChanged',
        'opened', 'rtlEnabled', 'selectedItem', 'selectedItemKey',
        'showArrowIcon', 'splitButton', 'stylingMode', 'tabIndex', 'template',
        'text', 'type', 'useItemTextAsTitle', 'useSelectMode', 'visible',
        'width', 'wrapItemText']


class DxDropDownButtonAnimation(External):
    imports = {"import {DxAnimation as DxDropDownButtonAnimation} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['hide', 'show']


class DxDropDownButtonAt(External):
    imports = {"import {DxAt as DxDropDownButtonAt} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownButtonBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxDropDownButtonBoundaryOffset} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownButtonCollision(External):
    imports = {"import {DxCollision as DxDropDownButtonCollision} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownButtonDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxDropDownButtonDropDownOptions} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'deferRendering', 'disabled',
        'dragAndResizeArea', 'dragEnabled', 'dragOutsideBoundary',
        'enableBodyScroll', 'focusStateEnabled', 'fullScreen', 'height',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onResize', 'onResizeEnd', 'onResizeStart',
        'onShowing', 'onShown', 'onTitleRendered', 'position', 'resizeEnabled',
        'restorePosition', 'rtlEnabled', 'shading', 'shadingColor',
        'showCloseButton', 'showTitle', 'tabIndex', 'title', 'titleTemplate',
        'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxDropDownButtonFrom(External):
    imports = {"import {DxFrom as DxDropDownButtonFrom} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDropDownButtonHide(External):
    imports = {"import {DxHide as DxDropDownButtonHide} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDropDownButtonItem(External):
    imports = {"import {DxItem as DxDropDownButtonItem} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['badge', 'disabled', 'html', 'icon', 'onClick', 'template', 'text', 'visible']


class DxDropDownButtonMy(External):
    imports = {"import {DxMy as DxDropDownButtonMy} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownButtonOffset(External):
    imports = {"import {DxOffset as DxDropDownButtonOffset} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownButtonPosition(External):
    imports = {"import {DxPosition as DxDropDownButtonPosition} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxDropDownButtonShow(External):
    imports = {"import {DxShow as DxDropDownButtonShow} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDropDownButtonTo(External):
    imports = {"import {DxTo as DxDropDownButtonTo} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDropDownButtonToolbarItem(External):
    imports = {"import {DxToolbarItem as DxDropDownButtonToolbarItem} from 'devextreme-vue/drop-down-button'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



