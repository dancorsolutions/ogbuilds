# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxList', 'DxListButton', 'DxListCursorOffset', 'DxListItem', 'DxListItemDragging',
 'DxListMenuItem', 'DxListOptions', 'DxListSearchEditorOptions']

common_attrs = ['key']


class DxList(External):
    imports = {"import DxList from 'devextreme-vue/list'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowItemDeleting', 'bounceEnabled',
        'collapsibleGroups', 'dataSource', 'disabled', 'displayExpr',
        'elementAttr', 'focusStateEnabled', 'grouped', 'groupTemplate',
        'height', 'hint', 'hoverStateEnabled', 'indicateLoading',
        'itemDeleteMode', 'itemDragging', 'itemHoldTimeout', 'items',
        'itemTemplate', 'keyExpr', 'menuItems', 'menuMode', 'nextButtonText',
        'noDataText', 'onContentReady', 'onDisposing', 'onGroupRendered',
        'onInitialized', 'onItemClick', 'onItemContextMenu', 'onItemDeleted',
        'onItemDeleting', 'onItemHold', 'onItemRendered', 'onItemReordered',
        'onItemSwipe', 'onOptionChanged', 'onPageLoading', 'onPullRefresh',
        'onScroll', 'onSelectAllValueChanged', 'onSelectionChanged',
        'pageLoadingText', 'pageLoadMode', 'pulledDownText', 'pullingDownText',
        'pullRefreshEnabled', 'refreshingText', 'repaintChangesOnly',
        'rtlEnabled', 'scrollByContent', 'scrollByThumb', 'scrollingEnabled',
        'searchEditorOptions', 'searchEnabled', 'searchExpr', 'searchMode',
        'searchTimeout', 'searchValue', 'selectAllMode', 'selectAllText',
        'selectByClick', 'selectedItemKeys', 'selectedItems', 'selectionMode',
        'showScrollbar', 'showSelectionControls', 'tabIndex',
        'useNativeScrolling', 'visible', 'width']


class DxListButton(External):
    imports = {"import {DxButton as DxListButton} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxListCursorOffset(External):
    imports = {"import {DxCursorOffset as DxListCursorOffset} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['x', 'y']


class DxListItem(External):
    imports = {"import {DxItem as DxListItem} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['badge', 'disabled', 'html', 'icon', 'showChevron', 'template', 'text',
        'visible']


class DxListItemDragging(External):
    imports = {"import {DxItemDragging as DxListItemDragging} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['allowDropInsideItem', 'allowReordering', 'autoScroll',
        'bindingOptions', 'boundary', 'container', 'cursorOffset', 'data',
        'dragDirection', 'dragTemplate', 'dropFeedbackMode', 'elementAttr',
        'filter', 'group', 'handle', 'height', 'itemOrientation',
        'moveItemOnDrop', 'onAdd', 'onDisposing', 'onDragChange', 'onDragEnd',
        'onDragMove', 'onDragStart', 'onInitialized', 'onOptionChanged',
        'onRemove', 'onReorder', 'rtlEnabled', 'scrollSensitivity',
        'scrollSpeed', 'width']


class DxListMenuItem(External):
    imports = {"import {DxMenuItem as DxListMenuItem} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['action', 'text']


class DxListOptions(External):
    imports = {"import {DxOptions as DxListOptions} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxListSearchEditorOptions(External):
    imports = {"import {DxSearchEditorOptions as DxListSearchEditorOptions} from 'devextreme-vue/list'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'buttons',
        'disabled', 'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'inputAttr', 'isDirty', 'isValid', 'label',
        'labelMode', 'mask', 'maskChar', 'maskInvalidMessage', 'maskRules',
        'maxLength', 'mode', 'name', 'onChange', 'onContentReady', 'onCopy',
        'onCut', 'onDisposing', 'onEnterKey', 'onFocusIn', 'onFocusOut',
        'onInitialized', 'onInput', 'onKeyDown', 'onKeyUp', 'onOptionChanged',
        'onPaste', 'onValueChanged', 'placeholder', 'readOnly', 'rtlEnabled',
        'showClearButton', 'showMaskMode', 'spellcheck', 'stylingMode',
        'tabIndex', 'text', 'useMaskedValue', 'validationError',
        'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'visible', 'width']



