# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxRangeSlider', 'DxRangeSliderFormat', 'DxRangeSliderLabel', 'DxRangeSliderTooltip']

common_attrs = ['key']


class DxRangeSlider(External):
    imports = {"import DxRangeSlider from 'devextreme-vue/range-slider'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'disabled', 'elementAttr', 'end',
        'endName', 'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'isDirty', 'isValid', 'keyStep', 'label', 'max', 'min',
        'onContentReady', 'onDisposing', 'onInitialized', 'onOptionChanged',
        'onValueChanged', 'readOnly', 'rtlEnabled', 'showRange', 'start',
        'startName', 'step', 'tabIndex', 'tooltip', 'validationError',
        'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeMode', 'visible', 'width', 'modelValue']


class DxRangeSliderFormat(External):
    imports = {"import {DxFormat as DxRangeSliderFormat} from 'devextreme-vue/range-slider'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxRangeSliderLabel(External):
    imports = {"import {DxLabel as DxRangeSliderLabel} from 'devextreme-vue/range-slider'"}
    attrs = common_attrs + ['format', 'position', 'visible']


class DxRangeSliderTooltip(External):
    imports = {"import {DxTooltip as DxRangeSliderTooltip} from 'devextreme-vue/range-slider'"}
    attrs = common_attrs + ['enabled', 'format', 'position', 'showMode']



