# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxMap', 'DxMapApiKey', 'DxMapCenter', 'DxMapLocation', 'DxMapMarker', 'DxMapRoute',
 'DxMapTooltip']

common_attrs = ['key']


class DxMap(External):
    imports = {"import DxMap from 'devextreme-vue/map'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'apiKey', 'autoAdjust', 'center',
        'controls', 'disabled', 'elementAttr', 'focusStateEnabled', 'height',
        'hint', 'hoverStateEnabled', 'markerIconSrc', 'markers', 'onClick',
        'onDisposing', 'onInitialized', 'onMarkerAdded', 'onMarkerRemoved',
        'onOptionChanged', 'onReady', 'onRouteAdded', 'onRouteRemoved',
        'provider', 'routes', 'rtlEnabled', 'tabIndex', 'type', 'visible',
        'width', 'zoom']


class DxMapApiKey(External):
    imports = {"import {DxApiKey as DxMapApiKey} from 'devextreme-vue/map'"}
    attrs = common_attrs + ['bing', 'google', 'googleStatic']


class DxMapCenter(External):
    imports = {"import {DxCenter as DxMapCenter} from 'devextreme-vue/map'"}
    attrs = common_attrs + ['lat', 'lng']


class DxMapLocation(External):
    imports = {"import {DxLocation as DxMapLocation} from 'devextreme-vue/map'"}
    attrs = common_attrs + ['lat', 'lng']


class DxMapMarker(External):
    imports = {"import {DxMarker as DxMapMarker} from 'devextreme-vue/map'"}
    attrs = common_attrs + ['iconSrc', 'location', 'onClick', 'tooltip']


class DxMapRoute(External):
    imports = {"import {DxRoute as DxMapRoute} from 'devextreme-vue/map'"}
    attrs = common_attrs + ['color', 'locations', 'mode', 'opacity', 'weight']


class DxMapTooltip(External):
    imports = {"import {DxTooltip as DxMapTooltip} from 'devextreme-vue/map'"}
    attrs = common_attrs + ['isShown', 'text']



