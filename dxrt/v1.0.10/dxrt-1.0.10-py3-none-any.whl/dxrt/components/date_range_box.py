# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDateRangeBox', 'DxDateRangeBoxAnimation', 'DxDateRangeBoxAt', 'DxDateRangeBoxBoundaryOffset',
 'DxDateRangeBoxButton', 'DxDateRangeBoxCalendarOptions', 'DxDateRangeBoxCollision',
 'DxDateRangeBoxDisplayFormat', 'DxDateRangeBoxDropDownOptions', 'DxDateRangeBoxFrom',
 'DxDateRangeBoxHide', 'DxDateRangeBoxMy', 'DxDateRangeBoxOffset', 'DxDateRangeBoxOptions',
 'DxDateRangeBoxPosition', 'DxDateRangeBoxShow', 'DxDateRangeBoxTo', 'DxDateRangeBoxToolbarItem']

common_attrs = ['key']


class DxDateRangeBox(External):
    imports = {"import DxDateRangeBox from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['acceptCustomValue', 'accessKey', 'activeStateEnabled',
        'applyButtonText', 'applyValueMode', 'buttons', 'calendarOptions',
        'cancelButtonText', 'dateSerializationFormat', 'deferRendering',
        'disabled', 'disableOutOfRangeSelection', 'displayFormat',
        'dropDownButtonTemplate', 'dropDownOptions', 'elementAttr', 'endDate',
        'endDateInputAttr', 'endDateLabel', 'endDateName',
        'endDateOutOfRangeMessage', 'endDatePlaceholder', 'endDateText',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'invalidEndDateMessage', 'invalidStartDateMessage', 'isDirty',
        'isValid', 'labelMode', 'max', 'min', 'multiView', 'onChange',
        'onClosed', 'onContentReady', 'onCopy', 'onCut', 'onDisposing',
        'onEnterKey', 'onFocusIn', 'onFocusOut', 'onInitialized', 'onInput',
        'onKeyDown', 'onKeyUp', 'onOpened', 'onOptionChanged', 'onPaste',
        'onValueChanged', 'opened', 'openOnFieldClick', 'readOnly',
        'rtlEnabled', 'showClearButton', 'showDropDownButton', 'spellcheck',
        'startDate', 'startDateInputAttr', 'startDateLabel', 'startDateName',
        'startDateOutOfRangeMessage', 'startDatePlaceholder', 'startDateText',
        'stylingMode', 'tabIndex', 'todayButtonText', 'useMaskBehavior',
        'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'visible', 'width', 'modelValue']


class DxDateRangeBoxAnimation(External):
    imports = {"import {DxAnimation as DxDateRangeBoxAnimation} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['hide', 'show']


class DxDateRangeBoxAt(External):
    imports = {"import {DxAt as DxDateRangeBoxAt} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateRangeBoxBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxDateRangeBoxBoundaryOffset} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateRangeBoxButton(External):
    imports = {"import {DxButton as DxDateRangeBoxButton} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxDateRangeBoxCalendarOptions(External):
    imports = {"import {DxCalendarOptions as DxDateRangeBoxCalendarOptions} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'cellTemplate',
        'dateSerializationFormat', 'disabled', 'disabledDates', 'elementAttr',
        'firstDayOfWeek', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'isDirty', 'isValid', 'max', 'maxZoomLevel', 'min',
        'minZoomLevel', 'name', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'readOnly', 'rtlEnabled',
        'selectionMode', 'selectWeekOnClick', 'showTodayButton',
        'showWeekNumbers', 'tabIndex', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'visible', 'weekNumberRule', 'width',
        'zoomLevel']


class DxDateRangeBoxCollision(External):
    imports = {"import {DxCollision as DxDateRangeBoxCollision} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateRangeBoxDisplayFormat(External):
    imports = {"import {DxDisplayFormat as DxDateRangeBoxDisplayFormat} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxDateRangeBoxDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxDateRangeBoxDropDownOptions} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'deferRendering', 'disabled',
        'dragAndResizeArea', 'dragEnabled', 'dragOutsideBoundary',
        'enableBodyScroll', 'focusStateEnabled', 'fullScreen', 'height',
        'hideOnOutsideClick', 'hideOnParentScroll', 'hint', 'hoverStateEnabled',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onContentReady',
        'onDisposing', 'onHidden', 'onHiding', 'onInitialized',
        'onOptionChanged', 'onResize', 'onResizeEnd', 'onResizeStart',
        'onShowing', 'onShown', 'onTitleRendered', 'position', 'resizeEnabled',
        'restorePosition', 'rtlEnabled', 'shading', 'shadingColor',
        'showCloseButton', 'showTitle', 'tabIndex', 'title', 'titleTemplate',
        'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxDateRangeBoxFrom(External):
    imports = {"import {DxFrom as DxDateRangeBoxFrom} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDateRangeBoxHide(External):
    imports = {"import {DxHide as DxDateRangeBoxHide} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDateRangeBoxMy(External):
    imports = {"import {DxMy as DxDateRangeBoxMy} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateRangeBoxOffset(External):
    imports = {"import {DxOffset as DxDateRangeBoxOffset} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDateRangeBoxOptions(External):
    imports = {"import {DxOptions as DxDateRangeBoxOptions} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxDateRangeBoxPosition(External):
    imports = {"import {DxPosition as DxDateRangeBoxPosition} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxDateRangeBoxShow(External):
    imports = {"import {DxShow as DxDateRangeBoxShow} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDateRangeBoxTo(External):
    imports = {"import {DxTo as DxDateRangeBoxTo} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDateRangeBoxToolbarItem(External):
    imports = {"import {DxToolbarItem as DxDateRangeBoxToolbarItem} from 'devextreme-vue/date-range-box'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



