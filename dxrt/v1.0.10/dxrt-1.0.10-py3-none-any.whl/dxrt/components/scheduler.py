# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxScheduler', 'DxSchedulerAppointmentDragging', 'DxSchedulerEditing', 'DxSchedulerResource',
 'DxSchedulerScrolling', 'DxSchedulerView']

common_attrs = ['key']


class DxScheduler(External):
    imports = {"import DxScheduler from 'devextreme-vue/scheduler'"}
    attrs = common_attrs + ['accessKey', 'adaptivityEnabled', 'allDayExpr', 'allDayPanelMode',
        'appointmentCollectorTemplate', 'appointmentDragging',
        'appointmentTemplate', 'appointmentTooltipTemplate', 'cellDuration',
        'crossScrollingEnabled', 'currentDate', 'currentView',
        'customizeDateNavigatorText', 'dataCellTemplate', 'dataSource',
        'dateCellTemplate', 'dateSerializationFormat', 'descriptionExpr',
        'disabled', 'dropDownAppointmentTemplate', 'editing', 'elementAttr',
        'endDateExpr', 'endDateTimeZoneExpr', 'endDayHour', 'firstDayOfWeek',
        'focusStateEnabled', 'groupByDate', 'groups', 'height', 'hint',
        'indicatorUpdateInterval', 'max', 'maxAppointmentsPerCell', 'min',
        'noDataText', 'offset', 'onAppointmentAdded', 'onAppointmentAdding',
        'onAppointmentClick', 'onAppointmentContextMenu',
        'onAppointmentDblClick', 'onAppointmentDeleted',
        'onAppointmentDeleting', 'onAppointmentFormOpening',
        'onAppointmentRendered', 'onAppointmentTooltipShowing',
        'onAppointmentUpdated', 'onAppointmentUpdating', 'onCellClick',
        'onCellContextMenu', 'onContentReady', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'recurrenceEditMode', 'recurrenceExceptionExpr',
        'recurrenceRuleExpr', 'remoteFiltering', 'resourceCellTemplate',
        'resources', 'rtlEnabled', 'scrolling', 'selectedCellData',
        'shadeUntilCurrentTime', 'showAllDayPanel', 'showCurrentTimeIndicator',
        'startDateExpr', 'startDateTimeZoneExpr', 'startDayHour', 'tabIndex',
        'textExpr', 'timeCellTemplate', 'timeZone', 'useDropDownViewSwitcher',
        'views', 'visible', 'width']


class DxSchedulerAppointmentDragging(External):
    imports = {"import {DxAppointmentDragging as DxSchedulerAppointmentDragging} from 'devextreme-vue/scheduler'"}
    attrs = common_attrs + ['autoScroll', 'data', 'group', 'onAdd', 'onDragEnd', 'onDragMove',
        'onDragStart', 'onRemove', 'scrollSensitivity', 'scrollSpeed']


class DxSchedulerEditing(External):
    imports = {"import {DxEditing as DxSchedulerEditing} from 'devextreme-vue/scheduler'"}
    attrs = common_attrs + ['allowAdding', 'allowDeleting', 'allowDragging', 'allowResizing',
        'allowTimeZoneEditing', 'allowUpdating']


class DxSchedulerResource(External):
    imports = {"import {DxResource as DxSchedulerResource} from 'devextreme-vue/scheduler'"}
    attrs = common_attrs + ['allowMultiple', 'colorExpr', 'dataSource', 'displayExpr', 'fieldExpr',
        'label', 'useColorAsDefault', 'valueExpr']


class DxSchedulerScrolling(External):
    imports = {"import {DxScrolling as DxSchedulerScrolling} from 'devextreme-vue/scheduler'"}
    attrs = common_attrs + ['mode']


class DxSchedulerView(External):
    imports = {"import {DxView as DxSchedulerView} from 'devextreme-vue/scheduler'"}
    attrs = common_attrs + ['agendaDuration', 'allDayPanelMode', 'appointmentCollectorTemplate',
        'appointmentTemplate', 'appointmentTooltipTemplate', 'cellDuration',
        'dataCellTemplate', 'dateCellTemplate', 'dropDownAppointmentTemplate',
        'endDayHour', 'firstDayOfWeek', 'groupByDate', 'groupOrientation',
        'groups', 'intervalCount', 'maxAppointmentsPerCell', 'name', 'offset',
        'resourceCellTemplate', 'scrolling', 'startDate', 'startDayHour',
        'timeCellTemplate', 'type']



