# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxAccordion', 'DxAccordionItem']

common_attrs = ['key']


class DxAccordion(External):
    imports = {"import DxAccordion from 'devextreme-vue/accordion'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animationDuration', 'collapsible',
        'dataSource', 'deferRendering', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'itemHoldTimeout', 'items', 'itemTemplate', 'itemTitleTemplate',
        'keyExpr', 'multiple', 'noDataText', 'onContentReady', 'onDisposing',
        'onInitialized', 'onItemClick', 'onItemContextMenu', 'onItemHold',
        'onItemRendered', 'onItemTitleClick', 'onOptionChanged',
        'onSelectionChanged', 'repaintChangesOnly', 'rtlEnabled',
        'selectedIndex', 'selectedItem', 'selectedItemKeys', 'selectedItems',
        'tabIndex', 'visible', 'width']


class DxAccordionItem(External):
    imports = {"import {DxItem as DxAccordionItem} from 'devextreme-vue/accordion'"}
    attrs = common_attrs + ['disabled', 'html', 'icon', 'template', 'text', 'title',
        'titleTemplate', 'visible']



