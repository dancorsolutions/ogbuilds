# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxValidationGroup']

common_attrs = ['key']


class DxValidationGroup(External):
    imports = {"import DxValidationGroup from 'devextreme-vue/validation-group'"}
    attrs = common_attrs + ['elementAttr', 'height', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'width']



