# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxCalendar']

common_attrs = ['key']


class DxCalendar(External):
    imports = {"import DxCalendar from 'devextreme-vue/calendar'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'cellTemplate',
        'dateSerializationFormat', 'disabled', 'disabledDates', 'elementAttr',
        'firstDayOfWeek', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'isDirty', 'isValid', 'max', 'maxZoomLevel', 'min',
        'minZoomLevel', 'name', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'readOnly', 'rtlEnabled',
        'selectionMode', 'selectWeekOnClick', 'showTodayButton',
        'showWeekNumbers', 'tabIndex', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'visible', 'weekNumberRule', 'width',
        'zoomLevel', 'modelValue']



