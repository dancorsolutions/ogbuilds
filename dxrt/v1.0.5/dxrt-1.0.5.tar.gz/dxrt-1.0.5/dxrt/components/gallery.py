# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxGallery', 'DxGalleryItem']

common_attrs = ['key']


class DxGallery(External):
    imports = {"import DxGallery from 'devextreme-vue/gallery'"}
    attrs = common_attrs + ['accessKey', 'animationDuration', 'animationEnabled', 'dataSource',
        'disabled', 'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'indicatorEnabled', 'initialItemWidth',
        'itemHoldTimeout', 'items', 'itemTemplate', 'loop', 'noDataText',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered', 'onOptionChanged',
        'onSelectionChanged', 'rtlEnabled', 'selectedIndex', 'selectedItem',
        'showIndicator', 'showNavButtons', 'slideshowDelay', 'stretchImages',
        'swipeEnabled', 'tabIndex', 'visible', 'width', 'wrapAround']


class DxGalleryItem(External):
    imports = {"import {DxItem as DxGalleryItem} from 'devextreme-vue/gallery'"}
    attrs = common_attrs + ['disabled', 'html', 'imageAlt', 'imageSrc', 'template', 'text']



