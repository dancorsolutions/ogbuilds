# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTreeList', 'DxTreeListAnimation', 'DxTreeListAsyncRule', 'DxTreeListAt',
 'DxTreeListBoundaryOffset', 'DxTreeListButton', 'DxTreeListChange', 'DxTreeListColCountByScreen',
 'DxTreeListCollision', 'DxTreeListColumn', 'DxTreeListColumnChooser',
 'DxTreeListColumnChooserSearch', 'DxTreeListColumnChooserSelection', 'DxTreeListColumnFixing',
 'DxTreeListColumnFixingTexts', 'DxTreeListColumnHeaderFilter',
 'DxTreeListColumnHeaderFilterSearch', 'DxTreeListColumnLookup', 'DxTreeListCompareRule',
 'DxTreeListCursorOffset', 'DxTreeListCustomOperation', 'DxTreeListCustomRule', 'DxTreeListEditing',
 'DxTreeListEditingTexts', 'DxTreeListEmailRule', 'DxTreeListField', 'DxTreeListFieldLookup',
 'DxTreeListFilterBuilder', 'DxTreeListFilterBuilderPopup', 'DxTreeListFilterOperationDescriptions',
 'DxTreeListFilterPanel', 'DxTreeListFilterPanelTexts', 'DxTreeListFilterRow', 'DxTreeListForm',
 'DxTreeListFormat', 'DxTreeListFormItem', 'DxTreeListFrom', 'DxTreeListGroupOperationDescriptions',
 'DxTreeListHeaderFilter', 'DxTreeListHide', 'DxTreeListItem', 'DxTreeListKeyboardNavigation',
 'DxTreeListLabel', 'DxTreeListLoadPanel', 'DxTreeListLookup', 'DxTreeListMy',
 'DxTreeListNumericRule', 'DxTreeListOffset', 'DxTreeListOperationDescriptions', 'DxTreeListPager',
 'DxTreeListPaging', 'DxTreeListPatternRule', 'DxTreeListPopup', 'DxTreeListPosition',
 'DxTreeListRangeRule', 'DxTreeListRemoteOperations', 'DxTreeListRequiredRule',
 'DxTreeListRowDragging', 'DxTreeListScrolling', 'DxTreeListSearch', 'DxTreeListSearchPanel',
 'DxTreeListSelection', 'DxTreeListShow', 'DxTreeListSorting', 'DxTreeListStateStoring',
 'DxTreeListStringLengthRule', 'DxTreeListTexts', 'DxTreeListTo', 'DxTreeListToolbar',
 'DxTreeListToolbarItem', 'DxTreeListHeaderFilterSearch', 'DxTreeListHeaderFilterTexts',
 'DxTreeListValidationRule']

common_attrs = ['key']


class DxTreeList(External):
    imports = {"import DxTreeList from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowColumnReordering',
        'allowColumnResizing', 'autoExpandAll', 'autoNavigateToFocusedRow',
        'cacheEnabled', 'cellHintEnabled', 'columnAutoWidth', 'columnChooser',
        'columnFixing', 'columnHidingEnabled', 'columnMinWidth',
        'columnResizingMode', 'columns', 'columnWidth', 'customizeColumns',
        'dataSource', 'dataStructure', 'dateSerializationFormat', 'disabled',
        'editing', 'elementAttr', 'errorRowEnabled', 'expandedRowKeys',
        'expandNodesOnFiltering', 'filterBuilder', 'filterBuilderPopup',
        'filterMode', 'filterPanel', 'filterRow', 'filterSyncEnabled',
        'filterValue', 'focusedColumnIndex', 'focusedRowEnabled',
        'focusedRowIndex', 'focusedRowKey', 'hasItemsExpr', 'headerFilter',
        'height', 'highlightChanges', 'hint', 'hoverStateEnabled', 'itemsExpr',
        'keyboardNavigation', 'keyExpr', 'loadPanel', 'noDataText',
        'onAdaptiveDetailRowPreparing', 'onCellClick', 'onCellDblClick',
        'onCellHoverChanged', 'onCellPrepared', 'onContentReady',
        'onContextMenuPreparing', 'onDataErrorOccurred', 'onDisposing',
        'onEditCanceled', 'onEditCanceling', 'onEditingStart',
        'onEditorPrepared', 'onEditorPreparing', 'onFocusedCellChanged',
        'onFocusedCellChanging', 'onFocusedRowChanged', 'onFocusedRowChanging',
        'onInitialized', 'onInitNewRow', 'onKeyDown', 'onNodesInitialized',
        'onOptionChanged', 'onRowClick', 'onRowCollapsed', 'onRowCollapsing',
        'onRowDblClick', 'onRowExpanded', 'onRowExpanding', 'onRowInserted',
        'onRowInserting', 'onRowPrepared', 'onRowRemoved', 'onRowRemoving',
        'onRowUpdated', 'onRowUpdating', 'onRowValidating', 'onSaved',
        'onSaving', 'onSelectionChanged', 'onToolbarPreparing', 'pager',
        'paging', 'parentIdExpr', 'remoteOperations', 'renderAsync',
        'repaintChangesOnly', 'rootValue', 'rowAlternationEnabled',
        'rowDragging', 'rtlEnabled', 'scrolling', 'searchPanel',
        'selectedRowKeys', 'selection', 'showBorders', 'showColumnHeaders',
        'showColumnLines', 'showRowLines', 'sorting', 'stateStoring',
        'syncLookupFilterValues', 'tabIndex', 'toolbar', 'twoWayBindingEnabled',
        'visible', 'width', 'wordWrapEnabled']


class DxTreeListAnimation(External):
    imports = {"import {DxAnimation as DxTreeListAnimation} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['hide', 'show']


class DxTreeListAsyncRule(External):
    imports = {"import {DxAsyncRule as DxTreeListAsyncRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxTreeListAt(External):
    imports = {"import {DxAt as DxTreeListAt} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['x', 'y']


class DxTreeListBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxTreeListBoundaryOffset} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['x', 'y']


class DxTreeListButton(External):
    imports = {"import {DxButton as DxTreeListButton} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'hint', 'icon', 'name', 'onClick', 'template',
        'text', 'visible']


class DxTreeListChange(External):
    imports = {"import {DxChange as DxTreeListChange} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['data', 'insertAfterKey', 'insertBeforeKey', 'type']


class DxTreeListColCountByScreen(External):
    imports = {"import {DxColCountByScreen as DxTreeListColCountByScreen} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['lg', 'md', 'sm', 'xs']


class DxTreeListCollision(External):
    imports = {"import {DxCollision as DxTreeListCollision} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['x', 'y']


class DxTreeListColumn(External):
    imports = {"import {DxColumn as DxTreeListColumn} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['alignment', 'allowEditing', 'allowFiltering', 'allowFixing',
        'allowHeaderFiltering', 'allowHiding', 'allowReordering',
        'allowResizing', 'allowSearch', 'allowSorting', 'buttons',
        'calculateCellValue', 'calculateDisplayValue',
        'calculateFilterExpression', 'calculateSortValue', 'caption',
        'cellTemplate', 'columns', 'cssClass', 'customizeText', 'dataField',
        'dataType', 'editCellTemplate', 'editorOptions', 'encodeHtml',
        'falseText', 'filterOperations', 'filterType', 'filterValue',
        'filterValues', 'fixed', 'fixedPosition', 'format', 'formItem',
        'headerCellTemplate', 'headerFilter', 'hidingPriority', 'isBand',
        'lookup', 'minWidth', 'name', 'ownerBand', 'renderAsync',
        'selectedFilterOperation', 'setCellValue', 'showEditorAlways',
        'showInColumnChooser', 'sortIndex', 'sortingMethod', 'sortOrder',
        'trueText', 'type', 'validationRules', 'visible', 'visibleIndex',
        'width']


class DxTreeListColumnChooser(External):
    imports = {"import {DxColumnChooser as DxTreeListColumnChooser} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowSearch', 'emptyPanelText', 'enabled', 'height', 'mode',
        'position', 'search', 'searchTimeout', 'selection', 'sortOrder',
        'title', 'width']


class DxTreeListColumnChooserSearch(External):
    imports = {"import {DxColumnChooserSearch as DxTreeListColumnChooserSearch} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'timeout']


class DxTreeListColumnChooserSelection(External):
    imports = {"import {DxColumnChooserSelection as DxTreeListColumnChooserSelection} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowSelectAll', 'recursive', 'selectByClick']


class DxTreeListColumnFixing(External):
    imports = {"import {DxColumnFixing as DxTreeListColumnFixing} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['enabled', 'texts']


class DxTreeListColumnFixingTexts(External):
    imports = {"import {DxColumnFixingTexts as DxTreeListColumnFixingTexts} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['fix', 'leftPosition', 'rightPosition', 'unfix']


class DxTreeListColumnHeaderFilter(External):
    imports = {"import {DxColumnHeaderFilter as DxTreeListColumnHeaderFilter} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'dataSource', 'groupInterval',
        'height', 'search', 'searchMode', 'width']


class DxTreeListColumnHeaderFilterSearch(External):
    imports = {"import {DxColumnHeaderFilterSearch as DxTreeListColumnHeaderFilterSearch} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'searchExpr', 'timeout']


class DxTreeListColumnLookup(External):
    imports = {"import {DxColumnLookup as DxTreeListColumnLookup} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowClearing', 'calculateCellValue', 'dataSource', 'displayExpr',
        'valueExpr']


class DxTreeListCompareRule(External):
    imports = {"import {DxCompareRule as DxTreeListCompareRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'message', 'type']


class DxTreeListCursorOffset(External):
    imports = {"import {DxCursorOffset as DxTreeListCursorOffset} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['x', 'y']


class DxTreeListCustomOperation(External):
    imports = {"import {DxCustomOperation as DxTreeListCustomOperation} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['calculateFilterExpression', 'caption', 'customizeText', 'dataTypes',
        'editorTemplate', 'hasValue', 'icon', 'name']


class DxTreeListCustomRule(External):
    imports = {"import {DxCustomRule as DxTreeListCustomRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxTreeListEditing(External):
    imports = {"import {DxEditing as DxTreeListEditing} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowAdding', 'allowDeleting', 'allowUpdating', 'changes',
        'confirmDelete', 'editColumnName', 'editRowKey', 'form', 'mode',
        'popup', 'refreshMode', 'selectTextOnEditStart', 'startEditAction',
        'texts', 'useIcons']


class DxTreeListEditingTexts(External):
    imports = {"import {DxEditingTexts as DxTreeListEditingTexts} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['addRow', 'addRowToNode', 'cancelAllChanges', 'cancelRowChanges',
        'confirmDeleteMessage', 'confirmDeleteTitle', 'deleteRow', 'editRow',
        'saveAllChanges', 'saveRowChanges', 'undeleteRow',
        'validationCancelChanges']


class DxTreeListEmailRule(External):
    imports = {"import {DxEmailRule as DxTreeListEmailRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxTreeListField(External):
    imports = {"import {DxField as DxTreeListField} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['calculateFilterExpression', 'caption', 'customizeText', 'dataField',
        'dataType', 'editorOptions', 'editorTemplate', 'falseText',
        'filterOperations', 'format', 'lookup', 'name', 'trueText']


class DxTreeListFieldLookup(External):
    imports = {"import {DxFieldLookup as DxTreeListFieldLookup} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowClearing', 'dataSource', 'displayExpr', 'valueExpr']


class DxTreeListFilterBuilder(External):
    imports = {"import {DxFilterBuilder as DxTreeListFilterBuilder} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowHierarchicalFields',
        'bindingOptions', 'customOperations', 'disabled', 'elementAttr',
        'fields', 'filterOperationDescriptions', 'focusStateEnabled',
        'groupOperationDescriptions', 'groupOperations', 'height', 'hint',
        'hoverStateEnabled', 'maxGroupLevel', 'onContentReady', 'onDisposing',
        'onEditorPrepared', 'onEditorPreparing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'rtlEnabled', 'tabIndex', 'value',
        'visible', 'width']


class DxTreeListFilterBuilderPopup(External):
    imports = {"import {DxFilterBuilderPopup as DxTreeListFilterBuilderPopup} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxTreeListFilterOperationDescriptions(External):
    imports = {"import {DxFilterOperationDescriptions as DxTreeListFilterOperationDescriptions} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['between', 'contains', 'endsWith', 'equal', 'greaterThan',
        'greaterThanOrEqual', 'isBlank', 'isNotBlank', 'lessThan',
        'lessThanOrEqual', 'notContains', 'notEqual', 'startsWith']


class DxTreeListFilterPanel(External):
    imports = {"import {DxFilterPanel as DxTreeListFilterPanel} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['customizeText', 'filterEnabled', 'texts', 'visible']


class DxTreeListFilterPanelTexts(External):
    imports = {"import {DxFilterPanelTexts as DxTreeListFilterPanelTexts} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['clearFilter', 'createFilter', 'filterEnabledHint']


class DxTreeListFilterRow(External):
    imports = {"import {DxFilterRow as DxTreeListFilterRow} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['applyFilter', 'applyFilterText', 'betweenEndText', 'betweenStartText',
        'operationDescriptions', 'resetOperationText', 'showAllText',
        'showOperationChooser', 'visible']


class DxTreeListForm(External):
    imports = {"import {DxForm as DxTreeListForm} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'alignItemLabels',
        'alignItemLabelsInAllGroups', 'bindingOptions', 'colCount',
        'colCountByScreen', 'customizeItem', 'disabled', 'elementAttr',
        'focusStateEnabled', 'formData', 'height', 'hint', 'hoverStateEnabled',
        'items', 'labelLocation', 'labelMode', 'minColWidth', 'onContentReady',
        'onDisposing', 'onEditorEnterKey', 'onFieldDataChanged',
        'onInitialized', 'onOptionChanged', 'optionalMark', 'readOnly',
        'requiredMark', 'requiredMessage', 'rtlEnabled', 'screenByWidth',
        'scrollingEnabled', 'showColonAfterLabel', 'showOptionalMark',
        'showRequiredMark', 'showValidationSummary', 'tabIndex',
        'validationGroup', 'visible', 'width']


class DxTreeListFormat(External):
    imports = {"import {DxFormat as DxTreeListFormat} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxTreeListFormItem(External):
    imports = {"import {DxFormItem as DxTreeListFormItem} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['colSpan', 'cssClass', 'dataField', 'editorOptions', 'editorType',
        'helpText', 'isRequired', 'itemType', 'label', 'name', 'template',
        'validationRules', 'visible', 'visibleIndex']


class DxTreeListFrom(External):
    imports = {"import {DxFrom as DxTreeListFrom} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxTreeListGroupOperationDescriptions(External):
    imports = {"import {DxGroupOperationDescriptions as DxTreeListGroupOperationDescriptions} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['and', 'notAnd', 'notOr', 'or']


class DxTreeListHeaderFilter(External):
    imports = {"import {DxHeaderFilter as DxTreeListHeaderFilter} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'dataSource', 'groupInterval',
        'height', 'search', 'searchMode', 'searchTimeout', 'texts', 'visible',
        'width']


class DxTreeListHide(External):
    imports = {"import {DxHide as DxTreeListHide} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxTreeListItem(External):
    imports = {"import {DxItem as DxTreeListItem} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'name', 'options', 'showText', 'template', 'text',
        'visible', 'widget']


class DxTreeListKeyboardNavigation(External):
    imports = {"import {DxKeyboardNavigation as DxTreeListKeyboardNavigation} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['editOnKeyPress', 'enabled', 'enterKeyAction', 'enterKeyDirection']


class DxTreeListLabel(External):
    imports = {"import {DxLabel as DxTreeListLabel} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['alignment', 'location', 'showColon', 'template', 'text', 'visible']


class DxTreeListLoadPanel(External):
    imports = {"import {DxLoadPanel as DxTreeListLoadPanel} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['enabled', 'height', 'indicatorSrc', 'shading', 'shadingColor',
        'showIndicator', 'showPane', 'text', 'width']


class DxTreeListLookup(External):
    imports = {"import {DxLookup as DxTreeListLookup} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowClearing', 'calculateCellValue', 'dataSource', 'displayExpr',
        'valueExpr']


class DxTreeListMy(External):
    imports = {"import {DxMy as DxTreeListMy} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['x', 'y']


class DxTreeListNumericRule(External):
    imports = {"import {DxNumericRule as DxTreeListNumericRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxTreeListOffset(External):
    imports = {"import {DxOffset as DxTreeListOffset} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['x', 'y']


class DxTreeListOperationDescriptions(External):
    imports = {"import {DxOperationDescriptions as DxTreeListOperationDescriptions} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['between', 'contains', 'endsWith', 'equal', 'greaterThan',
        'greaterThanOrEqual', 'lessThan', 'lessThanOrEqual', 'notContains',
        'notEqual', 'startsWith']


class DxTreeListPager(External):
    imports = {"import {DxPager as DxTreeListPager} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowedPageSizes', 'displayMode', 'infoText', 'label', 'showInfo',
        'showNavigationButtons', 'showPageSizeSelector', 'visible']


class DxTreeListPaging(External):
    imports = {"import {DxPaging as DxTreeListPaging} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['enabled', 'pageIndex', 'pageSize']


class DxTreeListPatternRule(External):
    imports = {"import {DxPatternRule as DxTreeListPatternRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'pattern', 'type']


class DxTreeListPopup(External):
    imports = {"import {DxPopup as DxTreeListPopup} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxTreeListPosition(External):
    imports = {"import {DxPosition as DxTreeListPosition} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxTreeListRangeRule(External):
    imports = {"import {DxRangeRule as DxTreeListRangeRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'reevaluate', 'type']


class DxTreeListRemoteOperations(External):
    imports = {"import {DxRemoteOperations as DxTreeListRemoteOperations} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['filtering', 'grouping', 'sorting']


class DxTreeListRequiredRule(External):
    imports = {"import {DxRequiredRule as DxTreeListRequiredRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['message', 'trim', 'type']


class DxTreeListRowDragging(External):
    imports = {"import {DxRowDragging as DxTreeListRowDragging} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowDropInsideItem', 'allowReordering', 'autoScroll', 'boundary',
        'container', 'cursorOffset', 'data', 'dragDirection', 'dragTemplate',
        'dropFeedbackMode', 'filter', 'group', 'handle', 'onAdd',
        'onDragChange', 'onDragEnd', 'onDragMove', 'onDragStart', 'onRemove',
        'onReorder', 'scrollSensitivity', 'scrollSpeed', 'showDragIcons']


class DxTreeListScrolling(External):
    imports = {"import {DxScrolling as DxTreeListScrolling} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['columnRenderingMode', 'mode', 'preloadEnabled', 'renderAsync',
        'rowRenderingMode', 'scrollByContent', 'scrollByThumb', 'showScrollbar',
        'useNative']


class DxTreeListSearch(External):
    imports = {"import {DxSearch as DxTreeListSearch} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'searchExpr', 'timeout']


class DxTreeListSearchPanel(External):
    imports = {"import {DxSearchPanel as DxTreeListSearchPanel} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['highlightCaseSensitive', 'highlightSearchText', 'placeholder',
        'searchVisibleColumnsOnly', 'text', 'visible', 'width']


class DxTreeListSelection(External):
    imports = {"import {DxSelection as DxTreeListSelection} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['allowSelectAll', 'mode', 'recursive', 'selectByClick']


class DxTreeListShow(External):
    imports = {"import {DxShow as DxTreeListShow} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxTreeListSorting(External):
    imports = {"import {DxSorting as DxTreeListSorting} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ascendingText', 'clearText', 'descendingText', 'mode', 'showSortIndexes']


class DxTreeListStateStoring(External):
    imports = {"import {DxStateStoring as DxTreeListStateStoring} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['customLoad', 'customSave', 'enabled', 'savingTimeout', 'storageKey', 'type']


class DxTreeListStringLengthRule(External):
    imports = {"import {DxStringLengthRule as DxTreeListStringLengthRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'trim', 'type']


class DxTreeListTexts(External):
    imports = {"import {DxTexts as DxTreeListTexts} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['addRow', 'addRowToNode', 'cancel', 'cancelAllChanges',
        'cancelRowChanges', 'clearFilter', 'confirmDeleteMessage',
        'confirmDeleteTitle', 'createFilter', 'deleteRow', 'editRow',
        'emptyValue', 'filterEnabledHint', 'fix', 'leftPosition', 'ok',
        'rightPosition', 'saveAllChanges', 'saveRowChanges', 'undeleteRow',
        'unfix', 'validationCancelChanges']


class DxTreeListTo(External):
    imports = {"import {DxTo as DxTreeListTo} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxTreeListToolbar(External):
    imports = {"import {DxToolbar as DxTreeListToolbar} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['disabled', 'items', 'visible']


class DxTreeListToolbarItem(External):
    imports = {"import {DxToolbarItem as DxTreeListToolbarItem} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']


class DxTreeListHeaderFilterSearch(External):
    imports = {"import {DxTreeListHeaderFilterSearch as DxTreeListHeaderFilterSearch} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'timeout']


class DxTreeListHeaderFilterTexts(External):
    imports = {"import {DxTreeListHeaderFilterTexts as DxTreeListHeaderFilterTexts} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['cancel', 'emptyValue', 'ok']


class DxTreeListValidationRule(External):
    imports = {"import {DxValidationRule as DxTreeListValidationRule} from 'devextreme-vue/tree-list'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'max',
        'message', 'min', 'pattern', 'reevaluate', 'trim', 'type',
        'validationCallback']



