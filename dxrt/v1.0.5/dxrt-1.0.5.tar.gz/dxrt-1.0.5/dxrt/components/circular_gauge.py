# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxCircularGauge', 'DxCircularGaugeAnimation', 'DxCircularGaugeBackgroundColor',
 'DxCircularGaugeBorder', 'DxCircularGaugeColor', 'DxCircularGaugeExport', 'DxCircularGaugeFont',
 'DxCircularGaugeFormat', 'DxCircularGaugeGeometry', 'DxCircularGaugeLabel',
 'DxCircularGaugeLoadingIndicator', 'DxCircularGaugeMargin', 'DxCircularGaugeMinorTick',
 'DxCircularGaugeRange', 'DxCircularGaugeRangeContainer', 'DxCircularGaugeScale',
 'DxCircularGaugeShadow', 'DxCircularGaugeSize', 'DxCircularGaugeSubtitle',
 'DxCircularGaugeSubvalueIndicator', 'DxCircularGaugeText', 'DxCircularGaugeTick',
 'DxCircularGaugeTitle', 'DxCircularGaugeTooltip', 'DxCircularGaugeValueIndicator']

common_attrs = ['key']


class DxCircularGauge(External):
    imports = {"import DxCircularGauge from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['animation', 'centerTemplate', 'containerBackgroundColor', 'disabled',
        'elementAttr', 'export', 'geometry', 'loadingIndicator', 'margin',
        'onDisposing', 'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onOptionChanged',
        'onTooltipHidden', 'onTooltipShown', 'pathModified', 'rangeContainer',
        'redrawOnResize', 'rtlEnabled', 'scale', 'size', 'subvalueIndicator',
        'subvalues', 'theme', 'title', 'tooltip', 'value', 'valueIndicator']


class DxCircularGaugeAnimation(External):
    imports = {"import {DxAnimation as DxCircularGaugeAnimation} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['duration', 'easing', 'enabled']


class DxCircularGaugeBackgroundColor(External):
    imports = {"import {DxBackgroundColor as DxCircularGaugeBackgroundColor} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['base', 'fillId']


class DxCircularGaugeBorder(External):
    imports = {"import {DxBorder as DxCircularGaugeBorder} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxCircularGaugeColor(External):
    imports = {"import {DxColor as DxCircularGaugeColor} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['base', 'fillId']


class DxCircularGaugeExport(External):
    imports = {"import {DxExport as DxCircularGaugeExport} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxCircularGaugeFont(External):
    imports = {"import {DxFont as DxCircularGaugeFont} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxCircularGaugeFormat(External):
    imports = {"import {DxFormat as DxCircularGaugeFormat} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxCircularGaugeGeometry(External):
    imports = {"import {DxGeometry as DxCircularGaugeGeometry} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['endAngle', 'startAngle']


class DxCircularGaugeLabel(External):
    imports = {"import {DxLabel as DxCircularGaugeLabel} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['customizeText', 'font', 'format', 'hideFirstOrLast', 'indentFromTick',
        'overlappingBehavior', 'useRangeColors', 'visible']


class DxCircularGaugeLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxCircularGaugeLoadingIndicator} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'font', 'show', 'text']


class DxCircularGaugeMargin(External):
    imports = {"import {DxMargin as DxCircularGaugeMargin} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxCircularGaugeMinorTick(External):
    imports = {"import {DxMinorTick as DxCircularGaugeMinorTick} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'visible', 'width']


class DxCircularGaugeRange(External):
    imports = {"import {DxRange as DxCircularGaugeRange} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['color', 'endValue', 'startValue']


class DxCircularGaugeRangeContainer(External):
    imports = {"import {DxRangeContainer as DxCircularGaugeRangeContainer} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'offset', 'orientation', 'palette',
        'paletteExtensionMode', 'ranges', 'width']


class DxCircularGaugeScale(External):
    imports = {"import {DxScale as DxCircularGaugeScale} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['allowDecimals', 'customMinorTicks', 'customTicks', 'endValue', 'label',
        'minorTick', 'minorTickInterval', 'orientation', 'scaleDivisionFactor',
        'startValue', 'tick', 'tickInterval']


class DxCircularGaugeShadow(External):
    imports = {"import {DxShadow as DxCircularGaugeShadow} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxCircularGaugeSize(External):
    imports = {"import {DxSize as DxCircularGaugeSize} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['height', 'width']


class DxCircularGaugeSubtitle(External):
    imports = {"import {DxSubtitle as DxCircularGaugeSubtitle} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxCircularGaugeSubvalueIndicator(External):
    imports = {"import {DxSubvalueIndicator as DxCircularGaugeSubvalueIndicator} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['arrowLength', 'backgroundColor', 'baseValue', 'beginAdaptingAtRadius',
        'color', 'horizontalOrientation', 'indentFromCenter', 'length',
        'offset', 'palette', 'secondColor', 'secondFraction', 'size',
        'spindleGapSize', 'spindleSize', 'text', 'type', 'verticalOrientation',
        'width']


class DxCircularGaugeText(External):
    imports = {"import {DxText as DxCircularGaugeText} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['customizeText', 'font', 'format', 'indent']


class DxCircularGaugeTick(External):
    imports = {"import {DxTick as DxCircularGaugeTick} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'visible', 'width']


class DxCircularGaugeTitle(External):
    imports = {"import {DxTitle as DxCircularGaugeTitle} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxCircularGaugeTooltip(External):
    imports = {"import {DxTooltip as DxCircularGaugeTooltip} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'interactive', 'opacity', 'paddingLeftRight', 'paddingTopBottom',
        'shadow', 'zIndex']


class DxCircularGaugeValueIndicator(External):
    imports = {"import {DxValueIndicator as DxCircularGaugeValueIndicator} from 'devextreme-vue/circular-gauge'"}
    attrs = common_attrs + ['arrowLength', 'backgroundColor', 'baseValue', 'beginAdaptingAtRadius',
        'color', 'horizontalOrientation', 'indentFromCenter', 'length',
        'offset', 'palette', 'secondColor', 'secondFraction', 'size',
        'spindleGapSize', 'spindleSize', 'text', 'type', 'verticalOrientation',
        'width']



