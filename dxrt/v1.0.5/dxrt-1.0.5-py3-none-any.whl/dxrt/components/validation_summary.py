# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxValidationSummary', 'DxValidationSummaryItem']

common_attrs = ['key']


class DxValidationSummary(External):
    imports = {"import DxValidationSummary from 'devextreme-vue/validation-summary'"}
    attrs = common_attrs + ['elementAttr', 'hoverStateEnabled', 'items', 'itemTemplate',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onOptionChanged', 'validationGroup']


class DxValidationSummaryItem(External):
    imports = {"import {DxItem as DxValidationSummaryItem} from 'devextreme-vue/validation-summary'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text', 'visible']



