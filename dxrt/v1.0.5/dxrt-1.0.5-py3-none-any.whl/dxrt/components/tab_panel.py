# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTabPanel', 'DxTabPanelItem']

common_attrs = ['key']


class DxTabPanel(External):
    imports = {"import DxTabPanel from 'devextreme-vue/tab-panel'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animationEnabled', 'dataSource',
        'deferRendering', 'disabled', 'elementAttr', 'focusStateEnabled',
        'height', 'hint', 'hoverStateEnabled', 'itemHoldTimeout', 'items',
        'itemTemplate', 'itemTitleTemplate', 'loop', 'noDataText',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered', 'onOptionChanged',
        'onSelectionChanged', 'onTitleClick', 'onTitleHold', 'onTitleRendered',
        'repaintChangesOnly', 'rtlEnabled', 'scrollByContent',
        'scrollingEnabled', 'selectedIndex', 'selectedItem', 'showNavButtons',
        'swipeEnabled', 'tabIndex', 'visible', 'width']


class DxTabPanelItem(External):
    imports = {"import {DxItem as DxTabPanelItem} from 'devextreme-vue/tab-panel'"}
    attrs = common_attrs + ['badge', 'disabled', 'html', 'icon', 'tabTemplate', 'template', 'text',
        'title']



