# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDiagram', 'DxDiagramAutoLayout', 'DxDiagramCommand', 'DxDiagramCommandItem',
 'DxDiagramConnectionPoint', 'DxDiagramContextMenu', 'DxDiagramContextToolbox',
 'DxDiagramCustomShape', 'DxDiagramDefaultItemProperties', 'DxDiagramEdges', 'DxDiagramEditing',
 'DxDiagramExport', 'DxDiagramGridSize', 'DxDiagramGroup', 'DxDiagramHistoryToolbar',
 'DxDiagramItem', 'DxDiagramMainToolbar', 'DxDiagramNodes', 'DxDiagramPageSize',
 'DxDiagramPageSizeItem', 'DxDiagramPropertiesPanel', 'DxDiagramTab', 'DxDiagramTabGroup',
 'DxDiagramToolbox', 'DxDiagramToolboxGroup', 'DxDiagramViewToolbar', 'DxDiagramZoomLevel']

common_attrs = ['key']


class DxDiagram(External):
    imports = {"import DxDiagram from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['autoZoomMode', 'contextMenu', 'contextToolbox', 'customShapes',
        'customShapeTemplate', 'customShapeToolboxTemplate',
        'defaultItemProperties', 'disabled', 'edges', 'editing', 'elementAttr',
        'export', 'fullScreen', 'gridSize', 'hasChanges', 'height',
        'historyToolbar', 'mainToolbar', 'nodes', 'onContentReady',
        'onCustomCommand', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemDblClick', 'onOptionChanged', 'onRequestEditOperation',
        'onRequestLayoutUpdate', 'onSelectionChanged', 'pageColor',
        'pageOrientation', 'pageSize', 'propertiesPanel', 'readOnly',
        'rtlEnabled', 'showGrid', 'simpleView', 'snapToGrid', 'toolbox',
        'units', 'useNativeScrolling', 'viewToolbar', 'viewUnits', 'visible',
        'width', 'zoomLevel']


class DxDiagramAutoLayout(External):
    imports = {"import {DxAutoLayout as DxDiagramAutoLayout} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['orientation', 'type']


class DxDiagramCommand(External):
    imports = {"import {DxCommand as DxDiagramCommand} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['icon', 'items', 'location', 'name', 'text']


class DxDiagramCommandItem(External):
    imports = {"import {DxCommandItem as DxDiagramCommandItem} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['icon', 'items', 'location', 'name', 'text']


class DxDiagramConnectionPoint(External):
    imports = {"import {DxConnectionPoint as DxDiagramConnectionPoint} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['x', 'y']


class DxDiagramContextMenu(External):
    imports = {"import {DxContextMenu as DxDiagramContextMenu} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['commands', 'enabled']


class DxDiagramContextToolbox(External):
    imports = {"import {DxContextToolbox as DxDiagramContextToolbox} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['category', 'displayMode', 'enabled', 'shapeIconsPerRow', 'shapes', 'width']


class DxDiagramCustomShape(External):
    imports = {"import {DxCustomShape as DxDiagramCustomShape} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['allowEditImage', 'allowEditText', 'allowResize',
        'backgroundImageHeight', 'backgroundImageLeft',
        'backgroundImageToolboxUrl', 'backgroundImageTop', 'backgroundImageUrl',
        'backgroundImageWidth', 'baseType', 'category', 'connectionPoints',
        'defaultHeight', 'defaultImageUrl', 'defaultText', 'defaultWidth',
        'imageHeight', 'imageLeft', 'imageTop', 'imageWidth',
        'keepRatioOnAutoSize', 'maxHeight', 'maxWidth', 'minHeight', 'minWidth',
        'template', 'templateHeight', 'templateLeft', 'templateTop',
        'templateWidth', 'textHeight', 'textLeft', 'textTop', 'textWidth',
        'title', 'toolboxTemplate', 'toolboxWidthToHeightRatio', 'type']


class DxDiagramDefaultItemProperties(External):
    imports = {"import {DxDefaultItemProperties as DxDiagramDefaultItemProperties} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['connectorLineEnd', 'connectorLineStart', 'connectorLineType',
        'shapeMaxHeight', 'shapeMaxWidth', 'shapeMinHeight', 'shapeMinWidth',
        'style', 'textStyle']


class DxDiagramEdges(External):
    imports = {"import {DxEdges as DxDiagramEdges} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['customDataExpr', 'dataSource', 'fromExpr', 'fromLineEndExpr',
        'fromPointIndexExpr', 'keyExpr', 'lineTypeExpr', 'lockedExpr',
        'pointsExpr', 'styleExpr', 'textExpr', 'textStyleExpr', 'toExpr',
        'toLineEndExpr', 'toPointIndexExpr', 'zIndexExpr']


class DxDiagramEditing(External):
    imports = {"import {DxEditing as DxDiagramEditing} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['allowAddShape', 'allowChangeConnection', 'allowChangeConnectorPoints',
        'allowChangeConnectorText', 'allowChangeShapeText',
        'allowDeleteConnector', 'allowDeleteShape', 'allowMoveShape',
        'allowResizeShape']


class DxDiagramExport(External):
    imports = {"import {DxExport as DxDiagramExport} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['fileName']


class DxDiagramGridSize(External):
    imports = {"import {DxGridSize as DxDiagramGridSize} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['items', 'value']


class DxDiagramGroup(External):
    imports = {"import {DxGroup as DxDiagramGroup} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['category', 'commands', 'displayMode', 'expanded', 'shapes', 'title']


class DxDiagramHistoryToolbar(External):
    imports = {"import {DxHistoryToolbar as DxDiagramHistoryToolbar} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['commands', 'visible']


class DxDiagramItem(External):
    imports = {"import {DxItem as DxDiagramItem} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['height', 'icon', 'items', 'location', 'name', 'text', 'width']


class DxDiagramMainToolbar(External):
    imports = {"import {DxMainToolbar as DxDiagramMainToolbar} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['commands', 'visible']


class DxDiagramNodes(External):
    imports = {"import {DxNodes as DxDiagramNodes} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['autoLayout', 'autoSizeEnabled', 'containerChildrenExpr',
        'containerKeyExpr', 'customDataExpr', 'dataSource', 'heightExpr',
        'imageUrlExpr', 'itemsExpr', 'keyExpr', 'leftExpr', 'lockedExpr',
        'parentKeyExpr', 'styleExpr', 'textExpr', 'textStyleExpr', 'topExpr',
        'typeExpr', 'widthExpr', 'zIndexExpr']


class DxDiagramPageSize(External):
    imports = {"import {DxPageSize as DxDiagramPageSize} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['height', 'items', 'width']


class DxDiagramPageSizeItem(External):
    imports = {"import {DxPageSizeItem as DxDiagramPageSizeItem} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['height', 'text', 'width']


class DxDiagramPropertiesPanel(External):
    imports = {"import {DxPropertiesPanel as DxDiagramPropertiesPanel} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['tabs', 'visibility']


class DxDiagramTab(External):
    imports = {"import {DxTab as DxDiagramTab} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['commands', 'groups', 'title']


class DxDiagramTabGroup(External):
    imports = {"import {DxTabGroup as DxDiagramTabGroup} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['commands', 'title']


class DxDiagramToolbox(External):
    imports = {"import {DxToolbox as DxDiagramToolbox} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['groups', 'shapeIconsPerRow', 'showSearch', 'visibility', 'width']


class DxDiagramToolboxGroup(External):
    imports = {"import {DxToolboxGroup as DxDiagramToolboxGroup} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['category', 'displayMode', 'expanded', 'shapes', 'title']


class DxDiagramViewToolbar(External):
    imports = {"import {DxViewToolbar as DxDiagramViewToolbar} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['commands', 'visible']


class DxDiagramZoomLevel(External):
    imports = {"import {DxZoomLevel as DxDiagramZoomLevel} from 'devextreme-vue/diagram'"}
    attrs = common_attrs + ['items', 'value']



