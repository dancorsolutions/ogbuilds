# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSlideOutView']

common_attrs = ['key']


class DxSlideOutView(External):
    imports = {"import DxSlideOutView from 'devextreme-vue/slide-out-view'"}
    attrs = common_attrs + ['activeStateEnabled', 'contentTemplate', 'disabled', 'elementAttr',
        'height', 'hint', 'hoverStateEnabled', 'menuPosition', 'menuTemplate',
        'menuVisible', 'onDisposing', 'onInitialized', 'onOptionChanged',
        'rtlEnabled', 'swipeEnabled', 'visible', 'width']



