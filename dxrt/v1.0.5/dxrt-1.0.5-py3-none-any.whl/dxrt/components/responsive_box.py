# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxResponsiveBox', 'DxResponsiveBoxCol', 'DxResponsiveBoxItem', 'DxResponsiveBoxLocation',
 'DxResponsiveBoxRow']

common_attrs = ['key']


class DxResponsiveBox(External):
    imports = {"import DxResponsiveBox from 'devextreme-vue/responsive-box'"}
    attrs = common_attrs + ['cols', 'dataSource', 'disabled', 'elementAttr', 'height',
        'hoverStateEnabled', 'itemHoldTimeout', 'items', 'itemTemplate',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered', 'onOptionChanged',
        'rows', 'rtlEnabled', 'screenByWidth', 'singleColumnScreen', 'visible',
        'width']


class DxResponsiveBoxCol(External):
    imports = {"import {DxCol as DxResponsiveBoxCol} from 'devextreme-vue/responsive-box'"}
    attrs = common_attrs + ['baseSize', 'ratio', 'screen', 'shrink']


class DxResponsiveBoxItem(External):
    imports = {"import {DxItem as DxResponsiveBoxItem} from 'devextreme-vue/responsive-box'"}
    attrs = common_attrs + ['disabled', 'html', 'location', 'template', 'text', 'visible']


class DxResponsiveBoxLocation(External):
    imports = {"import {DxLocation as DxResponsiveBoxLocation} from 'devextreme-vue/responsive-box'"}
    attrs = common_attrs + ['col', 'colspan', 'row', 'rowspan', 'screen']


class DxResponsiveBoxRow(External):
    imports = {"import {DxRow as DxResponsiveBoxRow} from 'devextreme-vue/responsive-box'"}
    attrs = common_attrs + ['baseSize', 'ratio', 'screen', 'shrink']



