# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxResizable']

common_attrs = ['key']


class DxResizable(External):
    imports = {"import DxResizable from 'devextreme-vue/resizable'"}
    attrs = common_attrs + ['area', 'elementAttr', 'handles', 'height', 'keepAspectRatio',
        'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'onResize', 'onResizeEnd',
        'onResizeStart', 'rtlEnabled', 'width']



