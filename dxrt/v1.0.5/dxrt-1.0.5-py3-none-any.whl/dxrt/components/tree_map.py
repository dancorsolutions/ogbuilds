# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTreeMap', 'DxTreeMapBorder', 'DxTreeMapColorizer', 'DxTreeMapExport', 'DxTreeMapFont',
 'DxTreeMapFormat', 'DxTreeMapGroup', 'DxTreeMapGroupLabel', 'DxTreeMapHoverStyle',
 'DxTreeMapLabel', 'DxTreeMapLoadingIndicator', 'DxTreeMapMargin', 'DxTreeMapSelectionStyle',
 'DxTreeMapShadow', 'DxTreeMapSize', 'DxTreeMapSubtitle', 'DxTreeMapTile', 'DxTreeMapTileLabel',
 'DxTreeMapTitle', 'DxTreeMapTooltip', 'DxTreeMapTooltipBorder', 'DxTreeMapborder']

common_attrs = ['key']


class DxTreeMap(External):
    imports = {"import DxTreeMap from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['childrenField', 'colorField', 'colorizer', 'dataSource', 'disabled',
        'elementAttr', 'export', 'group', 'hoverEnabled', 'idField',
        'interactWithGroup', 'labelField', 'layoutAlgorithm', 'layoutDirection',
        'loadingIndicator', 'maxDepth', 'onClick', 'onDisposing', 'onDrawn',
        'onDrill', 'onExported', 'onExporting', 'onFileSaving',
        'onHoverChanged', 'onIncidentOccurred', 'onInitialized',
        'onNodesInitialized', 'onNodesRendering', 'onOptionChanged',
        'onSelectionChanged', 'parentField', 'pathModified', 'redrawOnResize',
        'rtlEnabled', 'selectionMode', 'size', 'theme', 'tile', 'title',
        'tooltip', 'valueField']


class DxTreeMapBorder(External):
    imports = {"import {DxBorder as DxTreeMapBorder} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxTreeMapColorizer(External):
    imports = {"import {DxColorizer as DxTreeMapColorizer} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['colorCodeField', 'colorizeGroups', 'palette', 'paletteExtensionMode',
        'range', 'type']


class DxTreeMapExport(External):
    imports = {"import {DxExport as DxTreeMapExport} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxTreeMapFont(External):
    imports = {"import {DxFont as DxTreeMapFont} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxTreeMapFormat(External):
    imports = {"import {DxFormat as DxTreeMapFormat} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxTreeMapGroup(External):
    imports = {"import {DxGroup as DxTreeMapGroup} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['border', 'color', 'headerHeight', 'hoverEnabled', 'hoverStyle',
        'label', 'padding', 'selectionStyle']


class DxTreeMapGroupLabel(External):
    imports = {"import {DxGroupLabel as DxTreeMapGroupLabel} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['font', 'textOverflow', 'visible']


class DxTreeMapHoverStyle(External):
    imports = {"import {DxHoverStyle as DxTreeMapHoverStyle} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['border', 'color']


class DxTreeMapLabel(External):
    imports = {"import {DxLabel as DxTreeMapLabel} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['font', 'textOverflow', 'visible', 'wordWrap']


class DxTreeMapLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxTreeMapLoadingIndicator} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxTreeMapMargin(External):
    imports = {"import {DxMargin as DxTreeMapMargin} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxTreeMapSelectionStyle(External):
    imports = {"import {DxSelectionStyle as DxTreeMapSelectionStyle} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['border', 'color']


class DxTreeMapShadow(External):
    imports = {"import {DxShadow as DxTreeMapShadow} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxTreeMapSize(External):
    imports = {"import {DxSize as DxTreeMapSize} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['height', 'width']


class DxTreeMapSubtitle(External):
    imports = {"import {DxSubtitle as DxTreeMapSubtitle} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxTreeMapTile(External):
    imports = {"import {DxTile as DxTreeMapTile} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['border', 'color', 'hoverStyle', 'label', 'selectionStyle']


class DxTreeMapTileLabel(External):
    imports = {"import {DxTileLabel as DxTreeMapTileLabel} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['font', 'textOverflow', 'visible', 'wordWrap']


class DxTreeMapTitle(External):
    imports = {"import {DxTitle as DxTreeMapTitle} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxTreeMapTooltip(External):
    imports = {"import {DxTooltip as DxTreeMapTooltip} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'opacity', 'paddingLeftRight', 'paddingTopBottom', 'shadow', 'zIndex']


class DxTreeMapTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxTreeMapTooltipBorder} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxTreeMapborder(External):
    imports = {"import {DxTreeMapborder as DxTreeMapborder} from 'devextreme-vue/tree-map'"}
    attrs = common_attrs + ['color', 'width']



