# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTextArea']

common_attrs = ['key']


class DxTextArea(External):
    imports = {"import DxTextArea from 'devextreme-vue/text-area'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'autoResizeEnabled', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'inputAttr', 'isValid', 'label', 'labelMode',
        'maxHeight', 'maxLength', 'minHeight', 'name', 'onChange',
        'onContentReady', 'onCopy', 'onCut', 'onDisposing', 'onEnterKey',
        'onFocusIn', 'onFocusOut', 'onInitialized', 'onInput', 'onKeyDown',
        'onKeyUp', 'onOptionChanged', 'onPaste', 'onValueChanged',
        'placeholder', 'readOnly', 'rtlEnabled', 'spellcheck', 'stylingMode',
        'tabIndex', 'text', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'valueChangeEvent', 'visible', 'width',
        'modelValue']



