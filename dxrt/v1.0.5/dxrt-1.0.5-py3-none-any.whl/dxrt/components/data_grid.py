# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDataGrid', 'DxDataGridAnimation', 'DxDataGridAsyncRule', 'DxDataGridAt',
 'DxDataGridBoundaryOffset', 'DxDataGridButton', 'DxDataGridChange', 'DxDataGridColCountByScreen',
 'DxDataGridCollision', 'DxDataGridColumn', 'DxDataGridColumnChooser',
 'DxDataGridColumnChooserSearch', 'DxDataGridColumnChooserSelection', 'DxDataGridColumnFixing',
 'DxDataGridColumnFixingTexts', 'DxDataGridColumnHeaderFilter',
 'DxDataGridColumnHeaderFilterSearch', 'DxDataGridColumnLookup', 'DxDataGridCompareRule',
 'DxDataGridCursorOffset', 'DxDataGridCustomOperation', 'DxDataGridCustomRule',
 'DxDataGridHeaderFilter', 'DxDataGridHeaderFilterSearch', 'DxDataGridHeaderFilterTexts',
 'DxDataGridSelection', 'DxDataGridEditing', 'DxDataGridEditingTexts', 'DxDataGridEmailRule',
 'DxDataGridExport', 'DxDataGridExportTexts', 'DxDataGridField', 'DxDataGridFieldLookup',
 'DxDataGridFilterBuilder', 'DxDataGridFilterBuilderPopup', 'DxDataGridFilterOperationDescriptions',
 'DxDataGridFilterPanel', 'DxDataGridFilterPanelTexts', 'DxDataGridFilterRow', 'DxDataGridForm',
 'DxDataGridFormat', 'DxDataGridFormItem', 'DxDataGridFrom', 'DxDataGridGrouping',
 'DxDataGridGroupingTexts', 'DxDataGridGroupItem', 'DxDataGridGroupOperationDescriptions',
 'DxDataGridGroupPanel', 'DxDataGridHide', 'DxDataGridItem', 'DxDataGridKeyboardNavigation',
 'DxDataGridLabel', 'DxDataGridLoadPanel', 'DxDataGridLookup', 'DxDataGridMasterDetail',
 'DxDataGridMy', 'DxDataGridNumericRule', 'DxDataGridOffset', 'DxDataGridOperationDescriptions',
 'DxDataGridPager', 'DxDataGridPaging', 'DxDataGridPatternRule', 'DxDataGridPopup',
 'DxDataGridPosition', 'DxDataGridRangeRule', 'DxDataGridRemoteOperations',
 'DxDataGridRequiredRule', 'DxDataGridRowDragging', 'DxDataGridScrolling', 'DxDataGridSearch',
 'DxDataGridSearchPanel', 'DxDataGridShow', 'DxDataGridSortByGroupSummaryInfo', 'DxDataGridSorting',
 'DxDataGridStateStoring', 'DxDataGridStringLengthRule', 'DxDataGridSummary',
 'DxDataGridSummaryTexts', 'DxDataGridTexts', 'DxDataGridTo', 'DxDataGridToolbar',
 'DxDataGridToolbarItem', 'DxDataGridTotalItem', 'DxDataGridValidationRule',
 'DxDataGridValueFormat']

common_attrs = ['key']


class DxDataGrid(External):
    imports = {"import DxDataGrid from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowColumnReordering',
        'allowColumnResizing', 'autoNavigateToFocusedRow', 'cacheEnabled',
        'cellHintEnabled', 'columnAutoWidth', 'columnChooser', 'columnFixing',
        'columnHidingEnabled', 'columnMinWidth', 'columnResizingMode',
        'columns', 'columnWidth', 'customizeColumns', 'dataRowTemplate',
        'dataSource', 'dateSerializationFormat', 'disabled', 'editing',
        'elementAttr', 'errorRowEnabled', 'export', 'filterBuilder',
        'filterBuilderPopup', 'filterPanel', 'filterRow', 'filterSyncEnabled',
        'filterValue', 'focusedColumnIndex', 'focusedRowEnabled',
        'focusedRowIndex', 'focusedRowKey', 'grouping', 'groupPanel',
        'headerFilter', 'height', 'highlightChanges', 'hint',
        'hoverStateEnabled', 'keyboardNavigation', 'keyExpr', 'loadPanel',
        'masterDetail', 'noDataText', 'onAdaptiveDetailRowPreparing',
        'onCellClick', 'onCellDblClick', 'onCellHoverChanged', 'onCellPrepared',
        'onContentReady', 'onContextMenuPreparing', 'onDataErrorOccurred',
        'onDisposing', 'onEditCanceled', 'onEditCanceling', 'onEditingStart',
        'onEditorPrepared', 'onEditorPreparing', 'onExporting',
        'onFocusedCellChanged', 'onFocusedCellChanging', 'onFocusedRowChanged',
        'onFocusedRowChanging', 'onInitialized', 'onInitNewRow', 'onKeyDown',
        'onOptionChanged', 'onRowClick', 'onRowCollapsed', 'onRowCollapsing',
        'onRowDblClick', 'onRowExpanded', 'onRowExpanding', 'onRowInserted',
        'onRowInserting', 'onRowPrepared', 'onRowRemoved', 'onRowRemoving',
        'onRowUpdated', 'onRowUpdating', 'onRowValidating', 'onSaved',
        'onSaving', 'onSelectionChanged', 'onToolbarPreparing', 'pager',
        'paging', 'remoteOperations', 'renderAsync', 'repaintChangesOnly',
        'rowAlternationEnabled', 'rowDragging', 'rowTemplate', 'rtlEnabled',
        'scrolling', 'searchPanel', 'selectedRowKeys', 'selection',
        'selectionFilter', 'showBorders', 'showColumnHeaders',
        'showColumnLines', 'showRowLines', 'sortByGroupSummaryInfo', 'sorting',
        'stateStoring', 'summary', 'syncLookupFilterValues', 'tabIndex',
        'toolbar', 'twoWayBindingEnabled', 'visible', 'width',
        'wordWrapEnabled']


class DxDataGridAnimation(External):
    imports = {"import {DxAnimation as DxDataGridAnimation} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['hide', 'show']


class DxDataGridAsyncRule(External):
    imports = {"import {DxAsyncRule as DxDataGridAsyncRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxDataGridAt(External):
    imports = {"import {DxAt as DxDataGridAt} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['x', 'y']


class DxDataGridBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxDataGridBoundaryOffset} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['x', 'y']


class DxDataGridButton(External):
    imports = {"import {DxButton as DxDataGridButton} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'hint', 'icon', 'name', 'onClick', 'template',
        'text', 'visible']


class DxDataGridChange(External):
    imports = {"import {DxChange as DxDataGridChange} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['data', 'insertAfterKey', 'insertBeforeKey', 'type']


class DxDataGridColCountByScreen(External):
    imports = {"import {DxColCountByScreen as DxDataGridColCountByScreen} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['lg', 'md', 'sm', 'xs']


class DxDataGridCollision(External):
    imports = {"import {DxCollision as DxDataGridCollision} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['x', 'y']


class DxDataGridColumn(External):
    imports = {"import {DxColumn as DxDataGridColumn} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['alignment', 'allowEditing', 'allowExporting', 'allowFiltering',
        'allowFixing', 'allowGrouping', 'allowHeaderFiltering', 'allowHiding',
        'allowReordering', 'allowResizing', 'allowSearch', 'allowSorting',
        'autoExpandGroup', 'buttons', 'calculateCellValue',
        'calculateDisplayValue', 'calculateFilterExpression',
        'calculateGroupValue', 'calculateSortValue', 'caption', 'cellTemplate',
        'columns', 'cssClass', 'customizeText', 'dataField', 'dataType',
        'editCellTemplate', 'editorOptions', 'encodeHtml', 'falseText',
        'filterOperations', 'filterType', 'filterValue', 'filterValues',
        'fixed', 'fixedPosition', 'format', 'formItem', 'groupCellTemplate',
        'groupIndex', 'headerCellTemplate', 'headerFilter', 'hidingPriority',
        'isBand', 'lookup', 'minWidth', 'name', 'ownerBand', 'renderAsync',
        'selectedFilterOperation', 'setCellValue', 'showEditorAlways',
        'showInColumnChooser', 'showWhenGrouped', 'sortIndex', 'sortingMethod',
        'sortOrder', 'trueText', 'type', 'validationRules', 'visible',
        'visibleIndex', 'width']


class DxDataGridColumnChooser(External):
    imports = {"import {DxColumnChooser as DxDataGridColumnChooser} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowSearch', 'emptyPanelText', 'enabled', 'height', 'mode',
        'position', 'search', 'searchTimeout', 'selection', 'sortOrder',
        'title', 'width']


class DxDataGridColumnChooserSearch(External):
    imports = {"import {DxColumnChooserSearch as DxDataGridColumnChooserSearch} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'timeout']


class DxDataGridColumnChooserSelection(External):
    imports = {"import {DxColumnChooserSelection as DxDataGridColumnChooserSelection} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowSelectAll', 'recursive', 'selectByClick']


class DxDataGridColumnFixing(External):
    imports = {"import {DxColumnFixing as DxDataGridColumnFixing} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['enabled', 'texts']


class DxDataGridColumnFixingTexts(External):
    imports = {"import {DxColumnFixingTexts as DxDataGridColumnFixingTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['fix', 'leftPosition', 'rightPosition', 'unfix']


class DxDataGridColumnHeaderFilter(External):
    imports = {"import {DxColumnHeaderFilter as DxDataGridColumnHeaderFilter} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'dataSource', 'groupInterval',
        'height', 'search', 'searchMode', 'width']


class DxDataGridColumnHeaderFilterSearch(External):
    imports = {"import {DxColumnHeaderFilterSearch as DxDataGridColumnHeaderFilterSearch} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'searchExpr', 'timeout']


class DxDataGridColumnLookup(External):
    imports = {"import {DxColumnLookup as DxDataGridColumnLookup} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowClearing', 'calculateCellValue', 'dataSource', 'displayExpr',
        'valueExpr']


class DxDataGridCompareRule(External):
    imports = {"import {DxCompareRule as DxDataGridCompareRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'message', 'type']


class DxDataGridCursorOffset(External):
    imports = {"import {DxCursorOffset as DxDataGridCursorOffset} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['x', 'y']


class DxDataGridCustomOperation(External):
    imports = {"import {DxCustomOperation as DxDataGridCustomOperation} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['calculateFilterExpression', 'caption', 'customizeText', 'dataTypes',
        'editorTemplate', 'hasValue', 'icon', 'name']


class DxDataGridCustomRule(External):
    imports = {"import {DxCustomRule as DxDataGridCustomRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxDataGridHeaderFilter(External):
    imports = {"import {DxDataGridHeaderFilter as DxDataGridHeaderFilter} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'height', 'search', 'searchTimeout',
        'texts', 'visible', 'width']


class DxDataGridHeaderFilterSearch(External):
    imports = {"import {DxDataGridHeaderFilterSearch as DxDataGridHeaderFilterSearch} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'timeout']


class DxDataGridHeaderFilterTexts(External):
    imports = {"import {DxDataGridHeaderFilterTexts as DxDataGridHeaderFilterTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['cancel', 'emptyValue', 'ok']


class DxDataGridSelection(External):
    imports = {"import {DxDataGridSelection as DxDataGridSelection} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowSelectAll', 'deferred', 'mode', 'selectAllMode', 'showCheckBoxesMode']


class DxDataGridEditing(External):
    imports = {"import {DxEditing as DxDataGridEditing} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowAdding', 'allowDeleting', 'allowUpdating', 'changes',
        'confirmDelete', 'editColumnName', 'editRowKey', 'form', 'mode',
        'newRowPosition', 'popup', 'refreshMode', 'selectTextOnEditStart',
        'startEditAction', 'texts', 'useIcons']


class DxDataGridEditingTexts(External):
    imports = {"import {DxEditingTexts as DxDataGridEditingTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['addRow', 'cancelAllChanges', 'cancelRowChanges',
        'confirmDeleteMessage', 'confirmDeleteTitle', 'deleteRow', 'editRow',
        'saveAllChanges', 'saveRowChanges', 'undeleteRow',
        'validationCancelChanges']


class DxDataGridEmailRule(External):
    imports = {"import {DxEmailRule as DxDataGridEmailRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxDataGridExport(External):
    imports = {"import {DxExport as DxDataGridExport} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowExportSelectedData', 'enabled', 'formats', 'texts']


class DxDataGridExportTexts(External):
    imports = {"import {DxExportTexts as DxDataGridExportTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['exportAll', 'exportSelectedRows', 'exportTo']


class DxDataGridField(External):
    imports = {"import {DxField as DxDataGridField} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['calculateFilterExpression', 'caption', 'customizeText', 'dataField',
        'dataType', 'editorOptions', 'editorTemplate', 'falseText',
        'filterOperations', 'format', 'lookup', 'name', 'trueText']


class DxDataGridFieldLookup(External):
    imports = {"import {DxFieldLookup as DxDataGridFieldLookup} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowClearing', 'dataSource', 'displayExpr', 'valueExpr']


class DxDataGridFilterBuilder(External):
    imports = {"import {DxFilterBuilder as DxDataGridFilterBuilder} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowHierarchicalFields',
        'bindingOptions', 'customOperations', 'disabled', 'elementAttr',
        'fields', 'filterOperationDescriptions', 'focusStateEnabled',
        'groupOperationDescriptions', 'groupOperations', 'height', 'hint',
        'hoverStateEnabled', 'maxGroupLevel', 'onContentReady', 'onDisposing',
        'onEditorPrepared', 'onEditorPreparing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'rtlEnabled', 'tabIndex', 'value',
        'visible', 'width']


class DxDataGridFilterBuilderPopup(External):
    imports = {"import {DxFilterBuilderPopup as DxDataGridFilterBuilderPopup} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxDataGridFilterOperationDescriptions(External):
    imports = {"import {DxFilterOperationDescriptions as DxDataGridFilterOperationDescriptions} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['between', 'contains', 'endsWith', 'equal', 'greaterThan',
        'greaterThanOrEqual', 'isBlank', 'isNotBlank', 'lessThan',
        'lessThanOrEqual', 'notContains', 'notEqual', 'startsWith']


class DxDataGridFilterPanel(External):
    imports = {"import {DxFilterPanel as DxDataGridFilterPanel} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['customizeText', 'filterEnabled', 'texts', 'visible']


class DxDataGridFilterPanelTexts(External):
    imports = {"import {DxFilterPanelTexts as DxDataGridFilterPanelTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['clearFilter', 'createFilter', 'filterEnabledHint']


class DxDataGridFilterRow(External):
    imports = {"import {DxFilterRow as DxDataGridFilterRow} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['applyFilter', 'applyFilterText', 'betweenEndText', 'betweenStartText',
        'operationDescriptions', 'resetOperationText', 'showAllText',
        'showOperationChooser', 'visible']


class DxDataGridForm(External):
    imports = {"import {DxForm as DxDataGridForm} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'alignItemLabels',
        'alignItemLabelsInAllGroups', 'bindingOptions', 'colCount',
        'colCountByScreen', 'customizeItem', 'disabled', 'elementAttr',
        'focusStateEnabled', 'formData', 'height', 'hint', 'hoverStateEnabled',
        'items', 'labelLocation', 'labelMode', 'minColWidth', 'onContentReady',
        'onDisposing', 'onEditorEnterKey', 'onFieldDataChanged',
        'onInitialized', 'onOptionChanged', 'optionalMark', 'readOnly',
        'requiredMark', 'requiredMessage', 'rtlEnabled', 'screenByWidth',
        'scrollingEnabled', 'showColonAfterLabel', 'showOptionalMark',
        'showRequiredMark', 'showValidationSummary', 'tabIndex',
        'validationGroup', 'visible', 'width']


class DxDataGridFormat(External):
    imports = {"import {DxFormat as DxDataGridFormat} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxDataGridFormItem(External):
    imports = {"import {DxFormItem as DxDataGridFormItem} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['colSpan', 'cssClass', 'dataField', 'editorOptions', 'editorType',
        'helpText', 'isRequired', 'itemType', 'label', 'name', 'template',
        'validationRules', 'visible', 'visibleIndex']


class DxDataGridFrom(External):
    imports = {"import {DxFrom as DxDataGridFrom} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDataGridGrouping(External):
    imports = {"import {DxGrouping as DxDataGridGrouping} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowCollapsing', 'autoExpandAll', 'contextMenuEnabled', 'expandMode',
        'texts']


class DxDataGridGroupingTexts(External):
    imports = {"import {DxGroupingTexts as DxDataGridGroupingTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['groupByThisColumn', 'groupContinuedMessage', 'groupContinuesMessage',
        'ungroup', 'ungroupAll']


class DxDataGridGroupItem(External):
    imports = {"import {DxGroupItem as DxDataGridGroupItem} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['alignByColumn', 'column', 'customizeText', 'displayFormat', 'name',
        'showInColumn', 'showInGroupFooter', 'skipEmptyValues', 'summaryType',
        'valueFormat']


class DxDataGridGroupOperationDescriptions(External):
    imports = {"import {DxGroupOperationDescriptions as DxDataGridGroupOperationDescriptions} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['and', 'notAnd', 'notOr', 'or']


class DxDataGridGroupPanel(External):
    imports = {"import {DxGroupPanel as DxDataGridGroupPanel} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowColumnDragging', 'emptyPanelText', 'visible']


class DxDataGridHide(External):
    imports = {"import {DxHide as DxDataGridHide} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDataGridItem(External):
    imports = {"import {DxItem as DxDataGridItem} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'name', 'options', 'showText', 'template', 'text',
        'visible', 'widget']


class DxDataGridKeyboardNavigation(External):
    imports = {"import {DxKeyboardNavigation as DxDataGridKeyboardNavigation} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['editOnKeyPress', 'enabled', 'enterKeyAction', 'enterKeyDirection']


class DxDataGridLabel(External):
    imports = {"import {DxLabel as DxDataGridLabel} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['alignment', 'location', 'showColon', 'template', 'text', 'visible']


class DxDataGridLoadPanel(External):
    imports = {"import {DxLoadPanel as DxDataGridLoadPanel} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['enabled', 'height', 'indicatorSrc', 'shading', 'shadingColor',
        'showIndicator', 'showPane', 'text', 'width']


class DxDataGridLookup(External):
    imports = {"import {DxLookup as DxDataGridLookup} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowClearing', 'calculateCellValue', 'dataSource', 'displayExpr',
        'valueExpr']


class DxDataGridMasterDetail(External):
    imports = {"import {DxMasterDetail as DxDataGridMasterDetail} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['autoExpandAll', 'enabled', 'template']


class DxDataGridMy(External):
    imports = {"import {DxMy as DxDataGridMy} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['x', 'y']


class DxDataGridNumericRule(External):
    imports = {"import {DxNumericRule as DxDataGridNumericRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxDataGridOffset(External):
    imports = {"import {DxOffset as DxDataGridOffset} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['x', 'y']


class DxDataGridOperationDescriptions(External):
    imports = {"import {DxOperationDescriptions as DxDataGridOperationDescriptions} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['between', 'contains', 'endsWith', 'equal', 'greaterThan',
        'greaterThanOrEqual', 'lessThan', 'lessThanOrEqual', 'notContains',
        'notEqual', 'startsWith']


class DxDataGridPager(External):
    imports = {"import {DxPager as DxDataGridPager} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowedPageSizes', 'displayMode', 'infoText', 'label', 'showInfo',
        'showNavigationButtons', 'showPageSizeSelector', 'visible']


class DxDataGridPaging(External):
    imports = {"import {DxPaging as DxDataGridPaging} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['enabled', 'pageIndex', 'pageSize']


class DxDataGridPatternRule(External):
    imports = {"import {DxPatternRule as DxDataGridPatternRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'pattern', 'type']


class DxDataGridPopup(External):
    imports = {"import {DxPopup as DxDataGridPopup} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxDataGridPosition(External):
    imports = {"import {DxPosition as DxDataGridPosition} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxDataGridRangeRule(External):
    imports = {"import {DxRangeRule as DxDataGridRangeRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'reevaluate', 'type']


class DxDataGridRemoteOperations(External):
    imports = {"import {DxRemoteOperations as DxDataGridRemoteOperations} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['filtering', 'grouping', 'groupPaging', 'paging', 'sorting', 'summary']


class DxDataGridRequiredRule(External):
    imports = {"import {DxRequiredRule as DxDataGridRequiredRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['message', 'trim', 'type']


class DxDataGridRowDragging(External):
    imports = {"import {DxRowDragging as DxDataGridRowDragging} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['allowDropInsideItem', 'allowReordering', 'autoScroll', 'boundary',
        'container', 'cursorOffset', 'data', 'dragDirection', 'dragTemplate',
        'dropFeedbackMode', 'filter', 'group', 'handle', 'onAdd',
        'onDragChange', 'onDragEnd', 'onDragMove', 'onDragStart', 'onRemove',
        'onReorder', 'scrollSensitivity', 'scrollSpeed', 'showDragIcons']


class DxDataGridScrolling(External):
    imports = {"import {DxScrolling as DxDataGridScrolling} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['columnRenderingMode', 'mode', 'preloadEnabled', 'renderAsync',
        'rowRenderingMode', 'scrollByContent', 'scrollByThumb', 'showScrollbar',
        'useNative']


class DxDataGridSearch(External):
    imports = {"import {DxSearch as DxDataGridSearch} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'searchExpr', 'timeout']


class DxDataGridSearchPanel(External):
    imports = {"import {DxSearchPanel as DxDataGridSearchPanel} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['highlightCaseSensitive', 'highlightSearchText', 'placeholder',
        'searchVisibleColumnsOnly', 'text', 'visible', 'width']


class DxDataGridShow(External):
    imports = {"import {DxShow as DxDataGridShow} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDataGridSortByGroupSummaryInfo(External):
    imports = {"import {DxSortByGroupSummaryInfo as DxDataGridSortByGroupSummaryInfo} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['groupColumn', 'sortOrder', 'summaryItem']


class DxDataGridSorting(External):
    imports = {"import {DxSorting as DxDataGridSorting} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ascendingText', 'clearText', 'descendingText', 'mode', 'showSortIndexes']


class DxDataGridStateStoring(External):
    imports = {"import {DxStateStoring as DxDataGridStateStoring} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['customLoad', 'customSave', 'enabled', 'savingTimeout', 'storageKey', 'type']


class DxDataGridStringLengthRule(External):
    imports = {"import {DxStringLengthRule as DxDataGridStringLengthRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'trim', 'type']


class DxDataGridSummary(External):
    imports = {"import {DxSummary as DxDataGridSummary} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['calculateCustomSummary', 'groupItems', 'recalculateWhileEditing',
        'skipEmptyValues', 'texts', 'totalItems']


class DxDataGridSummaryTexts(External):
    imports = {"import {DxSummaryTexts as DxDataGridSummaryTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['avg', 'avgOtherColumn', 'count', 'max', 'maxOtherColumn', 'min',
        'minOtherColumn', 'sum', 'sumOtherColumn']


class DxDataGridTexts(External):
    imports = {"import {DxTexts as DxDataGridTexts} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['addRow', 'avg', 'avgOtherColumn', 'cancel', 'cancelAllChanges',
        'cancelRowChanges', 'clearFilter', 'confirmDeleteMessage',
        'confirmDeleteTitle', 'count', 'createFilter', 'deleteRow', 'editRow',
        'emptyValue', 'exportAll', 'exportSelectedRows', 'exportTo',
        'filterEnabledHint', 'fix', 'groupByThisColumn',
        'groupContinuedMessage', 'groupContinuesMessage', 'leftPosition', 'max',
        'maxOtherColumn', 'min', 'minOtherColumn', 'ok', 'rightPosition',
        'saveAllChanges', 'saveRowChanges', 'sum', 'sumOtherColumn',
        'undeleteRow', 'unfix', 'ungroup', 'ungroupAll',
        'validationCancelChanges']


class DxDataGridTo(External):
    imports = {"import {DxTo as DxDataGridTo} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDataGridToolbar(External):
    imports = {"import {DxToolbar as DxDataGridToolbar} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['disabled', 'items', 'visible']


class DxDataGridToolbarItem(External):
    imports = {"import {DxToolbarItem as DxDataGridToolbarItem} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']


class DxDataGridTotalItem(External):
    imports = {"import {DxTotalItem as DxDataGridTotalItem} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['alignment', 'column', 'cssClass', 'customizeText', 'displayFormat',
        'name', 'showInColumn', 'skipEmptyValues', 'summaryType',
        'valueFormat']


class DxDataGridValidationRule(External):
    imports = {"import {DxValidationRule as DxDataGridValidationRule} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'max',
        'message', 'min', 'pattern', 'reevaluate', 'trim', 'type',
        'validationCallback']


class DxDataGridValueFormat(External):
    imports = {"import {DxValueFormat as DxDataGridValueFormat} from 'devextreme-vue/data-grid'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']



