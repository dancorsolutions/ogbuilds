# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxForm', 'DxFormAsyncRule', 'DxFormButtonItem', 'DxFormButtonOptions', 'DxFormColCountByScreen',
 'DxFormCompareRule', 'DxFormCustomRule', 'DxFormEmailRule', 'DxFormEmptyItem', 'DxFormGroupItem',
 'DxFormItem', 'DxFormLabel', 'DxFormNumericRule', 'DxFormPatternRule', 'DxFormRangeRule',
 'DxFormRequiredRule', 'DxFormSimpleItem', 'DxFormStringLengthRule', 'DxFormTab',
 'DxFormTabbedItem', 'DxFormTabPanelOptions', 'DxFormTabPanelOptionsItem', 'DxFormValidationRule']

common_attrs = ['key']


class DxForm(External):
    imports = {"import DxForm from 'devextreme-vue/form'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'alignItemLabels',
        'alignItemLabelsInAllGroups', 'colCount', 'colCountByScreen',
        'customizeItem', 'disabled', 'elementAttr', 'focusStateEnabled',
        'formData', 'height', 'hint', 'hoverStateEnabled', 'items',
        'labelLocation', 'labelMode', 'minColWidth', 'onContentReady',
        'onDisposing', 'onEditorEnterKey', 'onFieldDataChanged',
        'onInitialized', 'onOptionChanged', 'optionalMark', 'readOnly',
        'requiredMark', 'requiredMessage', 'rtlEnabled', 'screenByWidth',
        'scrollingEnabled', 'showColonAfterLabel', 'showOptionalMark',
        'showRequiredMark', 'showValidationSummary', 'tabIndex',
        'validationGroup', 'visible', 'width']


class DxFormAsyncRule(External):
    imports = {"import {DxAsyncRule as DxFormAsyncRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxFormButtonItem(External):
    imports = {"import {DxButtonItem as DxFormButtonItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['buttonOptions', 'colSpan', 'cssClass', 'horizontalAlignment',
        'itemType', 'name', 'verticalAlignment', 'visible', 'visibleIndex']


class DxFormButtonOptions(External):
    imports = {"import {DxButtonOptions as DxFormButtonOptions} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxFormColCountByScreen(External):
    imports = {"import {DxColCountByScreen as DxFormColCountByScreen} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['lg', 'md', 'sm', 'xs']


class DxFormCompareRule(External):
    imports = {"import {DxCompareRule as DxFormCompareRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'message', 'type']


class DxFormCustomRule(External):
    imports = {"import {DxCustomRule as DxFormCustomRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'reevaluate', 'type', 'validationCallback']


class DxFormEmailRule(External):
    imports = {"import {DxEmailRule as DxFormEmailRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxFormEmptyItem(External):
    imports = {"import {DxEmptyItem as DxFormEmptyItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['colSpan', 'cssClass', 'itemType', 'name', 'visible', 'visibleIndex']


class DxFormGroupItem(External):
    imports = {"import {DxGroupItem as DxFormGroupItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['alignItemLabels', 'caption', 'colCount', 'colCountByScreen', 'colSpan',
        'cssClass', 'items', 'itemType', 'name', 'template', 'visible',
        'visibleIndex']


class DxFormItem(External):
    imports = {"import {DxItem as DxFormItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['alignItemLabels', 'badge', 'buttonOptions', 'caption', 'colCount',
        'colCountByScreen', 'colSpan', 'cssClass', 'dataField', 'disabled',
        'editorOptions', 'editorType', 'helpText', 'horizontalAlignment',
        'html', 'icon', 'isRequired', 'items', 'itemType', 'label', 'name',
        'tabPanelOptions', 'tabs', 'tabTemplate', 'template', 'text', 'title',
        'validationRules', 'verticalAlignment', 'visible', 'visibleIndex']


class DxFormLabel(External):
    imports = {"import {DxLabel as DxFormLabel} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['alignment', 'location', 'showColon', 'template', 'text', 'visible']


class DxFormNumericRule(External):
    imports = {"import {DxNumericRule as DxFormNumericRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'type']


class DxFormPatternRule(External):
    imports = {"import {DxPatternRule as DxFormPatternRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'message', 'pattern', 'type']


class DxFormRangeRule(External):
    imports = {"import {DxRangeRule as DxFormRangeRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'reevaluate', 'type']


class DxFormRequiredRule(External):
    imports = {"import {DxRequiredRule as DxFormRequiredRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['message', 'trim', 'type']


class DxFormSimpleItem(External):
    imports = {"import {DxSimpleItem as DxFormSimpleItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['colSpan', 'cssClass', 'dataField', 'editorOptions', 'editorType',
        'helpText', 'isRequired', 'itemType', 'label', 'name', 'template',
        'validationRules', 'visible', 'visibleIndex']


class DxFormStringLengthRule(External):
    imports = {"import {DxStringLengthRule as DxFormStringLengthRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['ignoreEmptyValue', 'max', 'message', 'min', 'trim', 'type']


class DxFormTab(External):
    imports = {"import {DxTab as DxFormTab} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['alignItemLabels', 'badge', 'colCount', 'colCountByScreen', 'disabled',
        'icon', 'items', 'tabTemplate', 'template', 'title']


class DxFormTabbedItem(External):
    imports = {"import {DxTabbedItem as DxFormTabbedItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['colSpan', 'cssClass', 'itemType', 'name', 'tabPanelOptions', 'tabs',
        'visible', 'visibleIndex']


class DxFormTabPanelOptions(External):
    imports = {"import {DxTabPanelOptions as DxFormTabPanelOptions} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animationEnabled', 'bindingOptions',
        'dataSource', 'deferRendering', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'itemHoldTimeout', 'items', 'itemTemplate', 'itemTitleTemplate', 'loop',
        'noDataText', 'onContentReady', 'onDisposing', 'onInitialized',
        'onItemClick', 'onItemContextMenu', 'onItemHold', 'onItemRendered',
        'onOptionChanged', 'onSelectionChanged', 'onTitleClick', 'onTitleHold',
        'onTitleRendered', 'repaintChangesOnly', 'rtlEnabled',
        'scrollByContent', 'scrollingEnabled', 'selectedIndex', 'selectedItem',
        'showNavButtons', 'swipeEnabled', 'tabIndex', 'visible', 'width']


class DxFormTabPanelOptionsItem(External):
    imports = {"import {DxTabPanelOptionsItem as DxFormTabPanelOptionsItem} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['badge', 'disabled', 'html', 'icon', 'tabTemplate', 'template', 'text',
        'title']


class DxFormValidationRule(External):
    imports = {"import {DxValidationRule as DxFormValidationRule} from 'devextreme-vue/form'"}
    attrs = common_attrs + ['comparisonTarget', 'comparisonType', 'ignoreEmptyValue', 'max',
        'message', 'min', 'pattern', 'reevaluate', 'trim', 'type',
        'validationCallback']



