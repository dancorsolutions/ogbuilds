# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxActionSheet', 'DxActionSheetItem']

common_attrs = ['key']


class DxActionSheet(External):
    imports = {"import DxActionSheet from 'devextreme-vue/action-sheet'"}
    attrs = common_attrs + ['cancelText', 'dataSource', 'disabled', 'elementAttr', 'height', 'hint',
        'hoverStateEnabled', 'itemHoldTimeout', 'items', 'itemTemplate',
        'onCancelClick', 'onContentReady', 'onDisposing', 'onInitialized',
        'onItemClick', 'onItemContextMenu', 'onItemHold', 'onItemRendered',
        'onOptionChanged', 'rtlEnabled', 'showCancelButton', 'showTitle',
        'target', 'title', 'usePopover', 'visible', 'width']


class DxActionSheetItem(External):
    imports = {"import {DxItem as DxActionSheetItem} from 'devextreme-vue/action-sheet'"}
    attrs = common_attrs + ['disabled', 'icon', 'onClick', 'stylingMode', 'template', 'text', 'type']



