# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxFilterBuilder', 'DxFilterBuilderCustomOperation', 'DxFilterBuilderField',
 'DxFilterBuilderFilterOperationDescriptions', 'DxFilterBuilderFormat',
 'DxFilterBuilderGroupOperationDescriptions', 'DxFilterBuilderLookup']

common_attrs = ['key']


class DxFilterBuilder(External):
    imports = {"import DxFilterBuilder from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowHierarchicalFields',
        'customOperations', 'disabled', 'elementAttr', 'fields',
        'filterOperationDescriptions', 'focusStateEnabled',
        'groupOperationDescriptions', 'groupOperations', 'height', 'hint',
        'hoverStateEnabled', 'maxGroupLevel', 'onContentReady', 'onDisposing',
        'onEditorPrepared', 'onEditorPreparing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'rtlEnabled', 'tabIndex', 'value',
        'visible', 'width']


class DxFilterBuilderCustomOperation(External):
    imports = {"import {DxCustomOperation as DxFilterBuilderCustomOperation} from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['calculateFilterExpression', 'caption', 'customizeText', 'dataTypes',
        'editorTemplate', 'hasValue', 'icon', 'name']


class DxFilterBuilderField(External):
    imports = {"import {DxField as DxFilterBuilderField} from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['calculateFilterExpression', 'caption', 'customizeText', 'dataField',
        'dataType', 'editorOptions', 'editorTemplate', 'falseText',
        'filterOperations', 'format', 'lookup', 'name', 'trueText']


class DxFilterBuilderFilterOperationDescriptions(External):
    imports = {"import {DxFilterOperationDescriptions as DxFilterBuilderFilterOperationDescriptions} from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['between', 'contains', 'endsWith', 'equal', 'greaterThan',
        'greaterThanOrEqual', 'isBlank', 'isNotBlank', 'lessThan',
        'lessThanOrEqual', 'notContains', 'notEqual', 'startsWith']


class DxFilterBuilderFormat(External):
    imports = {"import {DxFormat as DxFilterBuilderFormat} from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxFilterBuilderGroupOperationDescriptions(External):
    imports = {"import {DxGroupOperationDescriptions as DxFilterBuilderGroupOperationDescriptions} from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['and', 'notAnd', 'notOr', 'or']


class DxFilterBuilderLookup(External):
    imports = {"import {DxLookup as DxFilterBuilderLookup} from 'devextreme-vue/filter-builder'"}
    attrs = common_attrs + ['allowClearing', 'dataSource', 'displayExpr', 'valueExpr']



