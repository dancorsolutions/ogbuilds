# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxMenu', 'DxMenuAnimation', 'DxMenuAt', 'DxMenuBoundaryOffset', 'DxMenuCollision', 'DxMenuDelay',
 'DxMenuFrom', 'DxMenuHide', 'DxMenuItem', 'DxMenuMy', 'DxMenuOffset', 'DxMenuPosition',
 'DxMenuShow', 'DxMenuShowFirstSubmenuMode', 'DxMenuShowSubmenuMode', 'DxMenuTo']

common_attrs = ['key']


class DxMenu(External):
    imports = {"import DxMenu from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'adaptivityEnabled', 'animation',
        'cssClass', 'dataSource', 'disabled', 'disabledExpr', 'displayExpr',
        'elementAttr', 'focusStateEnabled', 'height', 'hideSubmenuOnMouseLeave',
        'hint', 'hoverStateEnabled', 'items', 'itemsExpr', 'itemTemplate',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemRendered', 'onOptionChanged',
        'onSelectionChanged', 'onSubmenuHidden', 'onSubmenuHiding',
        'onSubmenuShowing', 'onSubmenuShown', 'orientation', 'rtlEnabled',
        'selectByClick', 'selectedExpr', 'selectedItem', 'selectionMode',
        'showFirstSubmenuMode', 'showSubmenuMode', 'submenuDirection',
        'tabIndex', 'visible', 'width']


class DxMenuAnimation(External):
    imports = {"import {DxAnimation as DxMenuAnimation} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['hide', 'show']


class DxMenuAt(External):
    imports = {"import {DxAt as DxMenuAt} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['x', 'y']


class DxMenuBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxMenuBoundaryOffset} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['x', 'y']


class DxMenuCollision(External):
    imports = {"import {DxCollision as DxMenuCollision} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['x', 'y']


class DxMenuDelay(External):
    imports = {"import {DxDelay as DxMenuDelay} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['hide', 'show']


class DxMenuFrom(External):
    imports = {"import {DxFrom as DxMenuFrom} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxMenuHide(External):
    imports = {"import {DxHide as DxMenuHide} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxMenuItem(External):
    imports = {"import {DxItem as DxMenuItem} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'disabled', 'icon', 'items',
        'linkAttr', 'selectable', 'selected', 'template', 'text', 'url',
        'visible']


class DxMenuMy(External):
    imports = {"import {DxMy as DxMenuMy} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['x', 'y']


class DxMenuOffset(External):
    imports = {"import {DxOffset as DxMenuOffset} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['x', 'y']


class DxMenuPosition(External):
    imports = {"import {DxPosition as DxMenuPosition} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxMenuShow(External):
    imports = {"import {DxShow as DxMenuShow} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxMenuShowFirstSubmenuMode(External):
    imports = {"import {DxShowFirstSubmenuMode as DxMenuShowFirstSubmenuMode} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['delay', 'name']


class DxMenuShowSubmenuMode(External):
    imports = {"import {DxShowSubmenuMode as DxMenuShowSubmenuMode} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['delay', 'name']


class DxMenuTo(External):
    imports = {"import {DxTo as DxMenuTo} from 'devextreme-vue/menu'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']



