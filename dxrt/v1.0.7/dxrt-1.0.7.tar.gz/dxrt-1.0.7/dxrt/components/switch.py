# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSwitch']

common_attrs = ['key']


class DxSwitch(External):
    imports = {"import DxSwitch from 'devextreme-vue/switch'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'isValid',
        'name', 'onContentReady', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'readOnly', 'rtlEnabled',
        'switchedOffText', 'switchedOnText', 'tabIndex', 'validationError',
        'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value', 'visible',
        'width', 'modelValue']



