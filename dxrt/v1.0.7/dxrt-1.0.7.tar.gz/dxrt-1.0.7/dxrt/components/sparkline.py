# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSparkline', 'DxSparklineBorder', 'DxSparklineFont', 'DxSparklineFormat', 'DxSparklineMargin',
 'DxSparklineShadow', 'DxSparklineSize', 'DxSparklineTooltip']

common_attrs = ['key']


class DxSparkline(External):
    imports = {"import DxSparkline from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['argumentField', 'barNegativeColor', 'barPositiveColor', 'dataSource',
        'disabled', 'elementAttr', 'firstLastColor', 'ignoreEmptyPoints',
        'lineColor', 'lineWidth', 'lossColor', 'margin', 'maxColor', 'maxValue',
        'minColor', 'minValue', 'onDisposing', 'onDrawn', 'onExported',
        'onExporting', 'onFileSaving', 'onIncidentOccurred', 'onInitialized',
        'onOptionChanged', 'onTooltipHidden', 'onTooltipShown', 'pathModified',
        'pointColor', 'pointSize', 'pointSymbol', 'rtlEnabled', 'showFirstLast',
        'showMinMax', 'size', 'theme', 'tooltip', 'type', 'valueField',
        'winColor', 'winlossThreshold']


class DxSparklineBorder(External):
    imports = {"import {DxBorder as DxSparklineBorder} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxSparklineFont(External):
    imports = {"import {DxFont as DxSparklineFont} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxSparklineFormat(External):
    imports = {"import {DxFormat as DxSparklineFormat} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxSparklineMargin(External):
    imports = {"import {DxMargin as DxSparklineMargin} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxSparklineShadow(External):
    imports = {"import {DxShadow as DxSparklineShadow} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxSparklineSize(External):
    imports = {"import {DxSize as DxSparklineSize} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['height', 'width']


class DxSparklineTooltip(External):
    imports = {"import {DxTooltip as DxSparklineTooltip} from 'devextreme-vue/sparkline'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'interactive', 'opacity', 'paddingLeftRight', 'paddingTopBottom',
        'shadow', 'zIndex']



