# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTreeView', 'DxTreeViewButton', 'DxTreeViewItem', 'DxTreeViewOptions',
 'DxTreeViewSearchEditorOptions']

common_attrs = ['key']


class DxTreeView(External):
    imports = {"import DxTreeView from 'devextreme-vue/tree-view'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animationEnabled', 'collapseIcon',
        'createChildren', 'dataSource', 'dataStructure', 'disabled',
        'disabledExpr', 'displayExpr', 'elementAttr', 'expandAllEnabled',
        'expandedExpr', 'expandEvent', 'expandIcon', 'expandNodesRecursive',
        'focusStateEnabled', 'hasItemsExpr', 'height', 'hint',
        'hoverStateEnabled', 'itemHoldTimeout', 'items', 'itemsExpr',
        'itemTemplate', 'keyExpr', 'noDataText', 'onContentReady',
        'onDisposing', 'onInitialized', 'onItemClick', 'onItemCollapsed',
        'onItemContextMenu', 'onItemExpanded', 'onItemHold', 'onItemRendered',
        'onItemSelectionChanged', 'onOptionChanged', 'onSelectAllValueChanged',
        'onSelectionChanged', 'parentIdExpr', 'rootValue', 'rtlEnabled',
        'scrollDirection', 'searchEditorOptions', 'searchEnabled', 'searchExpr',
        'searchMode', 'searchTimeout', 'searchValue', 'selectAllText',
        'selectByClick', 'selectedExpr', 'selectionMode',
        'selectNodesRecursive', 'showCheckBoxesMode', 'tabIndex',
        'useNativeScrolling', 'virtualModeEnabled', 'visible', 'width']


class DxTreeViewButton(External):
    imports = {"import {DxButton as DxTreeViewButton} from 'devextreme-vue/tree-view'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxTreeViewItem(External):
    imports = {"import {DxItem as DxTreeViewItem} from 'devextreme-vue/tree-view'"}
    attrs = common_attrs + ['disabled', 'expanded', 'hasItems', 'html', 'icon', 'id', 'items',
        'parentId', 'selected', 'template', 'text', 'visible']


class DxTreeViewOptions(External):
    imports = {"import {DxOptions as DxTreeViewOptions} from 'devextreme-vue/tree-view'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxTreeViewSearchEditorOptions(External):
    imports = {"import {DxSearchEditorOptions as DxTreeViewSearchEditorOptions} from 'devextreme-vue/tree-view'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'buttons',
        'disabled', 'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'inputAttr', 'isValid', 'label', 'labelMode',
        'mask', 'maskChar', 'maskInvalidMessage', 'maskRules', 'maxLength',
        'mode', 'name', 'onChange', 'onContentReady', 'onCopy', 'onCut',
        'onDisposing', 'onEnterKey', 'onFocusIn', 'onFocusOut', 'onInitialized',
        'onInput', 'onKeyDown', 'onKeyUp', 'onOptionChanged', 'onPaste',
        'onValueChanged', 'placeholder', 'readOnly', 'rtlEnabled',
        'showClearButton', 'showMaskMode', 'spellcheck', 'stylingMode',
        'tabIndex', 'text', 'useMaskedValue', 'validationError',
        'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'visible', 'width']



