# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxFileUploader']

common_attrs = ['key']


class DxFileUploader(External):
    imports = {"import DxFileUploader from 'devextreme-vue/file-uploader'"}
    attrs = common_attrs + ['abortUpload', 'accept', 'accessKey', 'activeStateEnabled',
        'allowCanceling', 'allowedFileExtensions', 'chunkSize', 'dialogTrigger',
        'disabled', 'dropZone', 'elementAttr', 'focusStateEnabled', 'height',
        'hint', 'hoverStateEnabled', 'inputAttr', 'invalidFileExtensionMessage',
        'invalidMaxFileSizeMessage', 'invalidMinFileSizeMessage', 'isValid',
        'labelText', 'maxFileSize', 'minFileSize', 'multiple', 'name',
        'onBeforeSend', 'onContentReady', 'onDisposing', 'onDropZoneEnter',
        'onDropZoneLeave', 'onFilesUploaded', 'onInitialized',
        'onOptionChanged', 'onProgress', 'onUploadAborted', 'onUploaded',
        'onUploadError', 'onUploadStarted', 'onValueChanged', 'progress',
        'readOnly', 'readyToUploadMessage', 'rtlEnabled', 'selectButtonText',
        'showFileList', 'tabIndex', 'uploadAbortedMessage', 'uploadButtonText',
        'uploadChunk', 'uploadCustomData', 'uploadedMessage',
        'uploadFailedMessage', 'uploadFile', 'uploadHeaders', 'uploadMethod',
        'uploadMode', 'uploadUrl', 'validationError', 'validationErrors',
        'validationStatus', 'value', 'visible', 'width']



