import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException



class AmbiguousName(Exception):
    pass


def xlower(s):
    return fr"""translate({s},'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')"""


class Find:

    def __init__(self, driver, timer=0.0, wait=5.0):
        self.d = driver
        self.timer = timer
        self.wait = wait

    def xf(self, xpath, wait=None, no_error=False, visible=True, multiple=False, clickable=False):
        if wait is None:
            wait = self.wait

        time.sleep(self.timer)

        if multiple:
            ec = EC.presence_of_all_elements_located((By.XPATH, xpath))
        elif clickable:
            ec = EC.element_to_be_clickable((By.XPATH, xpath))
        elif visible:
            ec = EC.visibility_of_element_located((By.XPATH, xpath))
        else:
            ec = EC.presence_of_element_located((By.XPATH, xpath))

        try:
            return WebDriverWait(self.d, wait).until(ec)
        except TimeoutException:
            if no_error:
                return None
            else:
                raise

    def xfs(self, xpath, wait=None, no_error=False):
        return self.xf(xpath=xpath, wait=wait, no_error=no_error, multiple=True)

    def tab(self, text):
        self.xf(f'//div[contains(@class,"dx-tab-content") and contains(text(), "{text}")]').click()

    def blur(self):
        self.xf('//body').click()

    def within(self, *args, **kwargs):
        return Find(driver=self.xf(*args, **kwargs))

    def _endswith(self, text, field):
        return '%r = substring(%s, string - length(%s) - string - length(%r) + 1' % (text, field, field, text)

    def button(self, text=None):
        e = self.xf('.//button[contains(text(), %r)]' % text)
        e.click()
        return e

    def input(self, name, text):
        e = self.xf('.//input[contains(@name, %r)]' % name)
        e.clear()
        e.send_keys(text)
        e.send_keys('\t')
        return e

    def date_input(self, name, text):
        return self.special_input(name, text)

    def special_input(self, name, text):
        e = self.xf('.//input[contains(@name, %r)]/../div/div/input' % name)
        e.clear()
        e.click()
        e.send_keys(text)
        e.send_keys('\t')
        return e

    def number_input(self, name, text):
        return self.special_input(name, str(text))

    def radio(self, name, label):
        e = self.xf('.//input[contains(@name, %r)]/../div//div[contains(text(), %r)]' % (name, label))
        e.click()
        return e

    def dropdown(self, name, label):
        self.xf('.//input[contains(@name, %r)]/../div//div[@role="button"]' % name).click()
        self.xf('.//div[contains(@class, "dx-dropdownlist-popup-wrapper")]//div[contains(@class, "dx-scrollview-content")]//div[contains(text(), %r)]' % label).click()

    def checkbox(self, name):
        e = self.xf('.//input[contains(@name,%r)]//parent::*//span[@class="dx-checkbox-icon"]' % name)
        e.click()
        return e

    def accordion(self, text, **kwargs):
        e = self.xf('.//*[contains(@class, "dx-accordion-item-title") and contains(text(), %r)]' % text, **kwargs)
        if not e:
            return None
        e.click()
        return e

    def grid_add(self):
        e = self.xf('.//*[contains(@class, "dx-datagrid-toolbar-button")]/div')
        e.click()
        return e

    def grid(self, index, text):
        e = self.xf(
            './/*[contains(@class, "dx-datagrid-rowsview")]//tbody/tr[position() = (last()-1)]/td[position() = %d]' % index)
        e.click()
        time.sleep(0.3)
        e = self.xf(
            './/*[contains(@class, "dx-datagrid-rowsview")]//tbody/tr[position() = (last()-1)]/td[position() = %d]//input' % index)
        e.clear()
        e.send_keys(text)

    def grid_select(self, index, label):
        e = self.xf(
            './/*[contains(@class, "dx-datagrid-rowsview")]//tbody/tr[position() = (last()-1)]/td[position() = %d]' % index)
        e.click()
        time.sleep(0.3)
        self.xf('.//*[contains(@class, "dx-datagrid-rowsview")]//tbody/tr[position() = (last()-1)]/td[position() = %d]//*[contains(@class, "dx-button-content")]' % index).click()
        e = self.xf('.//div[contains(@class, "dx-dropdownlist-popup-wrapper")]//div[contains(@class, "dx-scrollview-content")]//div[contains(text(), %r)]' % label).click()
        return e

    def textarea(self, name, text):
        e = self.xf('.//textarea[contains(@name, %r)]' % name)
        e.clear()
        e.send_keys(text)
        e.send_keys('\t')
        return e

    def link(self, text):
        e = self.xf(fr"""//a[contains({xlower('text()')}, {text!r})]""")
        e.click()
        return e

    def tree_item(self, text):
        e = self.xf(fr"""//div[contains(@class, 'dx-treeview-item-content')]//*[contains({xlower('text()')}, {text!r})]""")
        e.click()
        return e

    def do(self, name, content=None):
        e = self.xf('.//*[contains(@name, %r)]' % name, visible=False)
        if e.tag_name == 'textarea':
            return self.textarea(name=name, text=content)
        if e.tag_name == 'a':
            # find again but ensure visible
            e = self.xf('.//*[contains(@name, %r)]' % name)
            e.click()
            return e

        e = self.xf('.//*[contains(@name, %r)]/..' % name, visible=False)
        cls = e.get_attribute('class')
        if 'dx-texteditor-input-container' in cls:
            return self.input(name=name, text=content)
        elif 'dx-numberbox' in cls:
            return self.number_input(name=name, text=content)
        elif 'dx-radiogroup' in cls:
            return self.radio(name=name, label=content)
        elif 'dx-checkbox' in cls:
            return self.checkbox(name=name)
        # TODO: dropdown, date, etc.
