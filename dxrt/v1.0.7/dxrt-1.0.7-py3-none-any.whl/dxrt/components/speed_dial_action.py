# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSpeedDialAction']

common_attrs = ['key']


class DxSpeedDialAction(External):
    imports = {"import DxSpeedDialAction from 'devextreme-vue/speed-dial-action'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'elementAttr', 'focusStateEnabled',
        'hint', 'hoverStateEnabled', 'icon', 'index', 'label', 'onClick',
        'onContentReady', 'onDisposing', 'onInitialized', 'onOptionChanged',
        'rtlEnabled', 'tabIndex', 'visible']



