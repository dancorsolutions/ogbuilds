# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxChart', 'DxChartAdaptiveLayout', 'DxChartAggregation', 'DxChartAggregationInterval',
 'DxChartAnimation', 'DxChartAnnotation', 'DxChartAnnotationBorder', 'DxChartAnnotationImage',
 'DxChartArgumentAxis', 'DxChartArgumentFormat', 'DxChartAxisConstantLineStyle',
 'DxChartAxisConstantLineStyleLabel', 'DxChartAxisLabel', 'DxChartAxisTitle',
 'DxChartBackgroundColor', 'DxChartBorder', 'DxChartBreak', 'DxChartBreakStyle', 'DxChartTitle',
 'DxChartTitleSubtitle', 'DxChartColor', 'DxChartCommonAnnotationSettings',
 'DxChartCommonAxisSettings', 'DxChartCommonAxisSettingsConstantLineStyle',
 'DxChartCommonAxisSettingsConstantLineStyleLabel', 'DxChartCommonAxisSettingsLabel',
 'DxChartCommonAxisSettingsTitle', 'DxChartCommonPaneSettings', 'DxChartCommonSeriesSettings',
 'DxChartCommonSeriesSettingsHoverStyle', 'DxChartCommonSeriesSettingsLabel',
 'DxChartCommonSeriesSettingsSelectionStyle', 'DxChartConnector', 'DxChartConstantLine',
 'DxChartConstantLineLabel', 'DxChartConstantLineStyle', 'DxChartCrosshair',
 'DxChartDataPrepareSettings', 'DxChartDragBoxStyle', 'DxChartExport', 'DxChartFont',
 'DxChartFormat', 'DxChartGrid', 'DxChartHatching', 'DxChartHeight', 'DxChartHorizontalLine',
 'DxChartHorizontalLineLabel', 'DxChartHoverStyle', 'DxChartImage', 'DxChartLabel', 'DxChartLegend',
 'DxChartLegendTitle', 'DxChartLegendTitleSubtitle', 'DxChartLength', 'DxChartLoadingIndicator',
 'DxChartMargin', 'DxChartMinorGrid', 'DxChartMinorTick', 'DxChartMinorTickInterval',
 'DxChartMinVisualRangeLength', 'DxChartPane', 'DxChartPaneBorder', 'DxChartPoint',
 'DxChartPointBorder', 'DxChartPointHoverStyle', 'DxChartPointImage', 'DxChartPointSelectionStyle',
 'DxChartReduction', 'DxChartScrollBar', 'DxChartSelectionStyle', 'DxChartSeries',
 'DxChartSeriesBorder', 'DxChartSeriesTemplate', 'DxChartShadow', 'DxChartSize', 'DxChartStrip',
 'DxChartStripLabel', 'DxChartStripStyle', 'DxChartStripStyleLabel', 'DxChartSubtitle',
 'DxChartTick', 'DxChartTickInterval', 'DxChartTooltip', 'DxChartTooltipBorder', 'DxChartUrl',
 'DxChartValueAxis', 'DxChartValueErrorBar', 'DxChartVerticalLine', 'DxChartVisualRange',
 'DxChartWholeRange', 'DxChartWidth', 'DxChartZoomAndPan']

common_attrs = ['key']


class DxChart(External):
    imports = {"import DxChart from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['adaptiveLayout', 'adjustOnZoom', 'animation', 'annotations',
        'argumentAxis', 'autoHidePointMarkers', 'barGroupPadding',
        'barGroupWidth', 'commonAnnotationSettings', 'commonAxisSettings',
        'commonPaneSettings', 'commonSeriesSettings',
        'containerBackgroundColor', 'crosshair', 'customizeAnnotation',
        'customizeLabel', 'customizePoint', 'dataPrepareSettings', 'dataSource',
        'defaultPane', 'disabled', 'elementAttr', 'export', 'legend',
        'loadingIndicator', 'margin', 'maxBubbleSize', 'minBubbleSize',
        'negativesAsZeroes', 'onArgumentAxisClick', 'onDisposing', 'onDone',
        'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onLegendClick',
        'onOptionChanged', 'onPointClick', 'onPointHoverChanged',
        'onPointSelectionChanged', 'onSeriesClick', 'onSeriesHoverChanged',
        'onSeriesSelectionChanged', 'onTooltipHidden', 'onTooltipShown',
        'onZoomEnd', 'onZoomStart', 'palette', 'paletteExtensionMode', 'panes',
        'pathModified', 'pointSelectionMode', 'redrawOnResize',
        'resizePanesOnZoom', 'resolveLabelOverlapping', 'rotated', 'rtlEnabled',
        'scrollBar', 'series', 'seriesSelectionMode', 'seriesTemplate', 'size',
        'stickyHovering', 'synchronizeMultiAxes', 'theme', 'title', 'tooltip',
        'valueAxis', 'zoomAndPan']


class DxChartAdaptiveLayout(External):
    imports = {"import {DxAdaptiveLayout as DxChartAdaptiveLayout} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['height', 'keepLabels', 'width']


class DxChartAggregation(External):
    imports = {"import {DxAggregation as DxChartAggregation} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['calculate', 'enabled', 'method']


class DxChartAggregationInterval(External):
    imports = {"import {DxAggregationInterval as DxChartAggregationInterval} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxChartAnimation(External):
    imports = {"import {DxAnimation as DxChartAnimation} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['duration', 'easing', 'enabled', 'maxPointCountSupported']


class DxChartAnnotation(External):
    imports = {"import {DxAnnotation as DxChartAnnotation} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['allowDragging', 'argument', 'arrowLength', 'arrowWidth', 'axis',
        'border', 'color', 'customizeTooltip', 'data', 'description', 'font',
        'height', 'image', 'name', 'offsetX', 'offsetY', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'series', 'shadow', 'template',
        'text', 'textOverflow', 'tooltipEnabled', 'tooltipTemplate', 'type',
        'value', 'width', 'wordWrap', 'x', 'y']


class DxChartAnnotationBorder(External):
    imports = {"import {DxAnnotationBorder as DxChartAnnotationBorder} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxChartAnnotationImage(External):
    imports = {"import {DxAnnotationImage as DxChartAnnotationImage} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxChartArgumentAxis(External):
    imports = {"import {DxArgumentAxis as DxChartArgumentAxis} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['aggregateByCategory', 'aggregatedPointsPosition',
        'aggregationGroupWidth', 'aggregationInterval', 'allowDecimals',
        'argumentType', 'axisDivisionFactor', 'breaks', 'breakStyle',
        'categories', 'color', 'constantLines', 'constantLineStyle',
        'customPosition', 'customPositionAxis', 'discreteAxisDivisionMode',
        'endOnTick', 'grid', 'holidays', 'hoverMode', 'inverted', 'label',
        'linearThreshold', 'logarithmBase', 'maxValueMargin', 'minorGrid',
        'minorTick', 'minorTickCount', 'minorTickInterval', 'minValueMargin',
        'minVisualRangeLength', 'offset', 'opacity', 'placeholderSize',
        'position', 'singleWorkdays', 'strips', 'stripStyle', 'tick',
        'tickInterval', 'title', 'type', 'valueMarginsEnabled', 'visible',
        'visualRange', 'visualRangeUpdateMode', 'wholeRange', 'width',
        'workdaysOnly', 'workWeek']


class DxChartArgumentFormat(External):
    imports = {"import {DxArgumentFormat as DxChartArgumentFormat} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxChartAxisConstantLineStyle(External):
    imports = {"import {DxAxisConstantLineStyle as DxChartAxisConstantLineStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'label', 'paddingLeftRight', 'paddingTopBottom', 'width']


class DxChartAxisConstantLineStyleLabel(External):
    imports = {"import {DxAxisConstantLineStyleLabel as DxChartAxisConstantLineStyleLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'position', 'verticalAlignment', 'visible']


class DxChartAxisLabel(External):
    imports = {"import {DxAxisLabel as DxChartAxisLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['alignment', 'customizeHint', 'customizeText', 'displayMode', 'font',
        'format', 'indentFromAxis', 'overlappingBehavior', 'position',
        'rotationAngle', 'staggeringSpacing', 'template', 'textOverflow',
        'visible', 'wordWrap']


class DxChartAxisTitle(External):
    imports = {"import {DxAxisTitle as DxChartAxisTitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['alignment', 'font', 'margin', 'text', 'textOverflow', 'wordWrap']


class DxChartBackgroundColor(External):
    imports = {"import {DxBackgroundColor as DxChartBackgroundColor} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['base', 'fillId']


class DxChartBorder(External):
    imports = {"import {DxBorder as DxChartBorder} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['bottom', 'color', 'cornerRadius', 'dashStyle', 'left', 'opacity',
        'right', 'top', 'visible', 'width']


class DxChartBreak(External):
    imports = {"import {DxBreak as DxChartBreak} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['endValue', 'startValue']


class DxChartBreakStyle(External):
    imports = {"import {DxBreakStyle as DxChartBreakStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'line', 'width']


class DxChartTitle(External):
    imports = {"import {DxChartTitle as DxChartTitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxChartTitleSubtitle(External):
    imports = {"import {DxChartTitleSubtitle as DxChartTitleSubtitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxChartColor(External):
    imports = {"import {DxColor as DxChartColor} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['base', 'fillId']


class DxChartCommonAnnotationSettings(External):
    imports = {"import {DxCommonAnnotationSettings as DxChartCommonAnnotationSettings} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['allowDragging', 'argument', 'arrowLength', 'arrowWidth', 'axis',
        'border', 'color', 'customizeTooltip', 'data', 'description', 'font',
        'height', 'image', 'offsetX', 'offsetY', 'opacity', 'paddingLeftRight',
        'paddingTopBottom', 'series', 'shadow', 'template', 'text',
        'textOverflow', 'tooltipEnabled', 'tooltipTemplate', 'type', 'value',
        'width', 'wordWrap', 'x', 'y']


class DxChartCommonAxisSettings(External):
    imports = {"import {DxCommonAxisSettings as DxChartCommonAxisSettings} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['aggregatedPointsPosition', 'allowDecimals', 'breakStyle', 'color',
        'constantLineStyle', 'discreteAxisDivisionMode', 'endOnTick', 'grid',
        'inverted', 'label', 'maxValueMargin', 'minorGrid', 'minorTick',
        'minValueMargin', 'opacity', 'placeholderSize', 'stripStyle', 'tick',
        'title', 'valueMarginsEnabled', 'visible', 'width']


class DxChartCommonAxisSettingsConstantLineStyle(External):
    imports = {"import {DxCommonAxisSettingsConstantLineStyle as DxChartCommonAxisSettingsConstantLineStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'label', 'paddingLeftRight', 'paddingTopBottom', 'width']


class DxChartCommonAxisSettingsConstantLineStyleLabel(External):
    imports = {"import {DxCommonAxisSettingsConstantLineStyleLabel as DxChartCommonAxisSettingsConstantLineStyleLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'position', 'visible']


class DxChartCommonAxisSettingsLabel(External):
    imports = {"import {DxCommonAxisSettingsLabel as DxChartCommonAxisSettingsLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['alignment', 'displayMode', 'font', 'indentFromAxis',
        'overlappingBehavior', 'position', 'rotationAngle', 'staggeringSpacing',
        'template', 'textOverflow', 'visible', 'wordWrap']


class DxChartCommonAxisSettingsTitle(External):
    imports = {"import {DxCommonAxisSettingsTitle as DxChartCommonAxisSettingsTitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['alignment', 'font', 'margin', 'textOverflow', 'wordWrap']


class DxChartCommonPaneSettings(External):
    imports = {"import {DxCommonPaneSettings as DxChartCommonPaneSettings} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['backgroundColor', 'border']


class DxChartCommonSeriesSettings(External):
    imports = {"import {DxCommonSeriesSettings as DxChartCommonSeriesSettings} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['aggregation', 'area', 'argumentField', 'axis', 'bar',
        'barOverlapGroup', 'barPadding', 'barWidth', 'border', 'bubble',
        'candlestick', 'closeValueField', 'color', 'cornerRadius', 'dashStyle',
        'fullstackedarea', 'fullstackedbar', 'fullstackedline',
        'fullstackedspline', 'fullstackedsplinearea', 'highValueField',
        'hoverMode', 'hoverStyle', 'ignoreEmptyPoints', 'innerColor', 'label',
        'line', 'lowValueField', 'maxLabelCount', 'minBarSize', 'opacity',
        'openValueField', 'pane', 'point', 'rangearea', 'rangebar',
        'rangeValue1Field', 'rangeValue2Field', 'reduction', 'scatter',
        'selectionMode', 'selectionStyle', 'showInLegend', 'sizeField',
        'spline', 'splinearea', 'stack', 'stackedarea', 'stackedbar',
        'stackedline', 'stackedspline', 'stackedsplinearea', 'steparea',
        'stepline', 'stock', 'tagField', 'type', 'valueErrorBar', 'valueField',
        'visible', 'width']


class DxChartCommonSeriesSettingsHoverStyle(External):
    imports = {"import {DxCommonSeriesSettingsHoverStyle as DxChartCommonSeriesSettingsHoverStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'width']


class DxChartCommonSeriesSettingsLabel(External):
    imports = {"import {DxCommonSeriesSettingsLabel as DxChartCommonSeriesSettingsLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['alignment', 'argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeText', 'displayFormat', 'font', 'format', 'horizontalOffset',
        'position', 'rotationAngle', 'showForZeroValues', 'verticalOffset',
        'visible']


class DxChartCommonSeriesSettingsSelectionStyle(External):
    imports = {"import {DxCommonSeriesSettingsSelectionStyle as DxChartCommonSeriesSettingsSelectionStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'width']


class DxChartConnector(External):
    imports = {"import {DxConnector as DxChartConnector} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxChartConstantLine(External):
    imports = {"import {DxConstantLine as DxChartConstantLine} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'displayBehindSeries', 'extendAxis', 'label',
        'paddingLeftRight', 'paddingTopBottom', 'value', 'width']


class DxChartConstantLineLabel(External):
    imports = {"import {DxConstantLineLabel as DxChartConstantLineLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'position', 'text', 'verticalAlignment',
        'visible']


class DxChartConstantLineStyle(External):
    imports = {"import {DxConstantLineStyle as DxChartConstantLineStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'label', 'paddingLeftRight', 'paddingTopBottom', 'width']


class DxChartCrosshair(External):
    imports = {"import {DxCrosshair as DxChartCrosshair} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'enabled', 'horizontalLine', 'label', 'opacity',
        'verticalLine', 'width']


class DxChartDataPrepareSettings(External):
    imports = {"import {DxDataPrepareSettings as DxChartDataPrepareSettings} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['checkTypeForAllData', 'convertToAxisDataType', 'sortingMethod']


class DxChartDragBoxStyle(External):
    imports = {"import {DxDragBoxStyle as DxChartDragBoxStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'opacity']


class DxChartExport(External):
    imports = {"import {DxExport as DxChartExport} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxChartFont(External):
    imports = {"import {DxFont as DxChartFont} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxChartFormat(External):
    imports = {"import {DxFormat as DxChartFormat} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxChartGrid(External):
    imports = {"import {DxGrid as DxChartGrid} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'opacity', 'visible', 'width']


class DxChartHatching(External):
    imports = {"import {DxHatching as DxChartHatching} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['direction', 'opacity', 'step', 'width']


class DxChartHeight(External):
    imports = {"import {DxHeight as DxChartHeight} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['rangeMaxPoint', 'rangeMinPoint']


class DxChartHorizontalLine(External):
    imports = {"import {DxHorizontalLine as DxChartHorizontalLine} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'label', 'opacity', 'visible', 'width']


class DxChartHorizontalLineLabel(External):
    imports = {"import {DxHorizontalLineLabel as DxChartHorizontalLineLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['backgroundColor', 'customizeText', 'font', 'format', 'visible']


class DxChartHoverStyle(External):
    imports = {"import {DxHoverStyle as DxChartHoverStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'size', 'width']


class DxChartImage(External):
    imports = {"import {DxImage as DxChartImage} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxChartLabel(External):
    imports = {"import {DxLabel as DxChartLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['alignment', 'argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeHint', 'customizeText', 'displayFormat', 'displayMode',
        'font', 'format', 'horizontalAlignment', 'horizontalOffset',
        'indentFromAxis', 'overlappingBehavior', 'position', 'rotationAngle',
        'showForZeroValues', 'staggeringSpacing', 'template', 'text',
        'textOverflow', 'verticalAlignment', 'verticalOffset', 'visible',
        'wordWrap']


class DxChartLegend(External):
    imports = {"import {DxLegend as DxChartLegend} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'columnCount', 'columnItemSpacing',
        'customizeHint', 'customizeItems', 'customizeText', 'font',
        'horizontalAlignment', 'hoverMode', 'itemsAlignment',
        'itemTextPosition', 'margin', 'markerSize', 'markerTemplate',
        'orientation', 'paddingLeftRight', 'paddingTopBottom', 'position',
        'rowCount', 'rowItemSpacing', 'title', 'verticalAlignment', 'visible']


class DxChartLegendTitle(External):
    imports = {"import {DxLegendTitle as DxChartLegendTitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'verticalAlignment']


class DxChartLegendTitleSubtitle(External):
    imports = {"import {DxLegendTitleSubtitle as DxChartLegendTitleSubtitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'offset', 'text']


class DxChartLength(External):
    imports = {"import {DxLength as DxChartLength} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxChartLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxChartLoadingIndicator} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxChartMargin(External):
    imports = {"import {DxMargin as DxChartMargin} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxChartMinorGrid(External):
    imports = {"import {DxMinorGrid as DxChartMinorGrid} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'opacity', 'visible', 'width']


class DxChartMinorTick(External):
    imports = {"import {DxMinorTick as DxChartMinorTick} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'shift', 'visible', 'width']


class DxChartMinorTickInterval(External):
    imports = {"import {DxMinorTickInterval as DxChartMinorTickInterval} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxChartMinVisualRangeLength(External):
    imports = {"import {DxMinVisualRangeLength as DxChartMinVisualRangeLength} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxChartPane(External):
    imports = {"import {DxPane as DxChartPane} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'height', 'name']


class DxChartPaneBorder(External):
    imports = {"import {DxPaneBorder as DxChartPaneBorder} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['bottom', 'color', 'dashStyle', 'left', 'opacity', 'right', 'top',
        'visible', 'width']


class DxChartPoint(External):
    imports = {"import {DxPoint as DxChartPoint} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'hoverMode', 'hoverStyle', 'image', 'selectionMode',
        'selectionStyle', 'size', 'symbol', 'visible']


class DxChartPointBorder(External):
    imports = {"import {DxPointBorder as DxChartPointBorder} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxChartPointHoverStyle(External):
    imports = {"import {DxPointHoverStyle as DxChartPointHoverStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'size']


class DxChartPointImage(External):
    imports = {"import {DxPointImage as DxChartPointImage} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxChartPointSelectionStyle(External):
    imports = {"import {DxPointSelectionStyle as DxChartPointSelectionStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'size']


class DxChartReduction(External):
    imports = {"import {DxReduction as DxChartReduction} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'level']


class DxChartScrollBar(External):
    imports = {"import {DxScrollBar as DxChartScrollBar} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'offset', 'opacity', 'position', 'visible', 'width']


class DxChartSelectionStyle(External):
    imports = {"import {DxSelectionStyle as DxChartSelectionStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'size', 'width']


class DxChartSeries(External):
    imports = {"import {DxSeries as DxChartSeries} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['aggregation', 'argumentField', 'axis', 'barOverlapGroup', 'barPadding',
        'barWidth', 'border', 'closeValueField', 'color', 'cornerRadius',
        'dashStyle', 'highValueField', 'hoverMode', 'hoverStyle',
        'ignoreEmptyPoints', 'innerColor', 'label', 'lowValueField',
        'maxLabelCount', 'minBarSize', 'name', 'opacity', 'openValueField',
        'pane', 'point', 'rangeValue1Field', 'rangeValue2Field', 'reduction',
        'selectionMode', 'selectionStyle', 'showInLegend', 'sizeField', 'stack',
        'tag', 'tagField', 'type', 'valueErrorBar', 'valueField', 'visible',
        'width']


class DxChartSeriesBorder(External):
    imports = {"import {DxSeriesBorder as DxChartSeriesBorder} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'visible', 'width']


class DxChartSeriesTemplate(External):
    imports = {"import {DxSeriesTemplate as DxChartSeriesTemplate} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['customizeSeries', 'nameField']


class DxChartShadow(External):
    imports = {"import {DxShadow as DxChartShadow} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxChartSize(External):
    imports = {"import {DxSize as DxChartSize} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['height', 'width']


class DxChartStrip(External):
    imports = {"import {DxStrip as DxChartStrip} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'endValue', 'label', 'paddingLeftRight', 'paddingTopBottom',
        'startValue']


class DxChartStripLabel(External):
    imports = {"import {DxStripLabel as DxChartStripLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'text', 'verticalAlignment']


class DxChartStripStyle(External):
    imports = {"import {DxStripStyle as DxChartStripStyle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['label', 'paddingLeftRight', 'paddingTopBottom']


class DxChartStripStyleLabel(External):
    imports = {"import {DxStripStyleLabel as DxChartStripStyleLabel} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'verticalAlignment']


class DxChartSubtitle(External):
    imports = {"import {DxSubtitle as DxChartSubtitle} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxChartTick(External):
    imports = {"import {DxTick as DxChartTick} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'shift', 'visible', 'width']


class DxChartTickInterval(External):
    imports = {"import {DxTickInterval as DxChartTickInterval} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxChartTooltip(External):
    imports = {"import {DxTooltip as DxChartTooltip} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['argumentFormat', 'arrowLength', 'border', 'color', 'container',
        'contentTemplate', 'cornerRadius', 'customizeTooltip', 'enabled',
        'font', 'format', 'interactive', 'location', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'shadow', 'shared', 'zIndex']


class DxChartTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxChartTooltipBorder} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxChartUrl(External):
    imports = {"import {DxUrl as DxChartUrl} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['rangeMaxPoint', 'rangeMinPoint']


class DxChartValueAxis(External):
    imports = {"import {DxValueAxis as DxChartValueAxis} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['aggregatedPointsPosition', 'allowDecimals', 'autoBreaksEnabled',
        'axisDivisionFactor', 'breaks', 'breakStyle', 'categories', 'color',
        'constantLines', 'constantLineStyle', 'customPosition',
        'discreteAxisDivisionMode', 'endOnTick', 'grid', 'inverted', 'label',
        'linearThreshold', 'logarithmBase', 'maxAutoBreakCount',
        'maxValueMargin', 'minorGrid', 'minorTick', 'minorTickCount',
        'minorTickInterval', 'minValueMargin', 'minVisualRangeLength',
        'multipleAxesSpacing', 'name', 'offset', 'opacity', 'pane',
        'placeholderSize', 'position', 'showZero', 'strips', 'stripStyle',
        'synchronizedValue', 'tick', 'tickInterval', 'title', 'type',
        'valueMarginsEnabled', 'valueType', 'visible', 'visualRange',
        'visualRangeUpdateMode', 'wholeRange', 'width']


class DxChartValueErrorBar(External):
    imports = {"import {DxValueErrorBar as DxChartValueErrorBar} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'displayMode', 'edgeLength', 'highValueField', 'lineWidth',
        'lowValueField', 'opacity', 'type', 'value']


class DxChartVerticalLine(External):
    imports = {"import {DxVerticalLine as DxChartVerticalLine} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'label', 'opacity', 'visible', 'width']


class DxChartVisualRange(External):
    imports = {"import {DxVisualRange as DxChartVisualRange} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['endValue', 'length', 'startValue']


class DxChartWholeRange(External):
    imports = {"import {DxWholeRange as DxChartWholeRange} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['endValue', 'length', 'startValue']


class DxChartWidth(External):
    imports = {"import {DxWidth as DxChartWidth} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['rangeMaxPoint', 'rangeMinPoint']


class DxChartZoomAndPan(External):
    imports = {"import {DxZoomAndPan as DxChartZoomAndPan} from 'devextreme-vue/chart'"}
    attrs = common_attrs + ['allowMouseWheel', 'allowTouchGestures', 'argumentAxis', 'dragBoxStyle',
        'dragToZoom', 'panKey', 'valueAxis']



