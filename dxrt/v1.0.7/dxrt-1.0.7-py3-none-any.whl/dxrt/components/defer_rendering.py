# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDeferRendering', 'DxDeferRenderingAnimation', 'DxDeferRenderingAt',
 'DxDeferRenderingBoundaryOffset', 'DxDeferRenderingCollision', 'DxDeferRenderingFrom',
 'DxDeferRenderingMy', 'DxDeferRenderingOffset', 'DxDeferRenderingPosition', 'DxDeferRenderingTo']

common_attrs = ['key']


class DxDeferRendering(External):
    imports = {"import DxDeferRendering from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animation', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'onContentReady', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onRendered', 'onShown', 'renderWhen', 'rtlEnabled',
        'showLoadIndicator', 'staggerItemSelector', 'tabIndex', 'visible',
        'width']


class DxDeferRenderingAnimation(External):
    imports = {"import {DxAnimation as DxDeferRenderingAnimation} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDeferRenderingAt(External):
    imports = {"import {DxAt as DxDeferRenderingAt} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['x', 'y']


class DxDeferRenderingBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxDeferRenderingBoundaryOffset} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['x', 'y']


class DxDeferRenderingCollision(External):
    imports = {"import {DxCollision as DxDeferRenderingCollision} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['x', 'y']


class DxDeferRenderingFrom(External):
    imports = {"import {DxFrom as DxDeferRenderingFrom} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDeferRenderingMy(External):
    imports = {"import {DxMy as DxDeferRenderingMy} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['x', 'y']


class DxDeferRenderingOffset(External):
    imports = {"import {DxOffset as DxDeferRenderingOffset} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['x', 'y']


class DxDeferRenderingPosition(External):
    imports = {"import {DxPosition as DxDeferRenderingPosition} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxDeferRenderingTo(External):
    imports = {"import {DxTo as DxDeferRenderingTo} from 'devextreme-vue/defer-rendering'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']



