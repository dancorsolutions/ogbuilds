# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxContextMenu', 'DxContextMenuAnimation', 'DxContextMenuAt', 'DxContextMenuBoundaryOffset',
 'DxContextMenuCollision', 'DxContextMenuDelay', 'DxContextMenuFrom', 'DxContextMenuHide',
 'DxContextMenuItem', 'DxContextMenuMy', 'DxContextMenuOffset', 'DxContextMenuPosition',
 'DxContextMenuShow', 'DxContextMenuShowEvent', 'DxContextMenuShowSubmenuMode', 'DxContextMenuTo']

common_attrs = ['key']


class DxContextMenu(External):
    imports = {"import DxContextMenu from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animation', 'closeOnOutsideClick',
        'cssClass', 'dataSource', 'disabled', 'disabledExpr', 'displayExpr',
        'elementAttr', 'focusStateEnabled', 'height', 'hideOnOutsideClick',
        'hint', 'hoverStateEnabled', 'items', 'itemsExpr', 'itemTemplate',
        'onContentReady', 'onDisposing', 'onHidden', 'onHiding',
        'onInitialized', 'onItemClick', 'onItemContextMenu', 'onItemRendered',
        'onOptionChanged', 'onPositioning', 'onSelectionChanged', 'onShowing',
        'onShown', 'position', 'rtlEnabled', 'selectByClick', 'selectedExpr',
        'selectedItem', 'selectionMode', 'showEvent', 'showSubmenuMode',
        'submenuDirection', 'tabIndex', 'target', 'visible', 'width']


class DxContextMenuAnimation(External):
    imports = {"import {DxAnimation as DxContextMenuAnimation} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['hide', 'show']


class DxContextMenuAt(External):
    imports = {"import {DxAt as DxContextMenuAt} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['x', 'y']


class DxContextMenuBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxContextMenuBoundaryOffset} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['x', 'y']


class DxContextMenuCollision(External):
    imports = {"import {DxCollision as DxContextMenuCollision} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['x', 'y']


class DxContextMenuDelay(External):
    imports = {"import {DxDelay as DxContextMenuDelay} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['hide', 'show']


class DxContextMenuFrom(External):
    imports = {"import {DxFrom as DxContextMenuFrom} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxContextMenuHide(External):
    imports = {"import {DxHide as DxContextMenuHide} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxContextMenuItem(External):
    imports = {"import {DxItem as DxContextMenuItem} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'disabled', 'icon', 'items',
        'selectable', 'selected', 'template', 'text', 'visible']


class DxContextMenuMy(External):
    imports = {"import {DxMy as DxContextMenuMy} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['x', 'y']


class DxContextMenuOffset(External):
    imports = {"import {DxOffset as DxContextMenuOffset} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['x', 'y']


class DxContextMenuPosition(External):
    imports = {"import {DxPosition as DxContextMenuPosition} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxContextMenuShow(External):
    imports = {"import {DxShow as DxContextMenuShow} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxContextMenuShowEvent(External):
    imports = {"import {DxShowEvent as DxContextMenuShowEvent} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['delay', 'name']


class DxContextMenuShowSubmenuMode(External):
    imports = {"import {DxShowSubmenuMode as DxContextMenuShowSubmenuMode} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['delay', 'name']


class DxContextMenuTo(External):
    imports = {"import {DxTo as DxContextMenuTo} from 'devextreme-vue/context-menu'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']



