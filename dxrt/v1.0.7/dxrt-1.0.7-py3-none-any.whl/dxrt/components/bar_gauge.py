# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxBarGauge', 'DxBarGaugeAnimation', 'DxBarGaugeTitle', 'DxBarGaugeTitleSubtitle',
 'DxBarGaugeBorder', 'DxBarGaugeExport', 'DxBarGaugeFont', 'DxBarGaugeFormat', 'DxBarGaugeGeometry',
 'DxBarGaugeItemTextFormat', 'DxBarGaugeLabel', 'DxBarGaugeLegend', 'DxBarGaugeLegendBorder',
 'DxBarGaugeLegendTitle', 'DxBarGaugeLegendTitleSubtitle', 'DxBarGaugeLoadingIndicator',
 'DxBarGaugeMargin', 'DxBarGaugeShadow', 'DxBarGaugeSize', 'DxBarGaugeSubtitle',
 'DxBarGaugeTooltip', 'DxBarGaugeTooltipBorder']

common_attrs = ['key']


class DxBarGauge(External):
    imports = {"import DxBarGauge from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['animation', 'backgroundColor', 'barSpacing', 'baseValue',
        'centerTemplate', 'disabled', 'elementAttr', 'endValue', 'export',
        'geometry', 'label', 'legend', 'loadingIndicator', 'margin',
        'onDisposing', 'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onOptionChanged',
        'onTooltipHidden', 'onTooltipShown', 'palette', 'paletteExtensionMode',
        'pathModified', 'redrawOnResize', 'relativeInnerRadius',
        'resolveLabelOverlapping', 'rtlEnabled', 'size', 'startValue', 'theme',
        'title', 'tooltip', 'values']


class DxBarGaugeAnimation(External):
    imports = {"import {DxAnimation as DxBarGaugeAnimation} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['duration', 'easing', 'enabled']


class DxBarGaugeTitle(External):
    imports = {"import {DxBarGaugeTitle as DxBarGaugeTitle} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxBarGaugeTitleSubtitle(External):
    imports = {"import {DxBarGaugeTitleSubtitle as DxBarGaugeTitleSubtitle} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxBarGaugeBorder(External):
    imports = {"import {DxBorder as DxBarGaugeBorder} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxBarGaugeExport(External):
    imports = {"import {DxExport as DxBarGaugeExport} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxBarGaugeFont(External):
    imports = {"import {DxFont as DxBarGaugeFont} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxBarGaugeFormat(External):
    imports = {"import {DxFormat as DxBarGaugeFormat} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxBarGaugeGeometry(External):
    imports = {"import {DxGeometry as DxBarGaugeGeometry} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['endAngle', 'startAngle']


class DxBarGaugeItemTextFormat(External):
    imports = {"import {DxItemTextFormat as DxBarGaugeItemTextFormat} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxBarGaugeLabel(External):
    imports = {"import {DxLabel as DxBarGaugeLabel} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['connectorColor', 'connectorWidth', 'customizeText', 'font', 'format',
        'indent', 'visible']


class DxBarGaugeLegend(External):
    imports = {"import {DxLegend as DxBarGaugeLegend} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'columnCount', 'columnItemSpacing',
        'customizeHint', 'customizeItems', 'customizeText', 'font',
        'horizontalAlignment', 'itemsAlignment', 'itemTextFormat',
        'itemTextPosition', 'margin', 'markerSize', 'markerTemplate',
        'orientation', 'paddingLeftRight', 'paddingTopBottom', 'rowCount',
        'rowItemSpacing', 'title', 'verticalAlignment', 'visible']


class DxBarGaugeLegendBorder(External):
    imports = {"import {DxLegendBorder as DxBarGaugeLegendBorder} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxBarGaugeLegendTitle(External):
    imports = {"import {DxLegendTitle as DxBarGaugeLegendTitle} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'verticalAlignment']


class DxBarGaugeLegendTitleSubtitle(External):
    imports = {"import {DxLegendTitleSubtitle as DxBarGaugeLegendTitleSubtitle} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['font', 'offset', 'text']


class DxBarGaugeLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxBarGaugeLoadingIndicator} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'font', 'show', 'text']


class DxBarGaugeMargin(External):
    imports = {"import {DxMargin as DxBarGaugeMargin} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxBarGaugeShadow(External):
    imports = {"import {DxShadow as DxBarGaugeShadow} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxBarGaugeSize(External):
    imports = {"import {DxSize as DxBarGaugeSize} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['height', 'width']


class DxBarGaugeSubtitle(External):
    imports = {"import {DxSubtitle as DxBarGaugeSubtitle} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxBarGaugeTooltip(External):
    imports = {"import {DxTooltip as DxBarGaugeTooltip} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'interactive', 'opacity', 'paddingLeftRight', 'paddingTopBottom',
        'shadow', 'zIndex']


class DxBarGaugeTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxBarGaugeTooltipBorder} from 'devextreme-vue/bar-gauge'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']



