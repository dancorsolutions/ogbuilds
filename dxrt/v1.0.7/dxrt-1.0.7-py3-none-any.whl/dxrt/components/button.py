# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxButton']

common_attrs = ['key']


class DxButton(External):
    imports = {"import DxButton from 'devextreme-vue/button'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'icon',
        'onClick', 'onContentReady', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'rtlEnabled', 'stylingMode', 'tabIndex', 'template',
        'text', 'type', 'useSubmitBehavior', 'validationGroup', 'visible',
        'width']



