# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxRadioGroup', 'DxRadioGroupItem']

common_attrs = ['key']


class DxRadioGroup(External):
    imports = {"import DxRadioGroup from 'devextreme-vue/radio-group'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'dataSource', 'disabled',
        'displayExpr', 'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'isValid', 'items', 'itemTemplate', 'layout',
        'name', 'onContentReady', 'onDisposing', 'onInitialized',
        'onOptionChanged', 'onValueChanged', 'readOnly', 'rtlEnabled',
        'tabIndex', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'valueExpr', 'visible', 'width',
        'modelValue']


class DxRadioGroupItem(External):
    imports = {"import {DxItem as DxRadioGroupItem} from 'devextreme-vue/radio-group'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text', 'visible']



