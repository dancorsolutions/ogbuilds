# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSlideOut', 'DxSlideOutItem']

common_attrs = ['key']


class DxSlideOut(External):
    imports = {"import DxSlideOut from 'devextreme-vue/slide-out'"}
    attrs = common_attrs + ['activeStateEnabled', 'contentTemplate', 'dataSource', 'disabled',
        'elementAttr', 'height', 'hint', 'hoverStateEnabled', 'itemHoldTimeout',
        'items', 'itemTemplate', 'menuGrouped', 'menuGroupTemplate',
        'menuItemTemplate', 'menuPosition', 'menuVisible', 'noDataText',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered',
        'onMenuGroupRendered', 'onMenuItemRendered', 'onOptionChanged',
        'onSelectionChanged', 'rtlEnabled', 'selectedIndex', 'selectedItem',
        'swipeEnabled', 'visible', 'width']


class DxSlideOutItem(External):
    imports = {"import {DxItem as DxSlideOutItem} from 'devextreme-vue/slide-out'"}
    attrs = common_attrs + ['disabled', 'html', 'menuTemplate', 'template', 'text', 'visible']



