# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDropDownBox', 'DxDropDownBoxAnimation', 'DxDropDownBoxAt', 'DxDropDownBoxBoundaryOffset',
 'DxDropDownBoxButton', 'DxDropDownBoxCollision', 'DxDropDownBoxDropDownOptions',
 'DxDropDownBoxFrom', 'DxDropDownBoxHide', 'DxDropDownBoxMy', 'DxDropDownBoxOffset',
 'DxDropDownBoxOptions', 'DxDropDownBoxPosition', 'DxDropDownBoxShow', 'DxDropDownBoxTo',
 'DxDropDownBoxToolbarItem']

common_attrs = ['key']


class DxDropDownBox(External):
    imports = {"import DxDropDownBox from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['acceptCustomValue', 'accessKey', 'activeStateEnabled', 'buttons',
        'contentTemplate', 'dataSource', 'deferRendering', 'disabled',
        'displayExpr', 'displayValueFormatter', 'dropDownButtonTemplate',
        'dropDownOptions', 'elementAttr', 'fieldTemplate', 'focusStateEnabled',
        'height', 'hint', 'hoverStateEnabled', 'inputAttr', 'isValid', 'items',
        'label', 'labelMode', 'maxLength', 'name', 'onChange', 'onClosed',
        'onCopy', 'onCut', 'onDisposing', 'onEnterKey', 'onFocusIn',
        'onFocusOut', 'onInitialized', 'onInput', 'onKeyDown', 'onKeyUp',
        'onOpened', 'onOptionChanged', 'onPaste', 'onValueChanged', 'opened',
        'openOnFieldClick', 'placeholder', 'readOnly', 'rtlEnabled',
        'showClearButton', 'showDropDownButton', 'stylingMode', 'tabIndex',
        'text', 'validationError', 'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'valueExpr', 'visible', 'width', 'modelValue']


class DxDropDownBoxAnimation(External):
    imports = {"import {DxAnimation as DxDropDownBoxAnimation} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['hide', 'show']


class DxDropDownBoxAt(External):
    imports = {"import {DxAt as DxDropDownBoxAt} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownBoxBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxDropDownBoxBoundaryOffset} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownBoxButton(External):
    imports = {"import {DxButton as DxDropDownBoxButton} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxDropDownBoxCollision(External):
    imports = {"import {DxCollision as DxDropDownBoxCollision} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownBoxDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxDropDownBoxDropDownOptions} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxDropDownBoxFrom(External):
    imports = {"import {DxFrom as DxDropDownBoxFrom} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDropDownBoxHide(External):
    imports = {"import {DxHide as DxDropDownBoxHide} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDropDownBoxMy(External):
    imports = {"import {DxMy as DxDropDownBoxMy} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownBoxOffset(External):
    imports = {"import {DxOffset as DxDropDownBoxOffset} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['x', 'y']


class DxDropDownBoxOptions(External):
    imports = {"import {DxOptions as DxDropDownBoxOptions} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxDropDownBoxPosition(External):
    imports = {"import {DxPosition as DxDropDownBoxPosition} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxDropDownBoxShow(External):
    imports = {"import {DxShow as DxDropDownBoxShow} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxDropDownBoxTo(External):
    imports = {"import {DxTo as DxDropDownBoxTo} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxDropDownBoxToolbarItem(External):
    imports = {"import {DxToolbarItem as DxDropDownBoxToolbarItem} from 'devextreme-vue/drop-down-box'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



