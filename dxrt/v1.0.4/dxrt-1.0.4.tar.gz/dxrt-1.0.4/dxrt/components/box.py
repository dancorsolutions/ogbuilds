# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxBox', 'DxBoxItem']

common_attrs = ['key']


class DxBox(External):
    imports = {"import DxBox from 'devextreme-vue/box'"}
    attrs = common_attrs + ['align', 'crossAlign', 'dataSource', 'direction', 'disabled',
        'elementAttr', 'height', 'hoverStateEnabled', 'itemHoldTimeout',
        'items', 'itemTemplate', 'onContentReady', 'onDisposing',
        'onInitialized', 'onItemClick', 'onItemContextMenu', 'onItemHold',
        'onItemRendered', 'onOptionChanged', 'rtlEnabled', 'visible', 'width']


class DxBoxItem(External):
    imports = {"import {DxItem as DxBoxItem} from 'devextreme-vue/box'"}
    attrs = common_attrs + ['baseSize', 'box', 'disabled', 'html', 'ratio', 'shrink', 'template',
        'text', 'visible']



