# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxPivotGrid', 'DxPivotGridExport', 'DxPivotGridFieldChooser', 'DxPivotGridFieldChooserTexts',
 'DxPivotGridFieldPanel', 'DxPivotGridFieldPanelTexts', 'DxPivotGridHeaderFilter',
 'DxPivotGridHeaderFilterTexts', 'DxPivotGridLoadPanel', 'DxPivotGridTexts', 'DxPivotGridScrolling',
 'DxPivotGridSearch', 'DxPivotGridStateStoring']

common_attrs = ['key']


class DxPivotGrid(External):
    imports = {"import DxPivotGrid from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['allowExpandAll', 'allowFiltering', 'allowSorting',
        'allowSortingBySummary', 'dataFieldArea', 'dataSource', 'disabled',
        'elementAttr', 'encodeHtml', 'export', 'fieldChooser', 'fieldPanel',
        'headerFilter', 'height', 'hideEmptySummaryCells', 'hint', 'loadPanel',
        'onCellClick', 'onCellPrepared', 'onContentReady',
        'onContextMenuPreparing', 'onDisposing', 'onExporting', 'onInitialized',
        'onOptionChanged', 'rowHeaderLayout', 'rtlEnabled', 'scrolling',
        'showBorders', 'showColumnGrandTotals', 'showColumnTotals',
        'showRowGrandTotals', 'showRowTotals', 'showTotalsPrior',
        'stateStoring', 'tabIndex', 'texts', 'visible', 'width',
        'wordWrapEnabled']


class DxPivotGridExport(External):
    imports = {"import {DxExport as DxPivotGridExport} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['enabled']


class DxPivotGridFieldChooser(External):
    imports = {"import {DxFieldChooser as DxPivotGridFieldChooser} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['allowSearch', 'applyChangesMode', 'enabled', 'height', 'layout',
        'searchTimeout', 'texts', 'title', 'width']


class DxPivotGridFieldChooserTexts(External):
    imports = {"import {DxFieldChooserTexts as DxPivotGridFieldChooserTexts} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['allFields', 'columnFields', 'dataFields', 'filterFields', 'rowFields']


class DxPivotGridFieldPanel(External):
    imports = {"import {DxFieldPanel as DxPivotGridFieldPanel} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['allowFieldDragging', 'showColumnFields', 'showDataFields',
        'showFilterFields', 'showRowFields', 'texts', 'visible']


class DxPivotGridFieldPanelTexts(External):
    imports = {"import {DxFieldPanelTexts as DxPivotGridFieldPanelTexts} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['columnFieldArea', 'dataFieldArea', 'filterFieldArea', 'rowFieldArea']


class DxPivotGridHeaderFilter(External):
    imports = {"import {DxHeaderFilter as DxPivotGridHeaderFilter} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['allowSearch', 'allowSelectAll', 'height', 'search', 'searchTimeout',
        'showRelevantValues', 'texts', 'width']


class DxPivotGridHeaderFilterTexts(External):
    imports = {"import {DxHeaderFilterTexts as DxPivotGridHeaderFilterTexts} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['cancel', 'emptyValue', 'ok']


class DxPivotGridLoadPanel(External):
    imports = {"import {DxLoadPanel as DxPivotGridLoadPanel} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['enabled', 'height', 'indicatorSrc', 'shading', 'shadingColor',
        'showIndicator', 'showPane', 'text', 'width']


class DxPivotGridTexts(External):
    imports = {"import {DxPivotGridTexts as DxPivotGridTexts} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['collapseAll', 'dataNotAvailable', 'expandAll', 'exportToExcel',
        'grandTotal', 'noData', 'removeAllSorting', 'showFieldChooser',
        'sortColumnBySummary', 'sortRowBySummary', 'total']


class DxPivotGridScrolling(External):
    imports = {"import {DxScrolling as DxPivotGridScrolling} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['mode', 'useNative']


class DxPivotGridSearch(External):
    imports = {"import {DxSearch as DxPivotGridSearch} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['editorOptions', 'enabled', 'mode', 'timeout']


class DxPivotGridStateStoring(External):
    imports = {"import {DxStateStoring as DxPivotGridStateStoring} from 'devextreme-vue/pivot-grid'"}
    attrs = common_attrs + ['customLoad', 'customSave', 'enabled', 'savingTimeout', 'storageKey', 'type']



