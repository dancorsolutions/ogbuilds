# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxPieChart', 'DxPieChartAdaptiveLayout', 'DxPieChartAnimation', 'DxPieChartAnnotation',
 'DxPieChartAnnotationBorder', 'DxPieChartArgumentFormat', 'DxPieChartBorder', 'DxPieChartColor',
 'DxPieChartCommonAnnotationSettings', 'DxPieChartCommonSeriesSettings', 'DxPieChartConnector',
 'DxPieChartExport', 'DxPieChartFont', 'DxPieChartFormat', 'DxPieChartHatching',
 'DxPieChartHoverStyle', 'DxPieChartImage', 'DxPieChartLabel', 'DxPieChartLegend',
 'DxPieChartLegendTitle', 'DxPieChartLegendTitleSubtitle', 'DxPieChartLoadingIndicator',
 'DxPieChartMargin', 'DxPieChartTitle', 'DxPieChartTitleSubtitle', 'DxPieChartSelectionStyle',
 'DxPieChartSeries', 'DxPieChartSeriesBorder', 'DxPieChartSeriesTemplate', 'DxPieChartShadow',
 'DxPieChartSize', 'DxPieChartSmallValuesGrouping', 'DxPieChartSubtitle', 'DxPieChartTooltip',
 'DxPieChartTooltipBorder']

common_attrs = ['key']


class DxPieChart(External):
    imports = {"import DxPieChart from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['adaptiveLayout', 'animation', 'annotations', 'centerTemplate',
        'commonAnnotationSettings', 'commonSeriesSettings',
        'customizeAnnotation', 'customizeLabel', 'customizePoint', 'dataSource',
        'diameter', 'disabled', 'elementAttr', 'export', 'innerRadius',
        'legend', 'loadingIndicator', 'margin', 'minDiameter', 'onDisposing',
        'onDone', 'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onLegendClick',
        'onOptionChanged', 'onPointClick', 'onPointHoverChanged',
        'onPointSelectionChanged', 'onTooltipHidden', 'onTooltipShown',
        'palette', 'paletteExtensionMode', 'pathModified', 'pointSelectionMode',
        'redrawOnResize', 'resolveLabelOverlapping', 'rtlEnabled',
        'segmentsDirection', 'series', 'seriesTemplate', 'size', 'sizeGroup',
        'startAngle', 'theme', 'title', 'tooltip', 'type']


class DxPieChartAdaptiveLayout(External):
    imports = {"import {DxAdaptiveLayout as DxPieChartAdaptiveLayout} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['height', 'keepLabels', 'width']


class DxPieChartAnimation(External):
    imports = {"import {DxAnimation as DxPieChartAnimation} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['duration', 'easing', 'enabled', 'maxPointCountSupported']


class DxPieChartAnnotation(External):
    imports = {"import {DxAnnotation as DxPieChartAnnotation} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['allowDragging', 'argument', 'arrowLength', 'arrowWidth', 'border',
        'color', 'customizeTooltip', 'data', 'description', 'font', 'height',
        'image', 'location', 'name', 'offsetX', 'offsetY', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'series', 'shadow', 'template',
        'text', 'textOverflow', 'tooltipEnabled', 'tooltipTemplate', 'type',
        'width', 'wordWrap', 'x', 'y']


class DxPieChartAnnotationBorder(External):
    imports = {"import {DxAnnotationBorder as DxPieChartAnnotationBorder} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxPieChartArgumentFormat(External):
    imports = {"import {DxArgumentFormat as DxPieChartArgumentFormat} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxPieChartBorder(External):
    imports = {"import {DxBorder as DxPieChartBorder} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxPieChartColor(External):
    imports = {"import {DxColor as DxPieChartColor} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['base', 'fillId']


class DxPieChartCommonAnnotationSettings(External):
    imports = {"import {DxCommonAnnotationSettings as DxPieChartCommonAnnotationSettings} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['allowDragging', 'argument', 'arrowLength', 'arrowWidth', 'border',
        'color', 'customizeTooltip', 'data', 'description', 'font', 'height',
        'image', 'location', 'offsetX', 'offsetY', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'series', 'shadow', 'template',
        'text', 'textOverflow', 'tooltipEnabled', 'tooltipTemplate', 'type',
        'width', 'wordWrap', 'x', 'y']


class DxPieChartCommonSeriesSettings(External):
    imports = {"import {DxCommonSeriesSettings as DxPieChartCommonSeriesSettings} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['argumentField', 'argumentType', 'border', 'color', 'hoverMode',
        'hoverStyle', 'label', 'maxLabelCount', 'minSegmentSize',
        'selectionMode', 'selectionStyle', 'smallValuesGrouping', 'tagField',
        'valueField']


class DxPieChartConnector(External):
    imports = {"import {DxConnector as DxPieChartConnector} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxPieChartExport(External):
    imports = {"import {DxExport as DxPieChartExport} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxPieChartFont(External):
    imports = {"import {DxFont as DxPieChartFont} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxPieChartFormat(External):
    imports = {"import {DxFormat as DxPieChartFormat} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxPieChartHatching(External):
    imports = {"import {DxHatching as DxPieChartHatching} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['direction', 'opacity', 'step', 'width']


class DxPieChartHoverStyle(External):
    imports = {"import {DxHoverStyle as DxPieChartHoverStyle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['border', 'color', 'hatching', 'highlight']


class DxPieChartImage(External):
    imports = {"import {DxImage as DxPieChartImage} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxPieChartLabel(External):
    imports = {"import {DxLabel as DxPieChartLabel} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeText', 'displayFormat', 'font', 'format', 'position',
        'radialOffset', 'rotationAngle', 'textOverflow', 'visible', 'wordWrap']


class DxPieChartLegend(External):
    imports = {"import {DxLegend as DxPieChartLegend} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'columnCount', 'columnItemSpacing',
        'customizeHint', 'customizeItems', 'customizeText', 'font',
        'horizontalAlignment', 'hoverMode', 'itemsAlignment',
        'itemTextPosition', 'margin', 'markerSize', 'markerTemplate',
        'orientation', 'paddingLeftRight', 'paddingTopBottom', 'rowCount',
        'rowItemSpacing', 'title', 'verticalAlignment', 'visible']


class DxPieChartLegendTitle(External):
    imports = {"import {DxLegendTitle as DxPieChartLegendTitle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'verticalAlignment']


class DxPieChartLegendTitleSubtitle(External):
    imports = {"import {DxLegendTitleSubtitle as DxPieChartLegendTitleSubtitle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['font', 'offset', 'text']


class DxPieChartLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxPieChartLoadingIndicator} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxPieChartMargin(External):
    imports = {"import {DxMargin as DxPieChartMargin} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxPieChartTitle(External):
    imports = {"import {DxPieChartTitle as DxPieChartTitle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxPieChartTitleSubtitle(External):
    imports = {"import {DxPieChartTitleSubtitle as DxPieChartTitleSubtitle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxPieChartSelectionStyle(External):
    imports = {"import {DxSelectionStyle as DxPieChartSelectionStyle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['border', 'color', 'hatching', 'highlight']


class DxPieChartSeries(External):
    imports = {"import {DxSeries as DxPieChartSeries} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['argumentField', 'argumentType', 'border', 'color', 'hoverMode',
        'hoverStyle', 'label', 'maxLabelCount', 'minSegmentSize', 'name',
        'selectionMode', 'selectionStyle', 'smallValuesGrouping', 'tag',
        'tagField', 'valueField']


class DxPieChartSeriesBorder(External):
    imports = {"import {DxSeriesBorder as DxPieChartSeriesBorder} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'visible', 'width']


class DxPieChartSeriesTemplate(External):
    imports = {"import {DxSeriesTemplate as DxPieChartSeriesTemplate} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['customizeSeries', 'nameField']


class DxPieChartShadow(External):
    imports = {"import {DxShadow as DxPieChartShadow} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxPieChartSize(External):
    imports = {"import {DxSize as DxPieChartSize} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['height', 'width']


class DxPieChartSmallValuesGrouping(External):
    imports = {"import {DxSmallValuesGrouping as DxPieChartSmallValuesGrouping} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['groupName', 'mode', 'threshold', 'topCount']


class DxPieChartSubtitle(External):
    imports = {"import {DxSubtitle as DxPieChartSubtitle} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxPieChartTooltip(External):
    imports = {"import {DxTooltip as DxPieChartTooltip} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['argumentFormat', 'arrowLength', 'border', 'color', 'container',
        'contentTemplate', 'cornerRadius', 'customizeTooltip', 'enabled',
        'font', 'format', 'interactive', 'opacity', 'paddingLeftRight',
        'paddingTopBottom', 'shadow', 'shared', 'zIndex']


class DxPieChartTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxPieChartTooltipBorder} from 'devextreme-vue/pie-chart'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']



