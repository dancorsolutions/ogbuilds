# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxCheckBox']

common_attrs = ['key']


class DxCheckBox(External):
    imports = {"import DxCheckBox from 'devextreme-vue/check-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'disabled', 'elementAttr',
        'enableThreeStateBehavior', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'iconSize', 'isValid', 'name', 'onContentReady',
        'onDisposing', 'onInitialized', 'onOptionChanged', 'onValueChanged',
        'readOnly', 'rtlEnabled', 'tabIndex', 'text', 'validationError',
        'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value', 'visible',
        'width', 'modelValue']



