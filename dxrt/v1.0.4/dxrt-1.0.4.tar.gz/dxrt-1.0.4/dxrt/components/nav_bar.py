# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxNavBar', 'DxNavBarItem']

common_attrs = ['key']


class DxNavBar(External):
    imports = {"import DxNavBar from 'devextreme-vue/nav-bar'"}
    attrs = common_attrs + ['accessKey', 'dataSource', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'itemHoldTimeout', 'items', 'itemTemplate', 'keyExpr', 'noDataText',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered', 'onOptionChanged',
        'onSelectionChanged', 'repaintChangesOnly', 'rtlEnabled',
        'scrollByContent', 'selectedIndex', 'selectedItem', 'selectedItemKeys',
        'selectedItems', 'selectionMode', 'tabIndex', 'visible', 'width']


class DxNavBarItem(External):
    imports = {"import {DxItem as DxNavBarItem} from 'devextreme-vue/nav-bar'"}
    attrs = common_attrs + ['badge', 'disabled', 'html', 'icon', 'template', 'text', 'visible']



