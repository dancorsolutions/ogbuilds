# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxVectorMap', 'DxVectorMapAnnotation', 'DxVectorMapAnnotationBorder', 'DxVectorMapBackground',
 'DxVectorMapBorder', 'DxVectorMapCommonAnnotationSettings', 'DxVectorMapControlBar',
 'DxVectorMapExport', 'DxVectorMapFont', 'DxVectorMapImage', 'DxVectorMapLabel', 'DxVectorMapLayer',
 'DxVectorMapLegend', 'DxVectorMapLegendTitle', 'DxVectorMapLegendTitleSubtitle',
 'DxVectorMapLoadingIndicator', 'DxVectorMapMargin', 'DxVectorMapProjection', 'DxVectorMapShadow',
 'DxVectorMapSize', 'DxVectorMapSource', 'DxVectorMapSubtitle', 'DxVectorMapTitle',
 'DxVectorMapTooltip', 'DxVectorMapTooltipBorder', 'DxVectorMapTitleSubtitle']

common_attrs = ['key']


class DxVectorMap(External):
    imports = {"import DxVectorMap from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['annotations', 'background', 'bounds', 'center',
        'commonAnnotationSettings', 'controlBar', 'customizeAnnotation',
        'disabled', 'elementAttr', 'export', 'layers', 'legends',
        'loadingIndicator', 'maxZoomFactor', 'onCenterChanged', 'onClick',
        'onDisposing', 'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onOptionChanged',
        'onSelectionChanged', 'onTooltipHidden', 'onTooltipShown',
        'onZoomFactorChanged', 'panningEnabled', 'pathModified', 'projection',
        'redrawOnResize', 'rtlEnabled', 'size', 'theme', 'title', 'tooltip',
        'touchEnabled', 'wheelEnabled', 'zoomFactor', 'zoomingEnabled']


class DxVectorMapAnnotation(External):
    imports = {"import {DxAnnotation as DxVectorMapAnnotation} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['allowDragging', 'arrowLength', 'arrowWidth', 'border', 'color',
        'coordinates', 'customizeTooltip', 'data', 'description', 'font',
        'height', 'image', 'name', 'offsetX', 'offsetY', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'shadow', 'template', 'text',
        'textOverflow', 'tooltipEnabled', 'tooltipTemplate', 'type', 'width',
        'wordWrap', 'x', 'y']


class DxVectorMapAnnotationBorder(External):
    imports = {"import {DxAnnotationBorder as DxVectorMapAnnotationBorder} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxVectorMapBackground(External):
    imports = {"import {DxBackground as DxVectorMapBackground} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['borderColor', 'color']


class DxVectorMapBorder(External):
    imports = {"import {DxBorder as DxVectorMapBorder} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxVectorMapCommonAnnotationSettings(External):
    imports = {"import {DxCommonAnnotationSettings as DxVectorMapCommonAnnotationSettings} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['allowDragging', 'arrowLength', 'arrowWidth', 'border', 'color',
        'coordinates', 'customizeTooltip', 'data', 'description', 'font',
        'height', 'image', 'offsetX', 'offsetY', 'opacity', 'paddingLeftRight',
        'paddingTopBottom', 'shadow', 'template', 'text', 'textOverflow',
        'tooltipEnabled', 'tooltipTemplate', 'type', 'width', 'wordWrap', 'x',
        'y']


class DxVectorMapControlBar(External):
    imports = {"import {DxControlBar as DxVectorMapControlBar} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['borderColor', 'color', 'enabled', 'horizontalAlignment', 'margin',
        'opacity', 'panVisible', 'verticalAlignment', 'zoomVisible']


class DxVectorMapExport(External):
    imports = {"import {DxExport as DxVectorMapExport} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxVectorMapFont(External):
    imports = {"import {DxFont as DxVectorMapFont} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxVectorMapImage(External):
    imports = {"import {DxImage as DxVectorMapImage} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxVectorMapLabel(External):
    imports = {"import {DxLabel as DxVectorMapLabel} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['dataField', 'enabled', 'font']


class DxVectorMapLayer(External):
    imports = {"import {DxLayer as DxVectorMapLayer} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['borderColor', 'borderWidth', 'color', 'colorGroupingField',
        'colorGroups', 'customize', 'dataField', 'dataSource', 'elementType',
        'hoveredBorderColor', 'hoveredBorderWidth', 'hoveredColor',
        'hoverEnabled', 'label', 'maxSize', 'minSize', 'name', 'opacity',
        'palette', 'paletteIndex', 'paletteSize', 'selectedBorderColor',
        'selectedBorderWidth', 'selectedColor', 'selectionMode', 'size',
        'sizeGroupingField', 'sizeGroups', 'type']


class DxVectorMapLegend(External):
    imports = {"import {DxLegend as DxVectorMapLegend} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'columnCount', 'columnItemSpacing',
        'customizeHint', 'customizeItems', 'customizeText', 'font',
        'horizontalAlignment', 'itemsAlignment', 'itemTextPosition', 'margin',
        'markerColor', 'markerShape', 'markerSize', 'markerTemplate',
        'orientation', 'paddingLeftRight', 'paddingTopBottom', 'rowCount',
        'rowItemSpacing', 'source', 'title', 'verticalAlignment', 'visible']


class DxVectorMapLegendTitle(External):
    imports = {"import {DxLegendTitle as DxVectorMapLegendTitle} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'verticalAlignment']


class DxVectorMapLegendTitleSubtitle(External):
    imports = {"import {DxLegendTitleSubtitle as DxVectorMapLegendTitleSubtitle} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['font', 'offset', 'text']


class DxVectorMapLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxVectorMapLoadingIndicator} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxVectorMapMargin(External):
    imports = {"import {DxMargin as DxVectorMapMargin} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxVectorMapProjection(External):
    imports = {"import {DxProjection as DxVectorMapProjection} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['aspectRatio', 'from', 'to']


class DxVectorMapShadow(External):
    imports = {"import {DxShadow as DxVectorMapShadow} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxVectorMapSize(External):
    imports = {"import {DxSize as DxVectorMapSize} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['height', 'width']


class DxVectorMapSource(External):
    imports = {"import {DxSource as DxVectorMapSource} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['grouping', 'layer']


class DxVectorMapSubtitle(External):
    imports = {"import {DxSubtitle as DxVectorMapSubtitle} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxVectorMapTitle(External):
    imports = {"import {DxTitle as DxVectorMapTitle} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxVectorMapTooltip(External):
    imports = {"import {DxTooltip as DxVectorMapTooltip} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'shadow', 'zIndex']


class DxVectorMapTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxVectorMapTooltipBorder} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxVectorMapTitleSubtitle(External):
    imports = {"import {DxVectorMapTitleSubtitle as DxVectorMapTitleSubtitle} from 'devextreme-vue/vector-map'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']



