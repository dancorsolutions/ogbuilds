# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxHtmlEditor', 'DxHtmlEditorFileUploaderOptions', 'DxHtmlEditorImageUpload', 'DxHtmlEditorItem',
 'DxHtmlEditorMediaResizing', 'DxHtmlEditorMention', 'DxHtmlEditorTab',
 'DxHtmlEditorTableContextMenu', 'DxHtmlEditorTableContextMenuItem', 'DxHtmlEditorTableResizing',
 'DxHtmlEditorToolbar', 'DxHtmlEditorToolbarItem', 'DxHtmlEditorVariables']

common_attrs = ['key']


class DxHtmlEditor(External):
    imports = {"import DxHtmlEditor from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowSoftLineBreak',
        'customizeModules', 'disabled', 'elementAttr', 'focusStateEnabled',
        'height', 'hint', 'hoverStateEnabled', 'imageUpload', 'isValid',
        'mediaResizing', 'mentions', 'name', 'onContentReady', 'onDisposing',
        'onFocusIn', 'onFocusOut', 'onInitialized', 'onOptionChanged',
        'onValueChanged', 'placeholder', 'readOnly', 'rtlEnabled',
        'stylingMode', 'tabIndex', 'tableContextMenu', 'tableResizing',
        'toolbar', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'valueType', 'variables', 'visible',
        'width', 'modelValue']


class DxHtmlEditorFileUploaderOptions(External):
    imports = {"import {DxFileUploaderOptions as DxHtmlEditorFileUploaderOptions} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['abortUpload', 'accept', 'accessKey', 'activeStateEnabled',
        'allowCanceling', 'allowedFileExtensions', 'bindingOptions',
        'chunkSize', 'dialogTrigger', 'disabled', 'dropZone', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'inputAttr',
        'invalidFileExtensionMessage', 'invalidMaxFileSizeMessage',
        'invalidMinFileSizeMessage', 'isValid', 'labelText', 'maxFileSize',
        'minFileSize', 'multiple', 'name', 'onBeforeSend', 'onContentReady',
        'onDisposing', 'onDropZoneEnter', 'onDropZoneLeave', 'onFilesUploaded',
        'onInitialized', 'onOptionChanged', 'onProgress', 'onUploadAborted',
        'onUploaded', 'onUploadError', 'onUploadStarted', 'onValueChanged',
        'progress', 'readOnly', 'readyToUploadMessage', 'rtlEnabled',
        'selectButtonText', 'showFileList', 'tabIndex', 'uploadAbortedMessage',
        'uploadButtonText', 'uploadChunk', 'uploadCustomData',
        'uploadedMessage', 'uploadFailedMessage', 'uploadFile', 'uploadHeaders',
        'uploadMethod', 'uploadMode', 'uploadUrl', 'validationError',
        'validationErrors', 'validationStatus', 'value', 'visible', 'width']


class DxHtmlEditorImageUpload(External):
    imports = {"import {DxImageUpload as DxHtmlEditorImageUpload} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['fileUploaderOptions', 'fileUploadMode', 'tabs', 'uploadDirectory',
        'uploadUrl']


class DxHtmlEditorItem(External):
    imports = {"import {DxItem as DxHtmlEditorItem} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['acceptedValues', 'beginGroup', 'closeMenuOnClick', 'cssClass',
        'disabled', 'formatName', 'formatValues', 'html', 'icon', 'items',
        'locateInMenu', 'location', 'menuItemTemplate', 'name', 'options',
        'selectable', 'selected', 'showText', 'template', 'text', 'visible',
        'widget']


class DxHtmlEditorMediaResizing(External):
    imports = {"import {DxMediaResizing as DxHtmlEditorMediaResizing} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['allowedTargets', 'enabled']


class DxHtmlEditorMention(External):
    imports = {"import {DxMention as DxHtmlEditorMention} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['dataSource', 'displayExpr', 'itemTemplate', 'marker',
        'minSearchLength', 'searchExpr', 'searchTimeout', 'template',
        'valueExpr']


class DxHtmlEditorTab(External):
    imports = {"import {DxTab as DxHtmlEditorTab} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['name']


class DxHtmlEditorTableContextMenu(External):
    imports = {"import {DxTableContextMenu as DxHtmlEditorTableContextMenu} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['enabled', 'items']


class DxHtmlEditorTableContextMenuItem(External):
    imports = {"import {DxTableContextMenuItem as DxHtmlEditorTableContextMenuItem} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'disabled', 'icon', 'items', 'name',
        'selectable', 'selected', 'template', 'text', 'visible']


class DxHtmlEditorTableResizing(External):
    imports = {"import {DxTableResizing as DxHtmlEditorTableResizing} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['enabled', 'minColumnWidth', 'minRowHeight']


class DxHtmlEditorToolbar(External):
    imports = {"import {DxToolbar as DxHtmlEditorToolbar} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['container', 'items', 'multiline']


class DxHtmlEditorToolbarItem(External):
    imports = {"import {DxToolbarItem as DxHtmlEditorToolbarItem} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['acceptedValues', 'cssClass', 'disabled', 'formatName', 'formatValues',
        'html', 'locateInMenu', 'location', 'menuItemTemplate', 'name',
        'options', 'showText', 'template', 'text', 'visible', 'widget']


class DxHtmlEditorVariables(External):
    imports = {"import {DxVariables as DxHtmlEditorVariables} from 'devextreme-vue/html-editor'"}
    attrs = common_attrs + ['dataSource', 'escapeChar']



