# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxMultiView', 'DxMultiViewItem']

common_attrs = ['key']


class DxMultiView(External):
    imports = {"import DxMultiView from 'devextreme-vue/multi-view'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'animationEnabled', 'dataSource',
        'deferRendering', 'disabled', 'elementAttr', 'focusStateEnabled',
        'height', 'hint', 'hoverStateEnabled', 'itemHoldTimeout', 'items',
        'itemTemplate', 'loop', 'noDataText', 'onContentReady', 'onDisposing',
        'onInitialized', 'onItemClick', 'onItemContextMenu', 'onItemHold',
        'onItemRendered', 'onOptionChanged', 'onSelectionChanged', 'rtlEnabled',
        'selectedIndex', 'selectedItem', 'swipeEnabled', 'tabIndex', 'visible',
        'width']


class DxMultiViewItem(External):
    imports = {"import {DxItem as DxMultiViewItem} from 'devextreme-vue/multi-view'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text']



