# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxDrawer']

common_attrs = ['key']


class DxDrawer(External):
    imports = {"import DxDrawer from 'devextreme-vue/drawer'"}
    attrs = common_attrs + ['activeStateEnabled', 'animationDuration', 'animationEnabled',
        'closeOnOutsideClick', 'disabled', 'elementAttr', 'height', 'hint',
        'hoverStateEnabled', 'maxSize', 'minSize', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'opened', 'openedStateMode',
        'position', 'revealMode', 'rtlEnabled', 'shading', 'template',
        'visible', 'width']



