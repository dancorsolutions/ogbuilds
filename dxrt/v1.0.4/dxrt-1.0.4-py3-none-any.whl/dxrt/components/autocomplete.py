# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxAutocomplete', 'DxAutocompleteAnimation', 'DxAutocompleteAt', 'DxAutocompleteBoundaryOffset',
 'DxAutocompleteButton', 'DxAutocompleteCollision', 'DxAutocompleteDropDownOptions',
 'DxAutocompleteFrom', 'DxAutocompleteHide', 'DxAutocompleteItem', 'DxAutocompleteMy',
 'DxAutocompleteOffset', 'DxAutocompleteOptions', 'DxAutocompletePosition', 'DxAutocompleteShow',
 'DxAutocompleteTo', 'DxAutocompleteToolbarItem']

common_attrs = ['key']


class DxAutocomplete(External):
    imports = {"import DxAutocomplete from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'buttons', 'dataSource',
        'deferRendering', 'disabled', 'displayValue', 'dropDownButtonTemplate',
        'dropDownOptions', 'elementAttr', 'focusStateEnabled', 'grouped',
        'groupTemplate', 'height', 'hint', 'hoverStateEnabled', 'inputAttr',
        'isValid', 'items', 'itemTemplate', 'label', 'labelMode',
        'maxItemCount', 'maxLength', 'minSearchLength', 'name', 'onChange',
        'onClosed', 'onContentReady', 'onCopy', 'onCut', 'onDisposing',
        'onEnterKey', 'onFocusIn', 'onFocusOut', 'onInitialized', 'onInput',
        'onItemClick', 'onKeyDown', 'onKeyUp', 'onOpened', 'onOptionChanged',
        'onPaste', 'onSelectionChanged', 'onValueChanged', 'opened',
        'openOnFieldClick', 'placeholder', 'readOnly', 'rtlEnabled',
        'searchExpr', 'searchMode', 'searchTimeout', 'selectedItem',
        'showClearButton', 'showDropDownButton', 'spellcheck', 'stylingMode',
        'tabIndex', 'text', 'useItemTextAsTitle', 'validationError',
        'validationErrors', 'validationMessageMode',
        'validationMessagePosition', 'validationStatus', 'value',
        'valueChangeEvent', 'valueExpr', 'visible', 'width', 'wrapItemText',
        'modelValue']


class DxAutocompleteAnimation(External):
    imports = {"import {DxAnimation as DxAutocompleteAnimation} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['hide', 'show']


class DxAutocompleteAt(External):
    imports = {"import {DxAt as DxAutocompleteAt} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['x', 'y']


class DxAutocompleteBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxAutocompleteBoundaryOffset} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['x', 'y']


class DxAutocompleteButton(External):
    imports = {"import {DxButton as DxAutocompleteButton} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxAutocompleteCollision(External):
    imports = {"import {DxCollision as DxAutocompleteCollision} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['x', 'y']


class DxAutocompleteDropDownOptions(External):
    imports = {"import {DxDropDownOptions as DxAutocompleteDropDownOptions} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['accessKey', 'animation', 'bindingOptions', 'closeOnOutsideClick',
        'container', 'contentTemplate', 'copyRootClassesToWrapper',
        'deferRendering', 'disabled', 'dragAndResizeArea', 'dragEnabled',
        'dragOutsideBoundary', 'elementAttr', 'enableBodyScroll',
        'focusStateEnabled', 'fullScreen', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'maxHeight',
        'maxWidth', 'minHeight', 'minWidth', 'onContentReady', 'onDisposing',
        'onHidden', 'onHiding', 'onInitialized', 'onOptionChanged', 'onResize',
        'onResizeEnd', 'onResizeStart', 'onShowing', 'onShown',
        'onTitleRendered', 'position', 'resizeEnabled', 'restorePosition',
        'rtlEnabled', 'shading', 'shadingColor', 'showCloseButton', 'showTitle',
        'tabIndex', 'title', 'titleTemplate', 'toolbarItems', 'visible',
        'width', 'wrapperAttr']


class DxAutocompleteFrom(External):
    imports = {"import {DxFrom as DxAutocompleteFrom} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxAutocompleteHide(External):
    imports = {"import {DxHide as DxAutocompleteHide} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxAutocompleteItem(External):
    imports = {"import {DxItem as DxAutocompleteItem} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['disabled', 'html', 'template', 'text', 'visible']


class DxAutocompleteMy(External):
    imports = {"import {DxMy as DxAutocompleteMy} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['x', 'y']


class DxAutocompleteOffset(External):
    imports = {"import {DxOffset as DxAutocompleteOffset} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['x', 'y']


class DxAutocompleteOptions(External):
    imports = {"import {DxOptions as DxAutocompleteOptions} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']


class DxAutocompletePosition(External):
    imports = {"import {DxPosition as DxAutocompletePosition} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxAutocompleteShow(External):
    imports = {"import {DxShow as DxAutocompleteShow} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxAutocompleteTo(External):
    imports = {"import {DxTo as DxAutocompleteTo} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxAutocompleteToolbarItem(External):
    imports = {"import {DxToolbarItem as DxAutocompleteToolbarItem} from 'devextreme-vue/autocomplete'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



