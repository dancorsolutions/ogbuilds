# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSortable', 'DxSortableCursorOffset']

common_attrs = ['key']


class DxSortable(External):
    imports = {"import DxSortable from 'devextreme-vue/sortable'"}
    attrs = common_attrs + ['allowDropInsideItem', 'allowReordering', 'autoScroll', 'boundary',
        'container', 'cursorOffset', 'data', 'dragDirection', 'dragTemplate',
        'dropFeedbackMode', 'elementAttr', 'filter', 'group', 'handle',
        'height', 'itemOrientation', 'moveItemOnDrop', 'onAdd', 'onDisposing',
        'onDragChange', 'onDragEnd', 'onDragMove', 'onDragStart',
        'onInitialized', 'onOptionChanged', 'onRemove', 'onReorder',
        'rtlEnabled', 'scrollSensitivity', 'scrollSpeed', 'width']


class DxSortableCursorOffset(External):
    imports = {"import {DxCursorOffset as DxSortableCursorOffset} from 'devextreme-vue/sortable'"}
    attrs = common_attrs + ['x', 'y']



