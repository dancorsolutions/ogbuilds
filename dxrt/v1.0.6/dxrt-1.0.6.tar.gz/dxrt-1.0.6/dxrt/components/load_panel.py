# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxLoadPanel', 'DxLoadPanelAnimation', 'DxLoadPanelAt', 'DxLoadPanelBoundaryOffset',
 'DxLoadPanelCollision', 'DxLoadPanelFrom', 'DxLoadPanelHide', 'DxLoadPanelMy', 'DxLoadPanelOffset',
 'DxLoadPanelPosition', 'DxLoadPanelShow', 'DxLoadPanelTo']

common_attrs = ['key']


class DxLoadPanel(External):
    imports = {"import DxLoadPanel from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['animation', 'closeOnOutsideClick', 'container',
        'copyRootClassesToWrapper', 'deferRendering', 'delay', 'elementAttr',
        'focusStateEnabled', 'height', 'hideOnOutsideClick',
        'hideOnParentScroll', 'hint', 'hoverStateEnabled', 'indicatorSrc',
        'maxHeight', 'maxWidth', 'message', 'minHeight', 'minWidth',
        'onContentReady', 'onDisposing', 'onHidden', 'onHiding',
        'onInitialized', 'onOptionChanged', 'onShowing', 'onShown', 'position',
        'rtlEnabled', 'shading', 'shadingColor', 'showIndicator', 'showPane',
        'visible', 'width', 'wrapperAttr']


class DxLoadPanelAnimation(External):
    imports = {"import {DxAnimation as DxLoadPanelAnimation} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['hide', 'show']


class DxLoadPanelAt(External):
    imports = {"import {DxAt as DxLoadPanelAt} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['x', 'y']


class DxLoadPanelBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxLoadPanelBoundaryOffset} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['x', 'y']


class DxLoadPanelCollision(External):
    imports = {"import {DxCollision as DxLoadPanelCollision} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['x', 'y']


class DxLoadPanelFrom(External):
    imports = {"import {DxFrom as DxLoadPanelFrom} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxLoadPanelHide(External):
    imports = {"import {DxHide as DxLoadPanelHide} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxLoadPanelMy(External):
    imports = {"import {DxMy as DxLoadPanelMy} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['x', 'y']


class DxLoadPanelOffset(External):
    imports = {"import {DxOffset as DxLoadPanelOffset} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['x', 'y']


class DxLoadPanelPosition(External):
    imports = {"import {DxPosition as DxLoadPanelPosition} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxLoadPanelShow(External):
    imports = {"import {DxShow as DxLoadPanelShow} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxLoadPanelTo(External):
    imports = {"import {DxTo as DxLoadPanelTo} from 'devextreme-vue/load-panel'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']



