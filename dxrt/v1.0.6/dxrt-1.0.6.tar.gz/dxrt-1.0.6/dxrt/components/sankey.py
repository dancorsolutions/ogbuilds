# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxSankey', 'DxSankeyAdaptiveLayout', 'DxSankeyBorder', 'DxSankeyExport', 'DxSankeyFont',
 'DxSankeyFormat', 'DxSankeyHatching', 'DxSankeyHoverStyle', 'DxSankeyLabel', 'DxSankeyLink',
 'DxSankeyLoadingIndicator', 'DxSankeyMargin', 'DxSankeyNode', 'DxSankeyborder', 'DxSankeyShadow',
 'DxSankeySize', 'DxSankeySubtitle', 'DxSankeyTitle', 'DxSankeyTooltip', 'DxSankeyTooltipBorder']

common_attrs = ['key']


class DxSankey(External):
    imports = {"import DxSankey from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['adaptiveLayout', 'alignment', 'dataSource', 'disabled', 'elementAttr',
        'export', 'hoverEnabled', 'label', 'link', 'loadingIndicator', 'margin',
        'node', 'onDisposing', 'onDrawn', 'onExported', 'onExporting',
        'onFileSaving', 'onIncidentOccurred', 'onInitialized', 'onLinkClick',
        'onLinkHoverChanged', 'onNodeClick', 'onNodeHoverChanged',
        'onOptionChanged', 'palette', 'paletteExtensionMode', 'pathModified',
        'redrawOnResize', 'rtlEnabled', 'size', 'sortData', 'sourceField',
        'targetField', 'theme', 'title', 'tooltip', 'weightField']


class DxSankeyAdaptiveLayout(External):
    imports = {"import {DxAdaptiveLayout as DxSankeyAdaptiveLayout} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['height', 'keepLabels', 'width']


class DxSankeyBorder(External):
    imports = {"import {DxBorder as DxSankeyBorder} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxSankeyExport(External):
    imports = {"import {DxExport as DxSankeyExport} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxSankeyFont(External):
    imports = {"import {DxFont as DxSankeyFont} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxSankeyFormat(External):
    imports = {"import {DxFormat as DxSankeyFormat} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxSankeyHatching(External):
    imports = {"import {DxHatching as DxSankeyHatching} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['direction', 'opacity', 'step', 'width']


class DxSankeyHoverStyle(External):
    imports = {"import {DxHoverStyle as DxSankeyHoverStyle} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['border', 'color', 'hatching', 'opacity']


class DxSankeyLabel(External):
    imports = {"import {DxLabel as DxSankeyLabel} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['border', 'customizeText', 'font', 'horizontalOffset',
        'overlappingBehavior', 'shadow', 'useNodeColors', 'verticalOffset',
        'visible']


class DxSankeyLink(External):
    imports = {"import {DxLink as DxSankeyLink} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['border', 'color', 'colorMode', 'hoverStyle', 'opacity']


class DxSankeyLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxSankeyLoadingIndicator} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxSankeyMargin(External):
    imports = {"import {DxMargin as DxSankeyMargin} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxSankeyNode(External):
    imports = {"import {DxNode as DxSankeyNode} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['border', 'color', 'hoverStyle', 'opacity', 'padding', 'width']


class DxSankeyborder(External):
    imports = {"import {DxSankeyborder as DxSankeyborder} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxSankeyShadow(External):
    imports = {"import {DxShadow as DxSankeyShadow} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxSankeySize(External):
    imports = {"import {DxSize as DxSankeySize} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['height', 'width']


class DxSankeySubtitle(External):
    imports = {"import {DxSubtitle as DxSankeySubtitle} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxSankeyTitle(External):
    imports = {"import {DxTitle as DxSankeyTitle} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxSankeyTooltip(External):
    imports = {"import {DxTooltip as DxSankeyTooltip} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'cornerRadius',
        'customizeLinkTooltip', 'customizeNodeTooltip', 'enabled', 'font',
        'format', 'linkTooltipTemplate', 'nodeTooltipTemplate', 'opacity',
        'paddingLeftRight', 'paddingTopBottom', 'shadow', 'zIndex']


class DxSankeyTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxSankeyTooltipBorder} from 'devextreme-vue/sankey'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']



