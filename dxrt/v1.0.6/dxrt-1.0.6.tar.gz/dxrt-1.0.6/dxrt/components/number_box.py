# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxNumberBox', 'DxNumberBoxButton', 'DxNumberBoxFormat', 'DxNumberBoxOptions']

common_attrs = ['key']


class DxNumberBox(External):
    imports = {"import DxNumberBox from 'devextreme-vue/number-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'buttons', 'disabled', 'elementAttr',
        'focusStateEnabled', 'format', 'height', 'hint', 'hoverStateEnabled',
        'inputAttr', 'invalidValueMessage', 'isValid', 'label', 'labelMode',
        'max', 'min', 'mode', 'name', 'onChange', 'onContentReady', 'onCopy',
        'onCut', 'onDisposing', 'onEnterKey', 'onFocusIn', 'onFocusOut',
        'onInitialized', 'onInput', 'onKeyDown', 'onKeyUp', 'onOptionChanged',
        'onPaste', 'onValueChanged', 'placeholder', 'readOnly', 'rtlEnabled',
        'showClearButton', 'showSpinButtons', 'step', 'stylingMode', 'tabIndex',
        'text', 'useLargeSpinButtons', 'validationError', 'validationErrors',
        'validationMessageMode', 'validationMessagePosition',
        'validationStatus', 'value', 'valueChangeEvent', 'visible', 'width',
        'modelValue']


class DxNumberBoxButton(External):
    imports = {"import {DxButton as DxNumberBoxButton} from 'devextreme-vue/number-box'"}
    attrs = common_attrs + ['location', 'name', 'options']


class DxNumberBoxFormat(External):
    imports = {"import {DxFormat as DxNumberBoxFormat} from 'devextreme-vue/number-box'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxNumberBoxOptions(External):
    imports = {"import {DxOptions as DxNumberBoxOptions} from 'devextreme-vue/number-box'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'bindingOptions', 'disabled',
        'elementAttr', 'focusStateEnabled', 'height', 'hint',
        'hoverStateEnabled', 'icon', 'onClick', 'onContentReady', 'onDisposing',
        'onInitialized', 'onOptionChanged', 'rtlEnabled', 'stylingMode',
        'tabIndex', 'template', 'text', 'type', 'useSubmitBehavior',
        'validationGroup', 'visible', 'width']



