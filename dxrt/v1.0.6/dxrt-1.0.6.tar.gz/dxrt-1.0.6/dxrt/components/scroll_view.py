# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxScrollView']

common_attrs = ['key']


class DxScrollView(External):
    imports = {"import DxScrollView from 'devextreme-vue/scroll-view'"}
    attrs = common_attrs + ['bounceEnabled', 'direction', 'disabled', 'elementAttr', 'height',
        'onDisposing', 'onInitialized', 'onOptionChanged', 'onPullDown',
        'onReachBottom', 'onScroll', 'onUpdated', 'pulledDownText',
        'pullingDownText', 'reachBottomText', 'refreshingText', 'rtlEnabled',
        'scrollByContent', 'scrollByThumb', 'showScrollbar', 'useNative',
        'width']



