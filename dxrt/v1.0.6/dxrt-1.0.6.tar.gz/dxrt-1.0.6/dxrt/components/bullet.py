# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxBullet', 'DxBulletBorder', 'DxBulletFont', 'DxBulletFormat', 'DxBulletMargin', 'DxBulletShadow',
 'DxBulletSize', 'DxBulletTooltip']

common_attrs = ['key']


class DxBullet(External):
    imports = {"import DxBullet from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['color', 'disabled', 'elementAttr', 'endScaleValue', 'margin',
        'onDisposing', 'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onOptionChanged',
        'onTooltipHidden', 'onTooltipShown', 'pathModified', 'rtlEnabled',
        'showTarget', 'showZeroLevel', 'size', 'startScaleValue', 'target',
        'targetColor', 'targetWidth', 'theme', 'tooltip', 'value']


class DxBulletBorder(External):
    imports = {"import {DxBorder as DxBulletBorder} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxBulletFont(External):
    imports = {"import {DxFont as DxBulletFont} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxBulletFormat(External):
    imports = {"import {DxFormat as DxBulletFormat} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxBulletMargin(External):
    imports = {"import {DxMargin as DxBulletMargin} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxBulletShadow(External):
    imports = {"import {DxShadow as DxBulletShadow} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxBulletSize(External):
    imports = {"import {DxSize as DxBulletSize} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['height', 'width']


class DxBulletTooltip(External):
    imports = {"import {DxTooltip as DxBulletTooltip} from 'devextreme-vue/bullet'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'interactive', 'opacity', 'paddingLeftRight', 'paddingTopBottom',
        'shadow', 'zIndex']



