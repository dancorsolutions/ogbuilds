# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxLinearGauge', 'DxLinearGaugeAnimation', 'DxLinearGaugeBackgroundColor', 'DxLinearGaugeBorder',
 'DxLinearGaugeColor', 'DxLinearGaugeExport', 'DxLinearGaugeFont', 'DxLinearGaugeFormat',
 'DxLinearGaugeGeometry', 'DxLinearGaugeLabel', 'DxLinearGaugeLoadingIndicator',
 'DxLinearGaugeMargin', 'DxLinearGaugeMinorTick', 'DxLinearGaugeRange',
 'DxLinearGaugeRangeContainer', 'DxLinearGaugeScale', 'DxLinearGaugeShadow', 'DxLinearGaugeSize',
 'DxLinearGaugeSubtitle', 'DxLinearGaugeSubvalueIndicator', 'DxLinearGaugeText',
 'DxLinearGaugeTick', 'DxLinearGaugeTitle', 'DxLinearGaugeTooltip', 'DxLinearGaugeValueIndicator',
 'DxLinearGaugeWidth']

common_attrs = ['key']


class DxLinearGauge(External):
    imports = {"import DxLinearGauge from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['animation', 'containerBackgroundColor', 'disabled', 'elementAttr',
        'export', 'geometry', 'loadingIndicator', 'margin', 'onDisposing',
        'onDrawn', 'onExported', 'onExporting', 'onFileSaving',
        'onIncidentOccurred', 'onInitialized', 'onOptionChanged',
        'onTooltipHidden', 'onTooltipShown', 'pathModified', 'rangeContainer',
        'redrawOnResize', 'rtlEnabled', 'scale', 'size', 'subvalueIndicator',
        'subvalues', 'theme', 'title', 'tooltip', 'value', 'valueIndicator']


class DxLinearGaugeAnimation(External):
    imports = {"import {DxAnimation as DxLinearGaugeAnimation} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['duration', 'easing', 'enabled']


class DxLinearGaugeBackgroundColor(External):
    imports = {"import {DxBackgroundColor as DxLinearGaugeBackgroundColor} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['base', 'fillId']


class DxLinearGaugeBorder(External):
    imports = {"import {DxBorder as DxLinearGaugeBorder} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']


class DxLinearGaugeColor(External):
    imports = {"import {DxColor as DxLinearGaugeColor} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['base', 'fillId']


class DxLinearGaugeExport(External):
    imports = {"import {DxExport as DxLinearGaugeExport} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxLinearGaugeFont(External):
    imports = {"import {DxFont as DxLinearGaugeFont} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxLinearGaugeFormat(External):
    imports = {"import {DxFormat as DxLinearGaugeFormat} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxLinearGaugeGeometry(External):
    imports = {"import {DxGeometry as DxLinearGaugeGeometry} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['orientation']


class DxLinearGaugeLabel(External):
    imports = {"import {DxLabel as DxLinearGaugeLabel} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['customizeText', 'font', 'format', 'indentFromTick',
        'overlappingBehavior', 'useRangeColors', 'visible']


class DxLinearGaugeLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxLinearGaugeLoadingIndicator} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'font', 'show', 'text']


class DxLinearGaugeMargin(External):
    imports = {"import {DxMargin as DxLinearGaugeMargin} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxLinearGaugeMinorTick(External):
    imports = {"import {DxMinorTick as DxLinearGaugeMinorTick} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'visible', 'width']


class DxLinearGaugeRange(External):
    imports = {"import {DxRange as DxLinearGaugeRange} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['color', 'endValue', 'startValue']


class DxLinearGaugeRangeContainer(External):
    imports = {"import {DxRangeContainer as DxLinearGaugeRangeContainer} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['backgroundColor', 'horizontalOrientation', 'offset', 'palette',
        'paletteExtensionMode', 'ranges', 'verticalOrientation', 'width']


class DxLinearGaugeScale(External):
    imports = {"import {DxScale as DxLinearGaugeScale} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['allowDecimals', 'customMinorTicks', 'customTicks', 'endValue',
        'horizontalOrientation', 'label', 'minorTick', 'minorTickInterval',
        'scaleDivisionFactor', 'startValue', 'tick', 'tickInterval',
        'verticalOrientation']


class DxLinearGaugeShadow(External):
    imports = {"import {DxShadow as DxLinearGaugeShadow} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxLinearGaugeSize(External):
    imports = {"import {DxSize as DxLinearGaugeSize} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['height', 'width']


class DxLinearGaugeSubtitle(External):
    imports = {"import {DxSubtitle as DxLinearGaugeSubtitle} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxLinearGaugeSubvalueIndicator(External):
    imports = {"import {DxSubvalueIndicator as DxLinearGaugeSubvalueIndicator} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['arrowLength', 'backgroundColor', 'baseValue', 'beginAdaptingAtRadius',
        'color', 'horizontalOrientation', 'indentFromCenter', 'length',
        'offset', 'palette', 'secondColor', 'secondFraction', 'size',
        'spindleGapSize', 'spindleSize', 'text', 'type', 'verticalOrientation',
        'width']


class DxLinearGaugeText(External):
    imports = {"import {DxText as DxLinearGaugeText} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['customizeText', 'font', 'format', 'indent']


class DxLinearGaugeTick(External):
    imports = {"import {DxTick as DxLinearGaugeTick} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['color', 'length', 'opacity', 'visible', 'width']


class DxLinearGaugeTitle(External):
    imports = {"import {DxTitle as DxLinearGaugeTitle} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxLinearGaugeTooltip(External):
    imports = {"import {DxTooltip as DxLinearGaugeTooltip} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'interactive', 'opacity', 'paddingLeftRight', 'paddingTopBottom',
        'shadow', 'zIndex']


class DxLinearGaugeValueIndicator(External):
    imports = {"import {DxValueIndicator as DxLinearGaugeValueIndicator} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['arrowLength', 'backgroundColor', 'baseValue', 'beginAdaptingAtRadius',
        'color', 'horizontalOrientation', 'indentFromCenter', 'length',
        'offset', 'palette', 'secondColor', 'secondFraction', 'size',
        'spindleGapSize', 'spindleSize', 'text', 'type', 'verticalOrientation',
        'width']


class DxLinearGaugeWidth(External):
    imports = {"import {DxWidth as DxLinearGaugeWidth} from 'devextreme-vue/linear-gauge'"}
    attrs = common_attrs + ['end', 'start']



