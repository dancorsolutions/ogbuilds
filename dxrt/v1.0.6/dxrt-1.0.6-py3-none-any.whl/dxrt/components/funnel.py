# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxFunnel', 'DxFunnelAdaptiveLayout', 'DxFunnelBorder', 'DxFunnelConnector', 'DxFunnelExport',
 'DxFunnelFont', 'DxFunnelFormat', 'DxFunnelTitle', 'DxFunnelTitleSubtitle', 'DxFunnelHatching',
 'DxFunnelHoverStyle', 'DxFunnelItem', 'DxFunnelItemBorder', 'DxFunnelLabel', 'DxFunnelLabelBorder',
 'DxFunnelLegend', 'DxFunnelLegendBorder', 'DxFunnelLegendTitle', 'DxFunnelLegendTitleSubtitle',
 'DxFunnelLoadingIndicator', 'DxFunnelMargin', 'DxFunnelSelectionStyle', 'DxFunnelShadow',
 'DxFunnelSize', 'DxFunnelSubtitle', 'DxFunnelTooltip', 'DxFunnelTooltipBorder']

common_attrs = ['key']


class DxFunnel(External):
    imports = {"import DxFunnel from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['adaptiveLayout', 'algorithm', 'argumentField', 'colorField',
        'dataSource', 'disabled', 'elementAttr', 'export', 'hoverEnabled',
        'inverted', 'item', 'label', 'legend', 'loadingIndicator', 'margin',
        'neckHeight', 'neckWidth', 'onDisposing', 'onDrawn', 'onExported',
        'onExporting', 'onFileSaving', 'onHoverChanged', 'onIncidentOccurred',
        'onInitialized', 'onItemClick', 'onLegendClick', 'onOptionChanged',
        'onSelectionChanged', 'palette', 'paletteExtensionMode', 'pathModified',
        'redrawOnResize', 'resolveLabelOverlapping', 'rtlEnabled',
        'selectionMode', 'size', 'sortData', 'theme', 'title', 'tooltip',
        'valueField']


class DxFunnelAdaptiveLayout(External):
    imports = {"import {DxAdaptiveLayout as DxFunnelAdaptiveLayout} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['height', 'keepLabels', 'width']


class DxFunnelBorder(External):
    imports = {"import {DxBorder as DxFunnelBorder} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxFunnelConnector(External):
    imports = {"import {DxConnector as DxFunnelConnector} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'opacity', 'visible', 'width']


class DxFunnelExport(External):
    imports = {"import {DxExport as DxFunnelExport} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxFunnelFont(External):
    imports = {"import {DxFont as DxFunnelFont} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxFunnelFormat(External):
    imports = {"import {DxFormat as DxFunnelFormat} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxFunnelTitle(External):
    imports = {"import {DxFunnelTitle as DxFunnelTitle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxFunnelTitleSubtitle(External):
    imports = {"import {DxFunnelTitleSubtitle as DxFunnelTitleSubtitle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxFunnelHatching(External):
    imports = {"import {DxHatching as DxFunnelHatching} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['direction', 'opacity', 'step', 'width']


class DxFunnelHoverStyle(External):
    imports = {"import {DxHoverStyle as DxFunnelHoverStyle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['border', 'hatching']


class DxFunnelItem(External):
    imports = {"import {DxItem as DxFunnelItem} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['border', 'hoverStyle', 'selectionStyle']


class DxFunnelItemBorder(External):
    imports = {"import {DxItemBorder as DxFunnelItemBorder} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxFunnelLabel(External):
    imports = {"import {DxLabel as DxFunnelLabel} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'connector', 'customizeText', 'font',
        'format', 'horizontalAlignment', 'horizontalOffset', 'position',
        'showForZeroValues', 'textOverflow', 'visible', 'wordWrap']


class DxFunnelLabelBorder(External):
    imports = {"import {DxLabelBorder as DxFunnelLabelBorder} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'dashStyle', 'visible', 'width']


class DxFunnelLegend(External):
    imports = {"import {DxLegend as DxFunnelLegend} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['backgroundColor', 'border', 'columnCount', 'columnItemSpacing',
        'customizeHint', 'customizeItems', 'customizeText', 'font',
        'horizontalAlignment', 'itemsAlignment', 'itemTextPosition', 'margin',
        'markerSize', 'markerTemplate', 'orientation', 'paddingLeftRight',
        'paddingTopBottom', 'rowCount', 'rowItemSpacing', 'title',
        'verticalAlignment', 'visible']


class DxFunnelLegendBorder(External):
    imports = {"import {DxLegendBorder as DxFunnelLegendBorder} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'cornerRadius', 'dashStyle', 'opacity', 'visible', 'width']


class DxFunnelLegendTitle(External):
    imports = {"import {DxLegendTitle as DxFunnelLegendTitle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'verticalAlignment']


class DxFunnelLegendTitleSubtitle(External):
    imports = {"import {DxLegendTitleSubtitle as DxFunnelLegendTitleSubtitle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['font', 'offset', 'text']


class DxFunnelLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxFunnelLoadingIndicator} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxFunnelMargin(External):
    imports = {"import {DxMargin as DxFunnelMargin} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxFunnelSelectionStyle(External):
    imports = {"import {DxSelectionStyle as DxFunnelSelectionStyle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['border', 'hatching']


class DxFunnelShadow(External):
    imports = {"import {DxShadow as DxFunnelShadow} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['blur', 'color', 'offsetX', 'offsetY', 'opacity']


class DxFunnelSize(External):
    imports = {"import {DxSize as DxFunnelSize} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['height', 'width']


class DxFunnelSubtitle(External):
    imports = {"import {DxSubtitle as DxFunnelSubtitle} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxFunnelTooltip(External):
    imports = {"import {DxTooltip as DxFunnelTooltip} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['arrowLength', 'border', 'color', 'container', 'contentTemplate',
        'cornerRadius', 'customizeTooltip', 'enabled', 'font', 'format',
        'opacity', 'paddingLeftRight', 'paddingTopBottom', 'shadow', 'zIndex']


class DxFunnelTooltipBorder(External):
    imports = {"import {DxTooltipBorder as DxFunnelTooltipBorder} from 'devextreme-vue/funnel'"}
    attrs = common_attrs + ['color', 'dashStyle', 'opacity', 'visible', 'width']



