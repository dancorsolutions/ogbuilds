# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxRangeSelector', 'DxRangeSelectorAggregation', 'DxRangeSelectorAggregationInterval',
 'DxRangeSelectorArgumentFormat', 'DxRangeSelectorBackground', 'DxRangeSelectorBackgroundImage',
 'DxRangeSelectorBehavior', 'DxRangeSelectorBorder', 'DxRangeSelectorBreak',
 'DxRangeSelectorBreakStyle', 'DxRangeSelectorChart', 'DxRangeSelectorColor',
 'DxRangeSelectorCommonSeriesSettings', 'DxRangeSelectorCommonSeriesSettingsHoverStyle',
 'DxRangeSelectorCommonSeriesSettingsLabel', 'DxRangeSelectorCommonSeriesSettingsSelectionStyle',
 'DxRangeSelectorConnector', 'DxRangeSelectorDataPrepareSettings', 'DxRangeSelectorExport',
 'DxRangeSelectorFont', 'DxRangeSelectorFormat', 'DxRangeSelectorHatching', 'DxRangeSelectorHeight',
 'DxRangeSelectorHoverStyle', 'DxRangeSelectorImage', 'DxRangeSelectorIndent',
 'DxRangeSelectorLabel', 'DxRangeSelectorLength', 'DxRangeSelectorLoadingIndicator',
 'DxRangeSelectorMargin', 'DxRangeSelectorMarker', 'DxRangeSelectorMarkerLabel',
 'DxRangeSelectorMaxRange', 'DxRangeSelectorMinorTick', 'DxRangeSelectorMinorTickInterval',
 'DxRangeSelectorMinRange', 'DxRangeSelectorPoint', 'DxRangeSelectorPointBorder',
 'DxRangeSelectorPointHoverStyle', 'DxRangeSelectorPointImage',
 'DxRangeSelectorPointSelectionStyle', 'DxRangeSelectorReduction', 'DxRangeSelectorScale',
 'DxRangeSelectorScaleLabel', 'DxRangeSelectorSelectionStyle', 'DxRangeSelectorSeries',
 'DxRangeSelectorSeriesBorder', 'DxRangeSelectorSeriesTemplate', 'DxRangeSelectorShutter',
 'DxRangeSelectorSize', 'DxRangeSelectorSliderHandle', 'DxRangeSelectorSliderMarker',
 'DxRangeSelectorSubtitle', 'DxRangeSelectorTick', 'DxRangeSelectorTickInterval',
 'DxRangeSelectorTitle', 'DxRangeSelectorUrl', 'DxRangeSelectorValue', 'DxRangeSelectorValueAxis',
 'DxRangeSelectorValueErrorBar', 'DxRangeSelectorWidth']

common_attrs = ['key']


class DxRangeSelector(External):
    imports = {"import DxRangeSelector from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['background', 'behavior', 'chart', 'containerBackgroundColor',
        'dataSource', 'dataSourceField', 'disabled', 'elementAttr', 'export',
        'indent', 'loadingIndicator', 'margin', 'onDisposing', 'onDrawn',
        'onExported', 'onExporting', 'onFileSaving', 'onIncidentOccurred',
        'onInitialized', 'onOptionChanged', 'onValueChanged', 'pathModified',
        'redrawOnResize', 'rtlEnabled', 'scale', 'selectedRangeColor',
        'selectedRangeUpdateMode', 'shutter', 'size', 'sliderHandle',
        'sliderMarker', 'theme', 'title', 'value']


class DxRangeSelectorAggregation(External):
    imports = {"import {DxAggregation as DxRangeSelectorAggregation} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['calculate', 'enabled', 'method']


class DxRangeSelectorAggregationInterval(External):
    imports = {"import {DxAggregationInterval as DxRangeSelectorAggregationInterval} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxRangeSelectorArgumentFormat(External):
    imports = {"import {DxArgumentFormat as DxRangeSelectorArgumentFormat} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxRangeSelectorBackground(External):
    imports = {"import {DxBackground as DxRangeSelectorBackground} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'image', 'visible']


class DxRangeSelectorBackgroundImage(External):
    imports = {"import {DxBackgroundImage as DxRangeSelectorBackgroundImage} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['location', 'url']


class DxRangeSelectorBehavior(External):
    imports = {"import {DxBehavior as DxRangeSelectorBehavior} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['allowSlidersSwap', 'animationEnabled', 'callValueChanged',
        'manualRangeSelectionEnabled', 'moveSelectedRangeByClick',
        'snapToTicks', 'valueChangeMode']


class DxRangeSelectorBorder(External):
    imports = {"import {DxBorder as DxRangeSelectorBorder} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'dashStyle', 'visible', 'width']


class DxRangeSelectorBreak(External):
    imports = {"import {DxBreak as DxRangeSelectorBreak} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['endValue', 'startValue']


class DxRangeSelectorBreakStyle(External):
    imports = {"import {DxBreakStyle as DxRangeSelectorBreakStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'line', 'width']


class DxRangeSelectorChart(External):
    imports = {"import {DxChart as DxRangeSelectorChart} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['barGroupPadding', 'barGroupWidth', 'bottomIndent',
        'commonSeriesSettings', 'dataPrepareSettings', 'maxBubbleSize',
        'minBubbleSize', 'negativesAsZeroes', 'palette', 'paletteExtensionMode',
        'series', 'seriesTemplate', 'topIndent', 'valueAxis']


class DxRangeSelectorColor(External):
    imports = {"import {DxColor as DxRangeSelectorColor} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['base', 'fillId']


class DxRangeSelectorCommonSeriesSettings(External):
    imports = {"import {DxCommonSeriesSettings as DxRangeSelectorCommonSeriesSettings} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['aggregation', 'area', 'argumentField', 'axis', 'bar',
        'barOverlapGroup', 'barPadding', 'barWidth', 'border', 'bubble',
        'candlestick', 'closeValueField', 'color', 'cornerRadius', 'dashStyle',
        'fullstackedarea', 'fullstackedbar', 'fullstackedline',
        'fullstackedspline', 'fullstackedsplinearea', 'highValueField',
        'hoverMode', 'hoverStyle', 'ignoreEmptyPoints', 'innerColor', 'label',
        'line', 'lowValueField', 'maxLabelCount', 'minBarSize', 'opacity',
        'openValueField', 'pane', 'point', 'rangearea', 'rangebar',
        'rangeValue1Field', 'rangeValue2Field', 'reduction', 'scatter',
        'selectionMode', 'selectionStyle', 'showInLegend', 'sizeField',
        'spline', 'splinearea', 'stack', 'stackedarea', 'stackedbar',
        'stackedline', 'stackedspline', 'stackedsplinearea', 'steparea',
        'stepline', 'stock', 'tagField', 'type', 'valueErrorBar', 'valueField',
        'visible', 'width']


class DxRangeSelectorCommonSeriesSettingsHoverStyle(External):
    imports = {"import {DxCommonSeriesSettingsHoverStyle as DxRangeSelectorCommonSeriesSettingsHoverStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'width']


class DxRangeSelectorCommonSeriesSettingsLabel(External):
    imports = {"import {DxCommonSeriesSettingsLabel as DxRangeSelectorCommonSeriesSettingsLabel} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['alignment', 'argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeText', 'displayFormat', 'font', 'format', 'horizontalOffset',
        'position', 'rotationAngle', 'showForZeroValues', 'verticalOffset',
        'visible']


class DxRangeSelectorCommonSeriesSettingsSelectionStyle(External):
    imports = {"import {DxCommonSeriesSettingsSelectionStyle as DxRangeSelectorCommonSeriesSettingsSelectionStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'width']


class DxRangeSelectorConnector(External):
    imports = {"import {DxConnector as DxRangeSelectorConnector} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxRangeSelectorDataPrepareSettings(External):
    imports = {"import {DxDataPrepareSettings as DxRangeSelectorDataPrepareSettings} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['checkTypeForAllData', 'convertToAxisDataType', 'sortingMethod']


class DxRangeSelectorExport(External):
    imports = {"import {DxExport as DxRangeSelectorExport} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'fileName', 'formats', 'margin',
        'printingEnabled', 'svgToCanvas']


class DxRangeSelectorFont(External):
    imports = {"import {DxFont as DxRangeSelectorFont} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'family', 'opacity', 'size', 'weight']


class DxRangeSelectorFormat(External):
    imports = {"import {DxFormat as DxRangeSelectorFormat} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['currency', 'formatter', 'parser', 'precision', 'type',
        'useCurrencyAccountingStyle']


class DxRangeSelectorHatching(External):
    imports = {"import {DxHatching as DxRangeSelectorHatching} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['direction', 'opacity', 'step', 'width']


class DxRangeSelectorHeight(External):
    imports = {"import {DxHeight as DxRangeSelectorHeight} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['rangeMaxPoint', 'rangeMinPoint']


class DxRangeSelectorHoverStyle(External):
    imports = {"import {DxHoverStyle as DxRangeSelectorHoverStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'size', 'width']


class DxRangeSelectorImage(External):
    imports = {"import {DxImage as DxRangeSelectorImage} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['height', 'location', 'url', 'width']


class DxRangeSelectorIndent(External):
    imports = {"import {DxIndent as DxRangeSelectorIndent} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['left', 'right']


class DxRangeSelectorLabel(External):
    imports = {"import {DxLabel as DxRangeSelectorLabel} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['alignment', 'argumentFormat', 'backgroundColor', 'border', 'connector',
        'customizeText', 'displayFormat', 'font', 'format', 'horizontalOffset',
        'overlappingBehavior', 'position', 'rotationAngle', 'showForZeroValues',
        'topIndent', 'verticalOffset', 'visible']


class DxRangeSelectorLength(External):
    imports = {"import {DxLength as DxRangeSelectorLength} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxRangeSelectorLoadingIndicator(External):
    imports = {"import {DxLoadingIndicator as DxRangeSelectorLoadingIndicator} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['backgroundColor', 'enabled', 'font', 'show', 'text']


class DxRangeSelectorMargin(External):
    imports = {"import {DxMargin as DxRangeSelectorMargin} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['bottom', 'left', 'right', 'top']


class DxRangeSelectorMarker(External):
    imports = {"import {DxMarker as DxRangeSelectorMarker} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['label', 'separatorHeight', 'textLeftIndent', 'textTopIndent',
        'topIndent', 'visible']


class DxRangeSelectorMarkerLabel(External):
    imports = {"import {DxMarkerLabel as DxRangeSelectorMarkerLabel} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['customizeText', 'format']


class DxRangeSelectorMaxRange(External):
    imports = {"import {DxMaxRange as DxRangeSelectorMaxRange} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxRangeSelectorMinorTick(External):
    imports = {"import {DxMinorTick as DxRangeSelectorMinorTick} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'opacity', 'visible', 'width']


class DxRangeSelectorMinorTickInterval(External):
    imports = {"import {DxMinorTickInterval as DxRangeSelectorMinorTickInterval} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxRangeSelectorMinRange(External):
    imports = {"import {DxMinRange as DxRangeSelectorMinRange} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxRangeSelectorPoint(External):
    imports = {"import {DxPoint as DxRangeSelectorPoint} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'hoverMode', 'hoverStyle', 'image', 'selectionMode',
        'selectionStyle', 'size', 'symbol', 'visible']


class DxRangeSelectorPointBorder(External):
    imports = {"import {DxPointBorder as DxRangeSelectorPointBorder} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'visible', 'width']


class DxRangeSelectorPointHoverStyle(External):
    imports = {"import {DxPointHoverStyle as DxRangeSelectorPointHoverStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'size']


class DxRangeSelectorPointImage(External):
    imports = {"import {DxPointImage as DxRangeSelectorPointImage} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['height', 'url', 'width']


class DxRangeSelectorPointSelectionStyle(External):
    imports = {"import {DxPointSelectionStyle as DxRangeSelectorPointSelectionStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'size']


class DxRangeSelectorReduction(External):
    imports = {"import {DxReduction as DxRangeSelectorReduction} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'level']


class DxRangeSelectorScale(External):
    imports = {"import {DxScale as DxRangeSelectorScale} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['aggregateByCategory', 'aggregationGroupWidth', 'aggregationInterval',
        'allowDecimals', 'breaks', 'breakStyle', 'categories',
        'discreteAxisDivisionMode', 'endOnTick', 'endValue', 'holidays',
        'label', 'linearThreshold', 'logarithmBase', 'marker', 'maxRange',
        'minorTick', 'minorTickCount', 'minorTickInterval', 'minRange',
        'placeholderHeight', 'showCustomBoundaryTicks', 'singleWorkdays',
        'startValue', 'tick', 'tickInterval', 'type', 'valueType',
        'workdaysOnly', 'workWeek']


class DxRangeSelectorScaleLabel(External):
    imports = {"import {DxScaleLabel as DxRangeSelectorScaleLabel} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['customizeText', 'font', 'format', 'overlappingBehavior', 'topIndent',
        'visible']


class DxRangeSelectorSelectionStyle(External):
    imports = {"import {DxSelectionStyle as DxRangeSelectorSelectionStyle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['border', 'color', 'dashStyle', 'hatching', 'highlight', 'size', 'width']


class DxRangeSelectorSeries(External):
    imports = {"import {DxSeries as DxRangeSelectorSeries} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['aggregation', 'argumentField', 'axis', 'barOverlapGroup', 'barPadding',
        'barWidth', 'border', 'closeValueField', 'color', 'cornerRadius',
        'dashStyle', 'highValueField', 'hoverMode', 'hoverStyle',
        'ignoreEmptyPoints', 'innerColor', 'label', 'lowValueField',
        'maxLabelCount', 'minBarSize', 'name', 'opacity', 'openValueField',
        'pane', 'point', 'rangeValue1Field', 'rangeValue2Field', 'reduction',
        'selectionMode', 'selectionStyle', 'showInLegend', 'sizeField', 'stack',
        'tag', 'tagField', 'type', 'valueErrorBar', 'valueField', 'visible',
        'width']


class DxRangeSelectorSeriesBorder(External):
    imports = {"import {DxSeriesBorder as DxRangeSelectorSeriesBorder} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'dashStyle', 'visible', 'width']


class DxRangeSelectorSeriesTemplate(External):
    imports = {"import {DxSeriesTemplate as DxRangeSelectorSeriesTemplate} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['customizeSeries', 'nameField']


class DxRangeSelectorShutter(External):
    imports = {"import {DxShutter as DxRangeSelectorShutter} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'opacity']


class DxRangeSelectorSize(External):
    imports = {"import {DxSize as DxRangeSelectorSize} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['height', 'width']


class DxRangeSelectorSliderHandle(External):
    imports = {"import {DxSliderHandle as DxRangeSelectorSliderHandle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'opacity', 'width']


class DxRangeSelectorSliderMarker(External):
    imports = {"import {DxSliderMarker as DxRangeSelectorSliderMarker} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'customizeText', 'font', 'format', 'invalidRangeColor',
        'paddingLeftRight', 'paddingTopBottom', 'placeholderHeight', 'visible']


class DxRangeSelectorSubtitle(External):
    imports = {"import {DxSubtitle as DxRangeSelectorSubtitle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['font', 'offset', 'text', 'textOverflow', 'wordWrap']


class DxRangeSelectorTick(External):
    imports = {"import {DxTick as DxRangeSelectorTick} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'opacity', 'width']


class DxRangeSelectorTickInterval(External):
    imports = {"import {DxTickInterval as DxRangeSelectorTickInterval} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['days', 'hours', 'milliseconds', 'minutes', 'months', 'quarters',
        'seconds', 'weeks', 'years']


class DxRangeSelectorTitle(External):
    imports = {"import {DxTitle as DxRangeSelectorTitle} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['font', 'horizontalAlignment', 'margin', 'placeholderSize', 'subtitle',
        'text', 'textOverflow', 'verticalAlignment', 'wordWrap']


class DxRangeSelectorUrl(External):
    imports = {"import {DxUrl as DxRangeSelectorUrl} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['rangeMaxPoint', 'rangeMinPoint']


class DxRangeSelectorValue(External):
    imports = {"import {DxValue as DxRangeSelectorValue} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['endValue', 'length', 'startValue']


class DxRangeSelectorValueAxis(External):
    imports = {"import {DxValueAxis as DxRangeSelectorValueAxis} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['inverted', 'logarithmBase', 'max', 'min', 'type', 'valueType']


class DxRangeSelectorValueErrorBar(External):
    imports = {"import {DxValueErrorBar as DxRangeSelectorValueErrorBar} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['color', 'displayMode', 'edgeLength', 'highValueField', 'lineWidth',
        'lowValueField', 'opacity', 'type', 'value']


class DxRangeSelectorWidth(External):
    imports = {"import {DxWidth as DxRangeSelectorWidth} from 'devextreme-vue/range-selector'"}
    attrs = common_attrs + ['rangeMaxPoint', 'rangeMinPoint']



