# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxPopup', 'DxPopupAnimation', 'DxPopupAt', 'DxPopupBoundaryOffset', 'DxPopupCollision',
 'DxPopupFrom', 'DxPopupHide', 'DxPopupMy', 'DxPopupOffset', 'DxPopupPosition', 'DxPopupShow',
 'DxPopupTo', 'DxPopupToolbarItem']

common_attrs = ['key']


class DxPopup(External):
    imports = {"import DxPopup from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['accessKey', 'animation', 'closeOnOutsideClick', 'container',
        'contentTemplate', 'copyRootClassesToWrapper', 'deferRendering',
        'disabled', 'dragAndResizeArea', 'dragEnabled', 'dragOutsideBoundary',
        'elementAttr', 'enableBodyScroll', 'focusStateEnabled', 'fullScreen',
        'height', 'hideOnOutsideClick', 'hideOnParentScroll', 'hint',
        'hoverStateEnabled', 'maxHeight', 'maxWidth', 'minHeight', 'minWidth',
        'onContentReady', 'onDisposing', 'onHidden', 'onHiding',
        'onInitialized', 'onOptionChanged', 'onResize', 'onResizeEnd',
        'onResizeStart', 'onShowing', 'onShown', 'onTitleRendered', 'position',
        'resizeEnabled', 'restorePosition', 'rtlEnabled', 'shading',
        'shadingColor', 'showCloseButton', 'showTitle', 'tabIndex', 'title',
        'titleTemplate', 'toolbarItems', 'visible', 'width', 'wrapperAttr']


class DxPopupAnimation(External):
    imports = {"import {DxAnimation as DxPopupAnimation} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['hide', 'show']


class DxPopupAt(External):
    imports = {"import {DxAt as DxPopupAt} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['x', 'y']


class DxPopupBoundaryOffset(External):
    imports = {"import {DxBoundaryOffset as DxPopupBoundaryOffset} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['x', 'y']


class DxPopupCollision(External):
    imports = {"import {DxCollision as DxPopupCollision} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['x', 'y']


class DxPopupFrom(External):
    imports = {"import {DxFrom as DxPopupFrom} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxPopupHide(External):
    imports = {"import {DxHide as DxPopupHide} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxPopupMy(External):
    imports = {"import {DxMy as DxPopupMy} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['x', 'y']


class DxPopupOffset(External):
    imports = {"import {DxOffset as DxPopupOffset} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['x', 'y']


class DxPopupPosition(External):
    imports = {"import {DxPosition as DxPopupPosition} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['at', 'boundary', 'boundaryOffset', 'collision', 'my', 'of', 'offset']


class DxPopupShow(External):
    imports = {"import {DxShow as DxPopupShow} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['complete', 'delay', 'direction', 'duration', 'easing', 'from',
        'staggerDelay', 'start', 'to', 'type']


class DxPopupTo(External):
    imports = {"import {DxTo as DxPopupTo} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['left', 'opacity', 'position', 'scale', 'top']


class DxPopupToolbarItem(External):
    imports = {"import {DxToolbarItem as DxPopupToolbarItem} from 'devextreme-vue/popup'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'html', 'locateInMenu', 'location',
        'menuItemTemplate', 'options', 'showText', 'template', 'text',
        'toolbar', 'visible', 'widget']



