# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxFileManager', 'DxFileManagerColumn', 'DxFileManagerContextMenu', 'DxFileManagerContextMenuItem',
 'DxFileManagerDetails', 'DxFileManagerFileSelectionItem', 'DxFileManagerItem',
 'DxFileManagerItemView', 'DxFileManagerNotifications', 'DxFileManagerPermissions',
 'DxFileManagerToolbar', 'DxFileManagerToolbarItem', 'DxFileManagerUpload']

common_attrs = ['key']


class DxFileManager(External):
    imports = {"import DxFileManager from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['accessKey', 'activeStateEnabled', 'allowedFileExtensions',
        'contextMenu', 'currentPath', 'currentPathKeys',
        'customizeDetailColumns', 'customizeThumbnail', 'disabled',
        'elementAttr', 'fileSystemProvider', 'focusedItemKey',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled', 'itemView',
        'notifications', 'onContentReady', 'onContextMenuItemClick',
        'onContextMenuShowing', 'onCurrentDirectoryChanged',
        'onDirectoryCreated', 'onDirectoryCreating', 'onDisposing',
        'onErrorOccurred', 'onFileUploaded', 'onFileUploading',
        'onFocusedItemChanged', 'onInitialized', 'onItemCopied',
        'onItemCopying', 'onItemDeleted', 'onItemDeleting', 'onItemDownloading',
        'onItemMoved', 'onItemMoving', 'onItemRenamed', 'onItemRenaming',
        'onOptionChanged', 'onSelectedFileOpened', 'onSelectionChanged',
        'onToolbarItemClick', 'permissions', 'rootFolderName', 'rtlEnabled',
        'selectedItemKeys', 'selectionMode', 'tabIndex', 'toolbar', 'upload',
        'visible', 'width']


class DxFileManagerColumn(External):
    imports = {"import {DxColumn as DxFileManagerColumn} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['alignment', 'caption', 'cssClass', 'dataField', 'dataType',
        'hidingPriority', 'sortIndex', 'sortOrder', 'visible', 'visibleIndex',
        'width']


class DxFileManagerContextMenu(External):
    imports = {"import {DxContextMenu as DxFileManagerContextMenu} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['items']


class DxFileManagerContextMenuItem(External):
    imports = {"import {DxContextMenuItem as DxFileManagerContextMenuItem} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'disabled', 'icon', 'items', 'name',
        'selectable', 'selected', 'text', 'visible']


class DxFileManagerDetails(External):
    imports = {"import {DxDetails as DxFileManagerDetails} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['columns']


class DxFileManagerFileSelectionItem(External):
    imports = {"import {DxFileSelectionItem as DxFileManagerFileSelectionItem} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'icon', 'locateInMenu', 'location', 'name',
        'options', 'showText', 'text', 'visible', 'widget']


class DxFileManagerItem(External):
    imports = {"import {DxItem as DxFileManagerItem} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['beginGroup', 'closeMenuOnClick', 'cssClass', 'disabled', 'icon',
        'items', 'locateInMenu', 'location', 'name', 'options', 'selectable',
        'selected', 'showText', 'text', 'visible', 'widget']


class DxFileManagerItemView(External):
    imports = {"import {DxItemView as DxFileManagerItemView} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['details', 'mode', 'showFolders', 'showParentFolder']


class DxFileManagerNotifications(External):
    imports = {"import {DxNotifications as DxFileManagerNotifications} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['showPanel', 'showPopup']


class DxFileManagerPermissions(External):
    imports = {"import {DxPermissions as DxFileManagerPermissions} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['copy', 'create', 'delete', 'download', 'move', 'rename', 'upload']


class DxFileManagerToolbar(External):
    imports = {"import {DxToolbar as DxFileManagerToolbar} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['fileSelectionItems', 'items']


class DxFileManagerToolbarItem(External):
    imports = {"import {DxToolbarItem as DxFileManagerToolbarItem} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['cssClass', 'disabled', 'icon', 'locateInMenu', 'location', 'name',
        'options', 'showText', 'text', 'visible', 'widget']


class DxFileManagerUpload(External):
    imports = {"import {DxUpload as DxFileManagerUpload} from 'devextreme-vue/file-manager'"}
    attrs = common_attrs + ['chunkSize', 'maxFileSize']



