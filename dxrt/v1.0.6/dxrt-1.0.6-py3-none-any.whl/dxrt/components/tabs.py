# GENERATED FILE: DO NOT EDIT
"""
Component wrappers auto-generated from DevExtreme javascript

Note: attrs and events are NOT used by roundtrip, they are here to be leveraged in automation in sk's
type system
"""

from roundtrip.component import External


__all__ = ['DxTabs', 'DxTabsItem']

common_attrs = ['key']


class DxTabs(External):
    imports = {"import DxTabs from 'devextreme-vue/tabs'"}
    attrs = common_attrs + ['accessKey', 'dataSource', 'disabled', 'elementAttr',
        'focusStateEnabled', 'height', 'hint', 'hoverStateEnabled',
        'itemHoldTimeout', 'items', 'itemTemplate', 'keyExpr', 'noDataText',
        'onContentReady', 'onDisposing', 'onInitialized', 'onItemClick',
        'onItemContextMenu', 'onItemHold', 'onItemRendered', 'onOptionChanged',
        'onSelectionChanged', 'repaintChangesOnly', 'rtlEnabled',
        'scrollByContent', 'scrollingEnabled', 'selectedIndex', 'selectedItem',
        'selectedItemKeys', 'selectedItems', 'selectionMode', 'showNavButtons',
        'tabIndex', 'visible', 'width']


class DxTabsItem(External):
    imports = {"import {DxItem as DxTabsItem} from 'devextreme-vue/tabs'"}
    attrs = common_attrs + ['badge', 'disabled', 'html', 'icon', 'template', 'text', 'visible']



