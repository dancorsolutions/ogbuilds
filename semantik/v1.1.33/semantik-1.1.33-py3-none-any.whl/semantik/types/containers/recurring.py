import mongoengine
from semantik.types.common import *
from semantik.types.form.form import BaseFieldCollection

__all__ = ["Recurring", "RecurringTabs"]


class Recurring(BaseFieldCollection):
    """
    A set of form form_fields that can be 'cloned' any number of times by the user to provide a list of values

    Usually used when in most cases one or two distinct set of values is required but the developer wants to support
    more without burdening the UX with something more extensive like a table-and-form view.
    """

    _parameters = (common_parameters.FORM_ITEM + BaseFieldCollection._parameters).add(
        Param("clsItem", help="Class to attach to each recurring form container"),
        Param("column", help="Items are stacked vertically (column-wise) rather than horizontally"),
        Param("readOnly", help="Do not allow adding/deleting items"),
        Param("isFieldContainer", default=True),
        Param("autoForm", default=True),
        Param("addButtonName"),
        Param(
            "showOverallError",
            help="Show an error message at the top of a field set if any contained form_fields have" "errors",
        ),
    )

    _tag = "SKRecurring"

    _transparentStore = False
    _transparentState = False

    def makeOne(self, context):
        return super()._data(context=context)[self._id]

    def _data(self, context):
        out = {}
        out[self._id] = {}
        out[self._id]["_value"] = [self.makeOne(context)]
        return out

    def _toState(self, storage, state, context):
        if not self._storageHas(storage, self._id):
            state.update(self._data(context=context))
            return

        items = self._storageGet(storage, self._id)

        if not items or not len(items):
            state[self._id] = dict(_value=self._data(context=context)[self._id]["_value"])
            return

        out = []
        for item in items:
            stateItem = dict()
            super()._toState({self._id: item}, stateItem, context=context)
            out.append(stateItem[self._id])

        if self._id not in state:
            state[self._id] = dict(_value=None)
        state[self._id]["_value"] = out

    def _toStorage(self, state, storage, context):
        if self._id not in state:
            storage[self._id] = []
            return

        items = state[self._id]["_value"]

        if isinstance(storage, dict):
            doc = dict
        elif hasattr(storage, "_sa_class_manager"):
            doc = dict
        else:
            doc = super()._getFields()[self._id].document_type
        out = []
        for item in items:
            storageItem = doc()
            super()._toStorage({self._id: item}, {self._id: storageItem}, context=context)
            out.append(storageItem)

        if not self._storageHas(storage, self._id):
            self._storageSet(storage, self._id, dict(_value=None))
        elif self._storageGet(storage, self._id) != out:
            self._storageSet(storage, self._id, out)

    def _getFields(self):
        embeddedDocumentField = super()._getFields()[self._id]
        return {self._id: mongoengine.EmbeddedDocumentListField(embeddedDocumentField.document_type)}

    def _validate(self, subState, context):
        overallError = None
        for index, item in enumerate(subState[self._id]._value):
            ctx = context._with(state=item) if context else context(state=item)

            if "validate" in self.p:
                itemError = self.p("validate", context=ctx)
                if itemError:
                    for k, v in itemError.items():
                        item[k]["_error"] = v
                    item["_error"] = True
                    overallError = True
            else:
                if "error" in item:
                    del item["_error"]

        if overallError or overallError:
            subState[self._id]._error = overallError or "Check and correct errors"
            return {self._id: "Check and correct errors"}
        elif self._id in subState and "_error" in subState[self._id]:
            del subState[self._id]["_error"]

        return None


class SKRecurring(SKComponent):
    # language=Vue
    template = r"""
    <div :class="{'sk-recurring-container': true, '--sk-column': config.column}">
        <div class="sk-recurring-overall-error" v-if="config.showOverallError && index == 0 && has_any_errors(state)">
            {{state._error}}
        </div>
        <div 
            :name="config._typeUID"
            :class="'sk-recurring' + (config.clsItem ? ' ' + config.clsItem : '')"
            v-bind="config._passthroughAttrs"
            v-for="(subState, index) in state._value"
            key="index"
        >
            <SKFormContents
                v-if="config.autoForm"
                :class="'sk-recurring-contents' +  (has_errors(subState) ? ' sk-recurring-error' : '')"
                :config="config" 
                :state="subState" 
                :itemState="itemState"
            />
            <SKContents
                v-else
                :class="'sk-recurring-contents' +  (has_errors(subState) ? ' sk-recurring-error' : '')"
                :config="config" 
                :state="subState" 
                :itemState="itemState"
            />            
            <div class="sk-recurring-buttons" v-if="!config.readOnly">
                <button v-if="state._value.length > 1" @click="doDelete(index)" class="--delete">
                    <i class="fa-regular fa-trash-can"></i>
                </button>
                <button  v-if="index === (state._value.length-1)" @click="doAdd(index)" class="--add">
                    <i class="fa-light fa-file-plus"></i>
                </button>
            </div>
        </div>
    </div>
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        has_errors=js(
            """
            function(state) {
                if(!state)
                    return false;
                for(let i of Object.entries(state)) {
                    if(i[1]._error)
                        return true;
                }
                return false;
            }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        has_any_errors=js(
            """
            function(state) {
                if(!state)
                    return false;
                for(let i of state._value) {
                    if(this.has_errors(i))
                        return true;
                }
                return false;
            }"""
        ),
    )

    computed = dict(console=js("""() => console"""))

    @method
    def doAdd(self, index):
        context = self.context
        self.client.state._value.push(self.skType.makeOne(context))

    @method
    def doDelete(self, index):
        self.client.state._value.splice(index, 1)


class RecurringTabs(Recurring):
    _tag = "SKRecurringTabs"

    _parameters = (
        (common_parameters.FORM_ITEM + BaseFieldCollection._parameters)
        .add(
            Param("clsItem", help="Class to attach to each recurring form container"),
            Param("column", help="Items are stacked vertically (column-wise) rather than horizontally"),
            Param("titleFunction", help="JS function that returns the title from the item state"),
            Param("readOnly", help="Do not allow adding/deleting items"),
            Param("autoForm", default=True),
            Param("isFieldContainer", default=True),
            Param(
                "showOverallError",
                help="Show an error message at the top of a field set if any contained form_fields have" "errors",
            ),
        )
        .addPassthroughs(dx.DxTabPanel.attrs)
    )

    def _data(self, context):
        out = {}
        one = super()._data(context=context)
        out[self._id] = dict(_value=[])
        return out


class SKRecurringTabs(SKRecurring):
    # language=Vue
    template = r"""
    <div :class="{'sk-recurring-tabs-container': true, '--sk-column': config.column}">
        <div class="sk-header-buttons">
                <dx-button 
                    v-if="!config.readOnly" 
                    class="sk-gallery-add-button"
                    type="success"
                    styling-mode="contained"
                    @click="async () => { await doAdd(state._value.length-1); $refs.tabs.instance.option('selectedIndex', state._value.length-1) }"
                >
                    <i class="fa-solid fa-plus"/> {{ config.addButtonName || 'Add' }}
                </dx-button>            
                <dx-button 
                    v-if="!config.readOnly" 
                    class="sk-gallery-delete-button"
                    type="danger"
                    styling-mode="contained"
                    @click="doDelete($refs.tabs.instance.option('selectedIndex'))"
                >
                    <i class="fa-solid fa-trash"/> {{ config.deleteButtonName || 'Delete' }}
                </dx-button>            
        </div>
        <div class="sk-recurring-overall-error" v-if="config.showOverallError && index == 0 && has_any_errors(state)">
            {{state._error}}
        </div>
        <dx-tab-panel
            :name="config._typeUID"
            :class="'sk-recurring' + (config.clsItem ? ' ' + config.clsItem : '')"
            v-bind="config._passthroughAttrs"
            ref="tabs"
            :scrolling-enabled="true"
            :show-nav-buttons="true"
        >
            <dx-tab-panel-item 
                v-for="(subState, index) in state._value"
                :title="config.titleFunction ? (config.titleFunction(subState) || 'None') : `${index+1}`"
                :key="index"
            >
                <template #default>
                    <SKFormContents
                        v-if="config.autoForm"
                        :class="'sk-recurring-tab-contents' +  (has_errors(subState) ? ' sk-recurring-error' : '')"
                        :config="config" 
                        :state="subState" 
                        :itemState="itemState"
                    />
                    <SKContents
                        v-else
                        :class="'sk-recurring-tab-contents' +  (has_errors(subState) ? ' sk-recurring-error' : '')"
                        :config="config" 
                        :state="subState" 
                        :itemState="itemState"
                    />            
                </template>
            </dx-tab-panel-item>
        </dx-tab-panel>
    </div>
    """
