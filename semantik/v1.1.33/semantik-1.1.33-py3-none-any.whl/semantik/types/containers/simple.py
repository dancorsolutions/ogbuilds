from ..common import *

__all__ = ["SimpleContainer"]


class SimpleContainer(ContainerType):
    _tag = "SKSimpleContainer"
    _parameters = Parameters(
        SSParam(
            id="id",
            help="The id is the name of the field as stored in the database and the state. This is set automatically"
            "based on the name of the class but can be overriden if needed by the applicaiton using this"
            "parameters.",
            required=True,
        ),
        Param(id="structure"),
        RTParam(id="style"),
    ).addPassthroughs(dx.DxBox)


class SKSimpleContainer(SKComponent):
    # language=Vue
    template = r"""
    <div 
        :name="config._typeUID"
        :class="'sk-simple-container reset-this ' + config.cls"
        v-bind="config._passthroughAttrs"
    >
        <SKContents
            class="sk-simple-container-contents"
            :config="config" 
            :state="state" 
            :itemState="itemState"
        />
    </div>     
    """
