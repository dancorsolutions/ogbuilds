import mongoengine

from semantik.types.common import *
from .base import *


__all__ = ["Number"]

#
# Number
#


class Number(SimpleField):
    _tag = "SKNumber"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxNumberBox)
    nullValue = None
    dataType = "float"


class SKNumber(SKComponent):
    imports = SKComponent.imports.union({"import { formatNumber } from 'devextreme/localization';"})

    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        <template v-if="config._passthroughAttrs && config._passthroughAttrs.format">
            {{ (state._value === null || state._value === undefined) ? '-' : formatNumber(state._value, config._passthroughAttrs.format) }}
        </template>
        <template v-else>
            {{ (state._value === null || state._value === undefined) ? '-' : state._value }}
        </template>
    </div>
    <dx-number-box
        v-else-if="config.calculated" 
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-number-box
        v-else 
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """

    computed = dict(formatNumber=js(r"""() => formatNumber"""))
