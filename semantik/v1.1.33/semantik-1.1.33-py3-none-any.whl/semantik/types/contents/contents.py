# language=rst
"""
Main contents view used to view and edit a collection of `Item`s
"""

from copy import deepcopy

import mongoengine

from roundtrip.server.connection import Connection

from ..common import *
from .remotestore import *
from .basecontents import *

__all__ = ["Contents", "Column"]


class Contents(BaseContents, Type):
    """
    Shows a collection of :class:`Item` objects in a data table
    """

    _tag = "SKContentsComponent"

    _parameters = BaseContents._parameters + Parameters(
        Param(id="filterRow", default=True),
        Param(id="filterPanel"),
        Param(id="canDuplicate", default=False),
        Param(id="filterBuilderPopup"),
        Param(id="storeState", default=True),
        RTParam(id="loadPanel", default=dict(delay=1000)),
        # data source related
        Param(id="type", help="only items of a specified item type (pass item type name)"),
        Param(
            id="path",
            help="show items under this fixed path (can be combined with <type>)",
        ),
        Param(id="showAll", help="show all items of <type> anywhere in the tree"),
        Param(
            id="baseQuery",
            help="function taking at, context that returns a mongoengine query to use as a base",
            callable=False,
        ),
        Param(
            id="allColumns",
            help="If true, retrieve all columns for items so they can be used in column " "calculations",
        ),
        # select mode
        Param(id="selectMode", default=False),
        SSParam(id="onSelect", callable=True),
        Param(id="columnChooser", help='"dragAndDrop" or "select"'),
        Param(id="path"),
        Param(id="dynamicLoading", default=True),
        Param(id="ordered", default=False),
        # Archiving
        Param(id="hideArchived", help="Show only non-archived items"),
        Param(id="deleteButtonArchives", help="The delete button causes an item to be archived rather than deleted"),
        # Other
        Param(
            id="masterDetail",
            help="Set up a master-detail row for this view, value should be a dict with the "
            "following keys: expand_all => true pre-expands all the detail rows, "
            'component => name of the component to use (must accept a "data" prop',
        ),
    )

    def _getFields(self):
        if self.p.ordered:
            return {self._id: mongoengine.ListField(mongoengine.StringField())}
        else:
            return {}

    def _data(self, context):
        if self.p.ordered:
            return Type._data(self, context=context)
        else:
            return {}

    def _toState(self, storage, state, context):
        if self.p.ordered and self.p.dynamicLoading:
            raise ValueError(f"Must use dynamicLoading=False with ordered=True in {self}")

        if not self.p.dynamicLoading:
            data = self._staticLoad(storage=storage, context=context)
            state[self._id] = dict(_value=data)

    def _staticLoad(self, storage, context=None):
        store = RemoteStore(
            showAll=self.p.get("showAll", None),
            type=self.p.get("type", None),
            columns=self.p.get("columns", None),
            path=self.p.get("path", None),
            baseQuery=self.p.get("baseQuery", None),
            allColumns=self.p.get("allColumns", None),
            hideArchived=self.p.get("hideArchived", None),
        )
        data = store.doLoad(
            options=dict(sort=[dict(desc=False, selector="_sk_order")]),
            at=storage,
            context=context,
        )["data"]
        return data

    def _toStorage(self, state, storage, context):
        return


class SKContentsComponent(BaseContentsComponent):
    linked = True
    store: RemoteStore

    inject = ["skRootConfigs"]

    skType: Contents

    imports = SKComponent.imports.union(
        {
            "import CustomStore from 'devextreme/data/custom_store'",
            "import { nextTick } from 'vue'",
        }
    )

    # language=Vue
    template = r"""
    <div 
        class="sk-contents-container"
        :style="config.style"
        ref="container"
        :key="_uid"
    >
        <SKDialog ref="confirm"></SKDialog>
        <div v-if="config.title" class="sk-contents-title" v-html="config.title"/>
        <dx-data-grid
            :remote-operations="true"            
            :data-source="config.dynamicLoading ? dataSource : state._value"
            :key-expr="config.dynamicLoading ? undefined : 'id'"
            v-model:selected-row-keys="selected"
            v-bind="config._passthroughAttrs"
            @initialized="config.dynamicLoading ? undefined : static_reload(state)"
            @rowDblClick="config.selectMode ? null : config.canEdit && doEdit($event.key)"
            @rowClick="config.selectMode ? doSelect($event.key) : null"
            ref="dataGrid"
        >
            <dx-data-grid-selection 
                :mode="config.selectMode ? 'single' : 'multiple'"
                :show-check-boxes-mode="config.selectMode ? null : 'onClick'"
            />
            <dx-data-grid-state-storing
                v-if="config.storeState"
                :enabled="true"
                type="custom"
                :customLoad="loadState"
                :customSave="saveState"
                :savingTimeout="250"
                :storage-key="config._typeUID"
            />
            <dx-data-grid-scrolling
                mode="virtual"
                row-rendering-mode="virtual"
            />
            <dx-data-grid-row-dragging
                v-if="config.ordered"
                :allow-reordering="true"
                :on-reorder="onReorder"
                :show-drag-icons="true"
            />    
            <dx-data-grid-paging :page-size="100"/>
            <dx-data-grid-header-filter
                :visible="true"
            >
                <dx-data-grid-header-filter-search :enabled="true"/>
            </dx-data-grid-header-filter>
            <dx-data-grid-filter-row :visible="config.filterRow" v-if="config.filterRow"/>
            <dx-data-grid-filter-panel :visible="config.filterPanel" v-if="config.filterPanel"/>
            <dx-data-grid-filter-builder-popup v-if="config.filterBuilderPopup"/>
            <dx-data-grid-column-chooser
                v-if="!!config.columnChooser"
                :enabled="false"
                :mode="config.columnChooser"
            />
            <dx-data-grid-column
                v-for="col, index of hydrateConfig(config.columns)" 
                v-bind="col._passthroughAttrs"
                :key="index"
            >
                <dx-data-grid-button
                    v-for="button in col.buttons"
                    v-bind="button.props"
                    v-on="button.handlers"
                >                    
                </dx-data-grid-button>
            </dx-data-grid-column>
            <dx-data-grid-master-detail
                v-if="config.master_detail"
                :enabled="true"
                :autoExpandAll="config.master_detail.expand_all"
                template="master_detail_template"
            />
            <template #master_detail_template="{ data }">
                <component v-bind:is="config.master_detail.component" :data="data"/>
            </template>
        </dx-data-grid>
        <div class="sk-contents-footer" style="background-color: white;">
            <div class="sk-contents-actions">
                <button 
                    v-if="!config.selectMode && config.canEdit && selected.length" 
                    @click="doEdit()" 
                    class="btn btn-sm ml-2 btn-outline-success"
                >
                    Edit
                </button>
                <button 
                    v-if="!config.selectMode && config.canEdit && selected.length && config.canDuplicate" 
                    @click="doDuplicate()" 
                    class="btn btn-sm ml-2 btn-outline-success"
                >
                    Duplicate
                </button>
                <button 
                    v-if="!config.selectMode && config.canDelete && selected.length" 
                    @click="$refs.confirm.show(
                        {
                            title: 'Confirm delete', width: '600px', height: '400px', 
                            buttons: [{label: 'Confirm', cls: 'btn-outline-danger', action: doDelete}]
                        }
                    )" 
                    class="btn btn-sm ml-2 btn-outline-danger"
                >
                    Delete
                </button>
                <template v-if="!config.selectMode && config.canAdd && config.addable && config.addControl === 'buttons'">
                    <button v-for="item in config.addable" @click="doAdd(item.type)" class="btn btn-sm ml-2 btn-outline-info">{{item.text}}</button>
                </template>
                <template v-else-if="!config.selectMode && config.canAdd && config.addable && config.addControl === 'dropdown'">
                    <dx-drop-down-button 
                        :elementAttr="{class: 'sk-dropdown-add-button'}"
                        text="Add"                         
                        height="31px"
                        @itemClick="doAdd($event.itemData.type)" 
                        :items="config.addable" 
                        displayExpr="text"
                        keyExpr="type"
                        class="btn btn-lg ml-2 btn-outline-info"
                    />
                </template>
                <button 
                    v-if="config.selectMode" 
                    @click="doSelect(null)" 
                    class="btn btn-sm ml-2 btn-outline-danger"
                >
                    Cancel
                </button>
                <button 
                    v-if="typeof config.canCopy === 'function' ? $refs.dataGrid.instance.getSelectedRows().some(config.canCopy) : config.canCopy" 
                    @click="doCopy()" 
                    class="btn btn-sm ml-2 btn-outline-info"
                >
                    Copy
                </button>
                <button 
                    v-if="config.canCopy" 
                    @click="doPaste()" 
                    class="btn btn-sm ml-2 btn-outline-info"
                >
                    Paste
                </button>
                <button 
                    @click="$refs.dataGrid.$_instance.state(null)" 
                    class="btn btn-sm ml-2 btn-outline-secondary" 
                >
                    Reset filters
                </button>
                <button 
                    @click="$refs.dataGrid.$_instance.refresh()" 
                    class="btn btn-sm ml-2 btn-outline-secondary" 
                >
                    <i class="fa-regular fa-rotate-right"></i>
                    Refresh
                </button>
                <SKItem
                    v-if="config.customActions"
                    v-for="action, index of hydrateConfig(config.customActions)"
                    :config="action"
                    v-show="(!action.onlyWhenSelected) || selected.length"
                    :state="{selected, grid: $refs.dataGrid?.instance}"
                    :itemState="{selected, grid: $refs.dataGrid?.instance}"
                    :key="action._typeUID"
                    @action="() => handleCustomAction({index, selected}).then((x) => x ? this.$refs.dataGrid.instance.refresh() : null)"
                />
            </div>
        </div>
     </div>
     """

    initialData = dict(selected=[], canPaste=False)

    watch = dict(
        # langauge=JavaScript prefix=[ suffix=]
        itemState=js(
            """
        function() { 
            this.$refs.dataGrid.$_instance.refresh(); 
        }
        """
        )
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        console=js("() => console"),
        # language=JavaScript prefix=[ suffix=]
        localStorage=js("() => localStorage"),
        # language=JavaScript prefix=[ suffix=]
        dataSource=js(
            r"""
        function(vm) { 
            return new CustomStore({
                key: "id", 
                load: function(options) { 
                    return vm.doLoad({options});
                } 
            }); 
        } 
        """
        ),
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        refreshAndSelectNext=r"""
        function(key) {
            let grid = this.$refs.dataGrid.$_instance;
            let index = grid.getRowIndexByKey(key);
            if(this.config.dynamicLoading) {
                grid.getDataSource().reload().then(
                    () => grid.selectRowsByIndexes([index]) 
                );
            } else {
                this.static_reload(this.state);
            }
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        withPopup=r"""
        function(callback) {
            this.popupCallback = callback;    
            this.$data.popupVisible = true;
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        onReorder=r"""
        function(e) {
            const visibleRows = e.component.getVisibleRows();
            const toIndex = this.state._value.indexOf(visibleRows[e.toIndex].data);
            const fromIndex = this.state._value.indexOf(e.itemData);
            const newData = [...this.state._value];

            newData.splice(fromIndex, 1);
            newData.splice(toIndex, 0, e.itemData);
            this.state._value = newData;
            let order = [];
            for(let i of this.state._value) {
                order.push(i.id);
            }
            this.saveOrder(order);
        }
        """,
        # function to selectively re-load the data grid if we're in static load mode (dynamicLoading = False)
        # language=JavaScript prefix=[ suffix=]
        static_reload=r"""
            function(state) {
                let self = this;
                if(this.state._sk_reloading) {
                    let rc = this.refreshStaticLoad();
                    rc.then(function f(v) {self.state._value = v;});
                } else {
                    this.state._sk_reloading = true;
                }                 
            }
        """,
        # language=JavaScript prefix=[ suffix=]
        loadState="""function() {
            let st = JSON.parse(localStorage.getItem(this.config._typeUID));
            if (st) {
                // Remove selectedRowKeys since it causes the load to fail
                delete(st.selectedRowKeys);
            }
            return st;
        }""",
        # language=JavaScript prefix=[ suffix=]
        saveState="""function(state) {
            localStorage.setItem(this.config._typeUID, JSON.stringify(state));
        }""",
    )

    def getStore(self):
        return RemoteStore(
            showAll=self.skType.p.get("showAll", None),
            type=self.skType.p.get("type", None),
            columns=self.skType.p.get("columns", None),
            path=self.skType.p.get("path", None),
            baseQuery=self.skType.p.get("baseQuery", None),
            allColumns=self.skType.p.get("allColumns", None),
            hideArchived=self.skType.p.get("hideArchived", None),
        )

    @method
    def doLoad(self, options):
        return self.getStore().doLoad(options=options, context=self.context, at=self.at)

    @method
    def refreshStaticLoad(self):
        """
        Re-load data from disk and return it to the client

        Used to re-load data when the component is redrawn for types with `dynamicLoading = False`
        """
        return self.skType._staticLoad(storage=self.at, context=self.context)

    def checkParentState(self):
        if not self.at._updateId:
            self.skRoot.notify("Save item before changing contents", "warning")
            return True
        return

    @method
    def doDelete(self):
        if self.checkParentState():
            return
        itemId = None
        deleted = []
        failed = 0
        messages = []
        for itemId in self.data.selected:
            item = self.getStore().getItem(itemId)
            if item:
                rc = item.sk.checkDelete(self.skRoot)
                if rc:
                    messages.append(rc)
                    failed += 1
                    continue
                else:
                    deleted.append(item.sk.id)
                if self.skType.p.deleteButtonArchives:
                    item.archive()
                else:
                    item.delete()

        plural = "s" if len(deleted) > 1 else ""
        notification = ""
        if deleted:
            notification = f"{len(deleted)} item{plural} deleted"
        if messages:
            notification += " " + ", ".join(messages)
        self.skRoot.notify(notification, "info" if not messages else "warning")
        self.client.refreshAndSelectNext(itemId)

    @method
    def doEdit(self, itemId=None):
        if self.checkParentState():
            return
        if not itemId:
            if not len(self.data.selected) == 1:
                return
            itemId = self.data.selected[0]
        item = self.getStore().getItem(itemId)
        if item:
            rc = item.sk.checkEdit(self.skRoot)
            if rc:
                self.skRoot.notify(rc, "info")
                return
        self.skRoot.openItem(item, target=self.skType.p.target)

    @method
    def doSelect(self, itemId=None):
        if not itemId:
            if not len(self.data.selected) == 1:
                return
            itemId = self.data.selected[0]
        item = self.session.getItem(itemId)
        self.skType.p.onSelect(self, item)

    @method
    def doAdd(self, itemType):
        if self.checkParentState():
            return
        self.skRoot.newItem(itemType, parent=self.at, target=self.skType.p.target)

    @method
    def doDuplicate(self, itemId=None):
        if self.checkParentState():
            return
        if not itemId:
            if not len(self.data.selected) == 1:
                return
            itemId = self.data.selected[0]
        item = self.getStore().getItem(itemId)
        initial = item.to_mongo()
        del initial["_updateId"]
        del initial["_id"]
        for k in item:
            v = item[k]
            if isinstance(v, list) and len(v) and isinstance(v[0], mongoengine.GridFSProxy):
                initial[k] = list(v)
            elif isinstance(v, mongoengine.GridFSProxy):
                initial[k] = v
        if hasattr(item.sk, "onDuplicate"):
            item.sk.onDuplicate(initial)
            return
        self.skRoot.newItem(item.__class__, parent=self.at, target=self.skType.p.target, initialData=initial)

    @method
    def doPaste(self):
        if self.checkParentState():
            return
        paste = self.skType.p.get("isPasteable", None)

        if not self.session.sk_clipboard or not paste:
            self.skRoot.notify("Nothing in the clipboard", "info")
            return

        toPaste = []
        if isinstance(paste, list) or isinstance(paste, tuple) or isinstance(paste, set):
            for i in self.session.sk_clipboard:
                if i.__class__.__name__ in paste:
                    toPaste.append(i)
        elif paste:
            toPaste = [i for i in self.session.sk_clipboard if paste(i)]

        if not toPaste:
            self.skRoot.notify("Nothing to paste here", "info")
            return

        for i in toPaste:
            new = deepcopy(i)
            new.id = None
            new._parent = self.at
            new.save()

        self.client.refreshAndSelectNext(str(new.sk.id))
        self.skRoot.notify(f"Pasted {len(toPaste)} items", "success")

    @method
    def doCopy(self):
        if not self.skType.p.get("canCopy", False):
            raise RuntimeError("Attempt to copy in a context where canCopy is not True")
        if not self.data.selected:
            self.skRoot.notify("Nothing selected", "info")
        self.session.sk_clipboard = [sm.getItem(id) for id in self.data.selected]
        self.skRoot.notify(f'Copied {len(self.data.selected)} item{"s" if len(self.data.selected) > 1 else ""}')

    @method
    def saveOrder(self, order):
        for index, id in enumerate(order):
            sm.getItem(id).update(set___sk_order=index)
