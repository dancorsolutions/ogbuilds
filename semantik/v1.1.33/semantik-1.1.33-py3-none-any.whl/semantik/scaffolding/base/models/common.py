import datetime

import mongoengine
from mongoengine import *

from roundtrip.core.javascript import js
from semantik.treestore.item import Item, VirtualItem
from semantik.treestore.semantik import Semantik as SemantikRoot
from semantik.types.core import validation as vl
from semantik.treestore.item import StorageManager as sm
from semantik.types.core.types import dynamic
from roundtrip.scaffolding.services.providers.make_token import make_url
from roundtrip.scaffolding.config.config import config


import semantik.types.core.components
from semantik.types.core.components import *
from semantik.types import all as types

from ..core.registry import registry as r
from ..core.utils.current import current
from .shared import all as shared

__all__ = (
    ["v", "vs", "js", "Item", "VirtualItem", "Semantik", "vl", "dynamic", "r", "types", "current", "shared"]
    + semantik.types.core.components.__all__
    + mongoengine.__all__
)


class Semantik(SemantikRoot):
    ignoreLeadingBreadcrumbs = 1


class V:
    def __getattr__(self, item):
        return getattr(js.this.itemState, item)._value


class VS:
    def __getattr__(self, item):
        return getattr(js.this.state, item)._value


v = V()
vs = VS()
