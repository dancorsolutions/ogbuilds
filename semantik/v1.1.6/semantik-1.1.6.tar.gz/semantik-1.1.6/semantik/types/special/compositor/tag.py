from semantik.types.form_fields.options.tag_box import SKTagBox, TagBox
from semantik.types.common import *

__all__ = ["GrammarTagBox"]


class GrammarTagBox(TagBox):
    _tag = "SKGrammarTagBox"


class SKGrammarTagBox(SKTagBox):
    imports = SKTagBox.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    # language=Vue
    template = r"""
    <dx-tag-box 
        ref="grammarSelect"    
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        @contentReady="filter_value(state._dynamic.options || config.options, state._value) && nextTick(() => this.$refs.grammarSelect.instance.focus())"
        {& sk.dx_field_attributes &}
    />    
    """

    computed = dict(nextTick=js("""() => nextTick"""))
