from ..base.current import current as currentBase
from ..base.current import classproperty, ThreadPool, Connection


class current(currentBase):
    _worker_pool = None

    import_mode = False
    mock_user = None

    @classproperty
    def connection(cls):
        return Connection.current

    @classproperty
    def session(cls):
        return cls.connection.session

    @classproperty
    def user(cls):
        return cls.connection.user

    @classproperty
    def worker_pool(cls):
        if cls._worker_pool is None:
            cls._worker_pool = ThreadPool(10)
        return cls._worker_pool
