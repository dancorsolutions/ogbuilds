from semantik.types.form_fields.options.select_box import SKSelectBox, SelectBox
from semantik.types.common import *

__all__ = ["GrammarSelectBox"]


class GrammarSelectBox(SelectBox):
    _tag = "SKGrammarSelectBox"


class SKGrammarSelectBox(SKSelectBox):
    imports = SKSelectBox.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._options.filter((x) => x.v == state._value).length ? state._options.filter((x) => x.v == state._value)[0].l : '-' }}
    </div>
    <dx-select-box 
        v-else 
        ref="grammarSelect"
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        @itemClick="$emit('interactiveCompleted')"
        @contentReady="nextTick(() => this.$refs.grammarSelect.instance.focus())"
        @blur="$emit('blur', $event)"
        @focusOut="$emit('focusOut', $event)"
        {& sk.dx_field_attributes &}
    />
    """

    computed = dict(nextTick=js("""() => nextTick"""))
