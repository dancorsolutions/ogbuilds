from semantik.types.common import *
from semantik.types.form_fields import base

__all__ = ["HTML"]


class HTML(base.SimpleField):
    """
    A WYSIWYG rich text editor type based on dx-html-editor
    """

    _tag = "SKHTML"
    _parameters = common_parameters.SIMPLE_FIELD.add(
        Param(id="title", help="A title string to show above the editor"),
        Param(id="style", help="Additional styles (must be a supplied as a style dict)"),
        Param(id="headers", help="List of heading styles", default=[False, 1, 2, 3, 4, 5]),
        Param(
            id="fonts",
            help="List of supported fonts",
            default=[
                "Arial",
                "Courier New",
                "Georgia",
                "Impact",
                "Lucida Console",
                "Tahoma",
                "Times New Roman",
                "Verdana",
            ],
        ),
        Param(
            id="sizes",
            help="List of supported size values",
            default=["8pt", "10pt", "12pt", "14pt", "18pt", "24pt", "36pt"],
        ),
    ).addPassthroughs(dx.DxHtmlEditor)
    _nullValue = ""
    dataType = "str"


class SKHTML(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.title" class="sk-field-title" v-html="config.title"/>
    <dx-html-editor
        :style="{backgroundColor: 'white', flexGrow: 1, ...(config.style || {})}"
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    >
        <dx-html-editor-media-resizing :enabled="true"/>
        <dx-html-editor-image-upload
            :tabs="['url', 'file']"
            file-upload-mode="base64"
        />

        <dx-html-editor-toolbar :multiline="true">
            <dx-html-editor-item name="undo"/>
            <dx-html-editor-item name="redo"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item
                :accepted-values="config.sizes"
                name="size"
            />
            <dx-html-editor-item
                :accepted-values="config.fonts"
                name="font"
            />
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="bold"/>
            <dx-html-editor-item name="italic"/>
            <dx-html-editor-item name="strike"/>
            <dx-html-editor-item name="underline"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="alignLeft"/>
            <dx-html-editor-item name="alignCenter"/>
            <dx-html-editor-item name="alignRight"/>
            <dx-html-editor-item name="alignJustify"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="orderedList"/>
            <dx-html-editor-item name="bulletList"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item
                :accepted-values="config.headers"
                name="header"
            />
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="color"/>
            <dx-html-editor-item name="background"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="link"/>
            <dx-html-editor-item name="image"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="clear"/>
            <dx-html-editor-item name="codeBlock"/>
            <dx-html-editor-item name="blockquote"/>
            <dx-html-editor-item name="separator"/>
            <dx-html-editor-item name="insertTable"/>
            <dx-html-editor-item name="deleteTable"/>
            <dx-html-editor-item name="insertRowAbove"/>
            <dx-html-editor-item name="insertRowBelow"/>
            <dx-html-editor-item name="deleteRow"/>
            <dx-html-editor-item name="insertColumnLeft"/>
            <dx-html-editor-item name="insertColumnRight"/>
            <dx-html-editor-item name="deleteColumn"/>
        </dx-html-editor-toolbar>        
    </dx-html-editor>
    """
