from ..common import *

__all__ = ["Template"]


class Template(DatalessType):
    """
    A type that can be used to render an arbitrary Roundtrip (or Vue) component within a Semantik type

    The tag name of the component should be passed in to the `component` parameter
    """

    _transparentState = True

    # class attributes
    components = []

    _tag = "SKTemplate"
    _parameters = common_parameters.FORM_ITEM + Parameters(
        Param(id="template", help="The name of the template", required=True),
    )


class SKTemplate(SKComponent):
    # language=Vue
    template = r"""
    <div class="sk-template">
        <component :is="template" v-if="template" v-bind="{config: config, state: state, itemState: itemState}"/>
    </div>
    """

    # language=JavaScript prefix=[ suffix=]
    computed = dict(
        template="""function() {
            let at = this;
            while(true) {
                if (at.$slots[this.config.template]) {
                    return at.$slots[this.config.template];
                }
                if (at.$parent) {
                    at = at.$parent;
                } else {
                    break;
                }
            }
        }""",
    )
