class TypesError(Exception):
    pass
