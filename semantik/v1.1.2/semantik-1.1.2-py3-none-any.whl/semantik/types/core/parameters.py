import inspect
import warnings

from .errors import TypesError
from ..core import types
from roundtrip.core.javascript import js, dumps
from roundtrip.component import component

__all__ = [
    "NO_PARAMETER",
    "NO_VALUE",
    "NO_DEFAULT",
    "Param",
    "Parameters",
    "Params",
    "RTParam",
    "SSParam",
    "ParametersMixin",
    "isStructure",
]


class ParameterError(TypesError):
    pass


class _NO_VALUE(object):
    def __bool__(self):
        return False

    @staticmethod
    def __nonzero__():
        return False


NO_VALUE = _NO_VALUE()


class _NO_PARAMETER(_NO_VALUE):
    pass


NO_PARAMETER = _NO_PARAMETER()


class _NO_DEFAULT(_NO_VALUE):
    pass


NO_DEFAULT = _NO_DEFAULT()


class Param:
    """
    Represents a parameter (usually a keyword argument) of a C{Type}

    Part of a C{Parameters} collection
    """

    def __init__(
        self,
        id,
        default=NO_DEFAULT,
        rtId=None,
        required=False,
        help=None,
        callable=True,
        hoist=False,
        structure=True,
        raw=False,
        inherit=False,
        preprocess=None,
        docCategory=None,
        docPassthrough=None,
    ):
        self.id = id  #: the id of the property
        self.hoist = hoist
        self.default = default  #: a default value
        self.rtId = rtId  #: the id to use when translating this to a property on the underlying component
        self.required = required  #: if True the type will raise an exception if this parameter is not supplied
        self.help = help  #: Help string (for future IDEs, autodocumentation, etc.)
        self.callable = callable  #: True if this parameter can accept callable objects
        self.structure = structure  #: True if this is a type instance or list of types instances
        self.raw = raw
        self.inherit = inherit
        self.preprocess = preprocess  #: function that takes (type instance, value) and returns an updated value
        self.docPassthrough = docPassthrough  #: Used if we want to document that this is a passthrough attribute used
        # to push options to a DevExtreme or similar component (we pass in the
        # actual External component class.
        self.docCategory = docCategory  #: Used to group parameters in the documentation by labelling with a string

    @property
    def isRT(self):
        """True if this is a parameter that can be directly converted into an attribute of a JS-side component"""
        return not not self.rtId


class RTParam(Param):
    """
    A quick way to define a parameter of a C{Type} that should simply be passed through as a proprety
    of the roundtrip control
    """

    isRT = True

    def __init__(
        self,
        id,
        default=NO_DEFAULT,
        rtId=None,
        required=False,
        help=None,
        callable=True,
        hoist=False,
        structure=True,
        raw=True,
        inherit=False,
        preprocess=None,
    ):
        id = id or rtId
        rtId = rtId or id
        super().__init__(
            id=id,
            default=default,
            rtId=rtId,
            required=required,
            help=help,
            callable=callable,
            hoist=hoist,
            structure=structure,
            raw=raw,
            inherit=inherit,
            preprocess=preprocess,
        )


class SSParam(Param):
    """
    A parameter that is only used server-side, never passed through config
    """

    def __init__(
        self,
        id,
        default=NO_DEFAULT,
        required=False,
        help=None,
        callable=True,
        hoist=False,
        structure=True,
        raw=False,
        inherit=False,
        preprocess=None,
    ):
        super().__init__(
            id=id,
            default=default,
            required=required,
            help=help,
            callable=callable,
            hoist=hoist,
            structure=structure,
            raw=raw,
            inherit=inherit,
            preprocess=preprocess,
        )


class Parameters:
    """
    Defines the possible parameters that can be supplied to a `Type`

    A collection of C{Param} objects that like a dictionary for most operations, but supports:

        * C{a+b} - equivalent to a dictionary update)
        * C{a-b} - removes all params from a that also appear in b (compares params by id;
            does nothing with params that only appear in b)
    """

    def __init__(self, *args, category=None):
        self.__dict__["d"] = {}
        for i in args:
            assert isinstance(i, Param)
            self.d[i.id] = i
            if category:
                i.docCategory = category

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k)

    def __getitem__(self, k):
        return self._resolveCallable(self.d[k])

    def __setattr__(self, k, param):
        assert isinstance(param, Param)
        self.d[k] = param

    def __contains__(self, k):
        return k in self.d

    def __setitem__(self, k, param):
        assert isinstance(param, Param)
        self.d[k] = param

    def keys(self):
        return self.d.keys()

    def items(self):
        return self.d.items()

    def values(self):
        return self.d.values()

    def update(self, other):
        assert isinstance(other, Parameters)
        self.d.update(other.d)

    def add(self, *parameters, category=None):
        for i in parameters:
            i.docCategory = category
        return Parameters(*(list(self.d.values()) + list(parameters)))

    def remove(self, *names):
        return Parameters(*[i for i in self.d.values() if i.id not in names])

    def __add__(self, other):
        c = Parameters()
        c.update(self)
        c.update(other)
        return c

    def __iadd__(self, other):
        self.update(other)
        return self

    def __sub__(self, other):
        for k in set(self.keys()) - set(other.keys()):
            del self.d[k]

    def __iter__(self):
        return self.d.__inter__()

    @staticmethod
    def _resolveCallable(item):
        if hasattr(item, "__call__"):
            if not item.callable:
                raise ParameterError("Callable passed to a parameter that does not support callables %s" % item.id)
            else:
                raise ParameterError(
                    "Attempted to get value of a callable parameter without supplying a context %s" % item.id
                )
        else:
            return item

    def addPassthroughs(self, attrs):
        docPassthrough = None
        if inspect.isclass(attrs) and issubclass(attrs, component.External):
            docPassthrough = attrs
            attrs = attrs.attrs

        toAdd = []
        for k in attrs:
            if type(k) is tuple:
                id = k[0]
                rtId = k[1]
            else:
                rtId = k
                id = k
            if id in self:
                if self[id].rtId:
                    continue
                id = "c" + id[0].upper() + id[1:]
            toAdd.append(Param(id=id, rtId=rtId, default=NO_DEFAULT, required=False, docPassthrough=docPassthrough))
        return self.add(*toAdd)

    def without(self, *args):
        new = Parameters()
        for k in args:
            if k in new.d:
                del new.d[k]
        return new


class Params(dict):
    """
    A collection of the actual parameters set on a `Type` instance
    """

    # TODO: refactor this so there is only one way to retrieve a parameter (and a `_get_raw`)

    def __init__(self, skType):
        super().__init__()
        self._skType = skType

    def _getRaw(self, k):
        return self[k]

    def __getattr__(self, k):
        return self(k)

    def _get_inherited(self, k):
        """
        Try to find a value for k in an ancestor of this component in the tree
        """
        at = self._skType._parent
        while at:
            if k in at.p:
                return at.p[k]
            at = at._parent
        return NO_VALUE

    def __call__(self, k, context=None, default=NO_DEFAULT):
        if k not in self._skType._parameters:
            raise KeyError("No parameter %r DEFINED on type %r" % (k, self._skType))
        elif k not in self:
            defn = self._skType._parameters[k]
            if defn.inherit:
                rc = self._get_inherited(k)
                if rc is not NO_VALUE:
                    return self._calc(k, rc, context=context, default=default)
            if default is not NO_DEFAULT:
                return default
            elif defn.default is not NO_DEFAULT:
                return defn.default
            else:
                raise KeyError("Required parameter %r not provided on type %r" % (k, self._skType))
        return self._calc(k, self[k], context=context, default=default)

    def _calc(self, k, raw, context, default=NO_DEFAULT):
        """
        Retrieve the value of a parameter

        Handles callable parameters and translates js parameters into dynamic client-side parameters but
        does not deal with defaults, inheritance, etc.
        """
        p = self._skType._parameters[k]

        if p.preprocess:
            raw = p.preprocess(value=raw, skType=self._skType)

        if p.raw:
            return raw
        elif (not hasattr(raw, "_as_javascript")) and getattr(raw, "skDynamicParameter", False):
            return raw
        elif hasattr(raw, "_as_javascript"):
            return raw
        elif hasattr(raw, "__call__") and p.callable:
            if context:
                return context._apply(raw)
            else:
                return raw()
        else:
            return raw


def isStructure(items):
    """Return True is a parameter is a list of parameters-supporting instances"""
    if not isinstance(items, list):
        return False
    if not items:
        return False
    for item in items:
        if getattr(item, "_is_parameter_type", False):
            continue
        return False
    return True


class ParametersMixin:
    _is_parameter_type = True  # marker for classes that accept parameters

    _parameters: Parameters = None
    p: Params

    def __init__(self, **kwargs):
        self._kwargs = {}  #: stores the keyword args and/or class attributes passed to this object
        # (e.g. for conversion to yaml, etc.)
        self.p = Params(self)
        self._attrsToParams()
        self._argsToParams(kwargs)
        self._checkParamsComplete()

    def _argsToParams(self, kwargs):
        """
        Fill type parameters from keyword arguments

        Used for instance-based type definitions
        """
        if not kwargs:
            return

        params = self.p

        # Set up the supplied keyword arguments as attributes
        for k, v in kwargs.items():
            if k not in self._parameters:
                raise TypesError("Unknown parameter %s for type %r" % (k, self))
            if getattr(v, "_is_parameter_type", False) and isinstance(v, types.Type):
                if v._parent is not None:
                    raise Exception("Trying to attach a type to two parents %r to %r and %r" % (v, v._parent, self))
                v._parent = self
            elif isStructure(v):
                for item in v:
                    if item._parent is not None:
                        raise Exception(
                            "Trying to attach a type to two parents %r to %r and %r" % (item, item._parent, self)
                        )
                    item._parent = self
            self._kwargs[k] = v
            params[k] = v

    def _attrsToParams(self):
        """
        Fill type parameters from class attributes

        Used for nested class based definitions
        """
        params = self.p

        for k in dir(self):
            if k in self._parameters:
                params[k] = getattr(self, k)  # set the raw parameter value in self.p
                continue
            if k.startswith("_") or (
                inspect.isclass(getattr(self, k)) and getattr(getattr(self, k), "_is_parameter_type", False)
            ):
                continue
            if k in self.__class__.__dict__:
                warnings.warn_explicit(
                    "Unrecognized attribute %s on type %r, were you trying to set a parameter?" % (k, self),
                    UserWarning,
                    inspect.getsourcefile(self.__class__),
                    inspect.getsourcelines(self.__class__)[1] if inspect.getsourcefile(self.__class__) else "N/A",
                )

    def _checkParamsComplete(self):
        params = self.p
        # Go through other parameters and raise an exception for any required parameters not supplied in the kwargs
        #  otherwise set the parameter values
        for param in self._parameters.values():
            if param.id not in params:
                if param.id == "id":
                    params[param.id] = self.__class__.__name__
                elif param.required and not (param.default or param.inherit):
                    raise TypesError("Parameter %s must be supplied for type %r" % (param.id, self))
