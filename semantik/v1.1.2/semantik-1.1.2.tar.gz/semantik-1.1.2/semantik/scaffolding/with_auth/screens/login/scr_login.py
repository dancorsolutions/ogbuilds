import time
import random

from roundtrip.scaffolding.utils import login_token
from roundtrip.scaffolding.config.config import config

from ....core.i18n import _
from ..common import *

screens = ["Login"]


class Login(PreLoginScreen):
    # language=Vue
    template = r"""
    <div class="min-vh-100 ig-login">
       <div class="card p-4 mb-0 ig-login-card">
          <div class="card-body" @keyup.enter="do_login()">
             <div class="-main-heading">Sign In</div>
             <ValidationError :error="error"/>
             <form>
                 <div class="input-group">
                    <input 
                        v-model="username" 
                        class="form-control" 
                        type="text" 
                        autocorrect="off" 
                        autocapitalize="none"
                        autocomplete="username"
                        placeholder="Username"
                    />
                 </div>
                 <div class="input-group">
                    <input 
                        v-model="password" 
                        class="form-control" 
                        type="password" 
                        placeholder="Password"
                        autocomplete="current-password"
                    />
                 </div>
             </form>
             <div class="input-group">
                <input 
                    v-model="remember_me" 
                    type="checkbox"
                    id="remember_me" 
                />
                <label for="remember_me"> Remember me</label>
             </div>
             <div class="row -buttons">
                <button @click="do_login()" type="button">Login</button>
             </div>
             <div class="-footer-text">
                Having trouble logging in?
                <br/>
                <span class="-link-text">We want to help!</span>
                <br/>
                <span class="-link-text" @click="do_forgot()">Forgot password?</span>
             </div>
          </div>
       </div>
       <div class="-post-card-text"><span class="-link-text" @click="do_tos()">Terms of Service</span></div>
    </div>    
    """

    initialData = dict(
        error="",
        username="",
        password="",
        banner=None,
        remember_me=False,
    )

    @method
    def do_login(self):
        username = self.data.username
        password = self.data.password

        if not username:
            self.data.error = _(f"You must provide a username")
            self.data.password = ""

        if not password:
            self.data.error = _("You must provide a password")
            return

        kwargs = dict(_archived__ne=True)
        user = m.User.objects(username=username).first()

        if not r.user.use_lockout:
            time.sleep(random.random() / 20.0)  # defeat timing attacks if we're using the non-lockout version
            # of login that tries not to reveal if the username is correct

        if user:
            if not user.password.is_set:
                self.session.temp_user = user
                self.app.open("SetPassword")
                return

            try:
                if user.password.check(password, with_lockout=r.user.use_lockout):
                    if r.user.use_lockout:
                        user.save()  # needed to reset attempts counter
                    m.Event.send(user=user, type=m.Event.TYPE.login.value)
                    self.app.login(user)
                    if self.data.remember_me:
                        self.app.client["$rt"].setCookie(
                            f"roundtripSession={login_token.make_token(user)}; "
                            f"max-age={config.login_token_expiry * 60 * 60}; path=/;"
                        )
                    else:
                        self.app.client["$rt"].setCookie(
                            "roundtripSession=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
                        )
                    if self.session.router_path_on_connection:
                        # TODO: check permissions here or in target screen
                        if not self.app.open(self.session.router_path_on_connection[1:]):
                            self.app.open("Upload")
                    else:
                        self.app.open("Upload")
                    return
                else:
                    m.Event.send(user=user, type=m.Event.TYPE.wrong_password.value)
                    if r.user.use_lockout:
                        self.data.error = _("Invalid password (%d attempts remaining)" % user.password.tries_remaining)
                    else:
                        self.data.error = _(f"Unknown username or password")
                    self.data.password = ""
                    if r.user.use_lockout:
                        user.save()  # needed to save incremented attempts counter
                    return
            except user.password.LockedError:
                m.Event.send(user=user, type=m.Event.TYPE.locked_account.value)
                self.data.error = _(
                    "Your account has been locked for security reasons. "
                    'Please click "Forgot password?" to have your account unlocked.'
                )
                self.data.password = ""
                return
        else:
            if r.user.use_lockout:
                self.data.error = _(f"Unknown username")
            else:
                self.data.error = _(f"Unknown username or password")
            self.data.password = ""
            return

    @method
    def do_forgot(self):
        self.app.open("Forgot")

    @method
    def do_tos(self):
        type = random.choice(["info", "success", "warning", "danger"])
        self.app.toast(f"Test {type} toast", type=type)
