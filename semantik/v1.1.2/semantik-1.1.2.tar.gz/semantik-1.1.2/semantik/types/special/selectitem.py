import mongoengine

from ..common import *
from ...treestore.item import StorageManager as sm
from semantik.types.form_fields.options.select_box import SKSelectBox, SelectBox
from semantik.types.form_fields.options.common import WITH_OPTIONS

__all__ = ["SelectItem"]


class SelectItem(SelectBox):
    """
    A select box (dropdown) for selecting items from an item type
    """

    dataType = "reference"
    _tag = "SKSelectItem"
    _parameters = WITH_OPTIONS.add(
        Param(
            id="copyFields",
            help="List of field ids to copy from the item; can accept (field_id, id_on_this_item)"
            " to rename form_fields, otherwise the copied field id is <select_field_id>_"
            "<copied_field_id>",
            default=[],
        ),
        Param(id="itemType", help="The type of item we're selecting"),
    ).addPassthroughs(dx.DxSelectBox)

    def _itemType(self):
        """The Item class of the item we're selecting"""
        if isinstance(self.p.itemType, str):
            return sm.getItemType(self.p.itemType)
        else:
            return self.p.itemType

    @property
    def _copyCanonical(self):
        """Canonical list of (field_id, id_on_this_item) of form_fields to be copied"""
        out = []
        for desc in self.p.copyFields or []:
            if isinstance(desc, str):
                source = desc
                target = f"{self._id}_{desc}"
            elif isinstance(desc, tuple):
                source, target = desc
            else:
                raise ValueError(f"Invalid copy specification {desc} in {self}")
            out.append((source, target))
        return out

    def _getFields(self):
        fields = dict()
        fields[self._id] = mongoengine.GenericReferenceField()

        # handle copied form_fields
        if self._copyCanonical:
            itemFields = self._itemType().sk.structure._getFields()
            for source, target in self._copyCanonical:
                fields[target] = itemFields[source]

        return fields

    def _toStorage(self, state, storage, context):
        super()._toStorage(state=state, storage=storage, context=context)
        for source, target in self._copyCanonical:
            if storage[self._id]:
                storage[target] = storage[self._id][source]
            else:
                storage[target] = None


class SKSelectItem(SKSelectBox):
    pass
