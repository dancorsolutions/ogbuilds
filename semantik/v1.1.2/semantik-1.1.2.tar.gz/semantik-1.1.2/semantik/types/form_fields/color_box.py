import mongoengine

from semantik.types.common import *
from .base import *


__all__ = ["ColorBox"]

#
# ColorBox
#


class ColorBox(SimpleField):
    _tag = "SKColorBox"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxCheckBox)
    dataType = "str"


class SKColorBox(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value sk-check-static">
        <label>{{ config._passthroughAttrs ? config._passthroughAttrs.text + ':' : '' }}</label>
        <div :style="'width: 20px; height: 20px; background-color: ' + state._value + ';'"/>
    </div>
    <dx-color-box 
        v-else
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
