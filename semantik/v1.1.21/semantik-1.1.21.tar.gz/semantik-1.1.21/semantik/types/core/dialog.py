from roundtrip.core.basic import *

__all__ = ["SKDialog"]


class SKDialog(Component):
    # language=Vue
    template = r"""
    <dx-popup
      v-model:visible="visible"
      :drag-enabled="false"
      :show-title="title ? true : false"
      :title="title"
      :width="width"
      :height="height"
      :minWidth="300"
      :minHeight="250"
      :wrapperAttr="{class:'sk-dialog'}"
    >
        <slot>
            <div class="sk-dialog-message">
                <p v-html="message"></p>
            </div>
            <div class="sk-dialog-buttons">
                <button 
                    v-for="button in buttons"
                    :class="{btn: true, [button.cls || 'btn-outline-secondary']: true}" 
                    @click="this.visible = false; button.action ? button.action() : null;"
                >
                    {{ button.label }}
                </button>
            </div>
        </slot>
    </dx-popup>
    """

    initialData = dict(
        visible=False,
        message=None,
        title=None,
        width="40%",
        height=None,
        buttons=[],
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        show=js(
            r"""
        function({ message, title, width, height, buttons }) {
            this.message = message || 'Are you sure?';
            this.title = title || 'Confirmation';
            this.width = width || '40%';
            this.height = height;
            this.buttons = buttons;
            this.$data.visible = true;
        }
        """
        )
    )
