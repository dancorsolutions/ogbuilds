from semantik.types.form_fields.text import SKText, Text
from semantik.types.common import *

__all__ = ["GrammarInput"]


class GrammarInput(Text):
    _tag = "SKGrammarInput"


class SKGrammarInput(SKText):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._value ? state._value : '-' }}
    </div>
    <dx-text-box 
        v-else-if="config.calculated"
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-text-box 
        v-else
        @key.enter="$emit('interactiveCompleted')"
        v-model:value="state._value"
        @focusOut="do_blur($event)"
        {& sk.dx_field_attributes &}
    />
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        do_blur=js(
            """
        function(event) {
            this.state._value = event.component._changedValue;
            this.$emit('interactiveCompleted');
        }
        """
        )
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        console=js("""() => console"""),
        # language=JavaScript prefix=[ suffix=]
        Event=js("""() => Event"""),
    )
