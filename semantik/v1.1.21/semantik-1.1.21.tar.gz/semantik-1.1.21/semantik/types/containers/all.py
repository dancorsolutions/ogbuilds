from . import tabs
from . import accordion
from . import simpletabs
from . import resizeable
from . import simple
from . import recurring
from . import splitpanes

from .tabs import *
from .accordion import *
from .simpletabs import *
from .resizeable import *
from .simple import *
from .recurring import *
from .splitpanes import *

__all__ = (
    tabs.__all__
    + accordion.__all__
    + simpletabs.__all__
    + resizeable.__all__
    + simple.__all__
    + recurring.__all__
    + splitpanes.__all__
)
