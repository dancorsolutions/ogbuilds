import typing

import roundtrip.server.connection
import semantik.treestore.item


__all__ = ["SKSession", "StackFrame"]


class StackFrame:
    """
    A frame within the Semantik navigation stack
    """

    item: semantik.treestore.item.BaseItem  #: the underlying item this frame is connected to
    state: object  #: the state of the item (data in the form, etc.)
    target: str  #: the target name for the frame: e.g. whether it should populate a popup, main screen area, etc.
    #: targets are

    def __init__(self, item, state, target):
        self.item = item
        self.state = state
        self.target = target


class SKSession:
    """
    Semantik `roundtrip` session object

    Semantik needs to use a special session object within the `roundtrip` framework to support its navigation system.
    Developers incorporating Semantik in their applications should sub-class this class for their session classes.
    """

    connection: roundtrip.server.connection.Connection  #: the roundtrip connection for which this session was created
    stack: []  #: a list of :class:`StackFrame` s
    sk_clipboard: []  #: a list of Items
    doAfterConfirmLeave: callable = None  #: a callable to be executed after the user confirms leaving the current
    #: page

    def __init__(self, connection):
        self.connection = connection
        self.stack = []
        self.sk_clipboard = []
        self.rt_history = []
        self.rt_history_index = None

    @property
    def sm(self) -> typing.Type[semantik.treestore.item.StorageManager]:
        """
        Quick-access to :class:`semantik.treestore.item.StorageManager`
        """
        return semantik.treestore.item.StorageManager

    @property
    def at(self):
        if not self.stack:
            return None
        return self.stack[-1].item

    @property
    def root(self) -> semantik.treestore.item.Item:
        """
        Quick access to the root item (uses `self.sm` 's `getRoot` method)
        """
        return self.sm.getRoot()

    def getItem(self, itemId: str) -> semantik.treestore.item.Item:
        """
        Find an item by uuid etc.
        """
        return self.sm.getItem(itemId)

    def getItemType(self, itemType: str) -> typing.Type[semantik.treestore.item.Item]:
        return self.sm.getItemType(itemType)

    def traverse(self, path) -> semantik.treestore.item.Item:
        return self.root.sk.traverse(path)
