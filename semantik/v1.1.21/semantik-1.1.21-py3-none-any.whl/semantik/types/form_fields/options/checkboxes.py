from .common import *

__all__ = ["CheckBoxes"]


#
# CheckBoxes
#


class CheckBoxes(OptionsField):
    """
    Shows a series of checkboxes and stores the result as a dict of bools.

    The dataType parameter here determines the type of the keys of the dict. The values are always bools.
    """

    _doc_base_component = None

    dataType = "str"
    _tag = "SKCheckBoxes"
    _parameters = WITH_OPTIONS.add(
        SSParam("default"),
        Param("columns", default=1),
    ).addPassthroughs(["style"])

    def _getFields(self):
        return {self._id: mongoengine.MapField(mongoengine.BooleanField())}


class SKCheckBoxes(OptionsComponent):
    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <div v-if="config.static" class="sk-checkboxes-static">
        <div v-for="opt of state._options" class="sk-checkboxes-checkbox" :style="'width: ' + Math.floor(100 / config.columns) + '%;'" :key="opt.v">
            <input v-if="state._value" type="checkbox" :id="opt.v" :nae="opt.v" v-model="state._value[opt.v]" :disabled="true"/> 
            <label :for="opt.v">{{opt.l}}</label>
        </div>
    </div>
    <div
        v-else 
        :style="config.style" 
        :class="'reset-this sk-checkboxes ' + config.cls"
        v-bind="config._passthroughAttrs"
    >
        <div v-if="state._error" class="sk-field-error-string-top">{{state._error}}</div> 
        <div v-for="opt of state._options" class="sk-checkboxes-checkbox" :style="'width: ' + Math.floor(100 / config.columns) + '%;'" :key="opt.v">
            <dx-check-box 
                @value-changed="state._value ? state._value[opt.v] = $event.value : null"
                :value="(state._value && state._value[opt.v]) || false"
                :name="opt.v"
                :text="opt.l"
            />
        </div>
    </div>
    """
