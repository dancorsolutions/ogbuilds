from ..common import *

__all__ = ["SimpleTabs", "SimpleTab"]


class SimpleTabs(ContainerType):
    _tag = "SKSimpleTabs"
    _parameters = (common_parameters.FORM_ITEM + common_parameters.HTML).add(
        Param("useShow", default=True),
        Param("structure", help="List of child objects (usually filled implicitly by declaring contained classes)"),
    )


class SKSimpleTabs(SKComponent):
    # language=Vue
    template = r"""
    <div
        v-bind="config._passthroughAttrs"
        class="nav-tabs-boxed sk-simpletab-panel"
    >
        <ul class="nav nav-tabs sk-simpletab-list" role="tablist">
            <li 
                v-for="(child, index) of children" 
                :class="{'nav-item': true, 'sk-simpletab-error': (state[child._id] && state[child._id]._error)}"
                @click="selectTab(index)"
            >
                <a :class="{'nav-link': true, 'active': index===selected}" role="tab" :href="'#tab'+index">
                    {{ child.title }}
                </a>
            </li>
        </ul>
        <div class="tab-content">
            <template v-if="config.useShow">
                <div 
                    :class="{'tab-pane': true}"
                    v-for="(child, index) in children"
                    v-show="index == selected" 
                    :id="'#tab'+index"
                    role="tabpanel"
                >
                    <SKItem
                        :config="child"
                        :state="state"
                        :itemState="itemState"
                        class="sk-simpletab-content"
                    />
                </div>
            </template>
            <template v-else>
                <div 
                    :class="{'tab-pane': true}"
                    v-for="(child, index) in children"
                    v-if="index == selected" 
                    :id="'#tab'+index"
                    role="tabpanel"
                >
                    <keep-alive>
                        <SKItem
                            :config="child"
                            :state="state"
                            :itemState="itemState"
                            class="sk-simpletab-content"
                        />
                    </keep-alive>
                </div>
            </template>
        </div>
    </div>
    """

    initialData = dict(selected=0)

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        children=js(
            r"""
        function() {
            return this.hydrateConfig(this.config.structure).filter((child)=>child.display === undefined || child.display);
        }
        """
        )
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        selectTab=js(
            r"""
        function(index) {
            return this.selected = index;
        }
        """
        )
    )


class SimpleTab(ContainerType):
    _tag = "SKSimpleTab"

    _parameters = (common_parameters.FORM_ITEM + common_parameters.HTML).add(
        Param(id="title", required=True, hoist=True),
        Param(id="structure"),
    )


class SKSimpleTab(SKComponent):
    # language=Vue
    template = r"""
    <SKContents
        :config="config" 
        :state="state" 
        :itemState="itemState"
    />
    """
