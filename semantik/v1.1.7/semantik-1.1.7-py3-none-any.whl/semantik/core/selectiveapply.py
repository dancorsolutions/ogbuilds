import inspect

__all__ = ["selectiveApply"]


def selectiveApply(fn, kwargs):
    """Call a function with a given set of keyword arguments but only pass in arguments the function is expecting"""
    args = set(inspect.getfullargspec(fn).args)
    selected = {k: v for k, v in kwargs.items() if k in args}
    return fn(**selected)
