from .common import *

__all__ = ["DragSelectList"]


#
# DragSelectList
#


class DragSelectList(BaseMayReorder):
    dataType = "str"
    nullValue = []
    _tag = "SKDragSelectList"
    _parameters = (
        WITH_OPTIONS.add(
            RTParam("width", default="100%"),
            RTParam("canReorder", default=True),
            Param("height", default=None),
            Param("style", default={}),
            Param("noDataTextLeft", default="- All items selected -"),
            Param("noDataTextRight", default="- Drag items here -"),
            Param("titleLeft", default="Available"),
            Param("titleRight", default="Selected"),
        )
        .addPassthroughs(dx.DxList)
        .remove("optionsDynamic")
    )  # does not yet support dynamic options


class SKDragSelectList(OptionsComponent):
    # language=Vue
    template = r"""
    <div 
        :style="{display: 'flex', flexDirection: 'column', height: config.height, ...config.style}" 
        class="sk-draglist-container"
        :id="config._id" 
    >
        <div style="display: flex; flex-direction: row;">
            <h6 v-if="config.titleLeft" style="width: 50%; margin-right: 8px; text-align: center;">{{config.titleLeft}}</h6>
            <h6 v-if="config.titleRight" style="width: 50%; text-align: center;">{{config.titleRight}}</h6>
        </div>
        <div style="display: flex; flex-direction: row; flex: 1;">
            <div style="width: 50%; margin-right: 8px;" class="sk-draglist-left">
                <dx-list 
                    :data-source="options.filter((i) => this.state._value ? this.state._value.indexOf(i.v) === -1 : true)"
                    :repaint-changes-only="true"
                    :no-data-text="config.noDataTextLeft"
                    style="border: 1px solid rgb(221, 221, 221); border-radius: 3px;"
                    ref="left_list"
                    {& sk.dx_field_attributes &}
                >
                    <dx-list-item-dragging
                        :data="options.filter((i) => this.state._value ? this.state._value.indexOf(i.v) === -1 : true)"
                        :allow-reordering="config.canReorder"
                        :on-drag-start="on_drag_start"
                        :on-add="on_remove"
                        :on-reorder="on_reorder"
                        :boundary="'#' + config._id"
                        handle=".dx-item.dx-list-item"
                        group="{&cmp.uid&}"
                    />
                </dx-list>
            </div>
            <div style="width: 50%;" class="sk-draglist-right">
                <dx-list 
                    :data-source="options.filter((i) => this.state._value ? this.state._value.indexOf(i.v) !== -1 : true)"
                    :repaint-changes-only="true"
                    :no-data-text="config.noDataTextRight"
                    style="border: 1px solid rgb(221, 221, 221); border-radius: 3px;"
                    ref="right_list"
                    {& sk.dx_field_attributes &}
                >
                    <dx-list-item-dragging
                        :data="options.filter((i) => this.state._value ? this.state._value.indexOf(i.v) !== -1 : true)"
                        :allow-reordering="config.canReorder"
                        :on-drag-start="on_drag_start"
                        :on-add="on_add"
                        :on-reorder="on_reorder"
                        :boundary="'#' + config._id"
                        handle=".dx-item.dx-list-item"
                        group="{&cmp.uid&}"
                    />
                </dx-list>
            </div>
        </div>
    </div>
    """

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        options=js("function() { return this.state._dynamic.options || this.config.options; }"),
        # language=JavaScript prefix=[ suffix=]
        console=js("() => console"),
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        on_reorder=r"""
             function(e) {
                 const visibleRows = e.component.getVisibleRows();
                 const toIndex = this.state._value.indexOf(visibleRows[e.toIndex].data);
                 const fromIndex = this.state._value.indexOf(e.itemData);
                 const newData = [...this.state._value];

                 newData.splice(fromIndex, 1);
                 newData.splice(toIndex, 0, e.itemData);
                 this.state['_value'] = newData;
             }        
         """,
        # language=JavaScript prefix=[ suffix=]
        on_drag_start=r"""function(e) {
            e.itemData = e.fromData[e.fromIndex].v;
        }""",
        # language=JavaScript prefix=[ suffix=]
        on_add=r"""function(e) {
            this.state._value.splice(e.toIndex, 0, e.itemData);
        }""",
        # language=JavaScript prefix=[ suffix=]
        on_remove=r"""function(e) {
            this.state._value = this.state._value.filter((i) => i !== e.itemData);
        }""",
    )
