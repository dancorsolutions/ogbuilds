"""
Requires monaco-editor

Currently this does not work. It's not clear why but Monaco is a complex editor and now seems to require a WebPack
plugin to build it.

"""

from semantik.types.common import *
from semantik.types.form_fields.base import SimpleField

__all__ = ["Monaco"]


class MonacoEditor(External):
    imports = {
        "import MonacoEditor from 'semantik/monaco'",
    }
    attrs = ["diffEditor", "original", "theme", "language", "options", "amdRequire", "style"]


class Monaco(SimpleField):
    _tag = "SKMonaco"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(MonacoEditor)
    _nullValue = ""
    dataType = "str"


class SKMonaco(SKComponent):
    # language=Vue
    template = r"""
        <MonacoEditor
            v-model:value="state._value"
            v-bind="config._passthroughAttrs"
        ></MonacoEditor>
    """
