from .form_fields_basics import *


__all__ = ["GenericCheck"]

#
# Check
#


class GenericCheck(GenericSimpleField):
    """
    Simple checkbox field.
    """

    _tag = "SKCheck"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxCheckBox)
    dataType = "bool"

    _doc_base_component = dx.DxCheckBox


class SKCheck(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value sk-check-static">
        <label>{{ config._passthroughAttrs ? config._passthroughAttrs.text + ':' : '' }}</label>
        <input type="checkbox" v-model="state._value" :disabled="true"/>
    </div>
    <dx-check-box 
        v-else
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
