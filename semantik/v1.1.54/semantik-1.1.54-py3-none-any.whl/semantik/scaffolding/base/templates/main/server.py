"""
Minimal scaffolding for a Semantik server.

This is the bare minimum you need to get a Semantik server running. If you run this once in your my_project/web folder,
it will create the basic files needed to get a webpack dev server running with a Semantik app behind it.

You can then run `python server.py` to start the app server and `npm start` to start the frontend server and reverse
proxy.
"""

from pathlib import Path

from semantik.scaffolding.server import SemantikServerConfig, SemantikServer
from roundtrip.application.application import RouterApplication


class MyApplication(RouterApplication):
    # language=Vue
    template = """
    <html>
        <body>
            <h1> Hello world </h1>
        </body>
    </html>
    """

    imports = {
        "import '../assets/main.scss'",
    }


config = SemantikServerConfig(
    project_web_path=Path(__file__).parent,
    application_class=MyApplication,
    crypto_password="CHANGE_ME_PLEASE",
    mongo_uri="mongodb://localhost:27017/##MY_APP_NAME##",
)


if __name__ == "__main__":
    server = SemantikServer(config, createWebFiles=True)
    server.go()
