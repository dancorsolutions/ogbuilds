__all__ = ["_"]


def _(s):
    return s
