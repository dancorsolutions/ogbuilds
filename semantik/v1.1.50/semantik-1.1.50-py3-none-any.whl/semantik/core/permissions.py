"""
Declarative permissioning:

    class MyItem(Item):

        @protect(p.x == p.session.y)
        def myMethod(self, a, b):
            pass
"""


from roundtrip.server import connection

__all__ = ["protect", "Permission", "Permissions", "P"]


class protect:
    def __init__(self, permission):
        self.permission = permission

    def __call__(self, method):
        def wrapper(obj, *args, **kwargs):
            if not self.permission._eval(obj):
                raise
            return method(obj, *args, **kwargs)

        wrapper.permission = self.permission
        return wrapper


class Permission:
    def __init__(self, op=None, l=None, r=None):
        self.__op = op
        self.__l = l
        self.__r = r

    def __and__(self, other):
        return Permission("and", self, other)

    def __or__(self, other):
        return Permission("or", self, other)

    def __neg__(self):
        return Permission("neg", self)

    def __getattr__(self, k):
        return Permission("getattr", self, k)

    def __eq__(self, other):
        return Permission("eq", self, other)

    def __ne__(self, other):
        return Permission("ne", self, other)

    def __call__(self, *args, **kwargs):
        return Permission("call", self, (args, kwargs))

    def _eval(self, obj):
        op = self.__operator
        l = self.__l
        r = self.__r

        def e(operand, o=obj):
            if isinstance(operand, Permission):
                return operand._eval(o)
            else:
                return operand

        if op == "and":
            return e(l) and e(r)
        elif op == "or":
            return e(l) or e(r)
        elif op == "neg":
            return not e(l)
        elif op == "ne":
            return e(l) != e(r)
        elif op == "call":
            return e(l)(*r[0], **r[1])
        elif op == "getattr":
            if e(l) is None:
                if r == "connection":
                    return connection.Connection.current
                elif r == "session":
                    return connection.Connection.current.session
                else:
                    return getattr(obj, r)
            else:
                return getattr(e(l), r)
        else:
            raise ValueError(op)


p = Permission()


class Permissions:

    """Collection of permissions for the application"""

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            v.id = k
        self._all = list(kwargs.values())

    def __add__(self, other):
        self._all.append(other)


class P:
    """
    Single permission
    """

    def __init__(self, category, description=None):
        self.id = None
        if description is None:
            self.category = "General"
            self.description = description
        else:
            self.category = category
            self.description = description
