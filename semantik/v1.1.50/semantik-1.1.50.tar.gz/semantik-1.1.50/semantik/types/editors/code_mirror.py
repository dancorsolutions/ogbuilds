"""
Requires vue-codemirror6

Currently we do not have a good solution for adding languages. This requires you to import the language support
object and set lang to an instance of that object -- Semantik types don't yet have a mechanism for dynamically
importing things based on a configuration setting (and we may never have that capability).

"""

from semantik.types.common import *
from semantik.types.form_fields.base import SimpleField

__all__ = ["CodeMirror"]


class CodeMirrorEditor(External):
    imports = {
        "import CodeMirror as CodeMirrorEditor from 'vue-codemirror6'",
    }

    attrs = [
        "modelValue",
        "basic",
        "minimal",
        "dark",
        "placeholder",
        "wrap",
        "tab",
        "allowMultipleSelections",
        "tabSize",
        "lineSeparator",
        "theme",
        "readonly",
        "disabled",
        "lang",
        "phrases",
        "extensions",
        "linter",
        "linterConfig",
        "gutter",
        "gutterConfig",
        "tag",
    ]


class CodeMirror(SimpleField):
    _tag = "SKCodeMirror"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(CodeMirrorEditor)
    _nullValue = ""
    dataType = "str"


class SKCodeMirror(SKComponent):
    # language=Vue
    template = r"""
        <CodeMirrorEditor
            :id="config._typeUID"
            v-model="state._value"
            v-bind="config._passthroughAttrs"
        ></CodeMirrorEditor>
    """
