from .common import *
from semantik.treestore.item import StorageManager as sm
from roundtrip.core.state import PersistentBase, unwrap
from html import escape

__all__ = ["TagBox"]


#
# TagBox
#


class TagBox(OptionsField):
    dataType = "str"
    nullValue = []
    _tag = "SKTagBox"
    _parameters = WITH_OPTIONS.add(
        RTParam("width", default="100%"),
        RTParam("acceptCustomValue", callable=False),
        SSParam("addValue", callable=False),
    ).addPassthroughs(dx.DxTagBox)

    def _getFields(self):
        d = super()._getFields()
        d[self._id] = mongoengine.ListField(d[self._id])
        return d

    def _toHTML(self, value, context=None):
        if not value:
            return ""
        if "optionsRaw" in self.p:
            options = self.p("optionsRaw", context=context)
        else:
            options = self.p("options", context=context)
        ld = {i["v"]: i["l"] for i in self._getOptions(options, context=context)}
        out = self._formatHTML([ld.get(i, i) for i in value])
        return out

    def _formatHTML(self, items):
        out = ""
        for i in sorted(items):
            out += f"""
            <span class="badge bg-light text-dark" style="font-weight: normal; font-size: 90%">
                {escape(i)}
            </span>
            """
        return out

    def _toStorage(self, state, storage, context):
        if "virtual" in self.p and self.p.virtual:
            return

        if "dataType" in self.p:
            dT = self.p.dataType
        else:
            dT = None

        if state is not None and self._id in state:
            val = self._valueToStorage(state[self._id]["_value"])
            if isinstance(val, PersistentBase):
                val = unwrap(val)
            if (dT == "reference" or (isinstance(dT, type) and issubclass(dT, Item))) and val is not None:
                val = sm.getItem(val)
            storage[self._id] = val
        else:
            storage[self._id] = None


class SKTagBox(OptionsComponent):
    # language=Vue
    template = r"""
    <dx-tag-box 
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        @contentReady="filter_value(state._dynamic.options || config.options, state._value)"
        @customItemCreating="create_custom_item"
        {& sk.dx_field_attributes &}        
    />
    """

    methods = dict(
        #: get rid of any items in the value that are not in options
        # language=JavaScript prefix=[ suffix=]
        filter_value="""
            function(options, values) {
                let option_dict = {};
                for(let i of options) {
                    option_dict[i.v] = i.l; 
                } 
                if(values)
                    for(let i=values.length-1; i>=0; i--) {
                        if(!option_dict[values[i]]) {
                            values.splice(i, 1);
                        }
                    }
                return values;
            }
        """,
        # language=JavaScript prefix=[ suffix=]
        create_custom_item="""
        function(args) {
            const new_value = args.text;
            const options = this.state._dynamic.options || this.config.options;
            if(!options.some((item) => item.v === new_value)) {
                if(this.state._dynamic.options)
                    this.state._dynamic.options = [{l: new_value, v: new_value}].concat(options);
                else
                    this.config.options = [{l: new_value, v: new_value}].concat(options);
                debugger;
                this.doAddValue(new_value);
            }
            args.customItem = {v:new_value, l:new_value};
         }
         """,
    )

    @method
    def doAddValue(self, value):
        self.skType.p.addValue(value)
