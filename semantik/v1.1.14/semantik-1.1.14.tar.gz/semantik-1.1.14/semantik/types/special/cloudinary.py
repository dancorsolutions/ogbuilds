import mongoengine
import time
import hashlib

from ..common import *
from roundtrip.scaffolding.config import config

__all__ = ["CloudinaryImage"]


class CloudinaryImage(Type):
    _parameters = common_parameters.FORM_ITEM.add(
        Param(id="options", required=True),
        RTParam(id="width", default="100%"),
    ).addPassthroughs(dx.DxTextArea)

    _tag = "VCloudinaryImage"

    def _getFields(self):
        return {self._id: mongoengine.DynamicField()}

    def options(self):
        timestamp = time.time()
        signature = hashlib.sha256(
            f"cloud_name={config.cloudinary.cloud_name}&"
            f"timestamp={timestamp}&"
            f"username={config.cloudinary.username}{config.cloudinary.api_secret}".encode("latin-1")
        ).hexdigest()
        return dict(
            timestamp=timestamp,
            signature=signature,
            cloud_name=config.cloudinary.cloud_name,
            api_key=config.cloudinary.api_key,
            username=config.cloudinary.username,
            insert_caption="Select media",
        )


class VCloudinaryImage(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._value ? state._value.url : '-' }}
    </div>
    <dx-text-box 
        v-else
        :value="state._value ? state._value.url : ''"
        :buttons="[
            {
                location: 'after', 
                name: 'change', 
                options: {
                    text:this.state._value ? 'Change' : 'Select', 
                    type:this.state._value ? 'default' : 'success', 
                    onClick: () => show(config.options)
                }
            },
            {
                location: 'after', 
                name: 'custom_clear', 
                options: {text:'Clear', type: 'danger', onClick: () => this.state._value = null}
            }
        ]"
        {& sk.dx_field_attributes &}
    />
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        show=js(
            """function(options) {
            this.widget = cloudinary.openMediaLibrary({...options, asset:this.state._value}, {insertHandler: this.insertHandler});
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        insertHandler=js(
            """function(data) {
            this.state._value = data.assets[0];
            console.log(data);
        }"""
        ),
    )
