import mongoengine

from semantik.types.common import *
from .base import *


__all__ = ["Text"]

#
# Text
#


class Text(SimpleField):
    _tag = "SKText"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxTextBox)
    _nullValue = ""
    dataType = "str"


class SKText(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._value ? state._value : '-' }}
    </div>
    <dx-text-box 
        v-else-if="config.calculated"
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-text-box 
        v-else
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
