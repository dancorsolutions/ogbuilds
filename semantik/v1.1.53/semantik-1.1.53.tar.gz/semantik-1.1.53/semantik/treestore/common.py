import bson

__all__ = ["ObjectId", "ROOTID", "NotFoundError", "AmbiguityError", "ConcurrencyError", "FormatError"]

ObjectId = bson.objectid.ObjectId
ROOTID = bson.objectid.ObjectId("000000000000000000000000")


class ItemError(Exception):
    """Item database error"""


class NotFoundError(ItemError):
    """No item found"""


class AmbiguityError(ItemError):
    """More than one item found"""


class ConcurrencyError(ItemError):
    """Edited/deleted by another user"""


class FormatError(ItemError):
    """Invalid formaton an item"""
