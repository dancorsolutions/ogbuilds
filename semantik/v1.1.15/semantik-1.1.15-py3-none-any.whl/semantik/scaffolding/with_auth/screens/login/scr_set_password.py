import datetime

from ..common import *
from semantik.types.core import validation as vl

screens = ["SetPassword"]


class SetPassword(Screen):
    # language=Vue
    template = r"""
    <div class="min-vh-100 ig-login">
       <div class="card p-4 mb-0 ig-login-card">
          <div class="card-body" @keyup.enter="do_login()">
             <div class="-main-heading">{& _('Reset password') &}</div>
             <ValidationError :error="error"/>
             <div class="input-group" v-if="!invalid_link">
                <input v-model="password" class="form-control" type="password" placeholder="{& _('password') &}"
                    autocomplete="new-password" name="password"/> 
            </div>                
             <div class="input-group" v-if="!invalid_link">
                <input v-model="confirm" class="form-control" type="password"  placeholder="{& _('confirm') &}" 
                    autocomplete="new-password" name="confirm"/> 
            </div>                
             <div class="row -buttons" v-if="!invalid_link">
                <button @click="set()" type="button">{& _('Set password') &}</button>
             </div>
             <div class="-footer-text">
                <span class="-link-text" @click="back_to_login()">{& _('Back to login') &}</span>
             </div>
          </div>
       </div>
    </div>
    """

    initialData = dict(password="", confirm="", error=None, invalid_link=False)

    @lifecycle
    def mounted(self):
        if Screen.mounted(self):
            return
        reset = m.PasswordReset.objects(key=self.session.set_password_key).first()
        if not reset:
            self.data.error = "Your link is invalid"
            self.data.invalid_link = True
            return

        if (reset.date - datetime.datetime.now()) > r.user.password_reset_link_expiry:
            self.data.error = "Your link has expired"
            self.data.invalid_link = True
            return

        if reset.expired:
            self.data.error = "Your link has expired"
            self.data.invalid_link = True
            return

        self.session.set_password_valid = True

    @method
    def set(self):
        reset = m.PasswordReset.objects(key=self.session.set_password_key).first()
        if not reset:
            raise SecurityError("Invalid operation")
        if (reset.date - datetime.datetime.now()) > r.user.password_reset_link_expiry:
            raise SecurityError("Invalid operation")
        if reset.expired:
            raise SecurityError("Invalid operation")

        self.session.set_password_valid = True

        if self.data.password != self.data.confirm:
            self.data.error = "Your passwords don't match"
            return
        message = vl.goodPassword()(value=self.data.password)
        if message:
            self.data.error = message
            return
        self.data.error = None

        user = m.User.objects(_archived__ne=True, id=reset.user).first()
        user.password.set(self.data.password)
        user.save()
        reset.expired = True
        reset.save()
        self.app.login(user)
        self.app.open("LearningHome")
        self.app.toast("Password reset", type="success")
        self.session.set_password_valid = False
        m.Event.send(user=user, type=m.Event.TYPE.set_password.value)

    @method
    def back_to_login(self):
        self.app.open("Login")
