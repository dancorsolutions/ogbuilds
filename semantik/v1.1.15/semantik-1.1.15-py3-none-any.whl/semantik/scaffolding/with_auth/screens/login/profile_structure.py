from semantik.treestore.item import StorageManager as sm
import semantik.types.all
from semantik.types.all import *
from semantik.types.core.parameters import *
from semantik.types.core import validation as vl
from semantik.types.core.components import SKComponent
from semantik.types.core.types import Type, ContainerType, DatalessType
from roundtrip.core.javascript import js

from ....core.i18n import _
from ....core.registry import registry as r
from ....models.shared import all as shared


class ProfileForm(Form):
    defaultLabelClass = "col-md-2"
    defaultFieldClass = "col-md-10"

    class Names(FieldSet):
        defaultClass = "col-lg-6"
        defaultLabelClass = "col-md-4"
        defaultFieldClass = "col-md-8"

        class first_name(Text):
            formLabel = _("First name")
            width = "100%"
            # validate = vl.required()
            readOnly = True

        class last_name(Text):
            formLabel = _("Last name")
            width = "100%"
            # validate = vl.required()
            readOnly = True

    class email(Text):
        formLabel = _("Email")
        width = "100%"
        validate = vl.required()


structure = ProfileForm()
