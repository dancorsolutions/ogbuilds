import mongoengine

from semantik.types.common import *
from .base import *

__all__ = ["DateRange"]


#
# DateRange
#


class DateRange(Type):
    _tag = "SKDateRange"
    _parameters = common_parameters.SIMPLE_FIELD.add(
        RTParam(id="width", default="135px"),
    ).addPassthroughs(dx.DxDateBox)
    nullValue = dict(start=None, end=None)
    dataType = None

    def _data(self, context):
        data = super()._data(context=context)
        data[self._id]["_value"] = self.p("default", default=self.nullValue, context=context)
        return data

    def _getFields(self):
        field = mongoengine.DynamicField()
        return {self._id: field}

    def _toHTML(self, value, context=None):
        if not value:
            return ""

        typ = self.p.get("type", "date")

        def fmt(v):
            if not v:
                return ""
            if typ == "date":
                return v.strftime("%m/%d/%Y")
            elif typ == "time":
                return v.strftime("%H:M:S")
            else:
                return v.strftime("%m/%d/%Y %H:%M:%S")

        return " - ".join([fmt(value["start"]), fmt(value["end"])])


class SKDateRange(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        <template v-if="state._value">
            {{(state._value.start) ? state._value.start.toLocaleDateString() : '-'}} 
                to 
            {{(state._value.end) ? state._value.end.toLocaleDateString() : '-'}}
        </template>
    </div>
    <div
        v-else 
        class="row"
    >
        <div class="col">
            <dx-date-box
                v-if="config.calculated" 
                :value="config.calculated().start"
                {& sk.dx_field_attributes &}
            />
            <dx-date-box
                v-else 
                v-model:value="state._value.start"
                {& sk.dx_field_attributes &}
            />
        </div>
        <div class="col-auto align-self-center">
        to
        </div>
        <div class="col">
            <dx-date-box
                v-if="config.calculated" 
                :value="config.calculated().start"
                {& sk.dx_field_attributes &}
            />
            <dx-date-box
                v-else 
                v-model:value="state._value.end"
                {& sk.dx_field_attributes &}
            />
        </div>
        <div class="col-auto align-self-center" v-if="state._value.start && state._value.end">
            ({{ Math.round((state._value.end.getTime() - state._value.start.getTime()) / (1000 * 60 * 60 * 24))  }} days)
        </div>
    </div>
    """
