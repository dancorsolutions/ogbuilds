import copy
import warnings
import inspect
from html import escape

import mongoengine

from roundtrip.core.javascript import js, dumps
from roundtrip.core.state import PersistentBase, unwrap

from ...treestore.item import Context
from ...core.i18n import _
from .parameters import *
from .errors import TypesError

__all__ = ["dynamic", "Config", "Type", "DatalessType", "ContainerType", "TypeContainer"]


def dynamic(skCompletion=None, **kwargs):
    # langauge=rst
    """
    Decorator for marking type parameters as being dynamically calculated server-side

    :param skCompletion: optional override to handle processing the return value from the server-side calculation.
        This should be a `js` object.
    :param kwargs: use keyword arguments on the decorator to identify any client-side data that should be monitored
        for changes and passed to the server-side function. Note: there is currently no way to specify client-side
        data that should be sent to the server-side function but does *not* need to be monitored for changes.
    """

    def fn(f):
        f.skDynamicParameter = True
        f.watch = kwargs
        f.complete = skCompletion
        return f

    return fn


class Config:
    def __init__(self, *args, **kwargs):
        self._data = dict(*args, **kwargs)

    def __getattr__(self, item):
        return self._data[item]

    def __setitem__(self, *args, **kwargs):
        self._data.__setitem__(*args, **kwargs)

    def __getitem__(self, *args, **kwargs):
        return self._data.__getitem__(*args, **kwargs)

    def __contains__(self, item):
        return item in self._data

    def _as_javascript(self):
        rc = "function() { return %s; }" % dumps(self._data)
        return rc

    def __repr__(self):
        return f"<Config {self._data!r}>"


class TypeMetaclass(type):
    order = 0

    def __new__(mcs, klassName, bases, klassDict):
        klassDict["_order"] = mcs.order
        klass = type.__new__(mcs, klassName, bases, klassDict)
        mcs.order += 1
        return klass

    def __repr__(cls):
        return "|Type class %s %s|" % (cls.__name__, hex(id(cls))[-4:])


def isStructure(items):
    """Return True is a parameter is a list of Type instances"""
    if not isinstance(items, list):
        return False
    if not items:
        return False
    for item in items:
        if isinstance(item, Type):
            continue
        return False
    return True


class TypeContainer:
    """
    Used by Type in class-hierarchy mode to put contained classes into an attribute other than `structure`
    """


class Type(ParametersMixin, metaclass=TypeMetaclass):
    """
    Class to represent and store a structured content element of a particular type

    Semantik type hierarchies can be defined in one of two ways:

        - by passing parameters (keyword arguments) when instantiating a Semantik type
        - by declaring a hierarchy of classes and setting class attributes to supply parameters
    """

    #
    # Class attributes
    #
    _byUID = dict()
    _instanceOrderCounter = 0
    _tag = None
    _fake = None  #: optional method that returns a mock value for this item

    #
    # Instance attribute defaults
    #
    _transparentState = False  #: decides whether a type creates a sub-object to hold contained values in state and
    # or makes its children peers with children of other (non-transparent) peers
    _transparentStore = False  #: decides whether a type creates a sub-object to hold contained values in storage and
    # or makes its children peers with children of other (non-transparent) peers
    _parameters = Parameters()  #: declared parameters for this type (class attributes or kwargs)
    _order = None  #: metaclass-supplied system-wide index used to keep track of declaration order when using the class hierarchy method
    _instanceOrder = None  #: constructor-created instance creation order
    _parent = None  #: the parent type object
    uid = None  #: uid for the type *instance*
    _ready = False  #: True when the type has finished being constructed (useful for @propertys etc. that may not get hit by inspect.getmembers before the object is ready to be used

    #
    # Methods
    #
    _toHTML: callable = None  #: Function that takes an item and returns HTML for the value of this type

    def __init__(self, parent=None, **kwargs):
        self._parent = parent
        self._instanceOrder = self._instanceOrderCounter
        self.__class__._instanceOrderCounter += 1

        ParametersMixin.__init__(self, **kwargs)

        self.uid = self._genUID()
        self._byUID[self.uid] = self

        self._id = self.p("id", default=None) if "id" in self.p else None

        # Class hierarchy composition (as opposed to passing structure as a parameter)

        byParameter = dict(structure=[])
        for k, v in inspect.getmembers(self, lambda o: inspect.isclass(o)):
            if k.startswith("_"):
                continue
            if issubclass(v, Type):
                child = v(parent=self)
                if k in self._parameters:
                    self.p[k] = v(parent=self)
                else:
                    byParameter["structure"].append(child)
            elif issubclass(v, TypeContainer):
                for k2, v2 in inspect.getmembers(v, lambda o: inspect.isclass(o)):
                    if not issubclass(v2, Type):
                        continue
                    child = v2(parent=self)
                    if v.__name__ not in byParameter:
                        byParameter[v.__name__] = []
                    byParameter[v.__name__].append(child)

        for parameter, children in byParameter.items():
            if not children:
                continue
            if parameter not in self._parameters:
                raise TypesError(f"Attempting to attach sub-types to unknown parameter {parameter!r} in {self!r}")
            children.sort(key=lambda a: a._order)
            self.p[parameter] = children

        self._ready = True

    def _up(self, className):
        at = self
        while 1:
            at = at._parent
            if not at:
                return
            if at.__class__.__name__ == className or className in [i.__name__ for i in at.__class__.__bases__]:
                return at

    def _root(self):
        at = self
        while 1:
            if not at._parent:
                return at
            at = at._parent

    def _genUID(self):
        """Generate a stable unique identifier for this type instance"""

        uid_param = None

        for k in "ident", "name", "id":
            if k in self.p and isinstance(self.p(k), str) and self.p(k).isidentifier():
                uid_param = self.p(k)
                if uid_param not in self._byUID:
                    return uid_param

        uid_class = self.__class__.__name__
        if uid_class not in self._byUID:
            return uid_class

        if self._root is not self and self._parent:
            uid_root_prefix = self._parent.uid.split(".")[-1] + "." + (uid_param or uid_class)
            if uid_root_prefix not in self._byUID:
                return uid_root_prefix

        if self._parent:
            uid_parent_prefix = self._parent.uid.split(".")[-1] + "." + (uid_param or uid_class)
            if uid_parent_prefix not in self._byUID:
                return uid_parent_prefix

        return (uid_param or uid_class) + str(self._order) + "_" + str(self._instanceOrder)

    def _config(self, context, statePath=None, static=False):
        """Return the config object used to render this type in an ItemView"""

        if statePath is None:
            statePath = []
        if not self._transparentState:
            statePath = statePath + [self._id]

        main = dict(
            _typeUID=self.uid,
            _tag=self._tag,
            _transparent=self._transparentState,
            _id=self._id,
            _statePath=statePath,
            _rest=Config(),
        )
        if static:
            main["static"] = True

        config = main["_rest"]

        passthroughAttrs = dict()
        bindings = {}
        attrs = {}
        dynamicParameters = {}

        for k, defn in self._parameters.d.items():
            # Server-side parameters do not go in config at all
            if isinstance(defn, SSParam):
                continue

            # normally config is evaluated when the Semantik component is loaded; parameters marked hoist are evaluated
            # when the parent component is defined
            if defn.hoist:
                target = main
            else:
                target = config

            if k not in self.p:
                # deal with default values
                if defn.inherit:
                    v = self.p(k, default=NO_VALUE, context=context)
                    if v is NO_VALUE:
                        if defn.default is not NO_DEFAULT:
                            v = defn.default
                        else:
                            continue
                elif defn.default is not NO_DEFAULT:
                    v = defn.default
                else:
                    continue
            else:
                # get the actual value
                v = self.p(k, context=context)

            # special processing for calculated values
            if k == "calculated" and v:
                v = js.arrow() << v

            if (not hasattr(v, "_as_javascript")) and getattr(v, "skDynamicParameter", False):
                if v.complete:
                    complete = v.complete
                    assert hasattr(complete, "_as_javascript"), f"complete must be a js object in {self!r}.{k}"
                else:
                    complete = js("this.state._dynamic[%s] = value" % dumps(k))

                if v.watch:
                    watch = dumps(v.watch)
                else:
                    watch = "{}"

                dynamicParameters[k] = dict(
                    skDynamicParameter=True,
                    watch=js("""function() { return %s; }""" % watch),
                    remote=js("""function(value) { return this.skGetDynamicParameter({name:'%s', value}); }""" % k),
                    complete=js("""function(value) { %s; }""" % complete._as_javascript()),
                )

                try:
                    v = v()  #: replace v with its default value (result of calling the dynamic function with no args)
                except TypeError as e:
                    raise TypeError(
                        f"@dynamic() methods need to be callable with no parameters and should then "
                        f"return a sensible default value in {e}"
                    )

            # roundtrip passthrough attributes
            if defn.isRT:
                rtId = defn.rtId
            else:
                rtId = k

            if defn.isRT:
                passthroughAttrs[rtId] = v
            elif isStructure(v):
                target[k] = [i._config(context=context, static=static) for i in v]
            else:
                target[k] = v

        if bindings:
            config["_bindings"] = bindings
        if passthroughAttrs:
            config["_passthroughAttrs"] = passthroughAttrs
        if attrs:
            config["_attrs"] = attrs
        if dynamicParameters:
            config["_dynamicParameters"] = dynamicParameters
        return main

    def _configDefault(self, context, statePath=None, static=False):
        config = self._config(context=context, statePath=statePath, static=static)
        return Config(**config)

    def _data(self, context):
        """
        Return initial data to pass to components of this type

        Note: this is not used to actually set `initialData` on components. Instead, this creates the top-level set of
        data on the ItemView that sub-components within the view get bound to (the binding is cascaded down to
        individual type components via the template javascript)
        """
        dynamic = dict()

        for k, defn in self._parameters.d.items():
            if isinstance(defn, SSParam):
                continue
            if k not in self.p:
                continue
            v = self.p(k, context=context)
            if (not hasattr(v, "_as_javascript")) and getattr(v, "skDynamicParameter", False):
                dynamic[k] = context._apply(v) if context else v()

        return {
            self._id: dict(_value=self.p("default", context=context) if "default" in self.p else None, _dynamic=dynamic)
        }

    def _getFields(self):
        """Return a dict of field id -> mongoengine field"""
        return {}

    @property
    def _children(self):
        """Return all child types that should be used for translating to storage, validating, etc."""
        if "structure" not in self.p:
            return []
        return self.p("structure")

    @property
    def _descendants(self):
        """Return a recursive list af all children below this type"""
        out = []
        for i in self._children:
            out.append(i)
            out += i._descendants
        return out

    def _validate(self, subState, context):
        """
        Validate current client-side state to (designed for validating forms before saving an item)

        :param subState: a part of the current client-side state (a sub-object of component.data)
        :param context: execution context for callable parameters
        :return: dict of type uid -> error string
        """
        error = None

        if "validate" in self.p:
            error = self.p(
                "validate",
                context=context._with(
                    subState=subState.get(self._id, None),
                    value=getattr(subState.get(self._id, None), "_value", None) if self._id in subState else None,
                )
                if context
                else None,
            )

        if error:
            subState[self._id]._error = error
            return {self._id: error}
        elif self._id in subState and subState[self._id].get("_error", None):
            del subState[self._id]["_error"]

        return None

    def _storageGet(self, storage, k):
        if self._isDict(storage):
            return storage.get(k, None)
        else:
            return getattr(storage, k, None)

    def _storageSet(self, storage, k, v):
        if self._isDict(storage):
            storage[k] = v
        else:
            setattr(storage, k, v)

    def _storageHas(self, storage, k):
        if self._isDict(storage) or isinstance(storage, mongoengine.Document):
            return k in storage
        else:
            return hasattr(storage, k)

    def _toState(self, storage, state, context):
        """
        Load stored data (from a database object or other source) into a given sub-object of client-side component state

        :param storage: database object (or similar), can be object-like or dict-like
        :param state: a sub-object of `State` representing sync'd client-side state for this component (used to write
        state once it's loaded from storage)
        :param context: execution context for any callable parameters
        :return: None
        """
        if "virtual" in self.p and self.p.virtual:
            self.p.virtual(state, storage, context)

        if storage is not None and self._storageHas(storage, self._id):
            if "state" in self.p:
                self.p.toState(storage, state, context)
                return

            v = self._valueToState(self._storageGet(storage, self._id))
            if self._id not in state:
                state.update(self._data(context=context))
                state[self._id]["_value"] = v
            elif v != state[self._id]["_value"]:
                state.update(self._data(context=context))
                state[self._id]["_value"] = v
        else:
            state.update(self._data(context=context))

    def _toStorage(self, state, storage, context):
        """
        Save data entered client-side to a database or other object
        :param state: a sub-object of `State` representing sync'd client-side state for this component (used to read
        state which is then saved to the storage)
        :param storage: database object (or similar), can be object-like or dict-like
        :param context: execution context for any callable parameters
        :return: None
        """
        if "virtual" in self.p and self.p.virtual:
            return

        if state is not None and self._id in state:
            val = self._valueToStorage(state[self._id]["_value"])
            if isinstance(val, PersistentBase):
                val = unwrap(val)
            self._storageSet(storage, self._id, val)
        else:
            self._storageSet(storage, self._id, None)

    def _valueToStorage(self, value):
        return value

    def _valueToState(self, value):
        return value

    def _isDict(self, storage):
        return isinstance(storage, dict)

    @classmethod
    def new(cls, name, children, **kwargs):
        """Programmatically create a subclass (for dynamic type creation)"""
        for child in children:
            kwargs[child.__name__] = child
        return type(name, (cls,), kwargs)

    def __repr__(self):
        return "<Type %s %s>" % (self.__class__.__name__, hex(id(self))[-4:])


class DatalessType(Type):
    """
    Inherits from Type but makes sure this control doesn't try to pull data into/out of the state
    """

    def _toState(self, storage, state, context):
        state.update(self._data(context=context))

    def _toStorage(self, state, storage, context):
        return

    def _data(self, context):
        data = Type._data(self, context=context)
        del data[self._id]["_value"]
        return data


class ContainerType(Type):
    """
    Inherits from Type but adds support for having contained types

    This container can be set to be 'transparent' so that data from the types in its structure will go into the storage
    in a new sub-mapping. Note that this expects formData to be FLAT -- i.e. it will still look at top level
    form data for the values of its children even while it groups them into a new sub-mapping in the storage data.
    """

    _transparentState = True  # If false, values of all child types will be stored in a separate object in the state
    _transparentStore = True  # If false, values of all child types will be stored in a separate object in the storage
    _embeddedDocumentCache = dict()
    _embeddedDocumentName = None  # If set, used as a key for caching the embedded document type created so it can be
    # shared between inheriting ContainerTypes, otherwise the type uid is used

    def _data(self, context):
        out = {}
        for child in self._children:
            out.update(child._data(context=context))
        if self._transparentState:
            return out
        else:
            return {self._id: out}

    def _validate(self, subState, context):
        if not self._transparentState:
            if self._id not in subState:
                return
            childState = subState[self._id]
        else:
            childState = subState

        errors = {}
        for skType in self._children:
            error = skType._validate(
                childState, context=context._with(state=childState) if context else Context(state=childState)
            )
            if error:
                if self._transparentState:
                    errors.update(error)
                else:
                    if self._id not in errors:
                        errors[self._id] = {}
                    errors[self._id].update(error)

        if "validate" in self.p:
            errors.update(
                self.p(
                    "validate", context=context._with(subState=childState) if context else Context(subState=childState)
                )
            )

        # this is the same whether or not state is transparent
        if errors:
            if self._id not in subState:
                subState[self._id] = dict(_error=True)
            else:
                subState[self._id]["_error"] = True
        else:
            if self._id in subState and subState[self._id].get("_error", None):
                del subState[self._id]["_error"]

        return errors

    def _getFields(self):
        """Return a dict of field id -> mongoengine field"""

        if "virtual" in self.p and self.p("virtual", default=False):
            return {}

        if self._transparentStore:
            return self._getFieldsInternal()
        else:
            return {self._id: mongoengine.EmbeddedDocumentField(self._embeddedDocument)}

    def _getFieldsInternal(self):
        out = {}
        for child in self._children:
            if "virtual" not in child.p:
                items = child._getFields()
                for k in items.keys():
                    if k is None:
                        warnings.warn_explicit(
                            f'Type classes must have required parameter "id" in {self!r}.{child!r}',
                            UserWarning,
                            inspect.getsourcefile(child.__class__),
                            inspect.getsourcelines(child.__class__)[1],
                        )
                        raise ValueError(f'Type classes must have required parameter "id" in {self!r}.{child!r}')
                out.update(items)
        return out

    @property
    def _embeddedDocument(self) -> type[mongoengine.EmbeddedDocument] or None:
        """
        For opaque storage: build an EmbeddedDocument class to hold a given set of form_fields

        Used by opaque type instances to build their own _embeddedDocument class
        """
        if not self._ready:
            return None

        if ("virtual" in self.p and self.p("virtual", default=False)) or self._transparentStore:
            return None

        key = self._embeddedDocumentName or self.uid

        if key in self._embeddedDocumentCache:
            return self._embeddedDocumentCache[key]

        name = self.uid + "Document"
        fields = self._getFieldsInternal()
        doc = type(name, (mongoengine.EmbeddedDocument,), fields)
        self._embeddedDocumentCache[key] = doc
        return doc

    def _toState(self, storage, state, context):
        if "virtual" in self.p:
            # virtual types calculate their own state
            state[self._id] = self.p("virtual", context=context)

        if not self._transparentStore and self._transparentState:
            raise ValueError("Cannot have a non-transparent storage and a transparent state")

        if self._transparentState:
            # transparent state with transparent storage
            for child in self._children:
                child._toState(storage, state, context=context)
        elif self._transparentStore:
            # non-transparent state with transparent storage
            subState = {}
            for child in self._children:
                child._toState(storage, subState, context=context)
            state[self._id] = subState
        else:
            # non-transparent state AND storage
            subState = {}
            subStorage = self._getSubStorage(storage, self._id)
            for child in self._children:
                child._toState(subStorage, subState, context=context)
            state[self._id] = subState

    def _toStorage(self, state, storage, context):
        if "virtual" in self.p:
            # virtual form_fields are not stored in the database
            return

        if not self._transparentStore and self._transparentState:
            raise ValueError("Cannot have a non-transparent storage and a transparent state")

        if self._transparentState:
            for child in self._children:
                child._toStorage(state, storage, context=context)
        elif self._transparentStore:
            # non-transparent state with transparent storage
            if self._id not in state:
                return
            for child in self._children:
                child._toStorage(state[self._id], storage, context=context)
        else:
            # non-transparent state AND storage
            if self._id not in state:
                return
            subStorage = self._getSubStorage(storage, self._id)
            for child in self._children:
                child._toStorage(state[self._id], subStorage, context=context)

    def _getSubStorage(self, storage, k):
        if self._isDict(storage):
            if k not in storage:
                storage[k] = dict()
            return storage[k]
        else:
            rc = getattr(storage, k)
            if rc is None:
                rc = storage._fields[self._id].document_type()
                storage[k] = rc
            return rc

    def __getitem__(self, item):
        for child in self.p.structure:
            if child._id == item:
                return child
        raise KeyError(item)
