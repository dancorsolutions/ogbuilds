from html import escape

import mongoengine

from ..common import *
from ..form_fields.base import common_parameters, SimpleField
from ..contents.remotestore import *
from ..contents import basecontents
from semantik.treestore.item import StorageManager
from semantik.treestore.item import Item

__all__ = ["ItemLookup", "ItemSelect"]


class BaseLookup(SimpleField):
    _parameters = common_parameters.SIMPLE_FIELD.add(
        # data source related
        Param(id="type", help="only items of a specified item type (pass item type name)"),
        Param(id="path", help="show items under this fixed path (can be combined with <type>)"),
        Param(
            id="search",
            help="the attribute on the item we should search to match items (we look for case "
            "insensitive substring matches)",
        ),
        Param(
            id="show",
            help="the attribute on the item we should show on the lookup; if you want to show a"
            "more complex expression provide a callable here or leave this blank and pass either "
            "allColumns or a list of columns then use displayExpr from the devextreme docs and/or "
            "itemTemplate to customize the appearance of items but note that leaving this blank will"
            "disable static mode for this component (it will show blank)",
        ),
        Param(id="showAll", help="show all items of <type> anywhere in the tree", default=True),
        Param(id="columns", required=False, help="List of contents Columns types"),
        Param(
            id="baseQuery",
            callable=False,
            help="function taking item, context that returns a mongoengine query to use as a base",
        ),
        Param(
            id="allColumns", help="If true, retrieve all columns for items so they can be used in column calculations"
        ),
        Param(id="hideArchived", help="Show only non-archived items"),
    )
    _nullValue = None
    dataType = "reference"


class SKBaseLookup(SKComponent):
    imports = SKComponent.imports.union(
        {
            "import CustomStore from 'devextreme/data/custom_store'",
        }
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        dataSource=js(
            r"""
        function(vm) { 
            return new CustomStore({
                key: "id", 
                load: function(options) { 
                    return vm.doLoad({options});
                },
                byKey: function(key) {
                    return vm.doLoad({options: {byKey: key}});
                }
            }); 
        } 
        """
        )
    )

    @method
    def doLoad(self, options):
        return self._p_node.store.doLoad(options=options, context=self.context, at=self.at)

    def ctMounted(self):
        self._p_node.store = self.makeStore()

    def makeStore(self):
        columns = self.skType.p.get("columns", [])
        search = self.skType.p.get("search", None)
        show = self.skType.p.get("show", None)

        if search:
            if not [i for i in columns if i.p.dataField == search]:
                columns.append(basecontents.Column(dataField=search))

        if show:
            if not [i for i in columns if i.p.dataField == show]:
                columns.append(basecontents.Column(dataField=show))

        return RemoteStore(
            showAll=self.skType.p.get("showAll", True),
            type=self.skType.p.get("type", None),
            columns=columns,
            path=self.skType.p.get("path", None),
            baseQuery=self.skType.p.get("baseQuery", None),
            allColumns=self.skType.p.get("allColumns", None),
            hideArchived=self.skType.p.get("hideArchived", None),
        )

    def _toHTML(self, value, context=None):
        if not value:
            return ""

        if isinstance(value, str):
            value = StorageManager.getItem(value)

        if self.skType.p.get("show", None):
            display = value[self.skType.p.show]
            store = self.makeStore()
        data = store.itemToColumns(value, context=context)

        out = f"""
        <span class="badge bg-light text-dark" style="font-weight: normal; font-size: 90%">
            {escape(display)}
        </span>
        """
        return out


class ItemLookup(BaseLookup):
    _tag = "SKItemLookup"
    _parameters = BaseLookup._parameters.addPassthroughs(dx.DxLookup)


class SKItemLookup(SKBaseLookup):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
    </div>
    <dx-lookup v-else
        value-expr="id"
        :element-attr="{class: 'sk-item-lookup'}"
        :data-source="dataSource"
        :search-expr="config.searchExpr || config.search || config.show"
        :display-expr="config.displayExpr || config.show || config.search"
        v-model:value="state._value"
        v-bind="config._passthroughAttrs"
        :show-cancel-button="false"
    >
    </dx-lookup>
    """


class ItemSelect(BaseLookup):
    _tag = "SKItemSelect"

    _parameters = BaseLookup._parameters.add(
        RTParam(
            "searchEnabled",
            default=True,
            help="Whether to enable search mode on the component (if False this will funciton like a plain select"
            "box that pulls all items of the specified type)",
        ),
    ).addPassthroughs(dx.DxSelectBox)


class SKItemSelect(SKBaseLookup):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
    </div>
    <dx-select-box v-else
        value-expr="id"
        :element-attr="{class: 'sk-item-select'}"
        :data-source="dataSource"
        :search-expr="config.searchExpr || config.search || config.show"
        :display-expr="config.displayExpr || config.show || config.search"
        v-model:value="state._value"
        v-bind="config._passthroughAttrs"
    >
    </dx-select-box>
    """
