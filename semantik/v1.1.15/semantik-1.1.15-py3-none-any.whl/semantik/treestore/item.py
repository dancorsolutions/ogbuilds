import uuid
import typing
import datetime

from bson import ObjectId
import mongoengine
import mongoengine.signals

from ..core.selectiveapply import selectiveApply
from roundtrip.core.classproperty import classproperty
from roundtrip.server.connection import Connection

from .common import *
import bson

__all__ = ["Item", "VirtualItem", "BaseItem"]


class StorageManager:
    registeredItemTypes = {}
    _root = None

    @classmethod
    def register(cls, itemType):
        # add the class to the registry
        cls.registeredItemTypes[itemType.sk.ident] = itemType

        # connect any signal handlers (user defined or sk builtins)
        for signalId in (
            "pre_init",
            "post_init",
            "pre_save",
            "post_save",
            "pre_delete",
            "post_delete",
            "pre_bulk_insert",
            "post_bulk_insert",
        ):
            localId = "on" + "".join([i.capitalize() for i in signalId.split("_")])
            if hasattr(itemType, localId):
                getattr(mongoengine.signals, signalId).connect(getattr(itemType, localId), sender=itemType)
            if hasattr(itemType.sk, localId):
                getattr(mongoengine.signals, signalId).connect(getattr(itemType.sk, localId), sender=itemType)

    @classmethod
    def getItemType(cls, itemType: str) -> typing.Type["Item"]:
        if isinstance(itemType, str):
            return cls.registeredItemTypes.get(itemType, None)
        else:
            return itemType

    @classmethod
    def getRoot(cls) -> "Item":
        if cls._root:
            return cls._root

        root = cls.registeredItemTypes["Root"].objects.first()
        if root is None:
            root = cls.registeredItemTypes["Root"](id=ROOTID)
            root.save()
        cls._root = root
        return root

    @classmethod
    def getItem(cls, itemId: str) -> typing.Any:
        if not itemId:
            return None
        elif "/" in itemId:
            [classIdent, itemId] = itemId.split("/")
            try:
                oid = ObjectId(itemId)
            except bson.errors.InvalidId:
                return None
            rc = cls.getItemType(classIdent)
            if rc is not None:
                return rc.objects.with_id(oid)
            else:
                return None
        else:
            return Item.objects.with_id(itemId)


class Context:
    """An object for storing context needed by callable parameters"""

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def _with(self, **kwargs):
        """Return a new context with the supplied keyword items added"""
        d = dict(**self.__dict__)
        d.update(kwargs)
        return Context(**d)

    def _apply(self, f, **kwargs):
        """Call a function with this context (uses selectiveApply to pass only desired arguments"""
        d = dict(context=self)
        d.update(self.__dict__)
        d.update(kwargs)
        return selectiveApply(f, d)


class ItemMeta(type(mongoengine.Document)):
    @staticmethod
    def __new__(mcs, name, bases, dct):
        if name != "Item":
            mcs.createDataFields(dct)
        cls = super(ItemMeta, mcs).__new__(mcs, name, bases, dct)
        if name != "Item":
            cls.sk.item = cls  # attach the mongoengine document class its Semantik class
            StorageManager.register(cls)
        return cls

    @classmethod
    def createDataFields(cls, dct):
        cls.getDBFields(dct)
        cls.getDBNamedChildren(dct)

    @classmethod
    def getDBFields(cls, dct):
        sk = dct["sk"]
        if sk.structure:
            for k, v in sk.structure._getFields().items():
                if k is None:
                    raise ValueError(f'Type classes must have required parameter "id" {cls!r}')
                if k not in dct:
                    dct[k] = v
        return

    @classmethod
    def getDBNamedChildren(cls, dct):
        sk = dct["sk"]
        if not sk.namedChildren:
            return
        for k, v in sk.namedChildren.items():
            if k not in dct:
                dct[k] = mongoengine.ReferenceField(v, dbref=True)


class BaseItem:
    """
    Common base Item class for Item and VirtualItem
    """

    sk: typing.ForwardRef("semantik.Semantik") = None  #: the `Semantik` instance for this item


class Item(BaseItem, mongoengine.Document, metaclass=ItemMeta):
    """
    Stored item
    """

    objects: mongoengine.QuerySetManager

    meta = dict(
        allow_inheritance=True,
        indexes=[dict(fields=["_parent"]), dict(fields=["_archived", "_parent"])],
    )

    _fixed_parent = None  #: ensure all children are created under this path (if `None` children will be created under
    # the current `at` item

    _parent = mongoengine.GenericReferenceField()  #: the parent `Item`
    _updateId = mongoengine.UUIDField()  #: OCC UUID
    _sk_order = mongoengine.IntField()  #: sort order for ordered contents
    _archived = mongoengine.BooleanField()
    _archived_date = mongoengine.DateTimeField()
    _update_date = mongoengine.DateTimeField()
    # (used for ordered containers)
    _disable_occ = False  #: if `True` disable optimistic concurrency checking

    def __init__(self, *args, **kargs):
        super(Item, self).__init__(*args, **kargs)
        self.sk = self.sk(document=self)

    @classmethod
    def onPostInit(cls, sender, document):
        if not getattr(document, "id", None):
            document.id = ObjectId()

    def save(self, *args, **kwargs):
        """Save this item to the database"""
        if self._disable_occ:
            return self.save_without_occ(*args, **kwargs)

        if self._updateId:
            if "save_condition" not in kwargs:
                kwargs["save_condition"] = dict()
            kwargs["save_condition"]["_updateId"] = self._updateId
        self._updateId = uuid.uuid4()

        try:
            return self.save_without_occ(*args, **kwargs)
        except mongoengine.SaveConditionError as e:
            raise ConcurrencyError(e)

    def save_without_occ(self, *args, **kwargs):
        """Save this item without doing Optimistic Concurrency Checking (OCC)

        OCC usually ensures this item has not been edited by other users before saving. This function does not
        perform that check. It has the same effect as saving with `_disabled_occ` set to True on the `Item` class.
        """
        if not self._parent_ref and not self.sk.ident == "Root":
            if self._fixed_parent and not self._parent:
                self._parent = self.sk.traverse(self._fixed_parent)
            else:
                raise FormatError("No parent set for item %r" % self)

        self._update_date = datetime.datetime.utcnow()

        return super().save(*args, **kwargs)

    def archive(self):
        self._archived = True
        self._archived_date = datetime.datetime.now()
        self.save()

    @property
    def _parent_ref(self):
        v = self._data.get("_parent", None)
        if v is None:
            return None
        if hasattr(v, "to_dbref"):
            return v.to_dbref()
        else:
            return v["_ref"]

    @property
    def _parent_skid(self):
        v = self._data.get("_parent", None)
        if v is None:
            return None
        m = self._fields["_parent"].to_mongo(v)
        return m["_cls"].split(".")[-1] + "/" + str(m["_ref"].id)


class VirtualItemMeta(type(mongoengine.EmbeddedDocument)):
    @staticmethod
    def __new__(mcs, name, bases, dct):
        if name != "VirtualItem":
            mcs.createDataFields(dct)
        cls = super(VirtualItemMeta, mcs).__new__(mcs, name, bases, dct)
        if name != "VirtualItem":
            cls.sk.item = cls  # attach the mongoengine document class its Semantik class
            StorageManager.register(cls)
        return cls

    @classmethod
    def createDataFields(cls, dct):
        cls.getDBFields(dct)

    @classmethod
    def getDBFields(cls, dct):
        sk = dct["sk"]
        if sk.structure:
            for k, v in sk.structure._getFields().items():
                if k not in dct:
                    dct[k] = v


class VirtualItem(BaseItem, mongoengine.EmbeddedDocument, metaclass=VirtualItemMeta):
    """
    'Virtual' stored item: item not stored on the database directly (e.g. stored in a list within a db-backed Item).

    Virtual items are 'saved' to a parent container (usually a dict or dict-like object in a list)
    """

    meta = dict(allow_inheritance=True)

    def __init__(self, *args, **kargs):
        super().__init__(*args, **kargs)
        self.sk = self.sk(document=self)

    def save(self, *args, **kwargs):
        raise RuntimeError("Cannot save virtual items")

    def save_without_occ(self, *args, **kwargs):
        raise RuntimeError("Cannot save virtual items")
