/**
 * Vue mixin for Semantik components (i.e. components passed state + context + config and draw using config)
 */
export const SemantikMixin = {
    methods: {
        hydrateConfig: function (config, $vm) {
            function hydrateOne(cfg, $vm) {
                let newConfig = Object.assign(
                    {},
                    cfg,
                    cfg._rest.bind(this)($vm)
                )
                delete newConfig._rest
                return newConfig
            }
            if (Array.isArray(config)) {
                return config.map((i) => hydrateOne.bind(this)(i, $vm))
            } else {
                return hydrateOne.bind(this)(config, $vm)
            }
        },
    },
}
