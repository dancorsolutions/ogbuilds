from ..common import *

screens = ["PreLogin"]


class PreLogin(PreLoginScreen):
    # language=Vue
    template = r"""
    <div class="min-vh-100 ig-pre-login">
        <div class="-image"></div>
       <button class="-sign-in" @click="do_login()">{& _('SIGN IN') &}</button>
    </div>    
    """

    @method
    def do_login(self):
        self.app.open("Login")
