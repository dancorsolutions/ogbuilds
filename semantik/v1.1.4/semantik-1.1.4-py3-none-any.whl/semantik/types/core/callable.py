class Call:
    def __init__(self, callable):
        pass
