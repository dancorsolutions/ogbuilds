from ..common import *

__all__ = ["SKValidationError"]


class SKValidationError(Component):
    props = ["error"]

    # language=Vue
    template = r"""
    <transition name="sk-flash">
        <div v-if="error" class="sk-validation-error" style="flex: 0;">
            <i class="fas fa-exclamation-triangle icon icon-lg"/>
            <strong>{{ error }}</strong>
        </div>
    </transition>
    """
