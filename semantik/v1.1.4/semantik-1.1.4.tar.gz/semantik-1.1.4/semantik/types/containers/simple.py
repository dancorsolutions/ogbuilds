from ..common import *

__all__ = ["SimpleContainer"]


class SimpleContainer(ContainerType):
    _tag = "SKSimpleContainer"
    _parameters = Parameters(
        Param(id="structure"),
        RTParam(id="style"),
    ).addPassthroughs(dx.DxBox)


class SKSimpleContainer(SKComponent):
    # language=Vue
    template = r"""
    <div 
        :name="config._typeUID"
        :class="'sk-simple-container reset-this ' + config.cls"
        v-bind="config._passthroughAttrs"
    >
        <SKContents
            class="sk-simple-container-contents"
            :config="config" 
            :state="state" 
            :itemState="itemState"
        />
    </div>     
    """
