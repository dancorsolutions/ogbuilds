from semantik.types.core import validation as vl

from ..common import *

screens = ["Reset"]


class Reset(PreLoginScreen):
    # language=Vue
    template = r"""
    <div class="min-vh-100 ig-login">
       <div class="card p-4 mb-0 ig-login-card">
          <div class="card-body" @keyup.enter="reset()">
             <div class="-main-heading">{& _('Reset Password') &}</div>
             <ValidationError :error="error"/>
             <label>{& _('Username') &}</label>
             <div class="input-group">
                <input 
                    v-model="username" 
                    class="form-control" 
                    type="text" 
                    placeholder="{& _('Username') &}"
                >
             </div>
             <label>{& _('Password') &}</label>
             <div class="input-group">
                <input v-model="password" class="form-control" type="password" autocomplete="new-password"
                 placeholder="{& _('Password') &}">
             </div>
             <label>{& _('Confirm Password') &}</label>
             <div class="input-group">
                <input v-model="confirm" class="form-control" type="password" autocomplete="new-password"
                 placeholder="{& _('Confirm Password') &}">
             </div>
             <div class="row -buttons">
                <button @click="reset()" type="button">{& _('Set password') &}</button>
             </div>
             <div class="-footer-text">
                <span class="-link-text" @click="back_to_login()">{& _('Back to login') &}</span>
             </div>
          </div>
       </div>
    </div>  
    """

    initialData = dict(message="", username="", error=None)

    @method
    def reset(self):
        if not self.data.username:
            self.data.error = f"Please provide your username"
            return
        elif self.data.password != self.data.confirm:
            self.data.error = "Your passwords don't match"
            return

        message = vl.goodPassword()(value=self.data.password)
        if message:
            self.data.error = "Password " + message
            return

        user = m.User.objects(_archived__ne=True, username__iexact=self.data.username).first()

        if not user:
            self.data.error = f"Invalid username"
            return

        m.Event.send(user=user, type=m.Event.TYPE.reset_password.value)
        user.password.set(self.data.password)
        user.save()

        self.app.open("Login")

    @method
    def back_to_login(self):
        self.app.open("Login")
