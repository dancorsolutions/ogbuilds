import bson
import mongoengine

from semantik.treestore.item import Item
from roundtrip.server.connection import Connection


__all__ = ["query", "oquery", "rquery", "OptionsReferenceQuery"]


class Query:
    def __init__(self, at=None):
        """
        To setup a query builder we start by specifying the base of the query::

            - str [item type]: 'MyItemType' => start with a generic query over all items of that type
            - str [path]: './MyOtherType' => start with a query for a specific type where the item parent is the current item
            - query object: custom query [FUTURE]
        """
        self.at = at
        self.qCalls = []
        self.skDynamicParameter = True
        self.watch = None
        self.complete = None
        self.default = []

    def build(self, context):
        q = self.getBaseQuery(context=context)
        for name, args, kwargs in self.qCalls:
            if name is None:
                q = q(*args, **kwargs)
            else:
                q = getattr(q, name)(*args, **kwargs)
        return q

    def getBaseQuery(self, context):
        if isinstance(self.at, mongoengine.QuerySet):
            return self.at
        elif self.at[0].isalpha():
            # item type specifier
            return Connection.current.session.getItemType(self.at).objects()
        elif self.at.startswith("./") or self.at.startswith("/"):
            return Item.objects(_parent=context.item.traverse(self.at).id)
        elif self.at is None:
            return Item.objects(_parent=context.item.id)
        else:
            raise ValueError("Unrecognised base query specifier %r" % self.at)

    #
    # query modifier calls
    #
    def only(self, *args, **kwargs):
        self.qCalls.append(("only", args, kwargs))
        return self

    def exclude(self, *args, **kwargs):
        self.qCalls.append(("exclude", args, kwargs))
        return self

    def order_by(self, *args, **kwargs):
        self.qCalls.append(("order_by", args, kwargs))
        return self

    def search_text(self, *args, **kwargs):
        self.qCalls.append(("search_text", args, kwargs))
        return self

    def filter(self, *args, **kwargs):
        self.qCalls.append(("filter", args, kwargs))
        return self


query = Query


class OptionsQuery(Query):
    def __init__(self, at=None, label=None, value=None, null=None):
        self.label = label
        self.value = value
        self.null = null
        super().__init__(at)

    def __call__(self, context=None):
        if context is None:
            return self.default
        q = self.build(context=context)
        scalars = [i for i in [self.value, self.label] if i]
        results = q.scalar(*scalars)
        out = []
        if self.null is not None:
            out.append(dict(l=self.null, v=None))
        for i in results:
            if isinstance(i, tuple):
                if isinstance(i[0], bson.ObjectId):
                    out.append(dict(v=str(i[0]), l=i[1]))
                else:
                    out.append(dict(v=i[0], l=i[1]))
            else:
                out.append(dict(v=i, l=i))
        return out


oquery = OptionsQuery


class OptionsReferenceQuery(OptionsQuery):
    """
    An options query that uses '<itemType>/<oid>' text as a value (for types that use mongoengine GenericReferenceField)

    param label: id of the field in the query result to use as a label, or a callable which is passed the item
        and should return the label string
    """

    def __init__(self, at=None, label=None, null=""):
        super().__init__(at, label=label, null=null)

    def __call__(self, context=None):
        if context is None:
            return self.default
        q = self.build(context=context)
        # TODO: efficiency improvement: should not need to retrieve the entire object, just label/id/item type
        #  challenge is that the mechanism for getting the proper '<itemType>/<id>' properly lives in
        #  item.sk
        results = q()
        out = []
        if self.null is not None:
            out.append(dict(l=self.null, v=None))
        for i in results:
            if isinstance(self.label, str):
                label = getattr(i, self.label)
            else:
                label = self.label(i)
            out.append(dict(l=label, v=i.sk.id))
        return out


rquery = OptionsReferenceQuery
