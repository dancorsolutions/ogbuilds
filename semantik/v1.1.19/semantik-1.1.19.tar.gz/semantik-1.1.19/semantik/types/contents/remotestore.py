# language=rst
"""
Provides server-side querying facilities for dx-data-grid remote stores
"""


import bson
from mongoengine.queryset.visitor import Q

from ...treestore.item import StorageManager, Item, BaseItem
from roundtrip.server import connection

from ..common import *

__all__ = ["RemoteStore"]


class SubOptions(dict):
    def __getattr__(self, attr):
        if attr not in self:
            raise AttributeError(attr)
        return self[attr]


class LoadOptions:
    def __init__(
        self,
        filter=None,
        sort=None,
        skip=None,
        take=None,
        requireTotalCount=None,
        group=None,
        totalSummary=None,
        groupSummary=None,
        dataField=None,
        searchOperation=None,
        searchValue=None,
        userData=None,
        searchExpr=None,
        byKey=None,
    ):
        self.dataField = dataField
        self.skip = skip
        self.take = take
        self.requireTotalCount = requireTotalCount
        self.searchOperation = searchOperation
        self.userData = userData
        self.searchValue = searchValue
        self.searchExpr = searchExpr  # used by DxLookup etc. to search for items without specifying a field
        self.byKey = byKey  # used as the only supplied option in our custom byKey method in our custom stores

        self.filter = filter
        self.sort = [SubOptions(i) for i in sort] if sort else None
        self.group = [SubOptions(i) for i in group] if group else None
        self.totalSummary = [SubOptions(i) for i in totalSummary] if totalSummary else None
        self.groupSummary = [SubOptions(i) for i in groupSummary] if groupSummary else None


class RemoteStore:
    def __init__(self, columns, showAll, path, type, hideArchived=False, allColumns=False, baseQuery=None):
        self.columns = columns
        self.showAll = showAll
        self.path = path
        self.type = type
        self.hideArchived = hideArchived
        self.allColumns = allColumns
        self.baseQuery = baseQuery

    def itemToColumns(self, o, context=None):
        row = dict(id=o.sk.id)
        for col in self.columns:
            row[col._fieldId] = col._compute(o, context=context)
        return row

    @property
    def cols(self):
        return {c._fieldId: c for c in self.columns}

    def getItem(self, item_id):
        return StorageManager.getItem(item_id)

    def doLoad(self, options, context, at=None):
        columnFields = []

        for col in self.columns:
            columnFields += col._getDataFields()

        e = LoadOptions(**options)

        if e.byKey:
            o = sm.getItem(e.byKey)
            return self.itemToColumns(o, context=context)

        rows = []
        rc = dict(data=rows)

        q = self.getBaseQuery(at=at, context=context).allow_disk_use(True)

        if e.filter:
            q = q(self.filterToQuerySet(e.filter))

        if e.searchOperation == "contains":
            if e.searchExpr and e.searchValue:
                q = q.filter(**{e.searchExpr + "__icontains": e.searchValue})

        # sort model
        if e.sort:
            keys = [("-" if i.desc else "+") + i.selector for i in e.sort]
            q = q.order_by(*keys)

        if e.dataField:
            # calculated field filter support
            if e.dataField in self.cols:
                column = self.cols[e.dataField]
                if "calc" in column.p and column.p.calc:
                    if "filterOptions" in column.p:
                        rc["data"] = column.p.filterOptions(context)
                    return rc
            q = q.only(e.dataField)
        elif not self.allColumns:
            q = q.only(*columnFields)

        if e.group:
            if not e.dataField:
                raise ValueError("Grouping is not supported")
            allDistinct = q.distinct(e.dataField)

            if e.skip is not None and e.take is not None:
                remaining = allDistinct[e.skip : e.skip + e.take]
            elif e.skip is not None:
                remaining = allDistinct[e.skip :]
            elif e.take is not None:
                remaining = allDistinct[: e.take]
            else:
                remaining = allDistinct

            for o in remaining:
                if isinstance(o, BaseItem):
                    rows.append(dict(key=o.sk._label_short, items=None, count=1))
                else:
                    rows.append(dict(key=o, items=None, count=1))
            if e.requireTotalCount or True:
                rc["totalCount"] = len(allDistinct)
            return rc

        if e.requireTotalCount or True:
            rc["totalCount"] = q.count()  # we need a count (without limit / skip) to return to the grid

        for o in q.skip(e.skip).limit(e.take):
            rows.append(self.itemToColumns(o, context=context))
        return rc

    def filterToQuerySet(self, filter, negate=False):
        lastQ = None
        nextOp = None

        if isinstance(filter[0], str):
            if filter[0] == "id":
                assert filter[1] == "="
                lastQ = Q(id=bson.ObjectId(filter[2].split("/")[1]))
            elif filter[0] == "!":
                assert not lastQ
                lastQ = self.filterToQuerySet(filter[1], negate=not negate)
            else:
                lastQ = Q(**self.filterToQueryArgs(*filter, negate=negate))
        else:
            for line in filter:
                if line == "and":
                    nextOp = "and"
                    continue
                elif line == "or":
                    nextOp = "or"
                    continue
                else:
                    newQ = self.filterToQuerySet(line, negate=negate)
                    if nextOp == "and":
                        lastQ = lastQ & newQ
                        nextOp = None
                    elif nextOp == "or":
                        # noinspection
                        lastQ = lastQ | newQ
                        nextOp = None
                    else:
                        lastQ = newQ

        return lastQ

    map_to_negative = {
        "equals": "<>",
        "=": "<>",
        "contains": "notcontains",
        "startswith": "notstartswith",
        "endswith": "notendswith",
        ">": "<=",
        "<": ">=",
        ">=": "<",
        "<=": ">",
    }

    def filterToQueryArgs(self, field_id, ft, fv, negate=False):
        """
        Translate a dx-data-grid filter to a set of keyword arguments to pass to a mongoengine query
        """
        out = {}

        # ignore filter requests on calculated form_fields (these should not have filtering enabled on the front-end
        # but this is a fallback if a developer accidentally leaves filtering on for a calc field
        if field_id in self.cols and "calc" in self.cols[field_id].p:
            return {}

        col = self.cols.get(field_id, None)
        if col and "filterToQueryArg" in col.p:
            return col.p.filterToQueryArg(ft, fv)
        if negate:
            if ft.lower() not in self.map_to_negative:
                raise ValueError("unsupported filter type negative of %s" % ft.lower())
            ft = self.map_to_negative[ft.lower()]

        if ft == "equals" and type(fv) is str:
            out[field_id + "__iexact"] = fv
        elif ft == "=":
            out[field_id] = fv
        elif ft == "contains":
            out[field_id + "__icontains"] = fv
        elif ft == "<>":
            out[field_id + "__ne"] = fv
        elif ft == "notcontains":
            out[field_id + "__not__icontains"] = fv
        elif ft.lower() == "startswith":
            out[field_id + "__istartswith"] = fv
        elif ft.lower() == "endswith":
            out[field_id + "__iendswith"] = fv
        elif ft.lower() == "notstartswith":
            out[field_id + "__not__istartswith"] = fv
        elif ft.lower() == "notendswith":
            out[field_id + "__not__iendswith"] = fv
        elif ft == ">":
            out[field_id + "__gt"] = fv
        elif ft == "<":
            out[field_id + "__lt"] = fv
        elif ft == ">=":
            out[field_id + "__gte"] = fv
        elif ft == "<=":
            out[field_id + "__lte"] = fv
        else:
            raise ValueError("unsupported filter type %s" % ft)
        return out

    def getBaseQuery(self, at=None, context=None):
        if self.baseQuery:
            return self.baseQuery(at=at, context=context)
        elif self.showAll:
            typ = StorageManager.getItemType(self.type)
            if not typ:
                raise ValueError("Need to specify a typ if using showAll")
            q = typ.objects()
        elif self.path:
            parent = StorageManager.getRoot().traverse(self.path)
            if parent._order:
                q = Item.objects(_id__in=parent._order)
            else:
                q = Item.objects(_parent=parent)
        elif self.type:
            typ = StorageManager.getItemType(self.type)
            at = at or connection.Connection.current.session.at
            q = typ.objects(_parent=at)
        else:
            at = at or connection.Connection.current.session.at
            q = Item.objects(_parent=at)

        if self.hideArchived:
            q = q.filter(_archived__ne=True)

        return q
