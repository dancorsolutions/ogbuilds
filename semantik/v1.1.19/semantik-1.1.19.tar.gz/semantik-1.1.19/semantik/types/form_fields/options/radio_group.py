from .common import *

__all__ = ["RadioGroup"]


#
# RadioGroup
#


class RadioGroup(OptionsField):
    dataType = "str"
    _tag = "SKRadioGroup"
    _parameters = WITH_OPTIONS.addPassthroughs(dx.DxRadioGroup)


class SKRadioGroup(OptionsComponent):
    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._options.filter((x) => x.v == state._value).length ? state._options.filter((x) => x.v == state._value)[0].l : '-' }}
    </div>
    <dx-radio-group
        v-else 
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
