from roundtrip.component import *
from roundtrip.core.javascript import js
from semantik.core.root import SKRoot
from semantik.treestore.item import StorageManager as sm
from semantik.views import ItemView


class BaseAdminRoot(SKRoot):

    item_view_header_component: str = "ItemViewHeader"
    item_view_component: str = "ItemView"

    # language=rst
    """
    Optional base class to quickly create the core admin UI with navigation within a Semantik-enabled roundtrip
    application.

    Sub-class this class and use it as a component inside a screen in your application.
    """

    imports = SKRoot.imports | {
        "import notify from 'devextreme/ui/notify'",
        "import hideToasts from 'devextreme/ui/toast/hide_toasts'",
        "import { nextTick } from 'vue'",
    }

    linked = True

    # language=Vue
    template = r"""
    <div 
        v-if="!!(windows._root && windows._root.item)"
        class="sk-admin-root"
    >
        <{& cmp.item_view_header_component &} 
            :item="windows._root.item"
            @navigateTo="navigateTo"
         />
        <{& cmp.item_view_component &} v-if="windows._root.item && windows._root.item.type !== 'Root'" :state="windows._root.state" :configs="config" :item="windows._root.item"/>
    </div>
    <dx-popup
        v-if="!!(windows.popup && windows.popup.item)"
        v-model:visible="popupWindowVisible"
        :animation="null"
        :show-title="true"
        :title="windows.popup.item.path[windows.popup.item.path.length-1].label" 
        :show-close-button="false"
        key="my-popup"
        @contentReady="(e) => e.component.content().style.padding='0'"
    >
        <div class="sk-popup">
            <{& cmp.item_view_component &} :state="windows.popup.state" :configs="config" :item="windows.popup.item"/>
        </div>
    </dx-popup>
    <dx-toast
        ref="toast"
        type="custom"
        :position="{at: 'top right', my:'top right', offset: '-10 10'}"
        :width="300"
        :display-time="2000"
        :wrapper-attr="{class: 'sk-toast-' + toast_type}"
    >
        <template #content>
            <i class="fa-solid fa-info" v-if="toast_type === 'info'"></i> 
            <i class="fa-solid fa-triangle-exclamation" v-if="toast_type === 'warning'"></i> 
            <i class="fa-solid fa-xmark-large" v-if="toast_type === 'danger'"></i> 
            <i class="fa-solid fa-thumbs-up" v-if="toast_type === 'success'"></i> 
            {{ toast_message }}
        </template>
    </dx-toast>
    """

    initialData = dict(toast_message="", toast_type=None, **SKRoot.initialData)

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        hide_toasts=js(
            """
        function() {
            hideToasts();
        }
        """
        ),
    )

    props = dict(type="type", id="id")
    syncProps = ["type", "id"]
    all_models = None  #: user application should set this to a module that contains references to all their sk models
    #: usually models.all

    @lifecycle
    def created(self):
        # language=rst
        """
        Open the root item when the client-side object is created

        .. todo:
           This class will eventually support operating on a sub-tree of items by working with an alternative root item
           but support for this is pending.
        """

        type = getattr(self.attrs, "type", None)
        id = getattr(self.attrs, "id", None)

        loaded = False
        if self.session.admin_initial_item_id:
            self.skRoot.openItem(sm.getItem(self.session.admin_initial_item_id), dont_push_route=True)
            loaded = True
        elif self.session.test and self.session.test[0] == "admin":
            ic = getattr(self.all_models, self.session.test[1], None)
            if ic:
                loaded = True
                if self.session.test[2]:
                    item = ic.objects(id=self.session.test[2])
                else:
                    item = ic.objects().first()
                self.skRoot.openItem(item)

            self.session.test = None
        elif type and id:
            self.skRoot.openItem(sm.getItem(f"{type}/{id}"))
            loaded = True

        if not loaded:
            self.skRoot.openItem(self.session.root)

    def checkForChanges(self, callback):
        # language=rst
        """
        Check whether the current item (if any) needs to be checked for changes and show a confirmation
        (see the `checkForChanges` boolean attribute on the `sk` attribute of the `Item`).
        """

        if self.session.at:
            # check when we're navigating away from an item that wants us to confirm if there are unsaved changes
            iv = self.down("ItemView")
            if iv:
                if self.session.at.sk.checkForChanges and self.skRoot.hasChanged():
                    iv.confirmThenDo(callback)
                    return True
        return False

    @method
    def completeNavigation(self):
        self.client.hide_toasts()
        item = self.session.getItem(self.session.completeNavigation["itemId"])
        self.openItem(item, dont_push_route=self.session.completeNavigation["dont_push_route"])

    @method
    def navigateTo(self, itemId: str, force: bool = False, dont_push_route: bool = False):
        # language=rst
        """
        Navigate to an item after checking whether the item needs to be checked for changes.
        """

        if self.session.at and not force:
            self.session.completeNavigation = dict(itemId=itemId, dont_push_route=dont_push_route)
            if self.checkForChanges(self.completeNavigation):
                return
        self.client.hide_toasts()
        item = self.session.getItem(itemId)
        return self.openItem(item, dont_push_route=dont_push_route)

    def notify(self, message: str, kind: str = "info"):
        # language=rst
        """
        Show a brief notification (toaster) to the user

        :param message: the message to display
        :param kind: one of 'warning', 'error', 'info' (*check this*)
        """
        self.data.toast_message = message
        self.data.toast_type = kind
        # self.client['$refs']['toast']._instance.show()
