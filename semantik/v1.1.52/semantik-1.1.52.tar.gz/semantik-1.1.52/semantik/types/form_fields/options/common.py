import enum
import inspect

import mongoengine

from roundtrip.core.context import getJavascriptArguments
from .. import options_query
from ..base import SimpleField
from semantik.treestore.item import Item

from semantik.types.common import *


def preprocessOptionsDynamic(value, skType: Type):
    # language=JavaScript prefix=[ suffix=]
    DATASOURCE = r"""
        function() {
            let load_data = %s;  // access relevant properties to ensure appropriate reactivity          
            return {
                key: "v", 
                cacheRawData: true,
                loadMode: 'raw',
                load: (function(options) {
                    return this.doLoad([options, load_data]); 
                }).bind(this)
            }
        }
    """

    if "options" in skType.p:
        raise RuntimeError(f"Cannot combine optionsDynamic with options/optionsRaw {skType!r}")
    args = getJavascriptArguments(value, fixed={"context", "options"})
    jsargs = args if args else "{}"
    rc = DATASOURCE % (jsargs)
    return js(rc)


WITH_OPTIONS = common_parameters.SIMPLE_FIELD.add(
    Param(
        id="options",
        callable=True,
        required=False,
        help="List of options in `dict(l=,v=)` form, an options function that returns such a list, or an "
        "`OptionsQuery` that can be called from a DevExtreme `CustomStore`",
    ),
    Param(
        id="optionsDynamic",
        callable=False,
        required=False,
        preprocess=preprocessOptionsDynamic,
        help="A callable method that is executed server-side to return a list of options to pass to the " "client",
    ),
    SSParam(
        id="optionsRaw",
        callable=False,
        help="Version of the `options` parameter that removes any filtering normally applied -- used to "
        "provide labels for previously stored values but not to provide available options. Optional.",
    ),
    RTParam(id="valueExpr", default="v"),
    RTParam(id="displayExpr", default="l"),
    category="Options Parameters",
)


class OptionsSupportMixin:
    def _generateOptions(self, data, context):
        if "options" in self.p:
            results = self._getOptions(options=self.p.options, context=context)
            data[self._id]["_options"] = results
            return results
        else:
            return []

    def _getOptions(self, options, context):
        if not options:
            return []

        elif isinstance(options, list):
            if isinstance(options[0], str):
                return [dict(v=i, l=i) for i in options]
            elif isinstance(options[0], tuple):
                return [dict(v=i[0], l=i[1]) for i in options]
            else:
                return options

        elif isinstance(options, options_query.OptionsQuery):
            # a query based on this item
            return options(context=context)

        elif getattr(options, "skDynamicParameter", False):
            return options()

        elif hasattr(options, "__call__"):
            return options(context=context)

        else:
            raise ValueError("unrecognized options")


class OptionsField(OptionsSupportMixin, SimpleField):
    pass


class OptionsComponent(SKComponent):
    imports = SKComponent.imports.union(
        {
            "import CustomStore from 'devextreme/data/custom_store'",
        }
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        dataSource=js(
            r"""
            function() {
                console.log("computed dataSource", this)
                if(this.config.optionsDynamic) {
                    return new CustomStore(this.config.optionsDynamic.bind(this)());
                } else {
                    let out = [...(this.state?._dynamic?.options || this.config?.options || this.state._options)]
                    if(!this.state._value?.length) {
                        return out
                    }
                    for(let k of this.state._value) {
                        if(!out.some((item) => item.v === k)) {
                            out.push({l: k, v: k})
                        }
                    }
                    return out
                }
            }
        """
        )
    )

    @method
    def doLoad(self, args):
        if "optionsDynamic" in self.skType.p:
            context = self.context
            return self.skType.p._getRaw("optionsDynamic")(options=args[0], context=context, **args[1])
        else:
            raise RuntimeError(f"Client-side attempted to call doLoad on {self!r} but dynamicOptions is not defined")


class BaseMayReorder(OptionsField):
    def _data(self, context):
        data = super()._data(context=context)
        data["_value"] = []
        return data

    def _getFields(self):
        d = super()._getFields()
        if self.p.canReorder:
            d[self._id] = mongoengine.ListField(d[self._id])
        else:
            d[self._id] = mongoengine.DictField()
        return d

    def _valueToState(self, value):
        value = super()._valueToState(value)
        if self.p.canReorder:
            return value or []
        else:
            return sorted([k for k in value]) if value else []

    def _valueToStorage(self, value):
        value = super()._valueToStorage(value)
        if self.p.canReorder:
            return value or []
        else:
            value = {k: True for k in value}
            return value or {}
