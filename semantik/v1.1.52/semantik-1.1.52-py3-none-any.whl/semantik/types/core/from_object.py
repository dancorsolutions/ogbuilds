from .. import all


def from_object(o, extra={}):
    d = dict()
    typeName = None
    for k, v in o.items():
        if k.startswith("$"):
            if k == "$type":
                typeName = v
                continue
            d[k] = from_object(v, extra=extra)

    if not isinstance(extra, dict):
        extra = extra.__dict__

    cls = getattr(all, typeName, extra.get(typeName, None))
    if not cls:
        raise ValueError("Class %s could not be found" % cls)
    return cls(**d)
