from . import scr_pre_login
from . import scr_login
from . import scr_set_password
from . import scr_forgot
from . import scr_profile

from .scr_pre_login import *
from .scr_login import *
from .scr_set_password import *
from .scr_forgot import *
from .scr_profile import *

screens = (
    scr_pre_login.screens + scr_login.screens + scr_set_password.screens + scr_forgot.screens + scr_profile.screens
)
