import mongoengine

from semantik.types.common import *
from .base import *

__all__ = ["Date"]


#
# Date
#


class Date(SimpleField):
    _tag = "SKDate"
    _parameters = common_parameters.SIMPLE_FIELD.add(RTParam(id="width", default="135px")).addPassthroughs(dx.DxDateBox)
    _nullValue = None
    dataType = "date"


class SKDate(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{state._value ? state._value.toLocaleDateString() : '-'}}
    </div>
    <dx-date-box
        v-else-if="config.calculated" 
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-date-box
        v-else 
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
