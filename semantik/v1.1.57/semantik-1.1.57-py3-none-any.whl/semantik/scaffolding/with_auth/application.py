from semantik.scaffolding.base.application import *


STANDALONE = {"PreLogin", "Login", "Forgot", "Reset", "SetPassword"}


def make_routes(screens, standalone_screens=STANDALONE):
    return [
        Route(path=f"/{screen}", component=screen, standalone=screen in standalone_screens) for screen in screens
    ] + [
        Route(path="/Admin/:type/:id", component="Admin", standalone=False),
    ]


class SemantikRouterApplicationWithAuth(SemantikRouterApplication):
    imports = {"import '../assets/styles/main.scss'", "import { computed } from 'vue'"}

    routes = None  #: override
    sessionClass = None  #: override
    components = None  #: override

    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <AppError/>
    <dx-toast
        ref="toast"
        type="custom"
        :position="{at: 'top right', my:'top right', offset: '-10 10'}"
        :width="300"
        :display-time="3000"
        :wrapper-attr="{class: 'ig-toast-' + toast_type}"
    >
        <template #content>
            <i class="fa-solid fa-info" v-if="toast_type === 'info'"></i> 
            <i class="fa-solid fa-triangle-exclamation" v-if="toast_type === 'warning'"></i> 
            <i class="fa-solid fa-xmark-large" v-if="toast_type === 'danger'"></i> 
            <i class="fa-solid fa-thumbs-up" v-if="toast_type === 'success'"></i> 
            {{ toast_message }}
        </template>
    </dx-toast>

    <Navigation 
        v-if="!standalone" 
        v-model:fold_sidebar="fold_sidebar" 
        ref="navigation" 
        :current="location.pathname"
        :avatar_html="avatar_html"
    />
    <div 
        class="wrapper d-flex flex-column min-vh-100 ig-app-loggedin-container" 
        v-if="!standalone"        
    >
        <div :class="{'ig-app-header': true, 'hidden': !fold_sidebar}">
            <i class="-ig-hamburger fa-solid fa-bars" @click="() => $refs.navigation.show_sidebar()"/>
            <div class="ig-avatar --sm --standalone" @click="do_profile()">
                <div v-html="avatar_html"></div>
            </div>
        </div>
        <component :is="current_screen" v-if="!iframe_url" v-bind="current_screen_props"/>
        <iframe ref="iframe" class="ig-elearning-iframe" v-if="iframe_url" :src="iframe_url"/>
    </div>
    <component :is="current_screen" v-bind="current_screen_props" v-else/>
    """

    initialData = dict(
        fold_sidebar=False,
        iframe_url=None,
        logged_in=False,
        toast_message="",
        toast_type="info",
        view_state=dict(phone=False),
        permissions=dict(),
        avatar_html="",
        current_screen=None,
        current_screen_props=dict(),
        standalone=True,
    )

    def open_iframe(self, url):
        self.data.iframe_url = url
        # TODO: fold the sidebar ? (not clear if we should)

    @method
    def iframe_exit(self, *args, **kwargs):
        self.data.iframe_url = None

    def logout(self):
        self.session.logout()
        self.server.connectionManager.delete(self.connection.connectionId)
        self.client["$rt"].setCookie("roundtripSession=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;")
        self.data.is_loaded = False
        js.window.location.href = "/Login"

    @method
    def do_profile(self):
        self.open("Profile")

    def login(self, user):
        current.session.login(user)
        self.data.avatar_html = user.avatar_html
        self.data.permissions = current.session.user.permissions
