import time
import random
import uuid
import datetime

from roundtrip.scaffolding.config import config

from ..common import *
from ....core.i18n import _


screens = ["Forgot"]


class Forgot(PreLoginScreen):
    # language=Vue
    template = r"""
    <div class="min-vh-100 ig-login">
       <div class="card p-4 mb-0 ig-login-card">
          <div class="card-body" @keyup.enter="reset()">
             <div class="-main-heading">{& _('Forgot Password') &}</div>
             <ValidationError :error="error"/>
             <label>{& _('Username') &}</label>
             <div class="input-group">
                <input 
                    v-model="username" 
                    class="form-control" 
                    type="text" 
                    placeholder="{& _('Username') &}"
                    autocomplete="username"                    
                >
             </div>
             <div class="-message" v-if="message">{{ message }}</div>
             <div class="row -buttons" v-if="!message">
                <button @click="reset()" type="button">
                    {& _('Forgot password') &}
                </button>
             </div>
             <div class="-footer-text">
                <span class="-link-text" @click="back_to_login()">{& _('Back to login') &}</span>
             </div>
          </div>
       </div>
    </div>  
    """

    initialData = dict(
        username="",
        password="",
        confirm="",
        error=None,
        message=None,
        working=False,
    )

    @method
    @spinner(200)
    def reset(self):
        username = self.data.username

        if not username:
            self.data.error = _("Please provide your username")
            return

        if not r.user.use_lockout:
            time.sleep(random.random() / 20.0)  # defeat timing attacks if we're using the non-lockout version
            # of login that tries not to reveal if the username is correct

        kwargs = dict(_archived__ne=True)
        kwargs[r.user.username_field] = username
        user = m.User.objects(**kwargs).first()

        self.data.message = _(
            "Thank you. If there is an email associated with this account you will shortly receive "
            "an email with a link to reset your password."
        )

        if user:
            for item in m.PasswordReset.objects(user=str(user.id), expired=False):
                item.expired = True
                item.save()

            rp = m.PasswordReset(user=str(user.id), date=datetime.datetime.now(), key=uuid.uuid4().hex)
            rp.save()

            link = f"{config.web_url}?forgot={rp.key}"

            r.email_sender.send(
                recipient=user.email,
                subject="Mova password reset",
                message_html=f'<body><p><a href="{link}">Click here to reset</a></p></body>',
                message_text=f"Use this link to reset {link}",
            )

            m.Event.send(user=user, type=m.Event.TYPE.forgot_password.value)

    @method
    def back_to_login(self):
        self.app.open("Login")
