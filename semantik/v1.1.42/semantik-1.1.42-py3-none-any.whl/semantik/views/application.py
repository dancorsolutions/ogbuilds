from roundtrip.application.router_application import Route, RouterApplication


class SKApplication(RouterApplication):
    @property
    def admin_cmp(self):
        """The underlying admin (SKRoot) component within the application (we delegate all events to this object)"""
        return self.down("SKRoot")

    def before_pop(self, from_route: Route, to_route: Route, route_kwargs: dict, history_state: dict or None):
        if from_route.path.startswith("/Admin") or to_route.path.startswith("/Admin"):
            return self.admin_cmp.before_pop(
                from_route=from_route, to_route=to_route, route_kwargs=route_kwargs, history_state=history_state
            )

    def before_push(self, from_route: Route, to_route: Route, route_kwargs: dict, history_state: dict or None):
        if to_route.path.startswith("/Admin"):
            return self.admin_cmp.before_pop(
                from_route=from_route, to_route=to_route, route_kwargs=route_kwargs, history_state=history_state
            )
