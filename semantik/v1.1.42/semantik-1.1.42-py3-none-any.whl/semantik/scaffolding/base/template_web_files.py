import os
import shutil
from pathlib import Path
import logging


def templateWebFiles(web_path, semantik_path):
    templates = semantik_path / "scaffolding" / "templates"

    def copy_file(src: Path, dst: Path):
        if not dst.exists():
            logging.info(f"Created file {dst} from template")
            shutil.copy(src, dst)

    def copy_path(src: Path, dst: Path):
        dst.mkdir(parents=True, exist_ok=True)
        for fp in src.glob("*"):
            if fp.is_dir():
                copy_path(fp, dst / fp.name)
            else:
                copy_file(fp, dst / fp.name)

    copy_path(templates / "main", web_path)
    copy_file(templates / ".gitignore", web_path.parent.parent)

    copy_path(templates / "assets", web_path / "assets")
    copy_path(templates / "public", web_path / "public")
    copy_path(templates / "semantik_models", web_path / "models")  # semantik only
    copy_path(templates / "semantik_screens", web_path / "screens")  # semantik only
    if not (web_path / ".npmrc").exists():  # semantik only
        print(
            "You should set up an npmrc:\n@fortawesome:registry=https://npm.fontawesome.com/\n"
            "//npm.fontawesome.com/:_authToken=###YOUR-AUTH-TOKEN###"
        )
        return
