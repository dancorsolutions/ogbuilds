# language=rst
"""
An alternative contents view shows a side bar for selecting/adding/deleting items beside an editing window

This provides a pleasant way to edit homogeneous lists of items quickly where we only expect a few items (less than
a dozen or two) and don't need the sort/search/filter capabilities that come with normal Contents types.

Its main advantage is that it makes it very quick to move between items and edit them since the user doesn't have to
double click, open an editor, save, and move on to the next item.
"""


import mongoengine
from ..common import *

__all__ = ["GalleryEditor"]


class GalleryEditor(Type):
    _parameters = Parameters(
        Param("id"),
        Param("addable"),
        Param("widget"),
        Param("size", default="220px"),
        Param("horizontal"),
        Param("canAdd"),
        Param("canDelete"),
        Param("static", inherit=True),
        Param("addButtonName", default="Add"),
        Param("duplicateButtonName", default="Duplicate"),
        Param("deleteButtonName", default="Delete"),
        Param("linked", default=True),
        SSParam("validate", callable=True),
        SSParam("galleryPlaceholder", structure=True),
        SSParam("formPlaceholder", structure=True),
    )

    _tag = "SKGalleryEditor"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        SKGalleryEditor.components = (SKGalleryEditor.components or []) + [i["widget"] for i in self.p.addable]
        pass

    def _data(self, context):
        data = Type._data(self, context=context)
        data[self._id]["_value"] = []
        return data

    def _config(self, context, statePath=None, static=False, isRoot=False):
        main = super()._config(context=context, statePath=statePath, static=static, isRoot=isRoot)
        config = main["_rest"]
        config["types"] = dict()
        for addable in self.p.addable:
            structure = sm.getItemType(addable["type"]).sk.structure
            config["types"][addable["type"]] = addable
            config["types"][addable["type"]]["config"] = structure._config(
                context=context, statePath=statePath, static=static
            )
        if self.p("formPlaceholder", default=None):
            config["formPlaceholder"] = self.p.formPlaceholder._config(
                context=context, statePath=statePath, static=static
            )
        if self.p("galleryPlaceholder", default=None):
            config["galleryPlaceholder"] = self.p.galleryPlaceholder._config(
                context=context, statePath=statePath, static=static
            )
        return main

    def _toState(self, storage, state, context):
        if self._id not in storage:
            state.update(self._data(context=context))

        items = storage[self._id]

        if not len(items):
            state[self._id]["_value"] = []
            return

        out = []
        for item in items:
            stateItem = dict()
            item.sk.structure._toState(item, stateItem, context=context)
            stateItem["_cls"] = item.sk.ident
            out.append(stateItem)

        state[self._id]["_value"] = out

    def _toStorage(self, state, storage, context):
        if self._id not in state:
            storage[self._id] = []
            return

        items = state[self._id]["_value"]

        out = []
        for item in items:
            storageItem = sm.getItemType(item["_cls"])()
            storageItem.sk.structure._toStorage(item, storageItem, context=context)
            out.append(storageItem)

        if len(storage[self._id]) == len(out):
            for i in range(len(out)):
                if storage[self._id][i] != out[i]:
                    storage[self._id][i] = out[i]
        else:
            storage[self._id] = out

    def _getFields(self):
        return {self._id: mongoengine.ListField(mongoengine.GenericEmbeddedDocumentField())}

    def _validate(self, subState, context):
        error = {}
        overallError = None
        for index, item in enumerate(subState[self._id]._value):
            structure = sm.getItemType(item["_cls"]).sk.structure
            errors = structure._validate(item, context=context._with(state=item) if context else context(state=item))
            if errors:
                error[index] = errors
                item["_error"] = True
            else:
                if "_error" in item:
                    del item["_error"]

        if "validate" in self.p:
            overallError = self.p(
                "validate",
                context=(
                    context._with(
                        subState=subState.get(self._id, None),
                        value=getattr(subState.get(self._id, None), "_value", None) if self._id in subState else None,
                    )
                    if context
                    else None
                ),
            )

        if error or overallError:
            if self.p.linked:
                subState[self._id]._error = overallError or "Check and correct errors"
            return {self._id: error}
        elif self._id in subState and "_error" in subState[self._id]:
            subState[self._id]["_error"] = None

        return None


class SKGalleryEditor(SKComponent):
    # language=Vue
    template = r"""
    <div :class="{'sk-gallery': true, '--sk-horizontal': config.horizontal}">
        <!-- Sidebar -->
        <div 
            :class="{'sk-sidebar': true, 'd-none': current !== null, 'd-sm-flex': true}"
            :style="{[config.horizontal ? 'height' : 'width']: config.size}"
        >
            <div 
                class="sk-items" 
                @click="selected = current = null"
            >            
                <dx-sortable
                    id="list"
                    ref="sortable"
                    drop-feedback-mode="push"
                    :item-orientation="config.horizontal ? 'horizontal': 'vertical'"
                    drag-direction="both"
                    :scroll-speed="30"
                    :scroll-sensitivity="60"
                    @reorder="on_reorder"
                >
                    <template #content>
                        <div>
                                <div 
                                    v-for="(item, index) of state._value"
                                    :key="index"
                                    :class="{'sk-item':true, 'sk-active': index == selected, 'sk-error': item._error}"
                                    @click.stop="index == selected ? null : do_select(index)"
                                >
                                    <component
                                        v-if="item && item._cls && config.types[item._cls] &&
                                              (Object.prototype.toString.call(config.types[item._cls].widget) === '[object String]')" 
                                        :is="config.types[item._cls].widget"
                                        :item="item"
                                        :config="config"
                                        :active="index == selected"
                                        :error="item._error"
                                        :itemState="itemState"
                                    />
                                    <div class="card" v-else-if="item && item._cls && config.types[item._cls]">
                                        <div class="card-body p-3 d-flex align-items-center">
                                            <SKItem                                
                                                :state="item"
                                                :config="hydrateConfig(config.types[item._cls].config)"
                                            />
                                        </div>
                                    </div>                
                                </div>
                        </div>
                    </template>
                </dx-sortable>            
                <div 
                    v-if="!state._value.length"
                    class="sk-placeholder"
                >
                    <SKItem
                        v-if="config.galleryPlaceholder"
                        :state="galleryPlaceholderState"
                        :itemState="itemState"
                        :config="hydrateConfig(config.galleryPlaceholder)"
                    />
                    <div v-else class="sk-placeholder-contents">No data</div>
                </div>                
            </div>
            <div v-if="!config.static && (config.linked || selected === null)" class="sk-footer">
                <dx-drop-down-button
                    v-if="config.canAdd !== false && config.addable && config.addable.length > 1" 
                    :text="config.addButtonName || 'Add'"                         
                    @itemClick="do_add($event.itemData.type)" 
                    :items="config.addable" 
                    displayExpr="text"
                    keyExpr="type"
                    class="btn btn-sm btn-outline-info sk-dropdown-add-button"                    
                />
                <dx-button 
                    v-if="config.canAdd !== false && config.addable && config.addable.length === 1" 
                    class="sk-gallery-add-button"
                    type="default"                    
                    styling-mode="outlined"
                    @click="do_add(config.addable[0].type)"
                >
                    {{ config.addButtonName || 'Add' }}
                </dx-button>
                <dx-button 
                    v-if="config.canAdd !== false && config.linked && selected !== null" 
                    class="sk-gallery-duplicate-button"                    
                    @click="do_duplicate(selected)"
                    styling-mode="outlined"
                    type="default"
                >
                    {{ config.duplicateButtonName || 'Duplicate' }}
                </dx-button>
                <dx-button 
                    v-if="config.canDelete !== false && config.linked && selected !== null" 
                    class="sk-gallery-delete-button"                    
                    @click="do_delete(selected)"
                    type="danger"
                    styling-mode="outlined"
                >
                    {{ config.deleteButtonName || 'Delete' }}
                </dx-button>
            </div>
        </div>
        <!-- Main area -->
        <div 
            v-if="current !== null"
            class="sk-main"
        >
            <SKValidationError :error="state._error || error"/>
            <!-- Form view (item selected) -->
            <div class="sk-content">           
                <SKItem
                    :state="current"
                    :itemState="itemState"
                    :config="hydrateConfig(config.types[current._cls].config)"
                />
            </div>
            
            <!-- Actions footer -->
            <div  v-if="!config.linked && !config.static" class="sk-footer">
                <div class="sk-buttons">
                    <button v-if="selected !== null" class="btn btn-outline-success mx-3" type="button" @click="do_save()">
                        Save
                    </button>
                    <button v-else class="btn btn-outline-success mx-3" type="button" @click="do_save()">
                        Save
                    </button>
                    <button class="btn btn-outline-secondary mx-3" type="button" @click="do_cancel()">
                        Cancel
                    </button>
                    <button 
                        v-if="config.canDelete !== false && selected !== null" 
                        class="btn btn-outline-danger mx-3" 
                        type="button" @click="do_delete(selected)">
                        Delete
                    </button>
                </div>
            </div>
        </div>
        <!-- Placeholder (no item selected) -->
        <div
            v-else-if="config.formPlaceholder"
            class="sk-main"
        >
            <div style="align-self: stretch; margin: 0 30px;">
                <SKValidationError :error="state._error || error"/>
            </div>
            <div class="sk-content">           
                <SKItem
                    :state="formPlaceholderState"
                    :itemState="itemState"
                    :config="hydrateConfig(config.formPlaceholder)"
                />
            </div>
        </div>
    </div>
    """

    initialData = dict(
        current=None, selected=None, error=None, formPlaceholderState=dict(), galleryPlaceholderState=dict()
    )

    imports = SKComponent.imports | {
        "import EJSON from 'roundtrip/ejson.js'",
        "import { nextTick } from 'vue'",
    }

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        select_item=r"""
        function(index, copy) {
            if(copy) {
                this.current = EJSON.clone(this.state._value[index]);
            } else {
                this.current = this.state._value[index];
            }
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        do_cancel=r"""
        function() {
            this.current = null;
            this.selected = null;
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        do_select=r"""
        function(index) {
            this.error = null;
            this.selected = index
            if(this.config.linked) {
                this.current = this.state._value[index];
            } else {
                this.current = EJSON.clone(this.state._value[index]);
            }
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        do_delete=r"""
        function(index) {
            if(this.selected > 0) {
                this.selected -= 1;
                this.current = this.state._value[this.selected];
            } else if(this.selected === 0 && this.state._value.length > 1) {
                this.selected = 0;
                this.current = this.state._value[0];
            } else {
                this.selected = null;
                this.current = null;
            }
            if(this.config.linked) {
                this.state._value.splice(index, 1);
            }
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        do_duplicate=r"""
        function(index) {
            if(this.config.linked) {
                const new_item = EJSON.clone(this.state._value[index]);
                this.state._value.splice(index, 0, new_item);
                this.selected = index + 1;
                this.current = new_item;
            } else {
                this.add_item(EJSON.clone(this.state._value[index]));
            }
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        on_reorder=r"""
        function(e) {
            let b = this.state._value[e.fromIndex];
            this.state._value[e.fromIndex] = this.state._value[e.toIndex];
            this.state._value[e.toIndex] = b;
            console.log(this.state._value);
         }
        """,
        # language=JavaScript prefix=[ suffix=]
        add_item=r"""
        function(item_data) {
            if(this.selected !== null && this.selected !== undefined) {
                this.state._value.splice(this.selected + 1, 0, item_data);
                this.selected = this.selected + 1;
                this.current = this.state._value[this.selected];
            } else { 
                this.state._value.push(item_data);
                this.selected = this.state._value.length - 1;
                this.current = this.state._value[this.selected];
            }
            nextTick(
                () => { if(this.$refs.sortable.instance._$element.children()[0].children[this.selected]) this.$refs.sortable.instance._$element.children()[0].children[this.selected].scrollIntoView(); }
            );
        }
        """,
    )

    def get_context(self):
        if self.skRoot:
            return self.skRoot.context
        else:
            return self.session.lap.sk.makeContext(state={})

    @method
    def do_add(self, type):
        if self.data.current and not self.skType.p.linked:
            return
        context = self.get_context()
        context.state = self.data.current
        structure = sm.getItemType(type).sk.structure
        newData = structure._data(context=context)
        newData["_cls"] = type
        if self.skType.p.linked:
            self.client.add_item(newData)
        else:
            self.data.current = newData
            self.data.selected = None

    @method
    def do_save(self):
        # this is never called for linked mode
        context = self.get_context()
        context.state = self.data.current
        structure = sm.getItemType(self.data.current._cls).sk.structure
        errors = structure._validate(self.data.current, context=context)
        if errors:
            self.data.error = "Check and correct errors"
            return

        if self.data.selected is not None:
            # save button
            assert "unsupported"
        elif not self.skType.p.linked:
            # add button
            self.client.state._value.push(self.data.current)
            self.data.current = None
