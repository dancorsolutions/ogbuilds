import datetime

from ...common import *


class TYPES:
    str = "str"
    int = "int"
    float = "float"
    decimal = "decimal"
    date = "date"
    datetime = "datetime"
    bool = "bool"
    reference = "reference"
    object = "object"


class GenericSimpleField(Type):
    _nullValue = None

    TYPES = TYPES

    def _data(self, context):
        data = Type._data(self, context=context)
        data[self._id]["_value"] = self.p("default", default=self._nullValue, context=context)
        return data

    def _valueToStorage(self, value):
        dT = self.p.get("dataType", None)

        if dT == "date":
            if isinstance(value, datetime.datetime):
                value = value.date()

        return super()._valueToStorage(value)

    def _valueToState(self, value):
        dT = self.p.get("dataType", None)

        if dT == "datetime" and value is not None:
            if isinstance(value, datetime.datetime):
                if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
                    value = value.replace(tzinfo=datetime.UTC)

        return super()._valueToState(value)
