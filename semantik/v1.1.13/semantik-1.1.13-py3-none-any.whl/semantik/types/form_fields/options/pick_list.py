from .common import *
from . import select_list

__all__ = ["PickList"]


#
# PickList
#


class PickList(select_list.SelectList):
    dataType = "str"
    nullValue = []
    _tag = "SKPickList"
    _parameters = (
        WITH_OPTIONS.add(
            Param("width", default="100%"),
            Param("canReorder", default=False),
            RTParam("allowItemDeleting", default=True),
            RTParam("itemDeleteMode", default="static"),
            RTParam("showSelectionControls", default=True),
            Param("selectOptions", default=dict(searchEnabled=True)),
        )
        .addPassthroughs(dx.DxList)
        .remove("optionsDynamic")
    )  # does not yet support dynamic options


class SKPickList(select_list.SKSelectList):
    # language=Vue
    template = r"""
    <div 
        :style="{display: 'flex', flexDirection: 'column', width: config.width}" 
        :id="config._id" 
        class="sk-picklist-container"
    >
        <dx-select-box
            :data-source="options"
            key-expr="v"
            display-expr="l"
            @itemClick="on_select($event.itemData)"
            v-bind="config.selectOptions" 
        >
        </dx-select-box>
        <dx-list 
            :data-source="state._value.map((i) => options.filter((j) => j.v === i)[0])"
            key-expr="v"
            display-expr="l"
            style="border: 1px solid rgb(221, 221, 221); border-radius: 3px;"
            ref="dxList"
            @itemDeleted="on_remove($event)"
            {& sk.dx_field_attributes &}
        >
            <dx-list-item-dragging
                v-if="config.canReorder"
                :allow-reordering="config.canReorder"
                :on-reorder="on_reorder"
                handle=".dx-item.dx-list-item"
                group="{&cmp.uid&}"
            />
        </dx-list>
    </div>
    """

    methods = select_list.SKSelectList.methods | dict(
        # language=JavaScript prefix=[ suffix=]
        on_select=r"""
        function(item) {
            if(!this.state._value.filter((i) => i === item.v).length) {
                this.state._value.push(item.v);
            }
        }
        """,
        # language=JavaScript prefix=[ suffix=]
        on_reorder=r"""
             function(e) {
                 const toIndex = e.toIndex
                 const fromIndex = e.fromIndex
                 const newData = [...this.state._value];

                 newData.splice(fromIndex, 1);
                 newData.splice(toIndex, 0, this.state._value[fromIndex]);
                 this.state['_value'] = newData;
             }        
         """,
        # language=JavaScript prefix=[ suffix=]
        on_remove=r"""function(e) {
            this.state._value = this.state._value.filter((i) => i !== e.itemData.v);
        }""",
    )
