from semantik.types.common import *
from semantik.types.form_fields import base

__all__ = ["CKEditorClassic"]


class CKEditor(External):
    imports = {
        "import CKEditor from 'semantik/ckeditor'",
        "import ClassicEditor from '@ckeditor/ckeditor5-build-classic'",
    }


class CKEditorClassic(base.SimpleField):
    _tag = "SKCKEditorClassic"
    _parameters = common_parameters.SIMPLE_FIELD.add(
        Param(id="config", default=dict(), help="CKEditor configuraiton options"),
        Param(id="disabled"),
    ).addPassthroughs(["width", "height", "minWidth", "minHeight", "maxWidth", "maxHeight"])
    _nullValue = ""
    dataType = "str"


class SKCKEditorClassic(SKComponent):
    # language=Vue
    template = r"""
        <CKEditor
            :id="config._typeUID"
            v-model="state._value"
            :editor="editor"
            :disabled="config.disabled"
            :config="config.config"
            v-bind="config._passthroughAttrs"
        ></CKEditor>
    """

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        editor=r"""
            function() {
                return ClassicEditor;
            }
        """
    )
