from roundtrip.component.component import ComponentMetaclass
from ..common import *

__all__ = ["QuickCustom"]


class QuickCustom(DatalessType):
    """
    A quick and dirty way of creating a custom, (dataless) component to display within a Semantik object's interface
    """

    _transparentState = True

    # class attributes
    components = []

    _component = None

    _parameters = common_parameters.FORM_ITEM.add(
        Param(id="props", callable=True),
        Param(id="load", help="List of form_fields to load from the underlying `Item` into state"),
        Param(id="template", help="A string containing the Vue template for this item"),
    )

    def _argsToParams(self, kwargs):
        if kwargs:
            assert False, "QuickCustom is not designed to be used in instance-based structures"
            # N.B. it could be we'd just need to detect it and put the custom component class in the instance
            # in case of instance-based structures

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self._component:

            class QuickCustomComponent(SKComponent):
                className = (
                    "QC" + "".join([i.capitalize() for i in self.uid.split("_")]) if "_" in self.uid else self.uid
                )
                template = self.p.template

            self.__class__._component = QuickCustomComponent
        self._tag = self._component.className

    def _toState(self, storage, state, context):
        if "load" not in self.p:
            return

        if self._id not in state:
            state[self._id] = dict()

        for k in self.p.load:
            state[self._id][k] = storage[k]
