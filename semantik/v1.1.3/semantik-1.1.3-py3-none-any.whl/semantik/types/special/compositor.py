from html import escape
import uuid

import mongoengine

from compositor import parser
from semantik.types.form_fields.options.select_box import SKSelectBox, SelectBox
from semantik.types.form_fields.options.tag_box import SKTagBox, TagBox
from semantik.types.form_fields.text import SKText, Text
from ..common import *

__all__ = ["Compositor", "GrammarSelectBox", "GrammarTagBox"]


class Compositor(Type):
    _parameters = Parameters(
        # server-side
        SSParam(id="id", required=True),
        SSParam(id="validate", callable=True),
        Param(id="display"),
        SSParam(id="grammar", required=True),
        # client-side
        Param(id="width", default="100%"),
        Param(id="formLabel"),
        Param(id="formLabel"),
        Param(id="formClass"),
        Param(id="labelClass"),
        Param(id="fieldClass"),
    )

    _tag = "SKCompositor"

    def _data(self, context):
        data = super()._data(context=context)
        data[self._id]["_value"] = self.p("default", context=context) if "default" in self.p else []
        return data

    def _getFields(self):
        """Return a dict of field id -> mongoengine field"""
        return {self._id: mongoengine.ListField(mongoengine.DynamicField())}

    def _valueToStorage(self, value):
        return value

    def _valueToState(self, value):
        return value


class SKCompositorToken(Component):
    # language=Vue
    template = r"""
    <div
        :key="token.uid" 
        :class="'sk-compositor-token sk-compositor-token-' + token.type"
        @click="onSelectToken(token.uid)"
        v-html="token.html ? token.html : token.name"
        v-if="(token !== null) && !(interactive_config && interactive_index === index)"
        tabindex=0
    />
    <div 
        v-if="
            (interactive_config && interactive_index === index) ||
            (interactive_config && interactive_index === -1 && index === (tokens.length - 1)) 
        "
        class="sk-compositor-editable"
        ref="compositor_editable"
    >
        <SKItem
            :config="interactive_config ? hydrateConfig(interactive_config) : undefined"
            :state="interactive_state"
            :itemState="interactive_state"
            ref="interactive"
            @interactiveCompleted="onInteractiveCompleted()"
        />
        <button 
            v-if="!interactive_config.noButton" 
            class="sk-compositor-field-button" @click="onInteractiveCompleted()"
        >
            <i class="fa-solid fa-circle-check"></i>
        </button>
    </div>
                            <div 
                                v-if="options.length && (interactive_index === null)"
                                class="sk-compositor-chooser"
                            >
                                <dx-select-box
                                    :data-source="options"
                                    v-model:value="terminal_selected"
                                    v-if="options.length"
                                    ref="terminalSelectBox"
                                    value-expr="id"
                                    display-expr="label"
                                    @itemClick="onSelectionChangeEvent($event)"
                                    @contentReady="onSelectReady"
                                    item-template="item"
                                >
                                    <template #item="{ data }">
                                        <div class="sk-compositor-grammar-choice"> 
                                            <div 
                                               :class="'sk-item sk-item-' + data.type"
                                            >
                                                {{ data.label }}
                                            </div>
                                        </div>
                                    </template>
                                </dx-select-box>
                            </div>
    
    """

    props = [""]


class SKCompositor(SKComponent):
    autoFillOnlyOption = False

    # language=Vue
    template = r"""

    <dx-drop-down-box
        v-if="config.display === undefined || config.display" 
        ref="compositor"
        width="100%"
        field-template="field"
        @opened="onOpened"
        @closed="onClosed"
        :drop-down-options="{animation: null, onHiding: (e) => complete ? null : e.cancel = true, 
                             wrapperAttr:{'class': 'sk-compositor-popup-wrapper'}}"
             
    >
        <template #field>
            <dx-text-box
                :read-only="true"
                :element-attr="{'class': 'sk-compositor-dx-text-field'}"
            >
                <div :class="{'sk-compositor-container-field': true, 'sk-compositor-container-field-active': active}"> 
                    <div
                        v-for="(token, index) in (tokens_before === null ? (tokens || []) : tokens_before)"
                        :key="token.uid" 
                        :class="'sk-compositor-token sk-compositor-token-' + token.type"
                        v-html="token.html ? token.html : token.name"
                        tabindex=0
                    />
                </div>
            </dx-text-box>
        </template>
        <template #content>
            <div class="sk-compositor-container">
                <div class="sk-compositor-container-main">
                    <div class="sk-compositor-tokens">
                        <TransitionGroup name="sk-compositor" :duration="500">                 
                            <template v-for="(token, index) in (tokens.length ? tokens : [null])">
                                <div
                                    :key="token.uid" 
                                    :class="'sk-compositor-token sk-compositor-token-' + token.type"
                                    @click="onSelectToken(token.uid)"
                                    v-html="token.html ? token.html : token.name"
                                    v-if="(token !== null) && !(interactive_config && interactive_index === index)"
                                    tabindex=0
                                />
                                <div 
                                    v-if="
                                        (interactive_config && interactive_index === index) ||
                                        (interactive_config && interactive_index === -1 && index === (tokens.length - 1)) 
                                    "
                                    class="sk-compositor-editable"
                                    ref="compositor_editable"
                                >
                                    <SKItem
                                        :config="interactive_config ? hydrateConfig(interactive_config) : undefined"
                                        :state="interactive_state"
                                        :itemState="interactive_state"
                                        ref="interactive"
                                        @interactiveCompleted="onInteractiveCompleted()"
                                    />
                                    <button 
                                        v-if="!interactive_config.noButton" 
                                        class="sk-compositor-field-button" @click="onInteractiveCompleted()"
                                    >
                                        <i class="fa-solid fa-circle-check"></i>
                                    </button>
                                </div>
                            </template>
                    
                            <div 
                                v-if="options.length && (interactive_index === null)"
                                class="sk-compositor-chooser"
                            >
                                <dx-select-box
                                    :data-source="options"
                                    v-model:value="terminal_selected"
                                    v-if="options.length"
                                    ref="terminalSelectBox"
                                    value-expr="id"
                                    display-expr="label"
                                    @itemClick="onSelectionChangeEvent($event)"
                                    @contentReady="onSelectReady"
                                    item-template="item"
                                >
                                    <template #item="{ data }">
                                        <div class="sk-compositor-grammar-choice"> 
                                            <div 
                                               :class="'sk-item sk-item-' + data.type"
                                            >
                                                {{ data.label }}
                                            </div>
                                        </div>
                                    </template>
                                </dx-select-box>
                            </div>
                        </TransitionGroup>
                    </div>
                    <div class="sk-compositor-tools">
                        <button 
                            :class="{'btn': true,  'btn-success': true, '-sk-hidden': !complete}"
                            @click="saveAndClose()"
                        >
                            <i class="fa-solid fa-check"></i>
                        </button>
                        <button 
                            class="btn btn-danger"
                            @click="discardAndClose()"
                        >
                            <i class="fa-solid fa-close"></i>
                        </button>
                    </div>
                </div>
                <div :class="{'sk-compositor-container-status': true, '-sk-complete': complete}">
                    <i 
                        class="fa-solid fa-badge-check"
                        v-if="complete"
                    ></i>
                    <span v-if="complete"> complete</span>
                </div>
            </div>
        </template>
    </dx-drop-down-box>
    """

    imports = SKComponent.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    initialData = dict(
        tokens=[],
        tokens_before=None,
        options=[],
        terminal_selected=None,
        active=False,  #: the component is focused (therefore editable)
        complete=False,
        interactive_index=None,  #: the component is editing an interactive component at this token index
        interactive_state=None,
        interactive_config=None,
        interactive_token_name=None,
    )
    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        console=js("""() => console"""),
        # language=JavaScript prefix=[ suffix=]
        nextTick=js("""() => nextTick"""),
        # language=JavaScript prefix=[ suffix=]
        setTimeout=js("""() => setTimeout"""),
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        beforeMount=js(
            """
            function() {
                this.tokens = this.state._value;
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        mounted=js(
            """
            function() {
                this.setInitialOptions();
            }
        """
        ),
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        onOpened=js(
            """
            function() {
                this.terminal_selected = null;
                this.tokens_before = this.tokens_before === null ? [...this.tokens] : this.tokens_before;
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        onClosed=js(
            """
            function() {
                this.tokens_before = [...this.tokens];
                this.active = true;
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        saveAndClose=js(
            """
            function() {
                this.tokens_before = [...this.tokens];
                this.$refs.compositor.instance.close();
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        discardAndClose=js(
            """
            function() {
                this.tokens = [...this.tokens_before];
                this.complete = true;
                this.$refs.compositor.instance.close();
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        onSelectionChangeEvent=js(
            """
            function(event) {
                if(!event.itemData) 
                    return;
                this.onSelection({value:event.itemData});
                this.active = true;
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        onSelectReady=js(
            """
        function(event) {
            setTimeout(() => event.component.open(), 100)
        }
    """
        ),
    )

    @method
    def setInitialOptions(self):
        self.updateOptions()

    def getOptions(self, tokens=None):
        """
        Set up the options for the next token

        This will add options from the autocomplete list (including interactive and non-interactive terminals)
        and will add an 'end' option for strings that are grammatical complete.
        """
        p = self.parse(tokens=tokens)
        ac = p.autocomplete()
        options = []
        if len(ac) > 0:
            for t in ac:
                if getattr(t.f, "structure", None):
                    options.append(dict(id=t.name, label=t.name, type="interactive", state="display"))
                else:
                    options.append(dict(id=t.name, label=t.name, type="static", state="display"))
        if p.isComplete():
            self.data.complete = True
            if options:
                options.append(dict(id="<END>", label="<END>", type="end", state="display"))
            else:
                self.client.saveAndClose()
        else:
            self.data.complete = False

        return options

    @method
    def onSelection(self, value):
        """
        Handle a user choosing a terminal
        """
        if not value:
            return
        if value["id"] == "<END>":
            self.client.saveAndClose()
            return

        if value["type"] == "interactive":
            self.loadInteractive(name=value["id"])
            return

        self.data.tokens.append(dict(uid=uuid.uuid4().hex, name=value["id"], type=value["type"], value=None))
        self.updateOptions()

    def updateOptions(self):
        """
        Loads available non-terminal options after adding tokens for any terminals where there is no choice

        Does what getOptions does but also skips asking the user about any terminals where there would
        only have been one choice
        """
        try:
            while 1:
                options = self.getOptions()
                if len(options) == 1 and options[0]["type"] == "static":
                    self.data.interactive_index = None
                    if self.autoFillOnlyOption:
                        self.data.tokens.append(
                            dict(uid=uuid.uuid4().hex, name=options[0]["id"], type=options[0]["type"], value=None)
                        )
                    else:
                        break
                elif len(options) == 1 and options[0]["type"] == "interactive":
                    self.loadInteractive(name=options[0]["id"])
                    break
                else:
                    self.data.interactive_index = None
                    break
            self.data.options = options
            self.client.state._value = self.client.tokens

        except parser.ParseError:
            self.data.tokens = []
            self.client.state._value = self.client.tokens
            self.data.options = self.getOptions(tokens=[])

    @method
    def onSelectToken(self, uid):
        """
        Handle the user selecting a token in the string
        """
        # self.data.active = False
        for index, token in enumerate(self.data.tokens):
            if token["uid"] == uid:
                break
        else:
            raise ValueError(f"No token with uid {uid}")
        if token["type"] == "interactive":
            self.loadInteractive(name=token["name"], index=index)
        else:
            del self.data.tokens[index:]
            self.updateOptions()

    def parse(self, tokens=None):
        """
        Parse a set of tokens and return the parser object
        """
        p = parser.Parser(self.skType.p.grammar)
        if tokens is None:
            tokens = self.data.tokens
        tokens = [parser.Token(name=i["name"]) for i in tokens]
        p.parse(tokens)
        return p

    def getStructure(self, name):
        for _, rule in self.skType.p.grammar:
            for sequence in rule:
                for element in sequence:
                    if element.name == name:
                        structure = getattr(element.f, "structure", None)
                        if not structure:
                            raise ValueError(f"No structure for terminal {name}")
                        return structure
        raise ValueError(f"No structure for terminal {name}")

    @method
    def loadInteractive(self, name, index=-1):
        structure = self.getStructure(name=name)
        getattr(self.client, "$").data.interactive_config = js(
            "(" + structure._configDefault(context=None)._as_javascript() + ")()"
        )
        context = self.at.sk.makeContext(state=self.data.interactive_state)
        state = {}
        if index == -1:
            storage = {}
        else:
            storage = {structure._id: self.data.tokens[index]["value"]}
        structure._toState(storage, state, context=context)
        self.data.interactive_state = state
        self.data.interactive_token_name = name
        self.data.interactive_index = index

    @method
    def onInteractiveCompleted(self):
        context = self.context
        structure = self.getStructure(name=self.data.interactive_token_name)
        value = self.data.interactive_state[structure._id]["_value"]
        error = structure._validate(self.data.interactive_state, context)
        if error:
            return
        if getattr(structure, "_toHTML", None):
            html = structure._toHTML(value, context=context)
        else:
            if value:
                html = escape(value)
            else:
                html = ""
        token = dict(
            uid=uuid.uuid4().hex, name=self.data.interactive_token_name, type="interactive", value=value, html=html
        )
        if self.data.interactive_index == -1:
            self.data.tokens.append(token)
        elif self.data.interactive_index is not None:
            self.data.tokens[self.data.interactive_index] = token
        self.updateOptions()


class GrammarSelectBox(SelectBox):
    _tag = "SKGrammarSelectBox"


class SKGrammarSelectBox(SKSelectBox):
    imports = SKSelectBox.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._options.filter((x) => x.v == state._value).length ? state._options.filter((x) => x.v == state._value)[0].l : '-' }}
    </div>
    <dx-select-box 
        v-else 
        ref="grammarSelect"
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        @itemClick="$emit('interactiveCompleted')"
        @contentReady="nextTick(() => this.$refs.grammarSelect.instance.focus())"
        @blur="$emit('blur', $event)"
        @focusOut="$emit('focusOut', $event)"
        {& sk.dx_field_attributes &}
    />
    """

    computed = dict(nextTick=js("""() => nextTick"""))


class GrammarTagBox(TagBox):
    _tag = "SKGrammarTagBox"


class SKGrammarTagBox(SKTagBox):
    imports = SKTagBox.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    # language=Vue
    template = r"""
    <dx-tag-box 
        ref="grammarSelect"    
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        @contentReady="filter_value(state._dynamic.options || config.options, state._value) && nextTick(() => this.$refs.grammarSelect.instance.focus())"
        {& sk.dx_field_attributes &}
    />    
    """

    computed = dict(nextTick=js("""() => nextTick"""))


class GrammarInput(Text):
    _tag = "SKGrammarInput"


class SKGrammarInput(SKText):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._value ? state._value : '-' }}
    </div>
    <dx-text-box 
        v-else-if="config.calculated"
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-text-box 
        v-else
        @key.enter="$emit('interactiveCompleted')"
        v-model:value="state._value"
        @focusOut="do_blur($event)"
        {& sk.dx_field_attributes &}
    />
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        do_blur=js(
            """
        function(event) {
            this.state._value = event.component._changedValue;
            this.$emit('interactiveCompleted');
        }
        """
        )
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        console=js("""() => console"""),
        # language=JavaScript prefix=[ suffix=]
        Event=js("""() => Event"""),
    )
