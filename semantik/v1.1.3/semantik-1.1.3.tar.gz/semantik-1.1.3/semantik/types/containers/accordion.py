"""
TODO: this is not correct! Using templates like this in dx-accordion or dx-tabs will cause sub-items to re-render
whenever anything in parent state chagnes, even if it has nothing to do with the items being rendered.

Less of a problem for accordions so we're keeping this for now but we'll have to replace it eventually.

When we switch to doing this the same way as tabs (i.e. with tab items rendered independently not using templates + slots)
then going into/out of a screen with accordions caused contents to disappear and we didn't have time to debug it!
"""


from ..common import *
from .multiview_base import *

__all__ = ["Accordion", "AccordionItem"]


class Accordion(MultiviewBase):
    _tag = "SKAccordion"
    _parameters = MultiviewBase._parameters.addPassthroughs(dx.DxAccordion) + Parameters(
        Param("isFieldContainer", default=True)
    )


class SKAccordion(SKMultiviewBase):
    # language=Vue
    template = r"""
    <dx-accordion 
        v-bind="config._passthroughAttrs"
        item-title-template="title"
        item-template="item"
        :items="items"
        class="sk-accordion"
        @selection-changed="
            config.monitorSelectionChange ? 
                selectionChanged({
                    oldSelection: $event.removedItems[0]._typeUID, 
                    newSelection: $event.addedItems[0]._typeUID
                }) 
                : null
        "
    >
        <template #title="{ data: child }">
            <div :class="{
                'sk-accordion-title-error': state[child._id] && state[child._id]._error, 
                'sk-accordion-title': true,
                'dx-template-wrapper': true,
                'dx-item-content': true,
                'dx-accordion-item-title': true
            }">
                {{ child.title }}
            </div>
        </template>
        <template #item="{ data: child }">
            <SKItem
                :key="child._typeUID"
                class="dx-template-wrapper dx-item-content dx-accordion-item-body sk-accordion-contents"
                :config="child"
                :state="state"
                :itemState="itemState"
            />
        </template>
    </dx-accordion>
    """

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        items=js(
            r"""
        function() { 
            return this.hydrateConfig(this.config.structure).filter((child)=>child.display === undefined || child.display); 
        }"""
        )
    )


class AccordionItem(MultiviewItemBase):
    _tag = "SKAccordionItem"
    _parameters = MultiviewItemBase._parameters.addPassthroughs(dx.DxAccordionItem)


class SKAccordionItem(SKComponent):
    # language=Vue
    template = r"""
    <SKContents
        :config="config" 
        :state="state" 
        :itemState="itemState"
    />
    """
