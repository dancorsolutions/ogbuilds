import mongoengine

from semantik.types.common import *
from .base import *


__all__ = ["Switch"]

#
# Switch
#


class Switch(SimpleField):
    _tag = "SKSwitch"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxSwitch)

    nullValue = 0
    dataType = "bool"

    def _toHTML(self, value, context=None):
        if value:
            return '<i class="fa-solid fa-toggle-on" style="font-size: 120%; color: green;"></i>'
        else:
            return '<i class="fa-solid fa-toggle-off" style="font-size: 120%; color: grey;"></i>'


class SKSwitch(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._value === true ? 'yes' : (state._value === false ? 'no' : '-') }}
    </div>
    <dx-switch 
        v-else
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
