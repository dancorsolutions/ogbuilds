"""
A fully-functional pre-configured Tornado server for Semantik projects.

You can use this as is or subclass it to add your own functionality.
"""

import dataclasses
from pathlib import Path
import logging
from typing import Type
import shutil
import os

import mongoengine

import roundtrip
import semantik
from semantik.treestore import item
from roundtrip.scaffolding.services.server import Server, ServerConfig
from roundtrip.scaffolding.services.providers.upload import UploadProvider
from roundtrip.scaffolding.services.providers.simple_upload import SimpleUploadProvider
from roundtrip.scaffolding.utils.crypto import crypto

from semantik.scaffolding.base.models.core import file

from semantik.scaffolding.base.template_web_files import templateWebFiles

server = None


@dataclasses.dataclass(kw_only=True)
class SemantikServerConfig(ServerConfig):
    autoreload: bool or str = True
    application_class: Type = None
    project_web_path: Path or str = None
    crypto_password: str = None
    mongo_uri: str = None
    file_model: Type[mongoengine.Document] = None
    root_model: Type[item.Item] = None
    max_upload_size = 1024 * 1024 * 500

    def from_config(self, config):
        self.server_url = config.server_url
        self.session_timeout = config.session_timeout
        self.debug_level = config.debug_level
        self.port = config.port
        self.secure_websocket = config.secure_websocket
        self.thread_pool = config.thread_pool
        self.connection_timeout = config.connection_timeout
        self.stats = config.stats
        self.logging = config.logging
        self.crypto_password = config.crypto_password
        self.mongo_uri = config.mongo.uri


class SemantikServer(Server):
    def __init__(self, config: SemantikServerConfig, createWebFiles=False):
        super().__init__(
            applicationClass=config.application_class,
            path=str(config.project_web_path),
            config=config,
            autoreload=config.autoreload,
        )

        handlers = []
        try:
            import rich.logging
        except ModuleNotFoundError:
            pass
        else:
            handlers = [rich.logging.RichHandler(rich_tracebacks=True)]

        logging.basicConfig(
            level=logging.DEBUG,
            format="[%(asctime)s,%(msecs)s] %(name)s %(levelname)s: %(message)s "
            "at line %(lineno)s %(filename)s in %(funcName)s",
            datefmt="%Y/%m/%d-%H:%M:%S",
            handlers=handlers or None,
        )

        path_roundtrip = Path(roundtrip.__file__).parent
        path_semantik = Path(semantik.__file__).parent

        if createWebFiles:
            # for first-time app building, scaffold the basic files needed to get an NPM dev server running
            templateWebFiles(web_path=config.project_web_path, semantik_path=path_semantik)

        self.vueSources = [config.project_web_path / "vue"]

        with open(config.project_web_path / "webpack.generated.js", "wt") as f:
            f.write(f'module.exports = {{ path_roundtrip: "{path_roundtrip}", path_semantik: "{path_semantik}"}};')

        self.addProvider(SimpleUploadProvider)
        if config.file_model:
            self.addProvider(
                UploadProvider, file_model=config.file_model or file.File, max_file_size=config.max_upload_size
            )

        self.initialize()

        crypto.setup(config.crypto_password)

        # database
        if config.mongo_uri:
            logging.info("connecting to mongodb")
            mongoengine.connect(host=config.mongo_uri, tz_aware=True)
