import datetime
import enum

from semantik.treestore.item import Item
from semantik.treestore.semantik import Semantik
from semantik.types import all as types
from semantik.types.core import validation as vl

__all__ = ["TestObjects", "TestObject"]


class TestObjects(Item):
    class sk(Semantik):
        iconClass = "fa-solid fa-phone"

        canSave = False

        class Main(types.Contents):
            type = "TestObject"

            showRowLines = True

            columns = [
                types.Column(caption="Name", dataField="name", width="50%"),
            ]
            addable = [
                dict(text="Add", type="TestObject"),
            ]

        structure = Main()


class TestObject(Item):
    meta = dict(
        collection="test_object",
        indexes=[
            dict(fields=["date", "date_created"]),
        ],
    )

    class sk(Semantik):
        checkForChanges = True
        iconClass = "fa-light fa-phone"
        deleteButtonArchives = True

        additionalState = {"transcript"}

        class MainForm(types.Form):
            class name(types.Text):
                formLabel = "Filename"
                help = "Original filename as uploaded"
                width = "100%"
                validate = vl.required()

            class date_created(types.Date):
                readOnly = True
                formLabel = "Date created"
                type = "datetime"
                width = "250"
                dataType = "datetime"

        structure = MainForm()
