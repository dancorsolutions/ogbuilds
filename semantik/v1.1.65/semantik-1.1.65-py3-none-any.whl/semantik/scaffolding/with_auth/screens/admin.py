from roundtrip.component import *
from semantik.treestore.item import StorageManager as sm
from semantik.views.admin import BaseAdminRoot
from ...base.current import current

screens = ["BaseAdminWithAuth"]


class BaseAdminWithAuth(BaseAdminRoot):
    imports = BaseAdminRoot.imports | {
        "import 'devextreme/dist/css/dx.common.css'",
        "import 'devextreme/dist/css/dx.light.css'",
    }

    app: ["mova.web.application.Application"]

    # language=Vue
    template = r"""
    <div 
        v-if="!!(windows._root && windows._root.item)"
        class="sk-admin-root"
    >
        <{& cmp.item_view_header_component &}
            :item="windows._root.item"
            @navigateTo="navigateTo"
         />
        <{& cmp.item_view_component &} v-if="windows._root.item && windows._root.item.type !== 'Root'" :state="windows._root.state" :configs="config" :item="windows._root.item"/>
    </div>
    <dx-popup
        v-if="!!(windows.popup && windows.popup.item)"
        v-model:visible="popupWindowVisible"
        :animation="null"
        :show-title="true"
        :title="windows.popup.item.path[windows.popup.item.path.length-1].label" 
        :show-close-button="false"
        key="my-popup"
        @contentReady="(e) => e.component.content().style.padding='0'"
    >
        <div class="sk-popup">
            <{& cmp.item_view_component &} :state="windows.popup.state" :configs="config" :item="windows.popup.item"/>
        </div>
    </dx-popup>
    """

    props = dict(type="type", id="id")
    syncProps = ["type", "id"]

    @lifecycle
    def created(self):
        type = getattr(self.attrs, "type", None)
        id = getattr(self.attrs, "id", None)

        if not current.user:
            self.app.open("PreLogin")
        elif not current.user.can("admin"):
            raise PermissionError()

        loaded = False
        if self.session.admin_initial_item_id:
            self.skRoot.openItem(sm.getItem(self.session.admin_initial_item_id), dont_push_route=True)
            loaded = True
        elif self.session.test and self.session.test[0] == "admin":
            ic = getattr(m, self.session.test[1], None)
            if ic:
                loaded = True
                if self.session.test[2]:
                    item = ic.objects(id=self.session.test[2])
                else:
                    item = ic.objects().first()
                self.skRoot.openItem(item)

            self.session.test = None
        elif type and id:
            self.skRoot.openItem(sm.getItem(f"{type}/{id}"))
            loaded = True

        if not loaded:
            self.skRoot.openItem(self.session.root)

    def notify(self, message: str, kind: str = "info"):
        self.app.toast(message, kind)
