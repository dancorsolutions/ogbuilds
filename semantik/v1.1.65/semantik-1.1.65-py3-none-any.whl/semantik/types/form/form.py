from ..common import *

__all__ = ["Form", "FieldSet", "Break", "Spacer"]


class BaseFieldCollection(ContainerType):
    _parameters = common_parameters.FIELD_CONTAINER


class FieldSet(BaseFieldCollection):
    _tag = "SKFieldSet"
    _parameters = BaseFieldCollection._parameters.add(
        Param(id="formClass"),
        Param(id="title", help="A title to show above the fieldset"),
    )


class SKFieldSet(SKComponent):
    # language=Vue
    template = r"""
    <div class="sk-fieldset-card mb-0" v-if="config.card || config.formLabel">
        <div class="card-header" v-if="config.formLabel">
            <strong>{{ config.formLabel }}</strong>
        </div>
        <div class="card-body">
            <SKFormContents 
                :config="config" 
                :state="state" 
                :itemState="itemState"
                :key="config._typeUID"
            />
        </div>
    </div>
    <SKFormContents 
        v-else 
        :config="config" 
        :state="state" 
        :itemState="itemState"
        :key="config._typeUID"
    />
    """


class Break(DatalessType):
    """
    A break that takes up an entire row on a form but doesn't render anything
    """

    _tag = "SKBreak"
    _parameters = Parameters()


class SKBreak(SKComponent):
    # language=Vue
    template = r"""
    <div class="w-100"/> 
    """


class Spacer(DatalessType):
    """
    A spacer that takes up a slot in a form but doesn't render anything
    """

    _tag = "SKSpacer"
    _parameters = Parameters()


class SKSpacer(SKComponent):
    # language=Vue
    template = r"""
    <div :class="config.fullWidth"/> 
    """


class Form(BaseFieldCollection):
    """
    A form with properly formatted fields and labels with consistent spacing, etc.

    This uses a CSS grid-type layout rather than a table for flexibility. Use CSS classes to determine label
    sizes, etc.
    """

    _tag = "SKForm"
    _parameters = BaseFieldCollection._parameters.add(
        Param(id="card", default=True, help="Render a card div around the form to give it visual separation"),
        Param(id="cardCls", help="Replace the style on the form card"),
    )

    def _validate(self, subState, context):
        errors = super()._validate(subState, context=context)
        if errors:
            if not self._transparentState:
                return errors[self._id]
            else:
                return errors


class SKForm(SKComponent):
    # language=Vue
    template = r"""
    <div :class="config.cardCls || 'sk-form-card mb-0'" v-if="config.card || config.formLabel">
        <div class="card-header" v-if="config.formLabel">
            <strong>{{ config.formLabel }}</strong>
        </div>
        <div class="card-body">
            <SKFormContents 
                :config="config" 
                :state="state" 
                :itemState="itemState"
                :key="config._typeUID"
            />
        </div>
    </div>
    <SKFormContents 
        v-else 
        :config="config" 
        :state="state" 
        :itemState="itemState"
        :key="config._typeUID"
    />
    """


class SKFormContentsField(Component):
    props = ["child", "state", "itemState", "hasLabel"]

    # language=Vue
    template = r"""
    <div class="input-group">
        <div class="input-group-prepend" v-if="child.prepend && !child.static">
            <span class="input-group-text" v-html="child.prepend"/>
        </div>
        <SKItem
            :config="child"
            :state="state"
            :itemState="itemState || state"
            :key="child._typeUID"
        />
        <small v-if="child.subscript" class="text-muted d-none d-md-flex sk-field-subscript" v-html="child.subscript"></small>
    </div>       
    <div v-if="child.help && (!child.helpStyle || child.helpStyle==='popover')" class="sk-field-help">
        <i class="fas fa-question-circle sk-field-icon" :id="'popup_' + _uid"></i>
        <dx-popover
            :target="'#popup_' + _uid"
            showEvent="dxhoverstart"
            hideEvent="dxhoverend"
        >
            <div class="sk-help-popover" v-html="child.help"></div>
        </dx-popover>
    </div>
    """


class SKFormContents(SKBase):
    props = ["config", "state", "itemState"]

    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <form 
        :class="{
            'sk-form': true,
            'form-horizontal': config.horizontal,
            'sk-static': config.static,  
            'sk-field-container': true, 
            [config.cls]: (config.cls ? true : false)
        }" 
        onsubmit="return false;"
    >
        <div class="row sk-form-core-row">
            <template 
                v-for="child of children"
            >
                <div 
                    v-if="child.isFieldContainer"
                    :class="'sk-form-col-container ' + (child.formClass || config.defaultClass)"
                >
                    <label 
                        v-if="child.formLabel && ((child.display === undefined) || child.display)"                    
                        v-html="child.formLabel" 
                        :for="child._typeUID"
                        :class="{'sk-label': true, 'sk-field-error': (state[child._id] ? state[child._id]._error : false)}"
                    />
                    <SKItem
                        v-if="(child.display === undefined) || child.display"                    
                        :config="child"
                        :state="state"
                        :itemState="itemState || state"
                        :key="child._typeUID"
                    />
                </div>
                <template v-else-if="config.horizontal">
                    <div
                        :class="child.formClass || config.defaultClass"
                    > 
                        <div 
                            v-if="child.formLabel"
                            :class="(child.rowClass || config.defaultRowClass)"
                        >
                            <div 
                                :class="'sk-form-col-label ' + (child.labelClass || config.defaultLabelClass)"
                            >
                                <label  
                                    v-html="child.formLabel" 
                                    :for="child._typeUID"
                                    :class="{'sk-form-label': true, 'sk-field-error': (state[child._id] ? state[child._id]._error : false)}"
                                />
                            </div>
                            <div 
                                :class="'sk-form-col-field ' + (child.fieldClass || config.defaultFieldClass)"
                            >
                                <SKFormContentsField 
                                    :key="child._typeUID"
                                    :child="child" 
                                    :state="state" 
                                    :itemState="itemState || state
                                "/>
                            </div>
                        </div>
                        <SKFormContentsField
                            v-else 
                            :key="child._typeUID"
                            :child="child" 
                            :state="state" 
                            :itemState="itemState || state
                        "/>
                    </div>
                </template>
                <template v-else>
                    <div 
                        :class="'sk-form-col-combined ' + (child.formClass || config.defaultClass)"
                        v-if="(child.display === undefined) || child.display"                    
                    >
                        <label 
                            v-if="child.formLabel && ((child.display === undefined) || child.display)"                    
                            v-html="child.formLabel" class="sk-label" :for="child._typeUID"
                        />
                        <SKFormContentsField 
                            v-if="(child.display === undefined) || child.display"                    
                            :child="child" 
                            :state="state" 
                            :key="child._typeUID"
                            :itemState="itemState || state"
                        />
                    </div>
                </template>
            </template>
        </div>
    </form>
    """

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        children=js(
            """
            function() { 
                if(!this.config.structure)
                    return [];
                return this.hydrateConfig(this.config.structure).filter(
                    function(x) { 
                        return (x.display === undefined || x.display); 
                    }
                ); 
            }
        """
        )
    )
