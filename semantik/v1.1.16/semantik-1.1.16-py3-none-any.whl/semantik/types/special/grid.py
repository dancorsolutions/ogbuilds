from ..common import *
import mongoengine

__all__ = ["Grid", "GridColumn"]


class Grid(Type):
    """
    In-place editable grid component based on dx-data-grid
    """

    _tag = "SKGrid"

    _parameters = common_parameters.FORM_ITEM.add(
        Param(id="title"),
        Param(id="ordered", help="Allow re-ordering rows by dragging"),
        Param(id="columns", required=True),
        Param(id="canAdd", default=True),
        Param(id="canDelete", default=True),
        Param(id="canEdit", default=True),
        Param(id="ordered", default=False),
        Param(id="largeAddButton"),
        RTParam(id="editing", default={}),
        SSParam(id="virtual", callable=True),
    ).addPassthroughs(dx.DxDataGrid)

    def _config(self, context, statePath=None, static=False):
        out = super()._config(context=context, statePath=statePath, static=static)
        out["columns"] = [
            i._config(context, statePath=statePath, static=static) for i in self.p("columns", context=context)
        ]
        return out

    def _data(self, context):
        data = super()._data(context=context)
        data[self._id]["_value"] = []
        return data

    def _getFields(self):
        return {self._id: mongoengine.DynamicField()}


class GridColumn(DatalessType):
    _tag = "DxDataGridColumn"
    _parameters = Parameters(Param("options")).addPassthroughs(dx.DxDataGridColumn)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if "dataField" not in self.p:
            self.p.dataField = self._id


class SKGrid(SKComponent):
    # language=Vue
    template = r"""
    <div class="sk-grid">
        <div v-if="config.title" class="sk-grid-title" v-html="config.title"/>
        <dx-data-grid
            :word-wrap-enabled="true"
            :show-borders="true"
            :data-source="state._value"
            :column-auto-width="true"
            v-bind="config._passthroughAttrs"
            ref="grid"
            contentReady="observeResize()"
        >
            <dx-data-grid-toolbar>
                <dx-toolbar-item location="before">
                    <SKValidationError :error="state._error || error"/>
                </dx-toolbar-item>  
                <dx-toolbar-item location="after" name="addRowButton">
                </dx-toolbar-item>  
            </dx-data-grid-toolbar>
            <dx-data-grid-editing
                :allow-updating="!config.static && config.canEdit"
                :allow-deleting="!config.static && config.canDelete"
                :allow-adding="!config.largeAddButton && !config.static && config.canAdd"
                mode="cell"
                v-bind="config._passthroughAttrs.editing"
            />
            <dx-data-grid-row-dragging
                v-if="config.ordered"
                :allow-reordering="true"
                :on-reorder="onReorder"
                :show-drag-icons="true"
            />    
            <dx-data-grid-column
                v-for="(col, index) of hydrateConfig(config.columns)" 
                v-bind="col._passthroughAttrs"
                :key="index"
            >
                <dx-data-grid-lookup
                    v-if="col.options"
                    :data-source="col.options"
                    value-expr="k"
                    display-expr="v"
                />
            </dx-data-grid-column>
        </dx-data-grid>
        <div class="sk-contents-footer" style="background-color: white;" v-if="!config.static && config.largeAddButton && config.canAdd">
            <div class="sk-contents-actions">
                <button 
                    @click="$refs.grid.instance.addRow()" 
                    class="btn btn-sm btn-outline-success sk-grid-add-button"
                >
                    {{config.largeAddButton === true ? 'Add' : config.largeAddButton}}
                </button>
            </div>
        </div>
    </div>
     """

    initialData = dict(error=None)

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        onReorder=r"""
            function(e) {
                let temp = this.state._value[e.fromIndex];
                this.state._value[e.fromIndex] = this.state._value[e.toIndex];
                this.state._value[e.toIndex] = temp;
                this.state._value = [...this.state._value];
            }        
        """
    )
