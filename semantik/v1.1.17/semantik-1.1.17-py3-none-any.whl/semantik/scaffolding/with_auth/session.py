import typing
from semantik.core.session import SKSession

__all__ = ["SKSessionWithAuth"]


class SKSessionWithAuth(SKSession):
    test: list | None = None
    user: typing.Any = None
    admin_initial_item_id: str | None = None
    router_path_on_connection: str | None = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def login(self, user):
        self.user = user

    def logout(self):
        self.user = None
        self.admin_initial_item_id = None
        self.test = None
