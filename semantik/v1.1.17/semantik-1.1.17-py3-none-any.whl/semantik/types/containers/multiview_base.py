from ..common import *
from semantik.types.core.types import Type

__all__ = ["MultiviewBase", "SKMultiviewBase", "MultiviewItemBase"]


class MultiviewBase(ContainerType):
    _parameters = Parameters(
        Param(id="id"),
        Param(id="display"),
        Param(id="structure"),
        Param(id="static", inherit=True),
    )

    def _config(self, context, statePath=None, static=False):
        out = super()._config(context=context, statePath=statePath, static=static)
        for i in self.p.structure:
            if "onEnter" in i.p and "onLeave" in i.p:
                if i.p("onEnter", default=None) or i.p("onLeave", default=None):
                    out["monitorSelectionChange"] = True
                    break
        return out


class SKMultiviewBase(SKComponent):
    @method
    def selectionChanged(self, oldSelection, newSelection):
        old = new = None
        if oldSelection:
            old = Type._byUID[oldSelection]
        if newSelection:
            new = Type._byUID[newSelection]

        if not old and not new:
            return

        context = self.context

        eh = old.p("onLeave", default=None)
        if eh:
            eh(context=context)
        eh = new.p("onEnter", default=None)
        if eh:
            eh(context=context)


class MultiviewItemBase(ContainerType):
    _parameters = Parameters(
        Param(id="id", required=True),
        Param(id="display"),
        Param(id="title", required=True, hoist=True),
        Param(id="structure"),
        Param(id="static", inherit=True),
        Param(id="onEnter"),
        Param(id="onLeave"),
    )
