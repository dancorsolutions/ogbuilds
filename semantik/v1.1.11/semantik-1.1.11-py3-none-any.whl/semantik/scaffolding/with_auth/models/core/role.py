from ..common import *

__all__ = ["Roles", "Role"]

PERMISSIONS = [dict(v="admin", l="Admin")]


class Roles(Item):
    class sk(Semantik):
        iconClass = "fa-regular fa-flag-swallowtail"

        class MainContents(types.Contents):
            addable = [dict(text="Add", type="Role")]
            type = "Role"
            showAll = True
            showRowLines = True
            deleteButtonArchives = True
            hideArchived = True

            columns = [
                types.Column(caption="Identifier", dataField="ident"),
                types.Column(caption="Name", dataField="name"),
                types.Column(caption="Description", dataField="description"),
            ]

        structure = MainContents()

        canDelete = False
        canSave = False


class Role(Item):
    class sk(Semantik):
        checkForChanges = True
        iconClass = "fa-light fa-flag-swallowtail"

        deleteButtonArchives = True

        class Structure(types.Form):
            horizontal = True

            class ident(types.Text):
                formLabel = "Identifier"
                width = "100%"
                validate = vl.identifier()

            class name(types.Text):
                formLabel = "Name"
                width = "100%"
                validate = vl.required()

            class description(types.TextArea):
                formLabel = "Description"
                width = "100%"

            class permissions(types.SelectList):
                options = PERMISSIONS
                formLabel = "Permissions"
                validate = vl.required()

        structure = Structure()
