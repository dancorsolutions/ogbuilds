from ..common import *
from ..form_fields import base

__all__ = ["Scheduler"]


class Scheduler(base.SimpleField):
    _tag = "SKScheduler"
    _parameters = common_parameters.SIMPLE_FIELD.add(
        Param(id="formCustomization"),
    ).addPassthroughs(dx.DxScheduler)
    _nullValue = []
    dataType = "object"


class SKScheduler(SKComponent):
    # language=Vue
    template = r"""
    <dx-scheduler
        :dataSource="state._value"
        @appointmentUpdated="doSet(state._value)"
        @appointmentAdded="doSet(state._value)"
        @appointmentDeleted="doSet(state._value)"
        @appointmentFormOpening="onForm"
        {& sk.dx_field_attributes &}
    >
    </dx-scheduler>
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        doSet=js(r"""function(e) { for (let i of e) { for (let j in Object.keys(i)) { this.$set(i, j, i[j]); } } }"""),
        # language=JavaScript prefix=[ suffix=]
        onForm=js(
            r"""
            function(e) {
                if(!this.config.formCustomization)
                    return;
                let formItems = e.form.option('items');
                if(formItems.length > 2)
                    return;
                formItems = formItems.concat(this.config.formCustomization);
                e.form.option('items', formItems);
            }
        """
        ),
    )
