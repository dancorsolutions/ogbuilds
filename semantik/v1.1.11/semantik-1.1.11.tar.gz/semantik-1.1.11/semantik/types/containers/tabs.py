from ..common import *
from .multiview_base import *

__all__ = ["Tabs", "Tab"]


class Tabs(MultiviewBase):
    _tag = "SKTabs"
    _parameters = MultiviewBase._parameters.addPassthroughs(dx.DxTabPanel) + Parameters(
        Param("isFieldContainer", default=True)
    )


class SKTabs(SKMultiviewBase):
    # language=Vue
    template = r"""
    <dx-tab-panel 
        v-bind="config._passthroughAttrs"
        class="sk-tabs"
        @selection-changed="onSelectionChanged($event)"
        item-title-template="title_template"
        ref="tab_panel"
    >
        <template #title_template="{ data }">
            <div :class="{'sk-tab-title-error': data.icon, 'sk-tab-title': true}">
                {{ data.title }}
            </div>
        </template>
        <dx-tab-panel-item
            v-for="child of hydrateConfig(this.config.structure).filter((child)=>child.display === undefined || child.display)"
            :key="child._typeUID + this._uid"
            :title="child.title"
            :icon="state[child._id] && state[child._id]._error ? 'error' : null"
            v-bind="child._passthroughAttrs"
        >
            <template #default>
                <SKItem
                    v-if="child.display === undefined || child.display"
                    class="sk-tab-contents"
                    :config="child"
                    :state="state"
                    :itemState="itemState"                    
                />
            </template>
        </dx-tab-panel-item>
    </dx-tab-panel>
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        onSelectionChanged=r"""
        function(e) {
            window.sessionStorage.setItem(this.config._typeUID, e.component.option('selectedIndex'));
        }
        """
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        mounted=r"""
        function() {     
            const tab = window.sessionStorage.getItem(this.config._typeUID);
            if(tab !== undefined) {
                this.$refs.tab_panel.instance.option('selectedIndex', tab);             
            }
        }
        """
    )


class Tab(MultiviewItemBase):
    _tag = "SKTab"
    _parameters = MultiviewItemBase._parameters.addPassthroughs(dx.DxTabPanelItem)


class SKTab(SKComponent):
    # language=Vue
    template = r"""
    <SKContents
        :config="config" 
        :state="state" 
        :itemState="itemState"
    />
    """
