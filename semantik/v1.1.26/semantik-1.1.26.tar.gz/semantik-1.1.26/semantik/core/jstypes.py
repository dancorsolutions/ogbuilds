import datetime

from roundtrip.core.javascript import *

__all__ = ["moment"]


class moment(datetime.datetime):
    def _as_javascript(self):
        init = [self.year, self.month, self.day, self.hour, self.minute, self.second, self.microsecond / 1000]
        return "moment(%r)" % init
