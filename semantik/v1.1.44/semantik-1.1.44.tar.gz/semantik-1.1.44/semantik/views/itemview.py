import os.path

from roundtrip.component.decorators import *
from roundtrip.core.javascript import js
from ..types.core.components import SKBase
from ..treestore.item import StorageManager

__all__ = ["ItemView", "ItemViewHeader"]


class ItemViewHeader(SKBase):
    props = ["item"]

    # language=Vue
    template = r"""
    <header v-if="item" class="sk-item-header" :style="item.color ? {'background-color': item.color}: {}">
        <i v-if="item.icon" :class="item.icon + ' sk-header-icon'"/>
        <div class="sk-item-header-label">
            <div class="sk-label">
                <span class="sk-label">{{item.headerLabel}}</span>
            </div>
            <nav class="sk-breadcrumb breadcrumb border-0 m-0 px-0 px-md-3">
                <span 
                    v-for="el in item.path"
                    :class="{'breadcrumb-item': true, active: el.active, navigable: !el.active && el.navigable}"
                    :href="el.active ? null : '#'"
                    @click="el.navigable && !el.active && $emit('navigateTo', el.id)"
                >{{el.label}}</span>
            </nav>
        </div>
        <ul class="header-nav mfs-auto">
            <li class="header-nav-item px-3 d-legacy-none">
                <a v-if="false" class="header-nav-link" href="#" role="button">
                    <button class="header-nav-btn" type="button">
                        <i class="fa fa-bell"/>
                    </button>
                    <span class="badge badge-pill badge-danger">5</span>
                </a>
            </li>
        </ul>
    </header>
    """


class ItemView(SKBase):
    props = ["configs", "item", "state"]

    imports = SKBase.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    # language=Vue
    template = r"""
    <div v-if="item && ready" class="sk-main-body" style="overflow: auto; height: 1px;">
        <SKDialog ref="confirm"></SKDialog>
        <component 
            v-if="popupComponent" 
            :is="popupComponent" 
            ref="popup" 
            :state="state"
        />        
        <SKValidationError :error="error"/>
        <SKItem :config="config" :state="state" :itemState="state"/>
        <footer v-if="item.hasActions" class="footer navbar-fixed-bottom sk-item-footer">
            <div class="sk-item-action-buttons">
                <button v-if="item.canCancel" @click="doCancel()" class="btn btn-md ml-2 btn-outline-secondary">Cancel</button>
                <button 
                    v-if="item.canDelete" 
                    @click="$refs.confirm.show({
                        title: 'Confirm delete', 
                        message: 'Are you sure?',
                        buttons: [
                            {label: 'Cancel', cls: 'btn-outline-secondary'},
                            {label: 'Confirm', cls: 'btn-outline-danger', action: doDelete}
                        ],
                        width: '600px',
                        height: '300px'
                    })" 
                    class="btn btn-md ml-2 btn-outline-danger"
                >
                    Delete
                </button>
                <button 
                    v-if="item.canArchive" 
                    @click="$refs.confirm.show({
                        title: 'Confirm archive', 
                        message: 'Are you sure?', 
                        buttons: [
                            {label: 'Cancel', cls: 'btn-outline-secondary'},
                            {label: 'Confirm', cls: 'btn-outline-danger', action: doArchive}
                        ],
                        width: '600px',
                        height: '300px'
                    })" 
                    class="btn btn-md ml-2 btn-outline-danger"
                >
                    Delete
                </button>
                <button v-if="item.canSave" @click="doSave(false)" class="btn btn-md ml-2 btn-outline-success">Save</button>
                <button v-if="item.canSaveClose" @click="doSave(true)" class="btn btn-md ml-2 btn-outline-success">Save & Close</button>
                <template
                    v-for="(button, index) of this.hydrateConfig(config.customActions)"
                    v-if="config.customActions && config.card" 
                    :key="index"
                >
                    <!-- v-bind="button._passthroughAttrs" -->
                    <button
                        v-if="button.display === undefined || button.display"
                        @click="doCustomAction(index)"
                        :class="'btn btn-md ml-2 btn-outline-' + button.cls"
                    >{{ button.text }}</button>
                </template>
            </div>
        </footer>
    </div>
    """

    initialData = dict(popupComponent=None, error=None, ready=False)

    watch = {
        # language=JavaScript prefix=[ suffix=]
        "item": r"""function(after, before) {
            this.error = null;
        }""",
        # language=JavaScript prefix=[ suffix=]
        "item.type": r"""async function(after, before) {
            if(!this.configs[this.item.type]) {
                this.configs[this.item.type] = await this.getCurrentConfig(this.item.type)
            }
            this.config = this.hydrateConfig(this.configs[this.item.type](this))
            this.ready = true;
        }"""
    }


    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        confirmLeave=r"""function(config) {
            this.$refs.confirm.show({
                title: (config && config.title) || 'Unsaved changes',
                message: (config && config.message) || 'Are you sure you want to close this item?',
                buttons: [
                    {label: 'Cancel', cls: 'btn-outline-secondary'},
                    {label: 'Discard Changes', cls: 'btn-outline-danger', 
                     action: () => this.doCancel(true)},                    
                    {label: 'Save Changes', cls: 'btn-outline-success', 
                     action: () => this.doSave({close: true})},                    
                ]
            });
        }""",
        # language=JavaScript prefix=[ suffix=]
        showPopup=r"""function(action, component) {
            this.popupComponent = component;
            nextTick(() => {
                this.$refs.popup.show(action, () => { this[action]({close: true, force: true});} );
            })
        }""",
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        beforeMount=r"""async function() {
            if(!this.configs[this.item.type]) {
                this.configs[this.item.type] = await this.getCurrentConfig(this.item.type)
            }
            this.config = this.hydrateConfig(this.configs[this.item.type](this))
            this.error = null;
            this.ready = true;
        }"""
    )

    @property
    def components(self):
        out = []
        for typ in StorageManager.registeredItemTypes.values():
            for k in "popupOnSave", "popupOnArchive", "popupOnDelete", "popupOnSaveChanged":
                if getattr(typ.sk, k, None):
                    out.append(getattr(typ.sk, k))
        return out

    @method
    def doSave(self, close=False, force=False):
        # Allow client to dynamically specify the popup
        currentPopupOnSave = self.skRoot.at.sk.popupOnSave
        if hasattr(self.skRoot.at.sk, "popupOnSaveOverride"):
            self.skRoot.toItem()
            currentPopupOnSave = self.skRoot.at.sk.popupOnSaveOverride()

        if (not force) and self.skRoot.at.sk.popupOnSaveChanged and self.skRoot.hasChanged():
            self.client.showPopup("doSave", self.skRoot.at.sk.popupOnSaveChanged)
        if (not force) and currentPopupOnSave:
            self.client.showPopup("doSave", currentPopupOnSave)
        else:
            if self.session.doAfterConfirmLeave:
                close = False  # ignore close argument if we're going to call a callback after we complete
            overall_error = self.skRoot.saveItem(close=False)
            if overall_error:
                self.session.doAfterConfirmLeave = None
                self.data.error = overall_error
                return
            else:
                if self.session.doAfterConfirmLeave:
                    go = self.session.doAfterConfirmLeave
                    self.session.doAfterConfirmLeave = None
                    go()

            if close:
                self.skRoot.closeItem()
                self.skRoot.notify("Item saved", "success")
            else:
                self.skRoot.reloadItem()

    @method
    def doDelete(self):
        self.data.error = None
        if self.skRoot.at.sk.deleteButtonArchives:
            if self.skRoot.at.sk.popupOnArchive:
                self.client.showPopup("doDelete", self.skRoot.at.sk.popupOnArchive)
            else:
                overall_error = self.skRoot.archiveItem()
                if overall_error:
                    self.data.error = overall_error
        else:
            if self.skRoot.at.sk.popupOnArchive:
                self.client.showPopup("doDelete", self.skRoot.at.sk.popupOnDelete)
            else:
                overall_error = self.skRoot.deleteItem()
                if overall_error:
                    self.data.error = overall_error

    @method
    def doArchive(self):
        self.data.error = None
        if self.skRoot.at.sk.popupOnArchive:
            self.client.showPopup("doArchive", self.skRoot.at.sk.popupOnArchive)
        else:
            overall_error = self.skRoot.archiveItem()
            if overall_error:
                self.data.error = overall_error

    @method
    def doCancel(self, force=False):
        if (not force) and self.session.at.sk.checkForChanges and self.skRoot.hasChanged():
            self.client.confirmLeave()
            return True
        if self.session.doAfterConfirmLeave:
            go = self.session.doAfterConfirmLeave
            self.session.doAfterConfirmLeave = None
            go()
        else:
            self.skRoot.closeItem()

    @method
    def doCustomAction(self, index):
        at = self.skRoot.at
        at.sk.structure.customActions[index].p.action(self, at)


    @method
    def confirmThenDo(self, callback):
        self.session.doAfterConfirmLeave = callback
        self.client.confirmLeave()

    @method
    def getCurrentConfig(self, key):
        cls = StorageManager.registeredItemTypes[key]
        return cls.sk.structure._configDefault(context=self.context)

