import mongoengine

from roundtrip.scaffolding.models.common import SaltedPassword

from semantik.types.common import *

from semantik.types.contents.contents import Column

__all__ = ["PasswordManager"]


#
# PasswordManager
#


class PasswordManager(Type):
    _tag = "SKPasswordManager"
    _parameters = common_parameters.FORM_ITEM

    def _data(self, context):
        return {
            self._id: dict(
                _is_set=False, _is_locked=False, _tries=0, _max_tries=0, _date_set=None, _value="", _dynamic={}
            )
        }

    def _toState(self, storage, state, context):
        if self._id not in storage:
            return self._data(context=context)
        val = storage[self._id]
        state[self._id] = dict(
            _is_set=val.is_set,
            _is_locked=val.locked,
            _tries=val.tries,
            _max_tries=val.max_tries,
            _date_set=val.is_set,
            _value="",
        )

    def _toStorage(self, state, storage, context):
        if self._id not in state:
            return

        if self._id not in storage:
            val = SaltedPassword()
            storage[self._id] = val
        else:
            val = storage[self._id]

        d = state[self._id]

        if d._value:
            val.set(d._value)
            val.tries = 0
            val.locked = False

        else:
            if "_is_locked" in d and d._is_locked != val.locked:
                val.locked = d._is_locked
                val.tries = 0

            if "_is_set" in d and d._is_set == False:
                val.reset()

    def _getFields(self):
        return {self._id: mongoengine.EmbeddedDocumentField(SaltedPassword, default=SaltedPassword)}

    @classmethod
    def _getColumnClass(cls):
        return PasswordMangerColumn


class PasswordMangerColumn(Column):
    """Default column base class"""

    dataField = "password"
    encodeHtml = False
    allowFiltering = False
    allowSearch = False
    allowSorting = False
    width = 100

    def calcValue(self, value):
        s = ""
        if value.is_set:
            # language=HTML
            s += '<div class="badge badge-primary">SET</div> '
        else:
            # language=HTML
            s += '<div class="badge badge-warning">NOT SET</div>'
        if value.locked:
            # language=HTML
            s += '<div class="badge badge-danger">LOCKED</div> '
        return s.strip()


class SKPasswordManager(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        **********
    </div>
    <div v-else :class="'sk-password-manager' + (config.cls ? ' ' + config.cls : '')" style="flex: 1;">
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text" style="height: 100%;"><i class="sk-dx-icon md dx-icon-lock"/></span>
            </div>
            <dx-text-box 
                type="password"
                class="reset-all"
                :placeholder="state._is_set ? 'Type to override password' : 'Type to set password'"
                style="flex: 1;"
                v-model:value="state._value"
                {& sk.dx_validate &}
            />
        </div>

        <template v-if="!state._value">
            <button v-if="state._is_set" @click="state._is_set=false" class="btn btn-outline-warning btn-sm">UNSET</button>
            <button v-if="state._is_locked" @click="() => { state._is_locked=false; state._tries = 0}" class="btn btn-outline-success btn-sm">UNLOCK</button>
            <button v-else @click="() => { state._is_locked=true; state._tries = 0 }" class="btn btn-outline-danger btn-sm">LOCK</button>
            &nbsp;
            <span v-if="!state._is_set" class="badge bg-warning">UNSET</span>
            <span v-else-if="state._is_set && !state._is_locked" class="badge bg-success">OK ({{state._tries}} / {{state._max_tries}})</span>
            <span v-else-if="state._is_set && state._is_locked" class="badge bg-danger">LOCKED</span>
        </template>
        <template v-else>
            <span class="badge bg-warning">CHANGED</span>
        </template>        
        &nbsp;
    </div>
    """
