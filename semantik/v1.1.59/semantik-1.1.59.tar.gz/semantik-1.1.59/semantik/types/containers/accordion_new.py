from ..common import *
from .multiview_base import *

__all__ = ["Accordion", "AccordionItem"]


class Accordion(MultiviewBase):
    _tag = "SKAccordionDX"
    _parameters = MultiviewBase._parameters.addPassthroughs(dx.DxAccordion) + Parameters(
        Param("isFieldContainer", default=True)
    )


class SKAccordion(SKMultiviewBase):
    # language=Vue
    template = r"""
    <div 
        v-bind="config._passthroughAttrs"
        class="sk-accordion"
    >
        <div
            class="sk-accordion-item"
            v-for="(child, index) of items"
        >
            <div 
                :class="{
                    'sk-accordion-title-error': state[child._id] && state[child._id]._error, 
                    'sk-accordion-title': true,
                    'dx-template-wrapper': true,
                    'dx-item-content': true,
                    'dx-accordion-item-title': true
                }"
                @click="toggle(index)"
            >
                {{ child.title }}
            </div>
            <div
                class="sk-aaccordion-body"
                v-if="is_open[index]"
            >
                <SKItem
                    class="sk-accordion-body dx-template-wrapper dx-item-content dx-accordion-item-body sk-accordion-contents"
                    :config="child"
                    :state="state"
                    :itemState="itemState"
                />
            </div>
        </div>
    </div>
    """

    initialData = dict(is_open=[])

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        items=js(
            r"""
        function(vm) {
            let rc = this.hydrateConfig(this.config.structure).filter((x) => x.display === undefined || x.display);
            if(rc.length && !this.$data.is_open.length) {
                this.$data.is_open[0] = true;
            }
            for(let i=0; i<rc.length; i++) {
                this.$data.is_open[i] = this.$data.is_open[i] || false; 
            }
            return rc;  
        }"""
        )
    )

    methods = dict(
        toggle=js(
            r"""
        function(index) {
            for(let i=0; i<this.$data.is_open.length; i++) {
                if(i == index)
                    if(this.$data.is_open[i])
                        this.$data.is_open[i] = false;
                    else
                        this.$data.is_open[i] = true;
                else
                    this.$data.is_open[i] = false;
            }
        }
        """
        )
    )


class AccordionItem(MultiviewItemBase):
    _tag = "SKAccordionItem"
    _parameters = MultiviewItemBase._parameters.addPassthroughs(dx.DxAccordionItem)


class SKAccordionItem(SKComponent):
    # language=Vue
    template = r"""
    <SKContents
        :config="config" 
        :state="state" 
        :itemState="itemState"
    />
    """


class SKAccordionDX(SKMultiviewBase):
    # language=Vue
    template = r"""
    <dx-accordion 
        v-bind="config._passthroughAttrs"
        class="sk-accordion"
        @selection-changed="
            config.monitorSelectionChange ? 
                selectionChanged({
                    oldSelection: $event.removedItems[0]._typeUID, 
                    newSelection: $event.addedItems[0]._typeUID
                }) 
                : null
        "
        item-title-template="title"
    >
        <template #title="{ data }">
            <div :class="{
                'sk-accordion-title-error': data.icon, 
                'sk-accordion-title': true,
                'dx-template-wrapper': true,
                'dx-item-content': true,
                'dx-accordion-item-title': true
            }">
                {{ data.title }}
            </div>
        </template>
        <dx-accordion-item
            v-for="child of hydrateConfig(this.config.structure).filter((x) => x.display === undefined || x.display)"
            ref="tpi"
            :key="child._typeUID"
            :title="child.title"
            :icon="state[child._id] && state[child._id]._error ? 'error' : null"
        >
            <template #default>
                <SKItem
                    class="dx-template-wrapper dx-item-content dx-accordion-item-body sk-accordion-contents"
                    :config="child"
                    :state="state"
                    :itemState="itemState"
                />
            </template>
        </dx-accordion-item>
    </dx-accordion>
    """
