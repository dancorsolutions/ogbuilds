/**
 * Vue mixin for Semantik components (i.e. components passed state + context + config and draw using config)
 */
export const SemantikMixin = {
    methods: {
        hydrateConfig: function (config) {
            function hydrateOne(cfg) {
                let newConfig = Object.assign(
                    {},
                    cfg,
                    cfg._rest.bind(this)(cfg.$vm)
                )
                delete newConfig._rest
                return newConfig
            }
            if (Array.isArray(config)) {
                return config.map((i) => hydrateOne.bind(this)(i))
            } else {
                return hydrateOne.bind(this)(config)
            }
        },
    },
}
