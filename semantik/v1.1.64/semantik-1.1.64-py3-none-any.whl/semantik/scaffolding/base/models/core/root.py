from ..common import *

__all__ = ["Root"]


class Root(Item):
    class sk(Semantik):
        iconClass = "fa-light fa-gear"

        treeExpandable = True

        structure = types.Form(structure=[types.Static(text="Root object")])

        namedChildren = dict(
            # Put your root objects here
        )
