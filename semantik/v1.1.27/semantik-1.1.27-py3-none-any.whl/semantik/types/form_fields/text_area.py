import mongoengine

from semantik.types.common import *
from .base import *

__all__ = ["TextArea"]


#
# TextArea
#


class TextArea(SimpleField):
    _tag = "SKTextArea"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxTextArea)
    nullValue = ""
    dataType = "str"


class SKTextArea(SKComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._value ? state._value : '-' }}
    </div>
    <dx-text-area
        v-else-if="config.calculated" 
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-text-area
        v-else 
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """
