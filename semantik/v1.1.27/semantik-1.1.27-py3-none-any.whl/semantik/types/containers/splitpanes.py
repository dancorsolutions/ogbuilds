from semantik.types.common import *

__all__ = ["SplitPanes", "SplitPane"]


class ESplitPanes(External):
    imports = SKComponent.imports | {
        "import { Splitpanes as ESplitPanes} from 'splitpanes'",
    }


class EPane(External):
    imports = SKComponent.imports | {
        "import { Pane as EPane } from 'splitpanes'",
    }


class SplitPanes(ContainerType):
    """
    Splitter view with one or more horizontal / vertical bars to allow the user to resize areas of the UI
    """

    _tag = "SKSplitPanes"
    _parameters = Parameters(
        Param(id="structure"),
    ).addPassthroughs(["style", "cls", "horizontal"])


class SKSplitPanes(SKComponent):
    components = ["ESplitPanes"]

    # language=Vue
    template = r"""
    <ESplitPanes 
        class="default-theme"
        :name="config._typeUID"
        @resize="$rt.setComponentState(config._typeUID, $event)"
        v-bind="config._passthroughAttrs"
    >
        <SKContentsFragment
            :config="config" 
            :state="state" 
            :itemState="itemState"
        />
    </ESplitPanes>     
    """


class SplitPane(ContainerType):
    """
    Split pane for use in a splitter view
    """

    _tag = "SKSplitPane"
    _parameters = Parameters(
        Param(id="structure"),
        Param(id="paneIndex"),
    ).addPassthroughs(["style", "cls", "horizontal"])


class SKSplitPane(SKComponent):
    components = ["EPane"]

    # language=Vue
    template = r"""
    <EPane
        :name="config._typeUID"
        :size="storedSize"
        v-bind="config._passthroughAttrs"
    >
        <SKContentsFragment
            :config="config" 
            :state="state" 
            :itemState="itemState"
        />
    </EPane>     
    """

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        storedSize=js(
            """
        function() {
            if(!this.config.paneIndex)
                return;
            let at = this.$parent.$parent;
            while(!at.config)
                at = at.$parent;
            let ss = this.$rt.getComponentState(at.config._typeUID);
            if(ss && ss[this.config.paneIndex]) {    
                return ss[this.config.paneIndex]['size'];
            }
         }
        """
        ),
    )
