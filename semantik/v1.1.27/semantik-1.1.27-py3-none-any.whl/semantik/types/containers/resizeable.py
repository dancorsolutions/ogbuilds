from ..common import *

__all__ = ["Resizeable"]


class Resizeable(ContainerType):
    _tag = "SKResizeable"
    _parameters = Parameters(
        Param(id="structure"),
    ).addPassthroughs(dx.DxResizable)


class SKResizeable(SKComponent):
    # language=Vue
    template = r"""
    <DxResizable 
        :name="config._typeUID"
        :class="'reset-this ' + config.cls"
        v-bind="config._passthroughAttrs"
    >
        <SKContents
            class="sk-resizeable-contents"
            :config="config" 
            :state="state" 
            :itemState="itemState"
        />
    </DxResizable>     
    """
