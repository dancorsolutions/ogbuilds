import logging

from roundtrip.core.javascript import js
from roundtrip.application.application import RouterApplication, Route
from roundtrip.component.decorators import *

from roundtrip.scaffolding.config import config
from roundtrip.scaffolding.components.apperror import AppError
from roundtrip.scaffolding.utils import login_token
from semantik.core.session import SKSession
from semantik.scaffolding.base.current import current

from semantik.treestore.item import StorageManager as sm


class MyAppError(AppError):
    methods = dict(**AppError.methods)


MyAppError.methods["connectionExpired"] = "window.location.reload()"


class SemantikRouterApplication(RouterApplication):
    routes = None  #: override
    sessionClass = SKSession  #: override

    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <MyAppError/>
    <dx-toast
        ref="toast"
        type="custom"
        :position="{at: 'top right', my:'top right', offset: '-10 10'}"
        :width="300"
        :display-time="3000"
        :wrapper-attr="{class: 'ska-toast-' + toast_type}"
    >
        <template #content>
            <i class="fa-solid fa-info" v-if="toast_type === 'info'"></i> 
            <i class="fa-solid fa-triangle-exclamation" v-if="toast_type === 'warning'"></i> 
            <i class="fa-solid fa-xmark-large" v-if="toast_type === 'danger'"></i> 
            <i class="fa-solid fa-thumbs-up" v-if="toast_type === 'success'"></i> 
            {{ toast_message }}
        </template>
    </dx-toast>
    <div 
        class="wrapper d-flex flex-column min-vh-100 ska-iframe-loggedin-container" 
        v-if="!standalone"        
    >
    <component :is="current_screen" v-if="!iframe_url" v-bind="current_screen_props"/>
    <iframe ref="iframe" class="ska-iframe" v-if="iframe_url" :src="iframe_url"/>
    </div>
    <component :is="current_screen" v-bind="current_screen_props" v-else/>
    """

    components = []

    initialData = dict(
        toast_message="",
        toast_type="info",
        current_screen=None,
        current_screen_props=dict(),
    )

    def open(self, path=None, iframe_url=None, **kwargs):
        """Push the page into router history and then set the current_screen appropriately"""
        path = "/" + path if not path.startswith("/") else path
        self.client.push(path, dict(path=path, iframe_url=iframe_url))
        return self.showRoute(path=path, iframe_url=iframe_url, **kwargs)

    def showRoute(self, path=None, iframe_url=None, **kwargs):
        """Set current_screen appropriately (does no other navigation)"""
        path = "/" + path if not path.startswith("/") else path
        route = RouterApplication.showRoute(self, path=path, **kwargs)
        if route is None:
            return None
        return route

    def completeNavigation(self):
        self.go(
            current.session.completeNavigation["location"],
            dont_push_route=current.session.completeNavigation["dont_push_route"],
            force=True,
        )

    def go(self, location, dont_push_route=False, force=False):
        if not force and self.down("SKRoot"):
            self.session.completeNavigation = dict(location=location, dont_push_route=dont_push_route)
            if self.down("SKRoot").checkForChanges(callback=self.completeNavigation):
                return
        if location.startswith("/Admin/"):
            ll = location.split("/")
            if len(ll) == 3:
                item = getattr(sm.getRoot(), ll[-1])
                location = "/Admin/" + item.sk.id
            if self.down("SKRoot"):
                # already checked for changes if force is False
                self.down("SKRoot").navigateTo(location[7:], force=True, dont_push_route=dont_push_route)
            else:
                current.session.admin_initial_item_id = location[7:]
                if dont_push_route:
                    self.showRoute(location)
                else:
                    self.open(location)
        else:
            if dont_push_route:
                self.showRoute(location)
            else:
                self.open(location)

    def back(self):
        js.history.go(-1)

    @method
    def do_connect(self, is_reconnection, path):
        self.session.router_path_on_connection = path

        if path and path.startswith("/Admin"):
            if len(path.split("/")) >= 4:
                [item_class, item_id] = path.split("/")[2:4]
                self.session.admin_initial_item_id = f"{item_class}/{item_id}"

        self.open("/Home")

        return

    def toast(self, message, type="info"):
        self.data.toast_message = message
        self.data.toast_type = type
        self.client["$refs"]["toast"].instance.show()

    @method
    def doPopstate(self, state):
        if state:
            self.go(state["path"], dont_push_route=True)
        else:
            self.go("", dont_push_route=True)
