import time


class Cache(object):
    """
    An item cache for use with StorageManager objects

    This is not so much for performance (though it should help with that) but to keep track of local edits before they
    are saved and make those edits available to other operations in the same thread.

    In future we will set up a 0mq notification service that will publish updates to items on a pub/sub queue (the
    Cache will subscribe to this queue and handle both publishing changed objects and re-fetching cached items when
    there is a change -- every item added to the cache will require a packet to be sent over the network but Mongo
    is already doing that anyway).

    Caches stamp items in the cache with an _v_cache attribute

    TODO: add locking to ensure this is thread safe
    TODO: cache invalidation notification system using e.g. 0MQ pub-sub and possibly tailing a Mongo cursor
    """

    def __init__(self, size=10000, ttl=600.0, sweepInterval=600.0):
        self.size = size
        self.ttl = ttl
        self.sweepInterval = sweepInterval

        self.cache = dict()
        self.lastSweep = time.time()

    def add(self, item):
        if not self.size:
            return
        self.sweep()
        doc = dict(
            touched=time.time(),
            item=item,
        )
        item._v_cache = self
        self.cache[item._id] = doc

    def touch(self, id):
        self.sweep()
        if id not in self.cache:
            return
        self.cache[id]["touched"] = time.time()

    def has(self, id):
        self.sweep()
        return id in self.cache

    def get(self, id):
        self.sweep()
        return self.cache.get(id, None)["item"]

    def remove(self, id):
        self.sweep()
        if id in self.cache:
            delattr(self.cache[id]["item"], "_v_cache")
            del self.cache[id]

    def sweep(self):
        if len(self.cache) >= self.size:
            # If the cache is too big reduce it to 50% of maximum size by removing the oldest items
            items = sorted(self.cache.items(), key=lambda a: a["touched"])
            self.cache = {}
            for k, v in items:
                if len(self.cache) < self.size / 2:
                    self.cache[k] = v
                else:
                    delattr(v["item"], "_v_cache")

        if time.time() - self.lastSweep < self.sweepInterval:
            return

        for id, doc in self.cache.items():
            if (time.time() - doc["touched"]) > self.ttl:
                doc["item"]._v_cache = None
                delattr(self.cache[id]["item"], "_v_cache")
                del self.cache[id]

        self.lastSweep = time.time()


def cached(method):
    """Caching decorator for item methods taking no arguments"""

    def _cached(self):
        if not hasattr(self, "_v_methodCache"):
            self._v_methodCache = dict()

        key = method
        if key in self._v_methodCache:
            return self._v_methodCache[key]

        rc = method(self)
        self._v_methodCache[key] = rc
        return rc

    return _cached
