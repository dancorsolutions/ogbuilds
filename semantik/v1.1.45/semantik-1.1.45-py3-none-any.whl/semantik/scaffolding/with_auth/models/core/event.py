import datetime
from enum import Enum

from ..common import *

__all__ = ["Event", "Events"]


class TYPE(Enum):
    login = "login"
    forgot_password = "forgot_password"
    set_password = "set_password"
    reset_password = "reset_password"
    wrong_password = "wrong_password"
    locked_account = "locked_account"


class Events(Item):
    class sk(Semantik):
        iconClass = "fas fa-user"
        canSave = False

        class Main(types.Contents):
            showRowLines = True
            type = "Event"

            columns = [
                types.Column(caption="Date", dataField="date", width="30%"),
                types.Column(caption="User", dataField="user", encodeHtml=False),
                types.Column(caption="Type", dataField="type", width="30%"),
                types.Column(caption="Message", dataField="message", width="30%"),
            ]

            canAdd = True
            canDelete = True
            canEdit = True

        structure = Main()

        def label(self, length="medium"):
            return "Events"


class Event(Item):
    _fixed_parent = "/Events"

    TYPE = TYPE

    meta = dict(
        collection="events",
        indexes=[
            dict(fields=["user", "-date"]),
        ],
    )

    class sk(Semantik):
        checkForChanges = True

        class MainForm(types.Form):
            class user(types.SelectBox):
                readOnly = True
                formLabel = "User"
                options = types.rquery("User", label="name").filter(_actived__ne=True)
                optionsRaw = types.rquery("User", label="name")

            class date(types.Date):
                def default(self):
                    return datetime.datetime.now()

                readOnly = True
                formLabel = "Date"
                type = "datetime"
                width = "250"
                dataType = "datetime"

            class message(types.TextArea):
                readOnly = True
                formLabel = "Message"
                width = "100%"
                height = "150px"
                validate = vl.required()
                maxLength = 400

            class type(types.SelectBox):
                readOnly = True
                formLabel = "Category"
                default = "system"
                options = [dict(l=i.name, v=i.value) for i in TYPE]
                validate = vl.required()

        structure = MainForm()

    @classmethod
    def send(cls, user, type, message=None, date=None):
        o = cls(
            _parent=Events.objects().first(),
            date=date or datetime.datetime.now(),
            user=user.sk.id,
            message=message,
            type=type,
        )
        o.save()
        return o
