import typing

from roundtrip.core.basic import *
from roundtrip.component import ComponentMetaclass
from ...treestore import item

from . import types

__all__ = ["SKContents", "SKComponent", "SKItem", "SKBase", "SKContentsFragment"]


class SKTools:
    # language=Vue prefix=<div suffix=/>
    dx_validate = r"""
        @input="state._error ? delete(state._error) : null"
        @valueChanged="state._error ? delete(state._error) : null"
        :isValid="state._error ? false : true"
        :validationStatus="state._error ? 'invalid' : 'valid'"
        :validationError="state._error ? {isValid:false, message:state._error} : null"
        """

    # language=Vue prefix=<div suffix=/>
    dx_field_attributes = (
        r"""
        :name="config._typeUID"
        :class="'reset-this ' + config.cls"
        v-bind="{...config._passthroughAttrs,...state._dynamic}"
        """
        + dx_validate
    )


ComponentMetaclass.context["sk"] = SKTools()


class SKBase(Component):
    """
    Base class for compoents that aren't rendering a Seamntik type but are present in the sk type tree
    """

    imports = {"import { SemantikMixin } from 'semantik/mixin'"}
    mixins = ["SemantikMixin"]

    @property
    def skRoot(self) -> typing.ForwardRef("SKRoot"):
        if self.isProxied:
            return self.up("SKRoot")

    @property
    def context(self):
        root = self.skRoot
        if not root:
            return item.Context(session=self.session) if self.connection else None
        if not root.at:
            return item.Context(session=self.session) if self.connection else None
        return root.at.sk.makeContext(state=root.currentWindow.state)


class SKComponent(SKBase):
    """
    Base class for components used to render Semantik Types
    """

    props = ["state", "config", "itemState"]
    syncProps = dict(
        typeUID="function() { return this.$props.config._typeUID; }",
    )

    @property
    def at(self):
        """
        Return the current item
        """
        if not self.isProxied:
            return
        return self.skRoot.at

    @property
    def skType(self) -> types.ContainerType or None:
        if not self.isProxied:
            return
        uid = self.attrs.typeUID
        return types.Type._byUID[uid]

    @method
    def skGetDynamicParameter(self, name, value):
        fn = self.skType.p(name, context=self.context)
        if self.context:
            return self.context._apply(fn, **value)
        else:
            return fn(**value)

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        created=js(
            r"""
            function() {
                if(!this.config || !this.config._dynamicParameters)
                    return;
                for (const [k, v] of Object.entries(this.config._dynamicParameters)) {
                    this.$watch(
                        v.watch.bind(this), 
                        (arg) => v.remote.bind(this)(arg).then(v.complete.bind(this)),
                        {immediate: true, deep: true, flush: 'post'}
                    );
                }
            }
        """
        )
    )


class SKItem(SKBase):
    """
    A UI component rendering an item supplied via the `config`, `state`, and `itemState` properties.
    """

    loadAsync = False

    props = ["config", "state", "itemState"]

    # language=Vue
    template = r"""
    <component
        v-bind="$attrs" 
        v-if="config.display === undefined || config.display"
        :is="config._tag" 
        :config="config"
        :key="config._typeUID"
        :state="config._transparent !== false ? state : state[config._id]"
        :itemState="itemState || state"
    />
    """

    @property
    def components(self):
        """Return all Semantik type components"""
        out = set()
        for t in types.Type._byUID.values():
            if not t._tag:
                continue
            out.add(t._tag)
        return list(out)


class SKContents(SKItem):
    # language=Vue
    template = r"""
        <div v-bind="$attrs">
            <SKItem
                v-for="child of hydrateConfig(config.structure)"
                :config="child"
                :state="state"
                :itemState="itemState || state"
                :key="child._typeUID"
            />
        </div>
    """


class SKContentsFragment(SKItem):
    # language=Vue
    template = r"""
        <SKItem
            v-for="child of hydrateConfig(config.structure)"
            :config="child"
            :state="state"
            :itemState="itemState || state"
            :key="child._typeUID"
        />
    """
