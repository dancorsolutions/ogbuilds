"""
This is a version of the File type that will save a single file value (rather than a list of files of length 1)
when multiple is set to False. Multiple also defaults to False.
"""

from ..common import *
import bson
import mongoengine

from roundtrip.scaffolding.services.providers.make_token import make_token
from roundtrip.scaffolding.services import server

__all__ = ["FileUpload"]


class FileUpload(Type):
    """
    Single/multiple file upload type

    Requires the upload and file plugins to be configured on the Semantik server for this application
    """

    _tag = "SKFileUpload"
    _parameters = common_parameters.FORM_ITEM.add(
        Param("imagePreview"),
        Param(id="multiple", rtId="multiple"),
        SSParam("uploadManager", callable=True),
        SSParam("onUploaded", callable=False),
        SSParam("onUploadError", callable=False),
        SSParam("model", default=None, callable=False),
    ).addPassthroughs(dx.DxFileUploader)

    def _data(self, context):
        data = super()._data(context=context)
        if self.p.multiple:
            data[self._id]["_value"] = []
        else:
            data[self._id]["_value"] = None
        return data

    def _toState(self, storage, state, context):
        if storage is None or self._id not in storage:
            state.update(self._data(context=context))
            return
        if not storage[self._id]:
            state[self._id] = dict(_value=None)
            return
        if self.p.multiple:
            state[self._id] = dict(_value=self._fromFileList(storage[self._id]))
        else:
            state[self._id] = dict(_value=self._fromFile(storage[self._id]))

    def _toStorage(self, state, storage, context):
        if self._id not in state or not state[self._id]._value:
            if self.p.multiple:
                for i in storage[self._id]:
                    i.delete()
                storage[self._id] = None
            else:
                if storage[self._id].grid_id:
                    storage[self._id].delete()
                    storage[self._id] = None
        else:
            if self.p.multiple:
                # list of files
                value = storage[self._id]
                for index, desc in enumerate(state[self._id]._value):
                    if index >= len(value):
                        value.append(mongoengine.GridFSProxy(grid_id=bson.ObjectId(desc["grid_id"])))
                    elif str(value[index].grid_id) != desc["grid_id"]:
                        value[index] = mongoengine.GridFSProxy(grid_id=bson.ObjectId(desc["grid_id"]))
                if len(value) > len(state[self._id]._value):
                    for i in value[len(state[self._id]._value) :]:
                        i.delete()
                    del value[len(state[self._id]._value) :]
            else:
                # single file
                desc = state[self._id]._value
                if not desc:
                    storage[self._id] = mongoengine.GridFSProxy(grid_id=bson.ObjectId(desc["grid_id"]))
                elif str(storage[self._id].grid_id) != desc["grid_id"]:
                    storage[self._id].delete()
                    storage[self._id] = mongoengine.GridFSProxy(grid_id=bson.ObjectId(desc["grid_id"]))

    def _fromFileList(self, files):
        out = []
        for file in files:
            rc = self._fromFile(file)
            if rc is not None:
                out.append(rc)
        return out

    def _fromFile(self, file):
        if not file:
            return None
        if not hasattr(file, "filename"):
            # nofile GridFSProxy
            return None
        return dict(
            grid_id=str(file.grid_id),
            token=make_token(str(file.grid_id)),
            filename=file.filename,
            content_type=file.content_type,
            size=file.length,
        )

    def _getFields(self):
        if self.p.multiple:
            return {self._id: mongoengine.ListField(mongoengine.FileField())}
        else:
            return {self._id: mongoengine.FileField()}


class SKFileUpload(SKComponent):
    # language=Vue
    template = r"""
    <div 
        class="sk-file-upload"
    > 
        <dx-file-uploader
            v-if="!config.static && (config.multiple || !state._value || !state._value.length)" 
            ref="uploader"            
            select-button-text="or Select File"
            label-text="Drop file here"
            accept="*/*"
            upload-mode="instantly"
            :isValid="state._error ? false : true"
            :validationStatus="state._error ? 'invalid' : 'valid'"
            :validationError="state._error ? {isValid:false, message:state._error} : null"
            :show-file-list="true"
            :upload-url="'/upload?token=' + token"
            @uploaded="(state._error ? delete(state._error) : null) ^ didUpload({token: $event.request.responseText, name:$event.file.name})"
            @contentReady="generateToken()"
            v-bind="config._passthroughAttrs"
        />
        <div class="sk-file-list" v-if="state._value && state._value.length">
            <div 
                v-for="(file, index) of state._value"
                class="sk-file-line"
            >
                <div v-if="!config.static" class="sk-delete" @click="doDelete(index)">
                    <i class="far fa-minus-circle"></i>
                </div>
                <div class="sk-file-details" @click="window.open('/file?token=' + file.token)">
                    <div class="sk-icon"><i :class="'far ' + contentTypeToIcon(file.content_type)"></i></div>
                    <div class="sk-filename">{{ file.filename }}</div>
                    <div class="sk-size">{{ bytesToSize(file.size) }}</div>
                    <img v-if="config.imagePreview" class="sk-file-preview" :src="'/file?token=' + file.token"/>
                </div>
            </div>
        </div>
    </div>
    """

    initialData = dict(
        token=None,
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        bytesToSize=js(
            r"""
        function(bytes) {
            const sizes = ['bytes', 'kB', 'MB', 'GB', 'TB']
            if (bytes === 0) return 'n/a'
                const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10)
            if (i === 0) return `${bytes} ${sizes[i]}`
                return `${(bytes / (1024 ** i)).toFixed(1)} ${sizes[i]}`
        }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        contentTypeToIcon=js(
            r"""
        function (mimeType) {
            const iconClasses = {
                // Media
                'image': 'fa-file-image',
                'audio': 'fa-file-audio',
                'video': 'fa-file-video',
                // Documents
                'application/pdf': 'fa-file-pdf',
                'application/msword': 'fa-file-word',
                'application/vnd.ms-word': 'fa-file-word',
                'application/vnd.oasis.opendocument.text': 'fa-file-word',
                'application/vnd.openxmlformatsfficedocument.wordprocessingml': 'fa-file-word',
                'application/vnd.ms-excel': 'fa-file-excel',
                'application/vnd.openxmlformatsfficedocument.spreadsheetml': 'fa-file-excel',
                'application/vnd.oasis.opendocument.spreadsheet': 'fa-file-excel',
                'application/vnd.ms-powerpoint': 'fa-file-powerpoint',
                'application/vnd.openxmlformatsfficedocument.presentationml': 'fa-file-powerpoint',
                'application/vnd.oasis.opendocument.presentation': 'fa-file-powerpoint',
                'text/plain': 'fa-file-text',
                'text/html': 'fa-file-code',
                'application/json': 'fa-file-code',
                // Archives
                'application/gzip': 'fa-file-archive',
                'application/zip': 'fa-file-archive'
            };

            let fa = 'file';
            for (let key in iconClasses) {
                if (iconClasses.hasOwnProperty(key) && mimeType.search(key) === 0) {
                    fa = iconClasses[key];
                }
            }
            return `${fa}`;
        }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        doDelete=js(
            r"""
        function(index) {
            this.$props.state._value.splice(index,1);
        }
        """
        ),
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        window=js("""() => window"""),
        console=js("""() => console"""),
    )

    @property
    def uploadManager(self):
        um = self.skType.p("uploadManager", default=None)
        if um is None:
            return server.Server.current.getProvider("upload").upload_manager
        else:
            return um

    @method
    def generateToken(self, context):
        self.data.token = self.uploadManager.newToken(_parent=self.up("SKRoot").at, model=self.skType.p.model)

    @method
    def didUpload(self, token, name):
        um = self.uploadManager
        o = um.get(token=token)
        if not o:
            return
        # seemed to re-allocate token every time a file was uploaded which is not necessary?
        # if self.data.token == token:
        #    self.data.token = um.newToken()
        if "onUploaded" in self.skType.p:
            self.skType.p.onUploaded(component=self, file=o)
        if self.skType.p.multiple:
            js.append(self.client["$props"].state._value, self.skType._fromFileList(o.files))
        else:
            self.client["$props"].state._value = self.skType._fromFile(o.files[0])
        return
