import urllib.parse

from roundtrip.component.component import Component
from roundtrip.component.decorators import *
from roundtrip.scaffolding.services.providers.make_token import make_url
from semantik.treestore.item import StorageManager as sm

from ...core.registry import registry as r
from ..common import *
from ..shared import all as shared
from ..core import role


__all__ = ["Users", "User"]


class Users(Item):
    class sk(Semantik):
        iconClass = "fas fa-user"
        canSave = False

        class Main(types.Contents):
            showRowLines = True
            type = "User"
            showAll = True
            deleteButtonArchives = True
            hideArchived = True

            columns = [
                types.Column(caption="", dataField="is_active", width="40px", encodeHtml=False),
                types.Column(caption="Username", dataField="username", width="200px"),
                types.Column(caption="First Name", dataField="first_name", width="30%"),
                types.Column(caption="Last Name", dataField="last_name", width="30%"),
            ]
            addable = [dict(text="Add User", type="User")]

            canAdd = True
            canDelete = True
            canEdit = True

        structure = Main()

        def label(self, length="medium"):
            return "Users"


class User(Item):
    meta = dict(
        collection="users",
        indexes=[
            dict(fields=["_cls", "email"], unique=True, partialFilterExpression=dict(username={"$exists": True})),
            dict(
                default_language="en",
                language_override="en",
                fields=["$first_name", "$last_name"],
            ),
        ],
    )

    _fixed_parent = "/Users"

    class sk(Semantik):
        iconClass = "fas fa-user"
        deleteButtonArchives = True
        checkForChanges = True

        class Main(types.Tabs):
            class Details(types.Tab):
                title = "Details"

                class UserMain(types.Form):
                    defaultClass = "col-lg-6"
                    defaultLabelClass = "col-md-4"
                    defaultFieldClass = "col-md-8"

                    class first_name(types.Text):
                        formLabel = "Name (first)"
                        width = "100%"

                    class last_name(types.Text):
                        formLabel = "Name (last)"
                        width = "100%"

                    class email(types.Text):
                        formLabel = "Email"
                        width = "100%"

                    class profile_image(types.File):
                        formLabel = "Profile image"

                    class created_date(types.Date):
                        formLabel = "Date created"

                    class is_active(types.Switch):
                        formLabel = "Active?"

                    class username(types.Text):
                        formLabel = f"Username"
                        width = "100%"

                    class password(types.PasswordManager):
                        formLabel = "Password"

                    class roles(types.TagBox):
                        formLabel = "Roles"
                        options = types.oquery("Role", label="name", value="ident")

                        def validate(self, value, item):
                            if not value:
                                return "Must set at least one role"

        structure = Main()

        def label(self, length="medium"):
            return self.doc.name or super().label(length=length)

    @property
    def name(self):
        if self.first_name or self.last_name:
            return ((self.first_name or "") + " " + (self.last_name or "")).strip()
        else:
            return "New User"

    @property
    def avatar_html(self):
        if self.profile_image:
            url = make_url(self.profile_image[0].grid_id)
            return f'<img src="{url}" title="{self.name}"/>'
        else:
            initials = (self.first_name[0].upper() if self.first_name else "") + (
                self.last_name[0].upper() if self.last_name else ""
            )
            return f"<span>{initials}</span>"

    @property
    def permissions(self):
        if not hasattr(self, "_permissions"):
            self._permissions = dict()
            for r in self.roles or ["standard_associate"]:
                r = role.Role.objects(ident=r).first()
                if not r:
                    continue
                for permission in r.permissions:
                    self._permissions[permission] = True
        return self._permissions

    def can(self, permission):
        return self.permissions.get(permission, False)
