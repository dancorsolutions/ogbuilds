from ..common import *
import bson
import mongoengine
from pathlib import Path
from roundtrip.core.state import unwrap
import uuid

__all__ = ["SimpleFile"]


class SimpleFile(Type):
    """
    Single/multiple file upload type

    Requires the upload and file plugins to be configured on the Semantik server for this application
    """

    _tag = "SKSimpleFile"
    _parameters = common_parameters.FORM_ITEM.add(
        Param("imagePreview", help="Set to True to show an image preview with this control"),
        Param("readOnly", help="Set to True to disallow uploads / changes"),
        SSParam(
            "targetDirectory",
            callable=True,
            required=True,
            help="The directory on the server in which to store files uploaded through this control",
        ),
        Param("targetURL", callable=True, help="A URL that will serve files uploaded to targetDirectory"),
        SSParam(
            "onUpload",
            callable=False,
            help="A method that will be called when files have been uploaded. The method will be passed a file"
            "descriptor of the form dict(filename=..., location=..., content_type=..., size=...)",
        ),
        Param(
            "multiple",
            default=False,
            callable=False,
            help="Set to True to allow multiple uploads (this will store a list of file descriptors in the database"
            "instead of a single descriptor)",
        ),
    ).addPassthroughs(dx.DxFileUploader)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if "imagePreview" in self.p and self.p.imagePreview and not self.p.targetURL:
            raise ValueError("You must define a targetURL to use imagePreview")
        if "targetURL" in self.p and self.p.targetURL.endswith("/"):
            raise ValueError('targetURL cannot end with a "/"')

    def _data(self, context):
        data = super()._data(context=context)
        data[self._id]["_value"] = []
        return data

    def _toState(self, storage, state, context):
        if storage is None or self._id not in storage:
            state.update(self._data(context=context))
            return
        v = storage[self._id]
        if not self.p.multiple:
            v = [v]
        state[self._id] = dict(_value=v)

    def _toStorage(self, state, storage, context):
        v = state[self._id]._value
        if self.p.multiple:
            to_store = unwrap(v)
            if storage[self._id] != to_store:
                storage[self._id] = to_store if to_store is not None else []
        else:
            if v:
                to_store = unwrap(v[0])
                if storage[self._id] != to_store:
                    storage[self._id] = to_store

    def _getFields(self):
        if self.p.multiple:
            return {self._id: mongoengine.ListField(mongoengine.DynamicField())}
        else:
            return {self._id: mongoengine.DynamicField()}


class SKSimpleFile(SKComponent):
    # language=Vue
    template = r"""
    <div 
        class="sk-file-upload"
    > 
        <dx-file-uploader
            v-if="(!config.static) && (config.multiple || (!state._value.length))" 
            ref="uploader"
            select-button-text="or Select File"
            label-text="Drop file here"
            accept="*/*"
            upload-mode="instantly"
            :read-only="config.readOnly"
            :multiple="config.multiple"
            :isValid="state._error ? false : true"
            :validationStatus="state._error ? 'invalid' : 'valid'"
            :validationError="state._error ? {isValid:false, message:state._error} : null"
            :show-file-list="true"
            :upload-url="'/simple_upload?roundtripId=' + $rt.webSocketChannel.connectionId + '&cmp=' + this._uid"
            v-bind="config._passthroughAttrs"
        />
        <div class="sk-file-list" v-if="state._value && state._value.length">
            <div 
                v-for="(file, index) of state._value"
                class="sk-file-line"
            >
                <div v-if="!config.static" class="sk-delete" @click="!config.readOnly && doDelete(index)">
                    <i class="far fa-minus-circle"></i>
                </div>
                <div class="sk-file-details" @click="targetURL ? window.open(config.targetURL + '/' + file.location) : null">
                    <div class="sk-icon"><i :class="'far ' + contentTypeToIcon(file.content_type)"></i></div>
                    <div class="sk-filename">{{ file.filename }}</div>
                    <div class="sk-size">{{ bytesToSize(file.size) }}</div>
                    <img v-if="config.imagePreview" class="sk-file-preview" :src="config.targetURL + '/' + file.location"/>
                </div>
            </div>
        </div>
    </div>
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        bytesToSize=js(
            r"""
        function(bytes) {
            const sizes = ['bytes', 'kB', 'MB', 'GB', 'TB']
            if (bytes === 0) return 'n/a'
                const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10)
            if (i === 0) return `${bytes} ${sizes[i]}`
                return `${(bytes / (1024 ** i)).toFixed(1)} ${sizes[i]}`
        }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        contentTypeToIcon=js(
            r"""
        function (mimeType) {
            const iconClasses = {
                // Media
                'image': 'fa-file-image',
                'audio': 'fa-file-audio',
                'video': 'fa-file-video',
                // Documents
                'application/pdf': 'fa-file-pdf',
                'application/msword': 'fa-file-word',
                'application/vnd.ms-word': 'fa-file-word',
                'application/vnd.oasis.opendocument.text': 'fa-file-word',
                'application/vnd.openxmlformatsfficedocument.wordprocessingml': 'fa-file-word',
                'application/vnd.ms-excel': 'fa-file-excel',
                'application/vnd.openxmlformatsfficedocument.spreadsheetml': 'fa-file-excel',
                'application/vnd.oasis.opendocument.spreadsheet': 'fa-file-excel',
                'application/vnd.ms-powerpoint': 'fa-file-powerpoint',
                'application/vnd.openxmlformatsfficedocument.presentationml': 'fa-file-powerpoint',
                'application/vnd.oasis.opendocument.presentation': 'fa-file-powerpoint',
                'text/plain': 'fa-file-text',
                'text/html': 'fa-file-code',
                'application/json': 'fa-file-code',
                // Archives
                'application/gzip': 'fa-file-archive',
                'application/zip': 'fa-file-archive'
            };

            let fa = 'file';
            for (let key in iconClasses) {
                if (iconClasses.hasOwnProperty(key) && mimeType.search(key) === 0) {
                    fa = iconClasses[key];
                }
            }
            return `${fa}`;
        }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        doDelete=js(
            r"""
        function(index) {
            this.$props.state._value.splice(index,1);
        }
        """
        ),
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        window=js("""() => window"""),
        console=js("""() => console"""),
    )

    @lifecycle
    def mounted(self):
        # need a mounted lifecycle method to make sure the tree is synchronized before any uploads
        # in future: can we trigger this in a beforeUpload handler (as long as we can block for a response)
        pass

    def onUpload(self, file):
        name = str(uuid.uuid4()) + Path(file.filename).suffix
        fn = Path(self.skType.p.targetDirectory) / name
        fn.parent.mkdir(parents=True, exist_ok=True)
        with open(fn, "wb") as f:
            f.write(file.body)
        descriptor = dict(filename=file.filename, location=name, content_type=file.content_type, size=len(file.body))
        self.client["$props"].state._value.push(descriptor)
        if "onUpload" in self.skType.p:
            self.skType.p.onUpload(descriptor)
