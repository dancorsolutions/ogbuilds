import urllib.parse

from roundtrip.component.component import Component
from roundtrip.component.decorators import *
from roundtrip.scaffolding.services.providers.make_token import make_url

from ...core.registry import registry as r
from ..common import *
from ..shared import all as shared
from . import user


__all__ = ["PasswordResets", "PasswordReset"]


class PasswordResets(Item):
    class sk(Semantik):
        iconClass = "fas fa-user"
        canSave = False

        class Main(types.Contents):
            showRowLines = True
            type = "User"

            columns = [
                types.Column(caption="", dataField="is_active", width="40px", encodeHtml=False),
                types.Column(caption="Username", dataField="username", width="200px"),
                types.Column(caption="First Name", dataField="first_name", width="30%"),
                types.Column(caption="Last Name", dataField="last_name", width="30%"),
                types.Column(caption="Groups", dataField="groups", width="30%", encodeHtml=False),
            ]
            addable = [dict(text="Add User (temporary)", type="User")]

            canAdd = True
            canDelete = True
            canEdit = True

        structure = Main()

        def label(self, length="medium"):
            return "Users"


class PasswordReset(Item):
    meta = dict(
        collection="password_reset",
        indexes=[
            dict(fields=["key"]),
        ],
    )

    _fixed_parent = "/PasswordResets"

    class sk(Semantik):
        iconClass = "fas fa-user"

        class Main(types.Tabs):
            class Details(types.Tab):
                title = "Details"

                class UserMain(types.Form):
                    defaultClass = "col-lg-6"
                    defaultLabelClass = "col-md-4"
                    defaultFieldClass = "col-md-8"

                    class user(types.SelectBox):
                        formLabel = "User"
                        options = types.oquery("User", label="name", value="ident")

                    class key(types.Text):
                        formLabel = "Key"
                        width = "100%"

                    class date(types.Date):
                        dataType = "datetime"
                        type = "datetime"
                        formLabel = "Date"
                        width = "100%"

                    class expired(types.Check):
                        formLabel = "Expired"
                        default = False
                        help = "Link was expired by another event (e.g. a new link was issued)"

        structure = Main()
