from .common import *

__all__ = ["SelectList"]


#
# SelectList
#


class SelectList(BaseMayReorder):
    dataType = "str"
    nullValue = []
    _tag = "SKSelectList"
    _parameters = (
        WITH_OPTIONS.add(
            Param("width", default="100%"),
            Param("canReorder", default=False),
            RTParam("showSelectionControls", default=True),
        )
        .addPassthroughs(dx.DxList)
        .remove("optionsDynamic")
    )  # does not yet support dynamic options


class SKSelectList(OptionsComponent):
    # language=Vue
    template = r"""
    <div style="display: flex; flex-direction: row;" :id="config._id" class="sk-selectlist-container">
        <dx-list 
            :data-source="options"
            selection-mode="all"
            key-expr="v"
            v-model:selected-item-keys="state._value"
            :repaint-changes-only="true"
            style="border: 1px solid rgb(221, 221, 221); border-radius: 3px;"
            ref="dxList"
            {& sk.dx_field_attributes &}
        >
            <dx-list-item-dragging
                v-if="config.canReorder"
                :allow-reordering="config.canReorder"
                :on-reorder="on_reorder"
                handle=".dx-item.dx-list-item"
                group="{&cmp.uid&}"
            />
        </dx-list>
    </div>
    """

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        options=js("function() { return this.state._dynamic.options || this.config.options; }"),
        # language=JavaScript prefix=[ suffix=]
        console=js("() => console"),
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        on_reorder=r"""
             function(e) {
                 const visibleRows = e.component.getVisibleRows();
                 const toIndex = this.state._value.indexOf(visibleRows[e.toIndex].data);
                 const fromIndex = this.state._value.indexOf(e.itemData);
                 const newData = [...this.state._value];

                 newData.splice(fromIndex, 1);
                 newData.splice(toIndex, 0, e.itemData);
                 this.state['_value'] = newData;
             }        
         """
    )
