"""
Common base contents class used for both standard and virtual contents views
"""

from ..common import *

__all__ = ["BaseContents", "Column", "BaseContentsComponent"]


class BaseContents:
    # language=rst
    """
    Common base mixin for :class:`..contents.Contents` and :class"`..virtualcontents.VirtualContents`

    Shows a collection of :class:`Item` (or :class:`VitualItem`) objects in a data table
    """

    _parameters = Parameters(
        # Core attributes
        Param(id="id", required=True),
        Param(id="title", help="An on-scree title for the view"),
        Param(id="display", help="set to False to hide the component (usually a client-side js expression)"),
        Param(id="columns", required=True, help="List of contents Columns types"),
        # Permissions
        Param(id="canAdd", default=True, help="True to allow adding new items"),
        Param(id="canDelete", default=True, help="True to allow deleting of items"),
        Param(id="canEdit", default=True, help="True to allow editing of items"),
        # Contents add controls
        Param(id="addable", default=None, help="List of dicts of name: id for Item classes that can be added here"),
        Param(
            id="addControl",
            default="buttons",
            help="type of control to use to select which type to add" ' ("buttons", "dropdown")',
        ),
        # Delete confirmation
        Param(id="confirmDelete", default=False, help="Show a popup to confirm item deletions"),
        # Re-orderable
        Param(id="ordered", default=False, help="Allow re-ordering rows by dragging"),
        # Semantik navigation configuration
        Param(id="linked", default=False, help="False to allow editing in a separate context"),
        Param(id="target", default="_root", help="id of the window in which to open items for add/edit"),
        Param(id="popup", help="True to open items in a popup window (double click or click edit to open)"),
        # Basic styling
        RTParam(id="showRowLines", default=True, help="See dx-data-grid (defined here to add a default of True)"),
        RTParam(id="wordWrapEnabled", default=False, help="See dx-data-grid (defined here to add a default of False)"),
        RTParam(id="showBorders", default=True, help="See dx-data-grid (defined here to add a default of True)"),
        RTParam(
            id="style", default="height: 100px; flex-grow: 1;", help="See dx-data-grid (defined here to add a default)"
        ),
        # Selection handling
        Param(id="selectMode", default=False, help="See dx-data-grid (defined here to add a default of False)"),
        SSParam(id="onSelect", callable=True, help="See dx-data-grid (defined here to add a default of True)"),
        # Copy/paste handling
        Param(id="canCopy", help="True to allow (all) items in this contents to be copied"),
        SSParam(
            id="isPasteable",
            callable=True,
            help="Set to a function that gets called with a list of Semantik"
            "items and returns True if they can be pasted here",
        ),
        # Enable the column selection mechanism
        Param(id="columnChooser", help='Set to "dragAndDrop" or "select" to enable the dx-data-grid column chooser'),
        # Customized per-item actions
        Param(
            id="customActions",
            help="List of types.CustomAction objects defining custom actions that can be"
            "performed on items in this contents",
        ),
    ).addPassthroughs(dx.DxDataGrid)

    def _config(self, context, statePath=None, static=False):
        """Add column config to the standard config object"""
        out = super()._config(context=context, statePath=statePath, static=static)
        out["columns"] = [
            i._config(context, statePath=statePath, static=static) for i in self.p("columns", context=context)
        ]
        if "customActions" in self.p:
            out["customActions"] = [
                i._config(context, statePath=statePath, static=static) for i in self.p("customActions", context=context)
            ]
        return out


class Column(DatalessType):
    """
    Grid column type with support for calculated column values

    This type is used within the `Contents`, `VirtualContents` and `Grid` types to define their columns.
    """

    _tag = "DxDataGridColumn"
    _parameters = Parameters(
        SSParam("calc", callable=False),
        SSParam(
            "calcValue",
            callable=False,
            help="A function that takes the value as pulled from the underlying data element and returns a new"
            "value.",
        ),
        Param(
            "filterToQueryArg",
            callable=False,
            help="If set, the filter value will be passed to the data store's do_load as a query argument with this "
            "name",
        ),
        RTParam("allowResizing", default=True, help="See dx-data-grid (defined here to add a default of True)"),
        SSParam(
            "filterOptions",
            callable=False,
            help="A function that takes a Semantik context and returns a set of options for the filter for this "
            "field",
        ),
        SSParam(
            "buttons",
            help="A list of dicts that specify command buttons (see dx documentation). The column type must be set "
            'to "buttons" The click key can be either a callable python object which gets called when the '
            "button if pressed (will cause the row to reload after firing), or a javascript object which "
            "will simply become the click event handler. If the Python click handler returns True the grid"
            "will refresh.",
        ),
    ).addPassthroughs(dx.DxDataGridColumn)

    @property
    def _fieldId(self):
        if "dataField" not in self.p:
            raise ValueError(f"dataField required in {self!r}.{self.p!r}")
        return self.p.dataField

    def _getDataFields(self):
        if "calc" in self.p or "buttons" in self.p:
            return []
        else:
            return [self.p.dataField]

    def _compute(self, item, context):
        if "calc" in self.p:
            return self.p.calc(item, context)
        elif "calcValue" in self.p:
            return self.p.calcValue(getattr(item, self.p.dataField))
        elif "buttons" in self.p:
            return None
        elif "__" in self.p.dataField:
            v = item
            for ident in self.p.dataField.split("__"):
                if isinstance(v, dict):
                    v = v[ident]
                else:
                    v = getattr(v, ident)
                if v is None:
                    return None
            return v
        else:
            type = item.sk.getTypeByName(self.p.dataField)
            if type and getattr(type, "_toHTML") and not self.p.get("encodeHtml", True):
                return type._toHTML(getattr(item, self.p.dataField, None), context=context)
            else:
                return getattr(item, self.p.dataField)

    def _config(self, context, statePath=None, static=False):
        main = super()._config(context, statePath=statePath, static=static)
        if not "buttons" in self.p or not self.p.buttons:
            return main
        buttons = []
        for index, button in enumerate(self.p.buttons):
            handlers = dict()
            props = dict()
            for k, v in button.items():
                if k == "click":
                    if callable(v):
                        handlers["click"] = js(
                            f"(e) => this.handleButtonClick("
                            f"{{rowData: e.row.data, dataField: {self.p.dataField!r}, buttonIndex: {index}}}"
                            f").then((x) => x ? this.$refs.dataGrid.instance.refresh() : null)"
                        )
                    else:
                        handlers["click"] = v
                else:
                    props[k] = v
            if "click" not in handlers:
                raise ValueError('Grid column buttons must have a "click" key set')
            buttons.append(dict(handlers=handlers, props=props))
        main["_rest"]["buttons"] = buttons
        return main


class BaseContentsComponent(SKComponent):
    @method
    def handleButtonClick(self, dataField, buttonIndex, rowData):
        for column in self.skType.p.columns:
            if column.p.dataField == dataField:
                return column.p.buttons[buttonIndex]["click"](self, rowData)

    @method
    def handleCustomAction(self, index, selected):
        return self.skType.p.customActions[index].p.action(self, selected)
