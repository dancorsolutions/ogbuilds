"""
Basic uploaded file model to support Semantik's upload-to- / serve-from- database feature.

Note: this is not needed if you don't intend to do any uploading, or if you prefer to use SimpleUpload that uploads
to a local directory instead of the database.
"""

import uuid
import datetime

from mongoengine import *

__all__ = ["File"]


class File(Document):
    meta = dict(
        allow_inheritance=True,
        indexes=[dict(fields=["token"]), dict(fields=["uploaded"], expireAfterSeconds=60 * 60 * 4, cls=False)],
    )

    _parent = GenericReferenceField()
    will_delete = BooleanField()
    token = StringField(default=lambda: uuid.uuid4().hex)
    uploaded = DateTimeField(default=datetime.datetime.utcnow)  # must be utcnow for expiry to work correctly!
    files = ListField(FileField())
