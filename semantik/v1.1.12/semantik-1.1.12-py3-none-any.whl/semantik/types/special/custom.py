from ..common import *

__all__ = ["Custom"]


class Custom(DatalessType):
    """
    A type that can be used to render an arbitrary Roundtrip (or Vue) component within a Semantik type

    The tag name of the component should be passed in to the `component` parameter
    """

    _transparentState = True

    # class attributes
    components = []

    _tag = "SKCustom"
    _parameters = common_parameters.FORM_ITEM + Parameters(
        Param(id="component", help="The (tag) name of the Vue component to display", required=True),
        Param(id="props", callable=True, help="A dict of properties to bind to the Vue component"),
        SSParam(
            id="load",
            help="What should be loaded into item state: either a list of attributes, a dict of"
            "name_in_state -> name_in_storage, or name_in_state -> python_callable, where"
            "the callable takes (item, context) and returns the value of name_in_state",
        ),
        Param(id="display", help="True if the component should be shown (accepts JS)"),
        Param(id="isFieldContainer", help="If used on a form this will display the object as a field container"),
        Param(
            id="toState",
            help="Replace the default _toState function (which processes the load parameter) with "
            "this. It should take (storage, state, context) and mutate state in place "
            "returning nothing",
            callable=False,
        ),
        Param(
            id="toStorage",
            help="Replace the default _toStorage function (which does nothing) with this. It should "
            "take (state, storage, context) and mutate storage in place returning nothing",
            callable=False,
        ),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.components.append(self.p.component)

    def _toState(self, storage, state, context):
        if "toState" in self.p:
            if "load" in self.p:
                raise ValueError("Cannot combine load with toState in Custom types")
            return self.p.toState(storage, state, context)

        if "load" not in self.p:
            return

        if self._id not in state:
            state[self._id] = dict()

        load = self.p.load

        if isinstance(load, list) or isinstance(load, tuple) or isinstance(load, set):
            for k in load:
                if k not in state:
                    state[k] = dict()
                if hasattr(storage, k):
                    state[k]["_value"] = getattr(storage, k)
                elif k in storage:
                    state[k]["_value"] = storage[k]
        elif isinstance(load, dict):
            for k, v in load.items():
                if isinstance(v, str):
                    if k not in state:
                        state[k] = dict()
                    if k in storage:
                        state[k]["_value"] = storage[k]
                    elif hasattr(storage, k):
                        state[k]["_value"] = getattr(storage, k)
                elif callable(v):
                    if k not in state:
                        state[k] = dict()
                    state[k]["_value"] = v(storage, state, context)
                else:
                    raise ValueError(
                        "load dicts on custom fields must map state id -> either a storage id or a " "callable"
                    )
        else:
            raise ValueError(
                "load parameter on custom fields must be a list/tuple/set or a dict of state id -> "
                "storage id or state id -> function(storage, state, context) which returns the value"
            )

    def _toStorage(self, state, storage, context):
        if "toStorage" in self.p:
            return self.p.toStorage(state, storage, context)


class SKCustom(SKComponent):
    # language=Vue
    template = r"""
    <component
        :is="config.component"
        :config="config"
        :key="config._typeUID"
        :state="state[config._id]"
        :itemState="itemState"
        v-bind="config.props"
    />
    """

    @property
    def components(self):
        return Custom.components
