import datetime

from ..common import *
from ....core.i18n import _
from . import profile_structure
from roundtrip.scaffolding.services import server

__all__ = ["Profile"]

screens = ["Profile"]


class Profile(Screen):
    imports = {"import { SemantikMixin } from 'semantik/mixin'"}
    mixins = ["SemantikMixin"]

    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <IGPageTwoCols root_class="ig-screen-profile">
    
        <template #left>

            <div class="ig-left-page-header">
                {& _('Account Details') &}
            </div>
            
            <div class="ig-profile">

                <div 
                    v-if="user_avatar_html" 
                    class="ig-avatar --standalone" 
                    v-html="user_avatar_html"
                />

                <dx-file-uploader
                    ref="uploader"            
                    select-button-text="or Select File"
                    label-text="Drop file here"
                    accept="*/*"
                    upload-mode="instantly"
                    :upload-url="'/upload?token=' + token"
                    @uploaded="did_upload({token: $event.request.responseText, name:$event.file.name})"
                />
                               
                <div class="ig-profile-body">
                    <SKItem
                        :state="state"
                        :config="hydrateConfig(config)"
                        :itemState="state"
                    />
                </div>
                
                <div class="ig-profile-footer ig-form-footer">
                    <button class="--cancel" @click="do_cancel()">CANCEL</button>
                    <button class="--confirm" @click="do_save()">SAVE</button>
                </div>
            </div>                        

        </template>
        
        <template #right>
            <IGRightActionItems title="Your Account">
                <IGRightActionItem
                    title="Logout"
                    icon="fa-light fa-arrow-right-from-bracket"
                    :action="true"
                    @click="do_logout()"
                >
                </IGRightActionItem>          
            </IGRightActionItems>
        </template>
    </IGPageTwoCols>
    """

    structure = profile_structure.structure

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        doLater=js(
            r"""
        function(k) {
            setTimeout(this[k], 100);
        }"""
        )
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        console=js(r"""() => console""")
    )

    load = set()

    def initialData(self):
        return dict(
            state=dict(**self.structure._data(context=None)),
            error=None,
            error_message=None,
            user_avatar_html=None,
            token=None,
        )

    @property
    def props(self):
        return dict(
            config=dict(default=self.structure._configDefault(context=None)),
        )

    @lifecycle
    def mounted(self):
        if not current.user:
            return
        emp = current.user
        context = emp.sk.makeContext(state=self.data.state)
        self.structure._toState(current.user, self.data.state, context=context)
        self.data.user_avatar_html = current.user.avatar_html
        for k in self.load:
            self.data.state[k] = dict(_value=emp[k])
        self.data.token = server.Server.current.getProvider("upload").upload_manager.newToken(
            _parent=current.user, model=None
        )

    @method
    def do_save(self, ignore=False):
        emp = current.user
        context = emp.sk.makeContext(state=self.data.state)

        self.structure._toStorage(self.data.state, emp, context=context)
        errors = self.structure._validate(self.data.state, context=context)
        if errors and not ignore:
            self.data.error = "Correct errors before continuing"
            return errors

        emp.save()
        self.app.toast("Profile updated", type="success")
        self.app.back()
        return None

    @method
    def do_cancel(self):
        self.app.back()

    @method
    def do_logout(self):
        self.app.logout()

    @method
    def later(self):
        if not self.do_save(ignore=True):
            self.app.open("LearningHome")

    @method
    def did_upload(self, token, name):
        um = server.Server.current.getProvider("upload").upload_manager
        o = um.get(token=token)
        if not o:
            return
        current.user.profile_image = o.files
        current.user.save()
        self.data.user_avatar_html = current.user.avatar_html
        self.app.data.avatar_html = self.data.user_avatar_html
