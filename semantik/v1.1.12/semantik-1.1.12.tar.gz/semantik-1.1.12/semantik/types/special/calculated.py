"""
A type that calculates a value which is stored in state but never stored in / loaded from storage
"""

from ..common import *

__all__ = ["Calculated"]


class Calculated(Type):
    _tag = "SKCalculated"
    _parameters = common_parameters.FORM_ITEM.add(
        SSParam(id="calc", callable=True),
    )

    def _data(self, context):
        return {self._id: self.p("calc", context=context)}

    def _toState(self, storage, state, context):
        state[self._id] = self.p("calc", context=context)

    def _toStorage(self, state, storage, context):
        pass

    def _validate(self, subState, context):
        return None


class SKCalculated(SKComponent):
    # language=Vue
    template = r"""<transition></transition>"""
