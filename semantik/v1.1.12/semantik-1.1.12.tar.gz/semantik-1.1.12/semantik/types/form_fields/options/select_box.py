from .common import *
from html import escape

__all__ = ["SelectBox"]


#
# SelectBox
#


class SelectBox(OptionsField):
    dataType = "str"
    _tag = "SKSelectBox"
    _parameters = WITH_OPTIONS.addPassthroughs(dx.DxSelectBox)

    def _toHTML(self, value, context=None):
        if not value:
            return ""
        if "optionsRaw" in self.p:
            options = self.p("optionsRaw", context=context)
        else:
            options = self.p("options", context=context)
        ld = {i["v"]: i["l"] for i in self._getOptions(options, context=context)}
        out = f"""
        <span class="badge bg-light text-dark" style="font-weight: normal; font-size: 90%">
            {escape(ld.get(value, value) if value else '-')}
        </span>
        """
        return out


class SKSelectBox(OptionsComponent):
    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        {{ state._options.filter((x) => x.v == state._value).length ? state._options.filter((x) => x.v == state._value)[0].l : '-' }}
    </div>
    <dx-select-box 
        v-else 
        @customItemCreating="create_custom_item"
        :data-source="state._dynamic.options || config.options"
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        create_custom_item="""
        function(args) {
            const new_value = args.text;
            const options = this.state._dynamic.options || this.config.options;
            if(!options.some((item) => item.v === new_value)) {
                if(this.state._dynamic.options)
                    this.state._dynamic.options = [{l: new_value, v: new_value}].concat(options);
                else
                    this.config.options = [{l: new_value, v: new_value}].concat(options);
                debugger;
                this.doAddValue(new_value);
            }
            args.customItem = {v:new_value, l:new_value};
         }
         """,
    )

    @method
    def doAddValue(self, value):
        self.skType.p.addValue(value)
