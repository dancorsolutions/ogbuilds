import typing

import mongoengine

from roundtrip.core.classproperty import classproperty
from roundtrip.component.component import pascalToKebab
from roundtrip.server import connection
from roundtrip.core.javascript import js
from bson import ObjectId
from . import item


class Semantik:
    item = None  #: the Item
    color = None  #: css (background) color if this item should have a distinctive color

    name = None
    namedChildren = None  #: specifies a set of fixed children with set names which are always present
    # dict of child id -> child item type NAME
    typeName = None  #: canonical name of this type (defaults to item class name if not supplied)
    structure = None  #: type hierarchy that specifies the internal structure of the item
    additionalState: set | dict[str, str | typing.Callable] | typing.Callable = None  #: Tells Semantik to load
    # additional form_fields into the item view state, can be a set of field names,
    # a dict of target name -> source name, or target name -> callable where the callable is of the form
    # f(storage, context) and returns the value. Alternatively you can supply a single callable that takes
    # (storage, state, context) and can mutate state directly in place

    #
    # Settings
    #
    hasActions = True
    canSave = True
    canSaveClose = True
    canDelete = False
    deleteButtonArchives = False
    canCancel = True
    navigable = True  #: True to allow users to navigate to this object via the path bar
    ignoreLeadingBreadcrumbs = 0
    checkForChanges = False  #: True to check for changes and warn the user before cancelling or navigating
    # away from this item and warn the user
    childType = None  #: String with the name of an item class to be used to find children of this type
    # not used by conntents automatically -> these have to explicity be given a type

    popupOnAdd = None  #: set to the name of a component that will be displayed when this item is saved (on add)
    popupOnSave = None  #: set to the name of a component that will be displayed when this item is saved
    # (on save)
    popupOnSaveChanged = None  #: set to the name of a component that will be displayed when this item is saved and
    # updated (on update)
    popupOnDelete = None  #: set to the name of a component that will be displayed when this item is deleted
    popupOnArchive = None  #: set to the name of a component that will be displayed when this item is archived
    customActions = None  #: a list of CustomAction objects representing custom buttons to be added to the screen
    labelSource = None  #: a string with the name of an attribute on the item from which to take the label (saves
    #: having to create a def label(...) function

    def __init__(self, document: typing.ForwardRef("Item")):
        self.doc = document

    #
    # Class properties
    #
    @classproperty
    def ident(cls):
        """the canonical name for this item type (typeName or the class name of the item if that's not specified)"""
        return cls.typeName or cls.item.__name__

    @classproperty
    def root(cls):
        """the root item in the storage"""
        return item.StorageManager.getRoot()

    @classproperty
    def sm(cls):
        """the storage manager"""
        return item.StorageManager

    def _toState(self, storage, state, context):
        self.structure._toState(storage, state, context)

        if not self.additionalState:
            return

        if isinstance(self.additionalState, set):
            for k in self.additionalState:
                state[k] = getattr(storage, k, None)
        elif isinstance(self.additionalState, dict):
            for k, v in self.additionalState.items():
                if isinstance(v, str):
                    state[k] = getattr(storage, v, None)
                if callable(v):
                    state[k] = v(storage, context)
                else:
                    raise ValueError("additionalState dict must be str->str or str->callable")
        elif callable(self.additionalState):
            self.additionalState(storage, state, context)
        else:
            raise ValueError("additionalState must be set, dict or callable")

    #
    # Events
    #
    @classmethod
    def onPostInit(cls, sender, document):
        """
        Ensure we have all named children and that they're saved when we instantiate
        """
        toSave = False
        if not getattr(document, "id", None):
            document.id = ObjectId()
        if cls.namedChildren:
            for k, v in cls.namedChildren.items():
                if document[k] is None:
                    type = item.StorageManager.getItemType(v)
                    if type is None:
                        raise ValueError(f"Unknown named child type {v!r}")
                    child = type(_parent=document)
                    child.save()
                    setattr(document, k, child)
                    toSave = True
            if toSave:
                document.save()

    #
    # Item descriptor
    #
    def descriptor(self):
        """
        Generate item descriptor
        :return: item descriptor object to pass client-side
        """
        descriptor = dict()
        descriptor["type"] = self.ident
        descriptor["id"] = self.id
        descriptor["headerLabel"] = self.headerLabel
        descriptor["icon"] = self.iconClass
        descriptor["color"] = self.color
        descriptor["canSave"] = self.canSave
        descriptor["canSaveClose"] = self.canSaveClose
        descriptor["canDelete"] = self.canDelete
        descriptor["canCancel"] = self.canCancel
        descriptor["deleteButtonArchives"] = self.deleteButtonArchives
        descriptor["hasActions"] = (
            descriptor["canSave"]
            or descriptor["canSaveClose"]
            or descriptor["canDelete"]
            or descriptor["canCancel"]
            or descriptor["customActions"]
        ) and self.hasActions
        descriptor["path"] = [
            dict(label=i.sk._label_short, id=i.sk.id, navigable=i.sk.navigable) for i in self.breadcrumb_path
        ]
        if descriptor["path"]:
            descriptor["path"][-1]["active"] = True
        return descriptor

    #
    # Identity and navigation
    #
    @classmethod
    def fetch(cls, skId):
        classIdent, id = skId.split("/")
        return item.StorageManager.getItem(classIdent).with_id(ObjectId(id))

    @property
    def _virtual(self):
        return isinstance(self.doc, item.VirtualItem)

    @property
    def session(self):
        if not connection.Connection.current:
            return None
        return connection.Connection.current.session

    @property
    def parent(self):
        parent = None
        try:
            parent = self.doc._parent
        except mongoengine.errors.DoesNotExist:
            if self.doc._fixed_parent:
                self.doc._parent = self.traverse(self.doc._fixed_parent)
                parent = self.doc._parent

        if not parent:
            return None
        return parent.sk

    @property
    def path(self):
        if self._virtual:
            return []
        at = self
        path = []
        while 1:
            path.insert(0, at.doc)
            at = at.parent
            if not at:
                break
        return path

    @property
    def breadcrumb_path(self):
        return self.path[self.ignoreLeadingBreadcrumbs :]

    @property
    def id(self):
        return self.ident + "/" + str(self.doc.id)

    @property
    def pathString(self) -> str:
        return "/" + ("/".join([str(i.sk.id) for i in self.path]))

    @property
    def children(self):
        childType = item.StorageManager.getItemType(self.childType) if self.childType else item.Item
        return childType.objects(_parent=self.doc)

    @property
    def hasChildren(self) -> bool:
        return item.Item.objects(_parent=self.doc).limit(1).count(True) > 0

    def traverse(self, path):
        """Traverse through NAMED children"""
        path = path.split("/")
        at = self
        while path:
            head = path.pop(0)
            if not head:
                at = self.root
                continue
            elif head == ".":
                continue
            else:
                at = getattr(at, head)
        return at

    #
    # Labels, icons and tree behavior
    #
    iconClass = None
    treeExpandable = False

    @property
    def treeLabel(self):
        """A label suitable for use as tree item text"""
        return self._label_short

    @property
    def headerLabel(self):
        """A label suitable for use as a page header"""
        return self._label_long

    @property
    def breadcrumbLabel(self):
        """A label suitable for use as a breadcrumb"""
        return self._label_short

    @property
    def _label_short(self):
        return self._label("short")

    @property
    def _label_long(self):
        return self._label("long")

    def _label(self, length="short"):
        user_label = getattr(self, "label", None)
        if callable(user_label):
            return user_label(length)
        elif user_label:
            return user_label

        ident = getattr(self.doc, "ident", "")
        name = self.doc.name if isinstance(getattr(self.doc, "name", None), str) else ""
        className = getattr(self, "typeName", "") or self.item.__name__
        className = pascalToKebab(className).replace("-", " ")

        if self.labelSource:
            return getattr(self, self.labelSource, className)

        names = []

        if className and name:
            names.append("%s: %s" % (className, name))

        names += [
            name,
            ident,
            className,
        ]

        if className and ident:
            names.append("%s: %s" % (className, ident))

        match length:
            case "short":
                return ([i for i in names if i and len(i) < 20] or [className])[0]
            case "medium":
                return ([i for i in names if i and len(i) < 40] or [className])[0]
            case "long":
                return [i for i in names if i][0]
            case _:
                raise ValueError('Label length must be "short", "long" or "medium')

    #
    # Other methods
    #
    def makeContext(self, state):
        """
        Create a context object with parameters to be passed to any calculated parameters that ask for them

        :param item: the current Item
        :return: dictionary of id -> item
        """
        return item.Context(item=self.doc, state=state, itemState=state, session=connection.Connection.current.session)

    def checkDelete(self, root):
        """
        Called before an item is to be deleted to ensure this is a valid action

        :return: True if the item should not be deleted
        """
        return None

    def checkEdit(self, root):
        """
        Called before an item is to be edited to ensure this is a valid action

        :return: True if the item should not be deleted
        """
        return None

    def getTypeByName(self, name):
        """
        Find the first matching descendant of this type that match the given type name

        :return: the matching type or None
        """
        for type in [self.structure] + self.structure._descendants:
            if type.__class__.__name__ == name:
                return type
        return None
