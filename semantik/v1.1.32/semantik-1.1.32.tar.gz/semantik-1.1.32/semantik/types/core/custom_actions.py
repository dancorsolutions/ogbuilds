from roundtrip.core.javascript import js
from roundtrip.component.decorators import *
from roundtrip.component import Component, External
from dxrt.components import all as dx

from .components import SKBase, SKComponent
from .types import Type, ContainerType, DatalessType
from .errors import TypesError
from .parameters import Parameters, Param, SSParam, RTParam
from . import common_parameters

__all__ = ["CustomAction"]


class CustomAction(DatalessType):
    """
    Represents a user-defined action that can be executed in a contents list (on multiple actions) or in an item view
    (on a single item)
    """

    _tag = "SKCustomActionButton"
    _parameters = Parameters(
        SSParam("action", callable=False),
        Param("display", default=True),
        Param("popup", callable=False),
        Param("onlyWhenSelected", default=True),
        Param("cls", default="info"),
        Param("text"),
    ).addPassthroughs(dx.DxButton)

    _components = []

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        popup = self.p.get("popup", None)
        if popup:
            self._components.append(popup)


class SKCustomActionButton(SKComponent):
    _transparent = True

    # language=Vue
    template = r"""
    <span class="sk-custom-action-container" v-if="config.display">
        <component
            v-if="config.popup"
            :is="config.popup"
            :config="config"
            :state="state"
            :itemState="itemState"
            ref="popup"
        />
        <button
            v-if="config.popup"
            @click="$refs.popup.show()"
            :name="config._typeUID"
            :class="config.cls"
            v-bind="config._passthroughAttrs"
        >{{ config.text }}</button>
        <button
            v-else
            @click="(e) => $emit('action', e)"
            :name="config._typeUID"
            :class="config.cls"
            v-bind="config._passthroughAttrs"
        >{{ config.text }}</button>
    </span>
    """

    @property
    def components(self):
        return CustomAction._components
