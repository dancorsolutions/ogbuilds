"""
Requires: vue3-ace-editor
"""

from semantik.types.common import *
from semantik.types.form_fields.base import SimpleField

__all__ = ["AceEditor"]


class VAceEditor(External):
    imports = {
        "import ace from 'ace-builds/src-min-noconflict/ace'",
        "import resolver from 'ace-builds/webpack-resolver'",
        "import language_tools from 'ace-builds/src-min-noconflict/ext-language_tools.js'",
        "import { VAceEditor } from 'vue3-ace-editor'",
    }

    attrs = []


class AceEditor(SimpleField):
    _tag = "SKAceEditor"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(VAceEditor)
    _nullValue = ""
    dataType = "str"


class SKAceEditorSKCodeMirror(SKComponent):
    # language=Vue
    template = r"""
        <VAceEditor
            :id="config._typeUID"
            v-model:value="state._value"
            v-bind="config._passthroughAttrs"
        ></VAceEditor>
    """
