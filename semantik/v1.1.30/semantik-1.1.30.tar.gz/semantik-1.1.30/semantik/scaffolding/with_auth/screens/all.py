from . import admin
from .login import all as login

screens = admin.screens + login.screens
