from semantik.treestore.item import StorageManager as sm
from semantik.views.admin import BaseAdminRoot
from semantik.scaffolding.current import current
from roundtrip.component.decorators import *
from ...models import all as m

screens = ["Admin"]


class Admin(BaseAdminRoot):
    imports = BaseAdminRoot.imports | {
        "import 'devextreme/dist/css/dx.common.css'",
        "import 'devextreme/dist/css/dx.light.css'",
    }

    app: ["##MYAPP##.web.application.Application"]

    all_models = m
