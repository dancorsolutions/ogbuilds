from ..common import *

__all__ = ["Dynamic"]


class Dynamic(Type):

    """
    A component that renders a specified Semantik type on the screen

    This component does not handle any data storage or retrieval for the type
    """

    # class attributes
    components = []

    _tag = "SKDynamicContents"
    _parameters = Parameters(
        Param(id="structure"),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _toState(self, storage, state, context):
        if self._id not in state:
            state[self._id] = dict()

        state[self._id]["_config"] = self._config(context=context)


class SKDynamic(SKComponent):
    initialData = dict(dynamic_config={})

    # language=Vue
    template = r"""
        <SKItem
            v-for="child of hydrateConfig(dynamic_config.structure)"
            :config="child"
            :state="state"
            :itemState="itemState || state"
            :key="child._typeUID"
        />
    """

    def setConfig(self, config):
        self.data.config = config
