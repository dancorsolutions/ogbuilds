from ...core.i18n import _
import re

from .callable import Call

__all__ = ["required", "email", "length", "between", "answered", "identifier"]


class ValidationRules(Call):
    def __init__(self, *args):
        self.rules = []
        for arg in args:
            if isinstance(arg, ValidationRules):
                self.rules += arg.rules
            elif isinstance(arg, ValidationRule):
                self.rules.append(arg)
            else:
                raise ValueError("Must be ValidationRule(s)")

    def __call__(self, context):
        for rule in self.rules:
            out = context._apply(rule)
            if out:
                return out
        return None

    def __add__(self, other):
        return ValidationRules(self, other)


class ValidationRule(Call):
    message = _("Invalid")

    def __init__(self, message=None):
        if message:
            self.message = message

    def __add__(self, other):
        return ValidationRules(self, other)

    def __call__(self, value):
        raise ValueError("Virtual")


class required(ValidationRule):
    message = _("A value is required")

    def __call__(self, value):
        return None if value else self.message


class answered(ValidationRule):
    message = _("A value is required")

    def __call__(self, value):
        return self.message if value is None else None


class email(ValidationRule):
    pattern = re.compile(r"^(.*?|)?([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$)", re.IGNORECASE)

    message = _("Must be a valid email")

    def __call__(self, value):
        v = value
        if not v:
            return None
        if self.pattern.match(v):
            return None
        return self.message


class identifier(ValidationRule):
    message = _("Must be a valid identifier (letters/numbers/underscores, no spaces, starts with a letter/_)")

    def __call__(self, value):
        if value and not value.isidentifier():
            return self.message


class length(ValidationRule):
    message = None

    def __init__(self, max=None, min=None, trim=True, message=None):
        super().__init__(message=message)
        self.max = max
        self.min = min
        self.trim = trim

    def __call__(self, value):
        if value is None:
            return
        v = value
        if self.trim:
            v = v.strip()
        ln = len(v)
        if self.min is not None and ln < self.min:
            if self.message:
                return self.message
            return _("Must be at least %d characters") % self.min
        if self.max is not None and ln > self.max:
            if self.message:
                return self.message
            return _("Must be at less than %d characters") % self.max


class between(ValidationRule):
    message = None

    def __init__(self, min=None, max=None, message=None):
        super().__init__(message=message)
        self.max = max
        self.min = min

    def __call__(self, value):
        v = value
        if v is None:
            return
        if self.min is not None and v < self.min:
            if self.message:
                return self.message
            return _("Must be > %s") % self.min
        if self.max is not None and v > self.max:
            if self.message:
                return self.message
            return _("Must be < %s") % self.max


class goodPassword(ValidationRule):
    message = None

    def __call__(self, value):
        v = value
        if len(v) < 7:
            return _("Must be at least 7 characters")
        if not re.search(r"[a-z]", v):
            return _("Must have at least one lowercase letter")
        if not re.search(r"[A-Z]", v):
            return _("Must have at least one uppercase letter")
        if not re.search(r"[0-9]|(\~`!@#\$%\^&*\(\)\_\+\-\=\[\]\{\}\|\;\'\:\"\,\.\/\<\>\?)", v):
            return _("Must have at least one number or symbol")
