from ..common import *

__all__ = ["Hidden"]


class Hidden(Type):
    """
    A type that doesn't show a control on screen but DOES save/load a field to the database
    """

    _tag = None
    _parameters = Parameters(
        Param(id="id", required=True),
        Param(id="fieldType"),
    )

    def _getFields(self):
        if self.p("fieldType", default=None):
            return {self._id: self.p.fieldType}
        else:
            return {}
