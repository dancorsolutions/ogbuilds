from roundtrip.component import *
from roundtrip.core.javascript import js
from roundtrip.server.connection import Connection
from roundtrip.scaffolding.config.config import config
from ...base.current import current

screens = ["Navigation"]


class BaseNavigation(Component):
    imports = {"import { Sidebar } from '@coreui/coreui-pro'"}

    NAVIGATION_ITEMS = []

    # language=Vue prefix=<template> suffix=</template>
    template = r"""
    <div 
        class="sidebar sidebar-fixed" 
        ref="sidebar"
    >        
        <div class="ig-navigation-profile">
            <div class="ig-avatar-container">
                <div class="ig-avatar">
                    <div v-html="avatar_html"></div>                
                </div>
                <div class="ig-avatar-name">{{user_name}}</div>
                <div class="ig-avatar-location">{{user_location}}</div>
            </div>
            <div class="-buttons">
                <i :class="{'fa-regular': true, 'fa-gear': true, 'active': current==='Profile'}" @click="do_profile()"/>
            </div>
        </div>
        <hr/>
        <ul class="sidebar-nav">
                        
            <template
                v-for="item in navigation_items" 
                :key="item.label"
            >   
            <li :class="{'nav-group': true, 'show': show_expanded(current, item)}">
                <a 
                    class="nav-link nav-group-toggle" 
                    href="#" 
                    @click.prevent="is_expanded[item.label] = is_expanded[item.label] ? false : true">
                    <i :class="item.icon" v-if="item.icon"/> &nbsp; <span>{{item.label}}</span>
                </a>
            
                <ul class="nav-group-items" style="height: auto;">
                    <template
                        v-for="sub_item in item.sub_items"
                    >
                        <li 
                            class="nav-item" 
                            :key="sub_item.label"
                            v-if="!sub_item.permission || permissions[sub_item.permission]" 
                        >
                            <span
                                :class="{
                                    'nav-link': true, 
                                    'ig-nav-l2': true, 
                                    'active': current.startsWith(sub_item.path) || 
                                              (sub_item.matches && sub_item.matches.some((x) => current.startsWith(x)))
                                }" 
                                @click="go(sub_item.path)"
                            >
                                <i :class="sub_item.icon" v-if="sub_item.icon"/> &nbsp;
                                {{sub_item.label}}
                            </span>
                        </li>
                    </template>                
                </ul>
            </li>
            </template>

            <li 
                class="nav-item mv-nav-item-standalone" 
                v-if="permissions.admin && !view_state.phone"
            >
                <span
                    :class="{'nav-link': true, 'active': current==='/Profiler'}" 
                >
                    <i class="fa-solid fa-ruler-triangle" v-if="profiler_on" @click="toggle_profiler()"/>
                    <i class="fa-light fa-ruler-triangle" v-else @click="toggle_profiler()"/>
                    <span @click="() => (current='/Profiler') && go('/Profiler')">Profiler</span>
                </span>
            </li>
            <li class="nav-item mv-nav-item-standalone">
                <span
                    class="nav-link" 
                    @click="do_logout()"
                >
                    <i class="fa-light fa-sign-out"/>
                    <span>Logout</span>
                </span>
            </li>
        </ul>
        <div class="-version-name" v-if="version_name">
            {{ version_name }}
        </div>
        <div class="-commit-id" v-if="commit_id">
            {{ commit_id }}
        </div>
        <div class="-branding"></div>
        <button 
            class="sidebar-toggler" 
            type="button" 
            @click="this.sidebar.hide(); this.$emit('update:fold_sidebar', true)"
        />
    </div>
    """

    props = ["fold_sidebar", "current", "avatar_html"]

    initialData = dict(
        profiler_on=False,
        user_name="",
        user_location="",
        is_expanded={},
        navigation_items=NAVIGATION_ITEMS,
        version_name="",
        commit_id="",
    )

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        hide_sidebar=js(
            """
            function() {
                if(window.innerWidth <= 768) {
                    this.sidebar.hide();
                    this.$emit('update:fold_sidebar', true);
                }
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        show_sidebar=js(
            """
            function() {
                this.sidebar.show();
                this.$emit('update:fold_sidebar', false);
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        show_expanded=js(
            """
        function(current, item) {
            if(this.is_expanded[item.label])
                return true;
            for(let i of this.navigation_items) {
                if(i.label === item.label)
                    for(let j of i.sub_items) {
                        if(
                            current.startsWith(j.path) || 
                            (j.matches && j.matches.some((x) => current.startsWith(x)))
                        ) {
                            this.is_expanded[item.label] = true;
                            return true;
                        }
                    }
            }
        }
        """
        ),
    )

    inject = ["view_state", "permissions"]

    @lifecycle
    def created(self):
        if Connection.current.PROFILE_CACHE_SIZE:
            self.data.profiler_on = True
        else:
            self.data.profiler_on = False
        e = current.session.user
        self.data.user_name = e.first_name
        self.data.user_location = ""
        if config.debug_level:
            self.data.version_name = config.stats.get("build_tag", None)
            self.data.commit_id = config.stats.get("commit_id", None)

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        mounted=js(
            """
        function() {
            if(this.sidebar) {
                return;
            }
            this.sidebar = new Sidebar(this.$refs.sidebar);
        }
        """
        )
    )

    @method
    def toggle_profiler(self):
        if Connection.current.PROFILE_CACHE_SIZE:
            Connection.current.PROFILE_CACHE_SIZE = None
            self.data.profiler_on = False
        else:
            Connection.current.PROFILE_CACHE_SIZE = 100
            self.data.profiler_on = True

    @method
    def do_profile(self):
        self.app.open("Profile")
        self.client.hide_sidebar()

    @method
    @cancelable
    def go(self, location):
        # ensure this is a valid location
        valid = False
        if location in ("Profiler", "/Profiler"):
            self.app.go("/Profiler")
        else:
            for i in self.NAVIGATION_ITEMS:
                for j in i["sub_items"]:
                    if location.startswith(j["path"]):
                        if j["permission"] in current.user.permissions:
                            valid = True
                            self.data.is_expanded[i["label"]] = True
                            break
                        else:
                            raise RuntimeError(f"Invalid permissions for user {current.user.username} -> {location}")
                if valid:
                    break
            if not valid:
                raise SystemError(f"Invalid navigation location {location}")
        self.app.go(location)
        self.client.hide_sidebar()

    @method
    def do_logout(self):
        self.app.logout()
