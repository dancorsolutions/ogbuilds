import datetime
import mongoengine
from semantik.treestore.item import StorageManager, Item

from semantik.types.common import *

__all__ = ["SimpleField", "MongoSimpleFieldMixin"]


#
# Legacy SimpleField base class (being replaced with MyField(GenericXXX, MongoSimpleField):
#
class SimpleField(Type):
    _nullValue = None

    def _data(self, context):
        data = Type._data(self, context=context)
        data[self._id]["_value"] = self.p("default", default=self._nullValue, context=context)
        return data

    def _getFields(self):
        if "dataType" in self.p:
            dT = self.p.dataType
        else:
            dT = None

        if isinstance(dT, mongoengine.fields.BaseField):
            field = dT
        elif dT == "str":
            field = mongoengine.StringField()
        elif dT == "int":
            field = mongoengine.IntField()
        elif dT == "float":
            field = mongoengine.FloatField()
        elif dT == "decimal":
            field = mongoengine.DecimalField()
        elif dT == "date":
            field = mongoengine.DateField()
        elif dT == "datetime":
            field = mongoengine.DateTimeField()
        elif dT == "bool":
            field = mongoengine.BooleanField()
        elif dT == "reference":
            field = mongoengine.GenericReferenceField()
        elif dT.startswith("reference:"):
            field = mongoengine.ReferenceField(dT.split(":")[-1])
        elif dT == "object":
            field = mongoengine.DynamicField()
        elif dT is None:
            field = mongoengine.StringField()
        else:
            raise ValueError("Invalid dataType %r" % dT)
        return {self._id: field}

    def _valueToStorage(self, value):
        if "dataType" in self.p:
            dT = self.p.dataType
        else:
            dT = None

        if (
            dT.startswith("reference:") or dT == "reference" or (isinstance(dT, type) and issubclass(dT, Item))
        ) and value is not None:
            value = StorageManager.getItem(value)
        if dT == "date":
            if isinstance(value, datetime.datetime):
                value = value.date()

        return super()._valueToStorage(value)

    def _valueToState(self, value):
        if "dataType" in self.p:
            dT = self.p.dataType
        else:
            dT = None

        if (
            dT.startswith("reference:") or dT == "reference" or (isinstance(dT, type) and issubclass(dT, Item))
        ) and value is not None:
            value = value.sk.id
        elif dT == "date" and value is not None:
            if isinstance(value, datetime.datetime):
                value = datetime.datetime(value.year, value.month, value.day, 12, 0, 0, 0, datetime.UTC)
        elif dT == "datetime" and value is not None:
            if isinstance(value, datetime.datetime):
                if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
                    value = value.replace(tzinfo=datetime.UTC)

        return super()._valueToState(value)


class MongoSimpleFieldMixin:
    def _getFields(self):
        dT = self.p.get("dataType", None)

        if isinstance(dT, mongoengine.fields.BaseField):
            field = dT
        elif dT == "str":
            field = mongoengine.StringField()
        elif dT == "int":
            field = mongoengine.IntField()
        elif dT == "float":
            field = mongoengine.FloatField()
        elif dT == "decimal":
            field = mongoengine.DecimalField()
        elif dT == "date":
            field = mongoengine.DateField()
        elif dT == "datetime":
            field = mongoengine.DateTimeField()
        elif dT == "bool":
            field = mongoengine.BooleanField()
        elif dT == "reference":
            field = mongoengine.GenericReferenceField()
        elif dT.startswith("reference:"):
            field = mongoengine.ReferenceField(dT.split(":")[-1])
        elif dT == "object":
            field = mongoengine.DynamicField()
        elif dT is None:
            field = mongoengine.StringField()
        else:
            raise ValueError("Invalid dataType %r" % dT)
        return {self._id: field}

    def _valueToStorage(self, value):
        value = super()._valueToState(value)
        dT = self.p.get("dataType", None)

        if (
            dT.startswith("reference:") or dT == "reference" or (isinstance(dT, type) and issubclass(dT, Item))
        ) and value is not None:
            value = StorageManager.getItem(value)

        return super()._valueToStorage(value)

    def _valueToState(self, value):
        value = super()._valueToState(value)
        dT = self.p.get("dataType", None)

        if (
            dT.startswith("reference:") or dT == "reference" or (isinstance(dT, type) and issubclass(dT, Item))
        ) and value is not None:
            value = value.sk.id

        return super()._valueToState(value)
