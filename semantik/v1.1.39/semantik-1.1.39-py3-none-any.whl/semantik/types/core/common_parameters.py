from .parameters import *

__all__ = ["CORE", "FORM_ITEM", "SIMPLE_FIELD", "HTML"]


# items that can be included in a container
CORE = Parameters(
    SSParam(
        id="id",
        help="The id is the name of the field as stored in the database and the state. This is set automatically"
        "based on the name of the class but can be overriden if needed by the applicaiton using this"
        "parameters.",
        required=True,
    ),
    Param(
        "display", help="A javascript function that returns a boolean indicating whether the item should be " "shown."
    ),
    Param("virtual", help="The field will not be loaded from or stored to the database."),
    category="Core Parameters",
)

# items that can be shown on a form but need not necessarily be form_fields
FORM_ITEM = CORE.add(
    # general
    # server-side
    SSParam(
        id="validate",
        callable=True,
        help="A function that validates the field and, if it is not acceptable, returns a string describing the "
        "error. If the field is acceptable, it should return None. The function will be called with the "
        "value of the field as the first argument and the context as the second argument. The context is "
        "an internal Semantik object that contains the current state of the form.",
    ),
    # layout
    Param(id="formLabel", help="The label to use when the type is used on a form."),
    Param(id="formClass", help="A CSS class to apply to the overall input group container", inherit=True),
    Param(id="labelClass", help="A CSS class to apply to the label", inherit=True),
    Param(id="fieldClass", help="A CSS class to apply to the field itself", inherit=True),
    Param(
        id="rowClass", help="A CSS class to apply to the form row div", default="row sk-form-internal-row", inherit=True
    ),
    # general
    Param(
        id="isFieldContainer",
        help="If True the field will be treated visually as a field container. This means that it will have less"
        "padding and an attempt will be made to have it fill horizontal space (whether it does so depends on"
        "the CSS of the field.)",
    ),
    # visual
    Param(id="prepend", help="A string to use as a prefix in front of the field. Not supported on all form fields."),
    Param(id="subscript", help="Text to write underneath the field as additional explanation, warnings, etc."),
    Param(
        id="help",
        help="If set a help icon will be shown next to the field. Hovering over the icon will show the "
        "text of this parameter.",
    ),
    Param(id="helpStyle", help="A CSS style to apply to the help hover-over content."),
    Param(id="cls", help="A CSS class to apply to the field container."),
    category="Form-item Parameters (for any field that can be shown on a form)",
)

SIMPLE_FIELD = FORM_ITEM.add(
    # field core
    SSParam(
        "dataType",
        help="The type of data that the field holds. Not all fields support all data types."
        "This can be: str, int, float, bool, date, datetime, time, "
        "reference (generic mongoengine reference), "
        "reference:ReferenceType (type-specific mongoengine reference), "
        "object (for a generic Python object), or any mongoengine field, "
        "e.g. mongoengine.IntField()",
    ),
    SSParam(
        "default",
        help="A default value for the field. This can be a literal value or a function that returns "
        "the default value. If a function is used, it will be called with the context as the "
        "parameter",
    ),
    Param(
        id="title",
        help="If used instead of babel this will create a title above the field instead of a label next to it."
        "Only used in custom form types (not for standard Semantik forms).",
    ),
    Param(
        id="calculated",
        help="A literal or function that takes context and returns the value for this field "
        "(used for fields that are derived from other fields)",
    ),
    # static support
    Param(
        "static",
        inherit=True,
        help="If True the field will be shown as a static value on a form. This is useful "
        "when you want to print a form and don't want field borders etc. Not all fields"
        "support static mode.",
    ),
    category="Core Field Parameters",
)

# adds any elements in standard HTML
HTML = Parameters(
    RTParam("cls", rtId="class"),
    *[Param(k) for k in ["style", "width", "height", "contenteditable", "name", "id", "subject", "role", "accesskey"]],
)

CONTAINER = CORE.add(
    Param(
        id="transparent",
        help="If False this will create a sub-object in the database to store the value of any"
        "child types (otherwise data from child types will be stored at the same level"
        "of the db/storage as this type, usually an attribute on the db object itself)",
        default=True,
    ),
    Param(id="structure", help="List of child objects (usually filled implicitly by declaring contained classes)"),
    Param(
        "display", help="A javascript function that returns a boolean indicating whether the item should be " "shown."
    ),
    # static support
    Param(
        "static",
        inherit=True,
        help="If True the field will be shown as a static value on a form. This is useful "
        "when you want to print a form and don't want field borders etc. Not all fields"
        "support static mode.",
    ),
    category="Container",
)

FIELD_CONTAINER = CONTAINER.add(
    Param(id="defaultClass", default="col-md-12", inherit=True, help="Default class for contained items"),
    Param(id="defaultLabelClass", default="col-md-5", inherit=True, help="Default label class for contained items"),
    Param(id="defaultFieldClass", default="col-md-7", inherit=True, help="Default field class for contained items"),
    Param(
        id="defaultRowClass",
        default="row sk-form-internal-row",
        inherit=True,
        help="Default row class for contained items",
    ),
    Param(
        id="horizontal",
        default=True,
        help="True (default) if this should be show in the horizontal form layout,"
        "otherwise False for vertical layout",
    ),
    SSParam(
        id="validate",
        callable=True,
        help="A function that validates the entire container (vs individual fields) for consistency.",
    ),
    category="Field Container",
)
