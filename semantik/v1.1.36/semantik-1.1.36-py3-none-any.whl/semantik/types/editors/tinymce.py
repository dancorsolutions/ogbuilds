from semantik.types.common import *
from semantik.types.form_fields.base import SimpleField

__all__ = ["TinyMCE"]


class TinyMCEExternal(External):
    imports = {
        "import TinyMCEExternal from '@tinymce/tinymce-vue'",
    }


class TinyMCE(SimpleField):
    _tag = "SKTinyMCE"
    _parameters = common_parameters.SIMPLE_FIELD.add(
        # tiny mce
        RTParam(
            id="init",
            help="TinyMCE initialization options",
            default=dict(
                height=500,
                menubar=False,
            ),
        ),
        RTParam(id="apiKey", help="TinyMCE API key"),
        RTParam(id="plugins", default=[]),
        RTParam(id="disabled"),
        RTParam(
            id="toolbar",
            default="undo redo | casechange blocks | bold italic backcolor | alignleft aligncenter "
            "alignright alignjustify | bullist numlst checklist outdent indent | removeformat"
            " | a11ycheck code table help",
        ),
    )
    _nullValue = ""
    dataType = "str"


class SKTinyMCE(SKComponent):
    # language=Vue
    template = r"""
    <TinyMCEExternal
        v-model="state._value"
        v-bind="config._passthroughAttrs"
    ></TinyMCEExternal>
    """
