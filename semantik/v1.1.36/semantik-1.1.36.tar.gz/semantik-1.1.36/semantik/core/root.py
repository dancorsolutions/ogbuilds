import logging
import re
import json

import mongoengine

from roundtrip.core.javascript import js, dumps

from ..types.core.components import SKBase
from ..treestore.item import StorageManager as sm
from ..treestore.item import Item
from ..core.session import StackFrame

__all__ = ["SKRoot"]


class SKRoot(SKBase):
    initialData = dict(
        windows={"_root": dict(state=None, item=None)},
        popupWindowVisible=False,
        clipboard=None,
    )

    provide = dict(skRootConfigs=js("() => this.config"))

    @property
    def at(self):
        """
        The current item
        """
        if not self.connection or not self.session:
            return None
        return self.session.at

    @property
    def currentWindow(self):
        """
        Get the current window from the stack

        :return: the client-side window object, i.e.::

                     {'state': client_side_window_state, 'item': item_uuid_with_table}
        """
        if self.session.stack:
            if self.session.stack[-1].target not in self.data.windows:
                self.data.windows[self.session.stack[-1].target] = dict(state=None, item=None)
            return self.data.windows[self.session.stack[-1].target]

    def __init__(self):
        configs = dict()
        for ident, cls in sm.registeredItemTypes.items():
            if not cls.sk.structure:
                raise ValueError("No structure defined on %r" % cls)

            configs[ident] = cls.sk.structure._configDefault(context=self.context)

        self.props = dict(
            config=dict(default=js("function() { return %s; }" % dumps(configs))),
            **(self.props or {}),
        )
        super().__init__()

    def reloadItem(self):
        item = self.at
        self.openItem(item, force=True)

    def openItem(self, item, target="_root", force=False, dont_push_route=False):
        if item is None:
            self.notify("Item no longer exists", "warning")
            return

        if target not in self.data.windows:
            self.data.windows[target] = dict(state=None, item=None)

        w = self.data.windows[target]

        if w.item and w.item.id == item.sk.id and not force:
            return

        if self.session.stack and self.currentWindow.state is not None:
            # save the state of the current window (before opening `item` in `target`) to the stack
            self.session.stack[-1].state = self.currentWindow.state

        if target == "_root":
            if dont_push_route:
                self.app.showRoute("/Admin/" + item.sk.id)
            else:
                self.app.open("/Admin/" + item.sk.id)

        ctx = self.context

        context = item.sk.makeContext(state={})
        d = item.sk.structure._data(context=context)
        context = item.sk.makeContext(state=d)
        item.sk._toState(item, d, context=context)
        w.state = d
        w.item = item.sk.descriptor()
        self.session.stack.append(StackFrame(state=d, item=item, target=target))
        if target == "popup":
            self.data.popupWindowVisible = True
        else:
            self.data.popupWindowVisible = False

    def loadTop(self):
        """
        Load the item at the top of the stack into the view
        """
        # TODO: check if the on-disk item has changed and notify the user if it has (use updateId)
        # TODO: if the previous activity was in a different window, notify the item that it has to reload any changed
        #  contents data
        sf = self.session.stack[-1]
        self.currentWindow.state = sf.state
        self.currentWindow.item = sf.item.sk.descriptor()
        self.app.showRoute("/Admin/" + sf.item.sk.id)

    def newItem(self, itemTypeName, parent=None, target="_root", initialData=None) -> Item:
        """
        Create a new item and open it into the given target
        """
        itemType = self.session.getItemType(itemTypeName)
        if itemType is None:
            raise ValueError(f"Cannot create item of type {itemTypeName}: no item class of that name exists")
        item = itemType()
        if parent is not None:
            item._parent = parent
        if initialData:
            for k, v in initialData.items():
                if k in ("id", "_id"):
                    continue
                setattr(item, k, v)
        self.openItem(item, target=target)
        return item

    def validateItem(self):
        """
        Validate form data from the UI against the current item

        :return: nested errors dict or None if there are no errors
        """
        at = self.at
        return at.sk.structure._validate(self.currentWindow.state, context=self.context)

    def toItem(self):
        """
        Save data from the UI to the current item
        """
        at = self.at
        at.sk.structure._toStorage(self.currentWindow.state, at, context=self.context)

    def fromItem(self):
        """
        Load data from the current item into the UI
        """
        at = self.at
        d = at.sk.structure._data(context=self.context)
        at.sk._toState(at, d, context=self.context)
        self.currentWindow.state = d

    def saveItem(self, close: bool = True):
        """
        Save the current item to the database (or to a parent item if it's virtual).

        This method checks for form validation errors before saving and will not save the item or close it if
        there are validation errors. It will instead send a notification that there are errors and highlight the
        errors.

        :param close: if `True`, pop this item from the stack after saving by calling `closeItem`.
        """
        at = self.at
        errors = self.validateItem()
        if errors:
            js.console.log("Form errors", errors)
            return "Correct errors below before saving"

        self.toItem()
        try:
            if hasattr(at.sk, "beforeSave"):
                rc = at.sk.beforeSave()
                if rc:
                    return "Correct errors below before saving"
            try:
                at.save()
            except mongoengine.NotUniqueError as e:
                m = re.search(r"'keyPattern'\: (\{.*?\})", e.args[0])
                if m:
                    s = m.group(1).replace("'", '"')
                    names = {i for i in json.loads(s).keys() if i != "_cls"}
                    return (
                        f'Saving would create two items with the same value for {", ".join(names)}: this value '
                        f"must be unique"
                    )
                else:
                    return f"Saving would create duplicates for one or more unique field"

        except mongoengine.ValidationError as e:
            # TODO: use these to display a message, just in case it's not caught by item developer validation
            logging.error("mongoengine validation error", e.errors)
            return "Database validation errors (check for missing values)"
            raise e

        if close:
            self.closeItem()
        self.notify("Item saved", "success")
        return None

    def hasChanged(self) -> bool:
        """
        Return `True` if the current item has changed since it was loaded.
        """
        self.at._delta()  # forces the object to clear its change detection buffers
        self.toItem()
        delta2 = self.at._delta()
        if delta2[0] or delta2[1]:
            return delta2
        else:
            return None

    def closeItem(self):
        """
        Close the current item and pop it off the navigation stack

        The application should check that it's OK to close the item (e.g. some changed and unsaved items should
        not be closed without providing a warning).
        """
        if not self.session.stack:
            self.app.go("/")
            return

        removed = self.session.stack.pop()
        if self.session.stack:
            self.loadTop()
            self.app.client.replace("/Admin/" + self.session.stack[-1].item.sk.id)
        else:
            self.app.go("/")
            return

        if self.session.stack:
            if removed.target != self.session.stack[-1].target:
                del self.data.windows[removed.target]
            if self.session.stack[-1].target == "popup":
                self.data.popupWindowVisible = True

    def deleteItem(self):
        """
        Delete the current item
        """
        self.at.delete()
        self.notify("Item deleted", "info")
        self.closeItem()

    def archiveItem(self):
        """
        Archive the current item
        """
        self.at.archive()
        self.notify("Item archived", "info")
        self.closeItem()

    def clipboardCopy(self, items):
        self.data.clipboard = dict(type="copy", items=items)
        self.notify(f'Copied {len(items)} item{"s" if len(items) > 1 else ""}', "info")

    def clipboardCut(self, items):
        self.data.clipboard = dict(type="cut", items=items)
        self.notify(f'Cut {len(items)} item{"s" if len(items) > 1 else ""}', "info")

    def clipboardClear(self, item):
        self.data.clipboard = None

    def clipboardPaste(self):
        parent = self.at
        items = []
        for id in self.data.clipboard.items:
            item = sm.getItem(id)
            if not item:
                continue
            items.append(item)

        if [i for i in items if not parent.sk.canPaste(item)]:
            self.notify("Some items cannot be pasted here", "warning")
            return

        for item in items:
            item._parent = parent
            item.save()

        self.data.clipboard = None

        self.notify(f'Pasted {len(items)} item{"s" if len(items) > 1 else ""}', "success")

    def notify(self, message: str, kind: str = "info"):
        """
        *Virtual Method*

        Override this with a method that provides some sort of notification to the user via the UI that an event has
        happened. Events should be unobtrusive and close automatically after a short period of time.

        :param message: the message to display
        :param kind: one of 'warning', 'error', 'info' (*check this*)
        """
        raise RuntimeError("Virtual method")

    def popup(
        self,
        title: str = None,
        message: str = None,
        kind: str = None,
        actions: [] = None,
    ):
        """
        *Virtual Method*

        Override this with a method that creates a *modal* popup dialog box with the given parameters
        """
        raise RuntimeError("Virtual method")

    @property
    def skRoot(self):
        return self
