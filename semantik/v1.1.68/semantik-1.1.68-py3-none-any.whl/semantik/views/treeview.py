import os.path

from roundtrip.component import Component
from roundtrip.component.decorators import *
from roundtrip.core.javascript import js
from ..types.core.components import SKBase

__all__ = ["TreeView"]


class TreeView(Component):
    # to expand on navigation: $refs.dx.$_instance.expandItem($event.itemData);

    # language=Vue
    template = r"""
    <dx-tree-view
        class="sk-tree-view"
        data-structure="plain"
        selection-mode="single"
        :select-by-click="false"
        :create-children="(parent) => createChildren(parent ? parent.itemData.id : '')"
        ref="dx"
        @item-click="$emit('navigateTo', $event.itemData.id)"
    />
    """

    initialData = dict()

    @method
    def createChildren(self, itemId):
        path = [i.sk.id for i in self.session.at.sk.path] if self.session.at else []
        if not itemId:
            item = self.session.root
            newNode = self.generateNode(item)
            return [newNode]
        else:
            children = []
            item = self.session.getItem(itemId)
            for child in item.sk.children:
                cn = self.generateNode(child)
                cn["parentId"] = itemId
                cn["expanded"] = False
                cn["hasItems"] = child.sk.treeExpandable
                children.append(cn)
            return children

    def navigatedTo(self, item):
        cmp = self.refs.dx["$_instance"]
        for i in item.sk.path:
            if i.sk.treeExpandable:
                cmp.expandItem(i.sk.id)
        cmp.selectItem(item.sk.id)

    def generateNode(self, item):
        node = dict()
        node["id"] = item.sk.id
        node["text"] = item.sk.treeLabel
        if item.sk.treeLabel == "Admin" and item.sk.iconClass:
            node["icon"] = item.sk.iconClass
        node["hasItems"] = item.sk.treeExpandable
        node["expanded"] = True
        return node
