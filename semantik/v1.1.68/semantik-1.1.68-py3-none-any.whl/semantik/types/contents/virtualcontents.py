# language=rst
"""
VirtualContents Type

The VirtualContents supports storing a list of Item-like objects inside an item

It is useful when you intend to store a small number of items logically 'inside' another item and do not need these
to be fully-fledged database rows. In this case using VirtualContents to store these items offers a simpler
to be fully-fledged database rows. In this case using VirtualContents to store these items offers a simpler
alternative with the following advantages:

    - does not require dB access to edit items
    - edits contained items within the editing context of the parent so if a user cancels an edit they also cancel
      changes to contained items
    - uses ordered lists by default

You use the addable param in the same way as with Contents but in this case the addable items should be VirtualItems,
not fully-fleged Items.

Data is stored in a `ListField(GenericEmbeddedDocumentField())`.
"""

import uuid

import mongoengine

from ..common import *
from .basecontents import *
from ...treestore.item import StorageManager

__all__ = ["VirtualContents"]


class VirtualContents(BaseContents, Type):
    _tag = "SKVirtualContentsComponent"

    _parameters = BaseContents._parameters + Parameters()

    def _getFields(self):
        """Return a dict of field id -> mongoengine field"""
        return {self._id: mongoengine.ListField(mongoengine.GenericEmbeddedDocumentField())}

    def _data(self, context):
        data = Type._data(self, context=context)
        data[self._id]["_value"] = self.p("default", context=context) if "default" in self.p else []
        return data

    def _toState(self, storage, state, context):
        value = storage[self._id]
        out = []
        for item in value:
            rowState = dict()
            item.sk._toState(item, rowState, context)
            row = self._toColumns(item)
            row["__itemType"] = item.sk.ident
            row["__key"] = str(uuid.uuid4())
            row["__state"] = rowState
            out.append(row)
        state[self._id] = dict(_value=out)

    def _toStorage(self, state, storage, context):
        # language=rst
        """
        Move data from `state` to `storage` (usually an underlying :class:`Item`-like object)

        .. note::
           This function only mutates the :class:`GenericEmbeddedDocument` list on the item the minimum amount necessary
           to update it: without this mongoengine would always see changes and try to save them to the item even
           if there are none.
        """

        value = state[self._id]._value
        out = storage[self._id]
        if out is None:
            out = []

        for index in range(max(len(out), len(value))):
            if index >= len(value):
                out.pop()
                continue

            row = value[index]
            itemType = StorageManager.getItemType(row["__itemType"])

            if index >= len(out):
                item = itemType()
                item.sk.structure._toStorage(row["__state"], item, context)
                out.append(item)
            else:
                if isinstance(out[index], itemType):
                    out[index].sk.structure._toStorage(row["__state"], out[index], context)
                else:
                    item = itemType()
                    item.sk.structure._toStorage(row["__state"], item, context)
                    out[index] = item

    def _toColumns(self, item):
        data = dict()
        for column in self.p.columns:
            data[column._fieldId] = column._compute(item)
        return data


class SKVirtualContentsComponent(BaseContentsComponent):
    linked = True

    inject = ["skRootConfigs"]

    skType: VirtualContents

    imports = SKComponent.imports.union(
        {
            "import CustomStore from 'devextreme/data/custom_store'",
            "import { nextTick } from 'vue'",
            "import { compare } from '../../../../roundtrip/roundtrip/js/utils'",
        }
    )

    # language=Vue
    template = r"""
    <div
        class="sk-contents-container"
        :style="config.style"
        ref="container"
        key="_uid"
    >
        <div :class="config.layout==='horizontal' ? 'sk-virtual-contents-container-h' : 'sk-virtual-contents-container-v'">
            <div v-if="config.title" class="sk-contents-title" v-html="config.title"/>
            <dx-data-grid
                :data-source="state._value"
                v-model:selected-row-keys="selection"
                :load-panel="{enabled: false}"
                v-bind="config._passthroughAttrs"
                ref="dataGrid"
                keyExpr="__key"
                @rowDblClick="config.canEdit && doEdit({storage: $event.data, index: $refs.dataGrid.instance.getRowIndexByKey($event.data.__key)})"
            >
                <dx-data-grid-selection 
                    mode="multiple" 
                    :allow-select-all="true" 
                    show-check-boxes-mode="onClick"
                />
                <dx-data-grid-row-dragging
                    v-if="config.ordered"
                    :allow-reordering="true"
                    :on-reorder="onReorder"
                    :show-drag-icons="true"
                />    
                <dx-data-grid-filter-row v-if="config.filterRow"/>
                <dx-data-grid-filter-panel v-if="config.filterPanel"/>
                <dx-data-grid-filter-builder-popup v-if="config.filterPopup"/>
    
                <dx-data-grid-column
                    v-for="col, index of hydrateConfig(config.columns)" 
                    v-bind="col._passthroughAttrs"
                    :key="index"
                >
                    <dx-data-grid-button
                        v-for="button in col.buttons"
                        v-bind="button.props"
                        v-on="button.handlers"
                    >                    
                    </dx-data-grid-button>
                </dx-data-grid-column>
            </dx-data-grid>
            <div class="sk-contents-footer" style="background-color: white;">
                <div class="sk-contents-actions">
                    <button 
                        v-if="config.canEdit && selection && selection.length == 1" 
                        @click="doEdit({storage: $refs.dataGrid.instance.getSelectedRowsData()[0], index: $refs.dataGrid.instance.getRowIndexByKey(selection[0])})" 
                        class="btn btn-sm ml-2 btn-outline-success"
                    >
                        Edit
                    </button>
                    <button 
                        v-if="config.canDelete && selection && selection.length && config.confirmDelete" 
                        @click="$refs.confirm.show({
                                    title: 'Confirm delete', 
                                    message: 'Are you sure?', 
                                    buttons: [
                                        {label: 'Cancel', cls: 'btn-outline-secondary'},
                                        {label: 'Confirm', cls: 'btn-outline-danger', action: () => doDelete(selection.map((k) => $refs.dataGrid.instance.getRowIndexByKey(k)))}
                                    ],
                                })" 
                        class="btn btn-sm ml-2 btn-outline-danger"
                    >
                        Delete
                    </button>
                    <button 
                        v-else-if="config.canDelete && selection && selection.length"
                        @click="doDelete(selection.map((k) => $refs.dataGrid.instance.getRowIndexByKey(k)))"
                        class="btn btn-sm ml-2 btn-outline-danger"
                    >
                        Delete
                    </button> 
                    <span v-if="config.canAdd && config.addable && config.addControl === 'buttons'">
                        <button 
                            v-for="item in config.addable" 
                            @click="doAdd(item.type)" 
                            class="btn btn-sm ml-2 btn-outline-info"
                        >
                            {{item.text}}
                        </button>
                    </span>
                    <span v-else-if="config.canAdd && config.addable && config.addControl === 'dropdown'">
                        <dx-drop-down-button 
                            text="Add" 
                            :items="config.addable" 
                            displayExpr="text"
                            keyExpr="type"
                            class="btn btn-sm ml-2 btn-outline-info"
                        />
                    </span>
                    <button 
                        @click="$refs.dataGrid.instance.state(null)" 
                        class="btn btn-sm ml-2 btn-outline-secondary" 
                        style="margin-left: auto;"
                    >
                        Reset filters
                    </button>
                    <button 
                        @click="$refs.dataGrid.instance.refresh()" 
                        class="btn btn-sm ml-2 btn-outline-secondary" 
                        style="margin-left: auto;"
                    >
                        Refresh
                    </button>
                </div>
            </div>
            <dx-popup 
                v-if="config.popup && current !== null"
                v-bind="typeof(config.popup) == 'object' ? config.popup : {}"
                :title="(changed ? '* ' : '') + config.title" 
                v-model:visible="popupVisible"
                :show-title="config.title ? true : false"
                :show-close-button="false"
                @contentReady="(e) => e.component.content().style.padding='0'"
                @initialized="(e) => e.component.registerKeyHandler('escape', function (arg) { doCancel(changed); arg.stopPropagation(); })"
            >
                <template #content>
                    <div class="sk-popup">
                        <div class="sk-popup-contents">
                            <SKItem :config="hydrateConfig(skRootConfigs()[current.__itemType]())" :state="current.__state" :itemState="state"/>
                        </div>
                        <div class="footer navbar-fixed-bottom sk-contents-footer">
                            <div class="sk-contents-actions">
                                <button @click="doCancel(changed)" class="btn btn-md ml-2 btn-outline-secondary">Cancel</button>
                                <button v-if="config.canEdit" @click="doSave()" class="btn btn-md ml-2 btn-outline-success">Save</button>
                            </div>
                        </div>
                    </div>
                </template>
            </dx-popup>
            <div v-if="!config.popup && current !== null" >
                <SKItem :config="hydrateConfig(skRootConfigs()[current.__itemType]())" :state="current.__state" :itemState="state"/>
                <div class="sk-contents-footer">
                    <div class="sk-contents-actions">
                        <button 
                            class="btn btn-md ml-2 btn-outline-secondary" 
                            @click="() => {current = null; selected = null;}"
                        >
                            Cancel
                        </button>
                        <button 
                            v-if="config.canEdit && selected !== null" 
                            class="btn btn-md ml-2 btn-outline-success" 
                            @click="doSave()"
                        >
                            Save
                        </button>
                        <button 
                            v-else-if="config.canEdit" 
                            class="btn btn-md ml-2 btn-outline-success" 
                            @click="doSave()"
                        >
                            Add
                        </button>
                    </div>
                </div>
            </div>
         </div> 
    </div>
     """

    initialData = dict(current=None, selection=[], selected=None, error=None, popupVisible=False)

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        onReorder=r"""
            function(e) {
                const visibleRows = e.component.getVisibleRows();
                const toIndex = this.state._value.indexOf(visibleRows[e.toIndex].data);
                const fromIndex = this.state._value.indexOf(e.itemData);
                const newData = [...this.state._value];
                
                newData.splice(fromIndex, 1);
                newData.splice(toIndex, 0, e.itemData);
                
                this.state._value = newData; // Vue3 means we can set this directly rather than using Vue.set
            }        
        """
    )

    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        changed=js(
            r"""function() {
            if(this.current && this.selected != null && this.state._value[this.selected]) 
                return compare(this.current.__state, this.state._value[this.selected].__state); }
        """
        ),
        console=js("() => console"),
    )

    @method
    def doAdd(self, itemTypeName):
        linked = self.skType.p.linked

        if self.data.current and not linked:
            return

        itemType = self.session.getItemType(itemTypeName)
        if itemType is None:
            raise ValueError(f"Cannot create item of type {itemTypeName}: no item class of that name exists")
        item = itemType()
        context = self.skRoot.context

        state = item.sk.structure._data(context=context)
        item.sk._toState(item, state, context=context)
        row = self.skType._toColumns(item) if linked else dict()
        row["__state"] = state
        row["__key"] = str(uuid.uuid4())
        row["__itemType"] = itemTypeName

        if linked:
            self.client.state._value.push(row)
            self.client.selected = self.client.state._value.length - 1  # Vue3 means we don't need Vue.set
            self.client.current = self.client.state._value[self.client.selected]  # Vue3 means we don't need Vue.set
        else:
            self.data.current = row
            self.data.selected = None

        self.data.popupVisible = True

    @method
    def doDelete(self, selection):
        for index in reversed(sorted(selection)):
            self.client.state._value.splice(index, 1)
        if self.data.selected in selection:
            self.data.current = None
            self.data.selected = None
        self.client["$refs"].dataGrid["instance"].refresh()

    @method
    def doSave(self):
        # Never called in linked mode
        itemTypeName = self.data.current["__itemType"]
        itemType = self.session.getItemType(itemTypeName)
        if itemType is None:
            raise ValueError(f"Cannot create item of type {itemTypeName}: no item class of that name exists")
        item = itemType()

        context = self.skRoot.context
        context.state = self.data.current["__state"]
        errors = item.sk.structure._validate(self.data.current["__state"], context=context)
        if errors:
            self.data.error = "Check and correct errors"
            return

        item.sk.structure._toStorage(self.data.current["__state"], item, context=context)
        self.data.current.update(self.skType._toColumns(item))

        if self.data.selected is not None:
            # save button
            self.client.state._value.splice(self.data.selected, 1, self.client.current)
            self.data.current = None
            self.data.selected = None
        else:
            # add button
            self.client.state._value.push(self.client.current)
            self.data.current = None

        self.client["$refs"].dataGrid["instance"].refresh()

    @method
    def doCancel(self, changed):
        self.data.current = None
        self.data.selected = None

    @method
    def doEdit(self, storage, index):
        self.data.error = None
        self.data.selected = index

        self.data.current = storage  # No need for Vue.set with Vue3
        self.data.popupVisible = True
        self.client["$refs"].dataGrid["instance"].refresh()
