import mongoengine

from semantik.types.common import *
from .base import *


__all__ = ["Slider"]

#
# Number
#


class Slider(SimpleField):
    _tag = "SKSlider"
    _parameters = common_parameters.SIMPLE_FIELD.addPassthroughs(dx.DxSlider)
    nullValue = None
    dataType = "float"


class SKSlider(SKComponent):
    imports = SKComponent.imports.union({"import { formatNumber } from 'devextreme/localization';"})

    # language=Vue
    template = r"""
    <div v-if="config.static" class="sk-static-value">
        <template v-if="config._passthroughAttrs && config._passthroughAttrs.format">
            {{ (state._value === null || state._value === undefined) ? '-' : formatNumber(state._value, config._passthroughAttrs.format) }}
        </template>
        <template v-else>
            {{ (state._value === null || state._value === undefined) ? '-' : state._value }}
        </template>
    </div>
    <dx-slider
        v-else-if="config.calculated" 
        :value="config.calculated()"
        {& sk.dx_field_attributes &}
    />
    <dx-slider
        v-else 
        v-model:value="state._value"
        {& sk.dx_field_attributes &}
    />
    """

    computed = dict(formatNumber=js(r"""() => formatNumber"""))
