from html import escape
import uuid

import mongoengine

from compositor import parser
from semantik.types.form_fields.options.select_box import SKSelectBox, SelectBox
from semantik.types.form_fields.options.tag_box import SKTagBox, TagBox
from semantik.types.form_fields.text import SKText, Text
from semantik.types.common import *

__all__ = ["Compositor"]

AUTO_CLOSE = False


class Compositor(Type):
    _parameters = Parameters(
        # server-side
        SSParam(id="id", required=True),
        SSParam(id="validate", callable=True),
        SSParam(
            id="noContext",
            default=False,
            help="If true, this will not attempt to get to an SKRoot and it's at attribute to build a context",
        ),
        Param(id="display"),
        SSParam(id="grammar", required=True),
        # client-side
        Param(id="width", default="100%"),
        Param(id="formLabel"),
        Param(id="formLabel"),
        Param(id="formClass"),
        Param(id="labelClass"),
        Param(id="fieldClass"),
    )

    _tag = "SKCompositor"

    def _data(self, context):
        data = super()._data(context=context)
        data[self._id]["_value"] = self.p("default", context=context) if "default" in self.p else []
        return data

    def _getFields(self):
        """Return a dict of field id -> mongoengine field"""
        return {self._id: mongoengine.ListField(mongoengine.DynamicField())}

    def _valueToStorage(self, value):
        return value

    def _valueToState(self, value):
        return value


class SKCompositor(SKComponent):
    autoFillOnlyOption = False

    # language=Vue prefix=<template> suffix=</template>
    template = r"""

    <dx-drop-down-box
        v-if="config.display === undefined || config.display" 
        ref="compositor"
        width="100%"
        field-template="field"
        @opened="onOpened"
        @closed="onClosed"
        :drop-down-options="{animation: null, 
                             wrapperAttr:{'class': 'sk-compositor-popup-wrapper'}}"
             
    >
        <!-- onHiding: (e) => (complete && error_free) ? null : e.cancel = true, -->
        <template #field>
            <dx-text-box
                :read-only="true"
                :element-attr="{'class': 'sk-compositor-dx-text-field'}"
            >
                <div :class="{'sk-compositor-container-field': true, 'sk-compositor-container-field-active': active}"> 
                    <div
                        v-for="(token, index) in (tokens_before === null ? (tokens || []) : tokens_before)"
                        :key="'static_' + token.uid" 
                        :class="'sk-compositor-token sk-compositor-token-' + token.type"
                        v-html="token.html ? token.html : token.name"
                        tabindex=0
                    />
                </div>
            </dx-text-box>
        </template>
        <template #content>
            <div class="sk-compositor-container">
                <div class="sk-compositor-container-main">
                    <div class="sk-compositor-tokens">
                        <TransitionGroup name="sk-compositor" :duration="500">                 
                            <div class="sk-compositor-token-container" 
                                v-for="(token, index) in (tokens.length ? tokens : [null])"
                                :key="token ? token.uid : '0'" 
                            >
                                <div 
                                    class="sk-compositor-adder"
                                >
                                    <i class="fa-solid fa-add" @click.stop="addToken(index)"></i>
                                </div>
                                <div
                                    :class="{'sk-compositor-token': true, ['sk-compositor-token-' + token.type]: true, '--error': token.error}"
                                    @click="onSelectToken(token.uid)"                                    
                                    v-if="(token_select_index !== index) && (token !== null) && !(interactive_config && interactive_index === index)"
                                    tabindex=0
                                >
                                    <i class="fa-solid fa-circle-xmark" @click.stop="doDeleteToken(index)"></i>
                                    <span v-html="token.html ? token.html : token.name"></span>
                                </div>
                                
                                <div 
                                    v-if="
                                        (interactive_config && (interactive_index === index)) ||
                                        (interactive_config && (interactive_index === -1) && (token === null || index === (tokens.length - 1)))
                                    "
                                    class="sk-compositor-editable"
                                    ref="compositor_editable"
                                >
                                    <SKItem
                                        :config="interactive_config ? hydrateConfig(interactive_config) : undefined"
                                        :state="interactive_state"
                                        :itemState="interactive_state"
                                        ref="interactive"
                                        @interactiveCompleted="onInteractiveCompleted()"
                                    />
                                    <button 
                                        v-if="!interactive_config.noButton" 
                                        class="sk-compositor-field-button" @click="onInteractiveCompleted()"
                                    >
                                        <i class="fa-solid fa-circle-check"></i>
                                    </button>
                                </div>
                                <div 
                                    v-if="token_select_index === index || (token_select_index === -1) && (!tokens.length || (index === (tokens.length - 1)))"
                                    class="sk-compositor-chooser"
                                >
                                    <dx-select-box
                                        :data-source="options"
                                        v-model:value="terminal_selected"
                                        v-if="options.length"
                                        ref="terminalSelectBox"
                                        value-expr="id"
                                        display-expr="label"
                                        @itemClick="onSelectionChangeEvent($event)"
                                        @contentReady="onSelectReady"
                                        item-template="item"
                                    >
                                        <template #item="{ data }">
                                            <div class="sk-compositor-grammar-choice"> 
                                                <div 
                                                   :class="'sk-item sk-item-' + data.type"
                                                >
                                                    {{ data.label }}
                                                </div>
                                            </div>
                                        </template>
                                    </dx-select-box>
                                </div>                            
                            </div>                    
                        </TransitionGroup>
                    </div>
                    <div class="sk-compositor-tools">
                        <button 
                            :class="{'btn': true,  'btn-success': true, '-sk-hidden': !(complete && error_free)}"
                            @click="saveAndClose()"
                        >
                            <i class="fa-solid fa-check"></i>
                        </button>
                        <button 
                            class="btn btn-danger"
                            @click="discardAndClose()"
                        >
                            <i class="fa-solid fa-close"></i>
                        </button>
                    </div>
                </div>
                <div class="sk-compositor-container-status">
                    <div class="-sk-complete" v-if="(complete && error_free)">
                        <i 
                            class="fa-solid fa-badge-check"
                        ></i>
                        <span> complete</span>
                    </div>
                    <div class="-sk-error" v-if="(complete && !error_free)">
                        <i 
                            class="fa-solid fa-circle-xmark"
                        ></i>
                        <span> error</span>
                    </div>
                </div>
            </div>
        </template>
    </dx-drop-down-box>
    """

    imports = SKComponent.imports.union(
        {
            "import { nextTick } from 'vue'",
        }
    )

    initialData = dict(
        tokens=[],
        tokens_before=None,
        options=[],
        terminal_selected=None,
        active=False,  #: the component is focused (therefore editable)
        complete=False,
        interactive_index=None,  #: the component is editing an interactive component at this token index
        interactive_state=None,
        interactive_config=None,
        interactive_token_name=None,
        token_select_index=None,
    )
    computed = dict(
        # language=JavaScript prefix=[ suffix=]
        console=js("""() => console"""),
        # language=JavaScript prefix=[ suffix=]
        nextTick=js("""() => nextTick"""),
        # language=JavaScript prefix=[ suffix=]
        setTimeout=js("""() => setTimeout"""),
        # language=JavaScript prefix=[ suffix=]
        error_free=js("""function() { return !this.tokens.some((i) => i.error) }"""),
    )

    watch = {
        # language=JavaScript prefix=[ suffix=]
        "state._value": dict(
            handler=js(
                """function(newValue, oldValue) {
            this.tokens = [...this.state._value]
        }""",
            ),
            deep=True
        ),
    }

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        onOpened=js(
            """
            function() {
                this.terminal_selected = null;
                this.tokens_before = this.tokens_before === null ? [...this.tokens] : this.tokens_before;
                this.setInitialOptions();
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        onClosed=js(
            """
            function() {
                this.tokens_before = [...this.tokens];
                if(this.complete && this.error_free) {
                    this.state._value = this.tokens;
                }
                this.active = true;
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        saveAndClose=js(
            """
            function() {
                if(!(this.complete && this.error_free)) {
                    return;
                }
                this.tokens_before = [...this.tokens];
                this.state._value = this.tokens;
                this.$refs.compositor.$_instance.close();
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        discardAndClose=js(
            """
            function() {
                this.tokens = [...this.tokens_before];
                this.complete = true;
                this.$refs.compositor.$_instance.close();
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        onSelectionChangeEvent=js(
            """
            function(event) {
                if(!event.itemData) 
                    return;
                this.onSelection({value:event.itemData});
                this.active = true;
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        onSelectReady=js(
            """
        function(event) {
            setTimeout(() => event.component.open(), 100)
        }
    """
        ),
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        beforeMount=js(
            """
        function() {
            this.tokens = [...this.state._value]
        }
    """
        ),
    )


    @method
    def setInitialOptions(self):
        self.updateOptions()

    def getOptions(self, index=None):
        """
        Set up the options for the next token

        This will add options from the autocomplete list (including interactive and non-interactive terminals)
        and will add an 'end' option for strings that are grammatical complete.
        """
        p = self.parse(index=index)
        ac = p.autocomplete()
        options = []
        if len(ac) > 0:
            for t in ac:
                if getattr(t.f, "structure", None):
                    options.append(dict(id=t.name, label=t.name, type="interactive", state="display"))
                else:
                    options.append(dict(id=t.name, label=t.name, type="static", state="display"))
        if p.isComplete():
            self.data.complete = True
            if options:
                options.append(dict(id="<END>", label="<END>", type="end", state="display"))
            else:
                if AUTO_CLOSE:
                    self.client.saveAndClose()
                return []
        else:
            self.data.complete = False

        return options

    @method
    def onSelection(self, value):
        """
        Handle a user choosing a terminal
        """
        if not value:
            return
        if value["id"] == "<END>":
            self.data.interactive_index = None
            self.data.token_select_index = None
            self.data.token_select_index = None
            if not [i for i in self.data.tokens if not i or i.get("error", False)]:
                self.client.saveAndClose()
            return

        if value["type"] == "interactive":
            self.loadInteractive(name=value["id"])
            return

        index = self.data.token_select_index
        if index is None or index == -1:
            self.data.tokens.append(dict(uid=uuid.uuid4().hex, name=value["id"], type=value["type"], value=None))
        else:
            self.data.tokens[index] = dict(uid=uuid.uuid4().hex, name=value["id"], type=value["type"], value=None)
        self.updateOptions()

    def updateOptions(self, index=None):
        """
        Loads available non-terminal options after adding tokens for any terminals where there is no choice

        Does what getOptions does but also skips asking the user about any terminals where there would
        only have been one choice
        """
        try:
            while 1:
                options = self.getOptions(index=index)
                if len(options) == 1 and options[0]["type"] == "static":
                    self.data.interactive_index = None
                    self.data.token_select_index = None
                    if self.autoFillOnlyOption:
                        self.data.tokens.append(
                            dict(uid=uuid.uuid4().hex, name=options[0]["id"], type=options[0]["type"], value=None)
                        )
                    else:
                        self.data.token_select_index = index = -1 if index is None else index
                        break
                elif len(options) == 1 and options[0]["type"] == "interactive":
                    self.loadInteractive(name=options[0]["id"], index=index or -1)
                    break
                else:
                    self.data.interactive_index = None
                    self.data.token_select_index = -1 if index is None else index
                    break
            self.data.options = options

        except parser.ParseError as e:
            self.data.interactive_index = None
            self.data.token_select_index = None
            for token in self.data.tokens[e.index :]:
                token.error = True

    @method
    def onSelectToken(self, uid):
        """
        Handle the user selecting a token in the string
        """
        # self.data.active = False
        for index, token in enumerate(self.data.tokens):
            if token["uid"] == uid:
                break
        else:
            raise ValueError(f"No token with uid {uid}")
        if token["type"] == "interactive":
            self.loadInteractive(name=token["name"], index=index)
        else:
            self.updateOptions(index)

    def resetErrors(self):
        for index, token in enumerate(self.data.tokens):
            if token.get("error", None):
                self.data.tokens[index]["error"] = False

    @method
    def addToken(self, index):
        self.data.tokens.insert(index, dict(uid=uuid.uuid4().hex, name=None, type=None, value=None))
        self.resetErrors()
        self.updateOptions(index)

    def parse(self, index=None):
        """
        Parse a set of tokens and return the parser object
        """
        p = parser.Parser(self.skType.p.grammar)
        tokens = self.data.tokens
        if index is not None:
            tokens = tokens[:index]
        tokens = [parser.Token(name=i["name"]) for i in tokens]
        p.parse(tokens)
        return p

    @method
    def doDeleteToken(self, index):
        del self.data.tokens[index]
        self.resetErrors()
        self.updateOptions()

    def getStructure(self, name):
        for _, rule in self.skType.p.grammar:
            for sequence in rule:
                for element in sequence:
                    if element.name == name:
                        structure = getattr(element.f, "structure", None)
                        if not structure:
                            raise ValueError(f"No structure for terminal {name}")
                        return structure
        raise ValueError(f"No structure for terminal {name}")

    @method
    def loadInteractive(self, name, index=-1):
        structure = self.getStructure(name=name)
        getattr(self.client, "$").data.interactive_config = js(
            "(" + structure._configDefault(context=None)._as_javascript() + ")()"
        )
        if self.skType.p.noContext:
            context = None
        else:
            context = self.at.sk.makeContext(state=self.data.interactive_state)
        state = {}
        if index == -1:
            storage = {}
        else:
            storage = {structure._id: self.data.tokens[index]["value"]}
        structure._toState(storage, state, context=context)
        self.data.interactive_index = None
        self.data.interactive_state = state
        self.data.interactive_token_name = name
        self.data.interactive_index = index
        self.data.token_select_index = None

    @method
    def onInteractiveCompleted(self):
        context = self.context
        structure = self.getStructure(name=self.data.interactive_token_name)
        value = self.data.interactive_state[structure._id]["_value"]
        error = structure._validate(self.data.interactive_state, context)
        if error:
            return
        if getattr(structure, "_toHTML", None):
            html = structure._toHTML(value, context=context)
        else:
            if value:
                html = escape(value)
            else:
                html = ""
        token = dict(
            uid=uuid.uuid4().hex, name=self.data.interactive_token_name, type="interactive", value=value, html=html
        )
        if self.data.interactive_index == -1:
            self.data.tokens.append(token)
        elif self.data.interactive_index is not None:
            self.data.tokens[self.data.interactive_index] = token
        self.updateOptions()
