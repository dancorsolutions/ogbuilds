import mongoengine

from semantik.types.common import *
from .base import *


__all__ = ["Static"]

#
# Static
#


class Static(DatalessType):
    _tag = "SKStatic"
    _parameters = common_parameters.FORM_ITEM.add(
        SSParam(id="text"),
        SSParam(id="calc", callable=True),
        Param(id="cls"),
    )

    def _data(self, context):
        data = super()._data(context=context)
        if "text" in self.p:
            data[self._id]["_value"] = self.p.text
        elif "calc" in self.p:
            if context:
                data[self._id]["_value"] = self.p.get("calc")(item=context.item, context=context)
        else:
            raise ValueError("Static must have either text or calc set as a parameter")
        return data


class SKStatic(SKComponent):
    # language=Vue
    template = r"""<div v-html="state ? state._value : config.text" style="flex-grow: 1;" :class="config.cls"/>"""
