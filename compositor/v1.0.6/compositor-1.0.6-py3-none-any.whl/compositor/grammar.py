"""
A more expressive way of defining grammars for compositor

This form of grammar definition supports a somewhat (E)BNF-like syntax but can be easily convereted back to plain production 
rules. Built to run with parser.py.
"""
import re
import warnings
from functools import cached_property

from . import parser


def chain(seq):
    out = []
    for i in seq:
        out += i
    return out


class NODEFAULT:
    pass


class MATCHED:
    pass


class GrammarError(parser.ParseError):
    """
    Error creating a parser grammar
    """


class FriendlyGrammar:
    """
    A friendly grammar definition

    This form of grammar definition supports a somewhat (E)BNF-like syntax but can be easily convereted back to plain production rules.

    The grammar supports the following syntax:

    >>> g.ROOT = g.MYRULE | g.MYOTHERRULE        # forward references and OR operator (|)
    >>> g.MYRULE = T('hello') + ~T('world')      # sequence composition operator (+) and optional operator (~)
    >>> 'MYNEWRULE' in g                         # test for containment
    False
    >>> g.canonical()                            # transform grammar into a set of plain production rules
    """

    def __init__(self, sessionClass=None):
        self.__dict__["productions"] = {}
        self.__dict__["sessionClass"] = sessionClass

    def __getattr__(self, k):
        if not k.isupper():
            warnings.warn(f"Only upper case names are supported within grammars {k!r}")
            return
        if k in self.productions:
            return self.productions[k]
        else:
            return GrammarReference(self, k)

    def __setattr__(self, k, v):
        if not k.isupper():
            warnings.warn(f"Only upper case names are supported within grammars {k!r}")
            return

        nt = NT(k)
        nt.production = v
        if k in self.productions:
            raise ValueError(f"{k!r} is already in the grammar")
        self.productions[k] = nt

    def __getitem__(self, k):
        return self.__getattr__(k)

    def __setitem__(self, k, v):
        return self.__setattr__(k, v)

    def __contains__(self, k):
        return k in self.productions

    def get_raw_rule(self, k):
        return self.productions[k]

    @cached_property
    def canonical(self):
        for k, v in self.productions.items():
            if not v.production:
                raise GrammarError("Named rule %s referenced but not defined" % k)

        g = parser.Grammar()
        g.f = self

        for name, rule in self.productions.items():
            canonical = rule.production.canonical(name=name, g=g)
            if canonical:
                g[name] = canonical

        return g


class FriendlyObject:
    """
    Base class for all grammar symbols
    """

    def __add__(self, other):
        if other is None:
            return self
        return SEQUENCE(self, other)

    def __radd__(self, other):
        if other is None:
            return self
        return SEQUENCE(other, self)

    def __or__(self, other):
        if other is None:
            return self
        return CHOICE(self, other)

    def __ror__(self, other):
        if other is None:
            return self
        return CHOICE(other, self)

    def __invert__(self):
        return OPTIONAL(self)

    def __mul__(self, amount):
        assert amount is N
        return REPEAT(self)

    def __eq__(self, other):
        return self is other

    def __ne__(self, other):
        return not self.__eq__(other)

    def canonical(self, name, g):
        assert "Virtual Method", False

    def copyAttributes(self, canonical):
        canonical.f = self
        for k in ["condition", "treeCondition"]:
            if hasattr(self, k):
                setattr(canonical, k, getattr(self, k))

    def reduce(self, ctx, node):
        raise RuntimeError(f"No reducer defined on {self!r}")

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"


class GrammarReference(FriendlyObject):
    """
    A (potentially forward) reference to a named production rule in the grammar
    """

    def __init__(self, grammar, name):
        self.__dict__["grammar"] = grammar
        self.__dict__["name"] = name

    def __setattr__(self, k, v):
        raise RuntimeError(
            f"Cannot set properties on forward references (define {self.name} on {self.grammar} before "
            f"setting properties)"
        )

    def canonical(self, name, g):
        friendly = self.grammar.get_raw_rule(self.name)
        if isinstance(friendly, GrammarReference):
            raise ValueError(
                f"Production rule {self.name} is referenced but not defined"
            )
        return friendly.canonical(name=name, g=g)


class FriendlyNode:
    def __init__(self, symbol, token, children):
        self.symbol = symbol
        self.token = token
        self.children = children

    def __repr__(self):
        return f"<Node symbol={self.symbol} token={self.token} children={len(self.children)}>"

    def pp(self, indent=""):
        s = f"{indent}{self!r}\n"
        for child in self.children:
            s += f'{child.pp(indent+"    ")}\b'
        return s


class CHOICE(FriendlyObject):
    """
    A set of alternatives in the grammar

    Primarly intended for internal use in FriendlyObject (really just the T class in practical applications)
    """

    def __init__(self, *args):
        super(CHOICE, self).__init__()
        self.children = list(args)

    def __or__(self, other):
        if other is None:
            return self
        self.children.append(other)
        return self

    def canonical(self, name, g):
        for index, child in enumerate(self.children):
            g[f"__{name}_CHOICE"] = child.canonical(
                name=f"_%s_CHOICE%d" % (name, index + 1), g=g
            )
        nt = parser.NonTerminal(f"__{name}_CHOICE")
        self.copyAttributes(nt)
        return [nt]

    @classmethod
    def collapse(cls, node):
        return node.children[0].symbol.f.collapse(node.children[0])


class SEQUENCE(FriendlyObject):
    """
    A sequence of symbols in the grammar

    Primarly intended for internal use in FriendlyObject (really just the T class in practical applications)
    """

    def __init__(self, *args):
        super(SEQUENCE, self).__init__()
        self.children = list(args)

    def __add__(self, other):
        if other is None:
            return self
        self.children.append(other)
        return self

    def canonical(self, name, g):
        l = []
        for index, child in enumerate(self.children):
            l += child.canonical(name=f"__{name}_SEQ{index+1}", g=g)

        # we put these in a separate rule rather than returning l simply so that there is somewhere to keep facts from the sequence
        g[f"__{name}_SEQ"] = l
        nt = parser.NonTerminal(f"__{name}_SEQ")
        self.copyAttributes(nt)
        return [nt]

    @classmethod
    def collapse(cls, node):
        return chain([i.symbol.f.collapse(i) for i in node.children])


class REPEAT(FriendlyObject):
    """
    A repeated sequence of symbols

    Primarly intended for internal use in FriendlyObject (really just the T class in practical applications)
    """

    def __init__(self, arg):
        super(REPEAT, self).__init__()
        self.children = [arg]

    def __mul__(self, other):
        assert False, "Cannot repeat an already repeated sequence"

    def canonical(self, name, g):
        nt = parser.NonTerminal(name + "_REP")
        self.copyAttributes(nt)

        l = []
        for index, child in enumerate(self.children):
            l += child.canonical(name=f"__{name}_REP{index+1}", g=g)

        g[f"__{name}_REP"] = []
        g[f"__{name}_REP"] = l
        g[f"__{name}_REP"] = l + [nt]

        return [nt]

    @classmethod
    def collapse(cls, node):
        return chain([i.symbol.f.collapse(i) for i in node.children])


class OPTIONAL(FriendlyObject):
    """
    An optional symbol in the grammar

    Primarly intended for internal use in FriendlyObject (really just the T class in practical applications)
    """

    def __init__(self, item):
        super(OPTIONAL, self).__init__()
        self.children = [item]

    def canonical(self, name, g):
        g[f"__{name}"] = []
        g[f"__{name}"] = self.children[0].canonical(f"__{name}_OPT", g)

        nt = parser.NonTerminal(f"__{name}")
        self.copyAttributes(nt)
        return [nt]

    @classmethod
    def collapse(cls, node):
        return node.children[0].symbol.f.collapse(node.children[0])


class T(FriendlyObject):
    """
    A terminal symbol in the grammar
    """

    def __init__(self, name, condition=None):
        super(T, self).__init__()
        self.name = name
        if condition:
            self.condition = condition

    def canonical(self, name, g):
        t = parser.Terminal(self.name)
        self.copyAttributes(t)
        return [t]

    def scan(self, s):
        toMatch = s[: len(self.name)]
        if getattr(self, "case", False):
            matched = self.name == toMatch
        else:
            matched = self.name.lower() == toMatch.lower()

        if matched:
            return parser.Token(toMatch), len(toMatch)
        else:
            return None, 0

    @classmethod
    def collapse(cls, node):
        return [FriendlyNode(symbol=node.symbol.f, token=node.token, children=[])]


class PT(T):
    """
    A terminal symbol that matches a regular expression
    """

    def __init__(self, name, condition=None):
        super(PT, self).__init__(name, condition=condition)
        self.pattern = re.compile(name)

    def scan(self, s):
        matched = self.pattern.match(s)
        if matched:
            return parser.Token(self.name, s[: matched.end()]), matched.end()
        else:
            return None, 0


class NT(FriendlyObject):
    """
    An nonterminal symbol in the grammar

    Primarly intended for internal use by FriendlyObject since an NT for MYRULE can be created by referencing g.MYRULE
    """

    def __init__(self, name, condition=None):
        super(NT, self).__init__()
        self.name = name
        self.production = []
        if condition:
            self.condition = condition

    def canonical(self, name, g):
        nt = parser.NonTerminal(self.name)
        self.copyAttributes(nt)
        return [nt]

    @classmethod
    def collapse(cls, node):
        children = chain([i.symbol.f.collapse(i) for i in node.children])
        return [FriendlyNode(symbol=node.symbol.f, token=node.token, children=children)]


class N:
    """
    An empty object we keep around so we can do (T('a') + T('b')) * N to represent a repeteated sequence
    """


class UIT(T):
    """
    A terminal symbol that has some interactive component (used by UI implementations of Compositor)
    """

    def __init__(self, name=None, structure=None, condition=None):
        FriendlyObject.__init__(self)
        if name is None:
            name = self.__class__.__name__
        self.name = name
        self.structure = structure
        if condition:
            setattr(self, condition)

    def getDisplayString(self, value):
        return str(value)

    def reduce(self, ctx, node):
        return node.token.value


def isUIT(o):
    return isinstance(o, UIT)
