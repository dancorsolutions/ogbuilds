"""
Modified Earley-style (chart) parser supporting autocompletion and other properties needed for compositor
This is a significant modification of standard chart parsing: the parser maintains distinct edges for different possible
parse trees and maintains links between edges that allow the tree to be walked efficiently. This is designed to allow
contextual grammars and other additions that depend on being able to build up a parse tree as we parse the token string.

N.B. that the parse chart we use here, which differs from Early in that edges are duplicated where there are ambugious
paths through the grammar, does not add any more *information* to the chart -- it only adds links that make it efficient
to traverse the chart in various ways (tests without these edge.parent/edge.children links implementing accurate 
parse-tree generation code for grammars needing significant lookahead have proven *very* slow)      

This parser is standalone: it will work *without* any of the other packages in compositor2 and is designed to be easy
to recode in C++ etc. if necessary for speed (though it is currently more than fast enough for a sentence building GUI).
"""

__all__ = ['ParseError', 'Grammar', 'Symbol', 'NonTerminal', 'Terminal', 'isNT', 'isT', 'Token', 'NODEFAULT',
           'EdgeContext', 'Edge', 'ParseNode', 'Parser']

class ParseError(Exception):
	"""
	Errors parsing the input string
	"""



class Grammar(object):
	"""
	Represents a complete grammar
	Named rules are in the form:
		name -> [production1,production2,...]
		production1 -> <seqeunce of terminal and non-terminal grammamr nodes>
	"""

	def __init__(self):
		self.rules = {}

	def __iter__(self):
		for k,v in self.rules.items():
			yield k,v

	def __getitem__(self,k):
		return self.rules[k]

	def __setitem__(self,k,v):
		if k not in self.rules:
			self.rules[k] = []
		self.rules[k].append(v)

	def pp(self):
		s = ''
		for name,rhs in sorted(self.rules.items()):
			for production in rhs:
				s += '%s -> %s\n'%(name,' '.join([i.pp() for i in production]))
		return s


class Symbol(object):
	""" Common base class for all symbols in the grammar """
	


class NonTerminal(Symbol):
	""" A non-terminal in the grammar """

	def __init__(self,name):
		self.name = name

	def __eq__(self,other):
		if not isinstance(other,NonTerminal): return False
		return self.name == other.name

	def __ne__(self,other):
		return not self.__eq__(other)

	def __hash__(self):
		return hash(self.name)

	def __repr__(self):
		return '<%s %s>'%(self.__class__.__name__,self.name)
	
	def pp(self):
		return '%s'%(self.name)



class Terminal(Symbol):
	""" A terminal in the grammar """

	def __init__(self,name):
		self.name = name

	def __eq__(self,other):
		if not isinstance(other,Terminal): return False
		return self.name == other.name

	def __ne__(self,other):
		return not self.__eq__(other)

	def __hash__(self):
		return hash(self.name)

	def __repr__(self):
		return '<%s %s>'%(self.__class__.__name__,self.name)

	def match(self,token):
		return token.name == self.name

	def pp(self):
		return '[%s]'%(self.name)



def isNT(o):
	""" Return true if the symbol is a nonterminal """
	return isinstance(o,NonTerminal)


def isT(o):
	""" Return true if the symbol is a terminal """
	return isinstance(o,Terminal)


class Token(object):
	""" Token """
	def __init__(self,name,value=None):
		self.name = name
		self.value = value

	def __repr__(self):
		if self.value is None:
			return '<%s %s>'%(self.__class__.__name__,self.name)
		else:
			return '<%s %s=%s>'%(self.__class__.__name__,self.name,self.value)
		


class NODEFAULT(object):
	pass



class EdgeContext(object):
	""" 
	A context object used to identify a location on a parse edge
	
	Used for navigating the edge tree without having to build a separate parse tree first. This is designed to 
	be used on an incomplete parse chart before a parse tree can be built. For operations that need to query a
	completed parse chart building a parse tree and then using queries on that should be simpler, more 
	reliable, and more efficient.
	 
	The most significant use for this is to have one UITerminal depend on the value of another UITerminal.
	
	This functionality is still a bit rough around the edges (e.g. how it handles symbols/tokens that are in
	the current edge for down/up functions -- it ignores them) but it should work for most purposes.
	N.B. using this to build parse conditions is not for the faint of heart: we're essentially altering the 
	grammar while parsing a string and it's very easy to build broken user experiences with this by e.g.
	having a later part of the grammar depend on a value in a UITerminal in an earlier part -- this will
	work when you're building a string from scratch but break horribly if a user edits the UITerminal while
	a full string exists!  
	"""
	
	def __init__(self,edge,at,parser):
		self.edge = edge
		self.at = at
		self.parser = parser
		
	
	@property
	def symbol(self):
		return self.edge.rule[self.at]

	
	@property
	def token(self):
		if not isT(self.symbol):
			return None
		return self.edge.children[self.at]
		
		
	@property
	def parent(self):
		if not self.edge.parent:
			return None
		pe = self.edge.parent
		
		if self.edge in pe.children:
			index = pe.children.index(self.edge)
		elif self.edge.label in pe.rule:
			index = pe.rule.index(self.edge.label)
		else:
			raise ValueError('Could not figure out our location in the parent edge:\n edge=%r\n parent=%r'%(self.edge,pe))
		
		return EdgeContext(edge=self.edge.parent,at=index,parser=self.parser)
	
	
	def parents(self):
		p = self.parent		
		if not p:
			return []
		return [p] + p.parents()
		
		
	def up(self,**kargs):
		""" 
		Support function for reducers/conditions/UI terminals 
		
		Return an EdgeContext for the first symbol/token in an edge that is a parent of this one matching the
		test criteria specified by keyword arguments.
		"""
		
		if not self.parent:
			return None

		for ec in self.parents():
			if ec != self and ec.test(**kargs):
				return ec

		
	def down(self,**kargs):
		""" 
		Support function for reducers/conditions/UI terminals 
		
		Return an EdgeContext for the first symbol/token in an edge that is a child of this one matching the
		test criteria specified by keyword arguments.
		"""

		chartPosition = self.edge.start
		for index in range(len(self.edge.rule)):
			ec = EdgeContext(edge=self.edge,at=index,parser=self.parser)
			if ec.test(**kargs):
				return ec
			if isT(self.edge.rule[index]):
				chartPosition += 1
			else:
				if(index < len(self.edge.children)):
					# There's already a fully-parsed child edge for this so we'll recurse on that
					chartPosition = self.edge.children[index].end
					rc = EdgeContext(edge=self.edge.children[index],at=0,parser=self.parser).down(**kargs)
					if rc:
						return rc
				else:
					# There isn't a fully-parsed child edge on the current edge so we'll have to look for a candidate
					candidates = self.parser.find(longest=True,start=chartPosition,label=self.edge.rule[index])
					for candidate in candidates:
						rc = EdgeContext(edge=candidate,at=0,parser=self.parser).down(**kargs)
						if rc:
							return rc

	def all(self,**kargs):
		""" 
		Support function for reducers/conditions/UI terminals 
		
		Return a lst of EdgeContexts for symbols/tokens in edges that are children of this one and matching 
		test criteria specified by kargs.
		"""
		
		out = []
		
		chartPosition = self.edge.start
		for index in range(len(self.edge.rule)):
			ec = EdgeContext(edge=self.edge,at=index,parser=self.parser)
			if ec.test(**kargs):
				out.append(ec)
			if isT(self.edge.rule[index]):
				chartPosition += 1
			else:
				if(index < len(self.edge.children)):
					# There's already a fully-parsed child edge for this so we'll recurse on that
					chartPosition = self.edge.children[index].end
					out += EdgeContext(edge=self.edge.children[index],at=0,parser=self.parser).all(**kargs)
				else:
					# There isn't a fully-parsed child edge on the current edge so we'll have to look for a candidate
					candidates = self.parser.find(longest=True,start=chartPosition,label=self.edge.rule[index])
					for candidate in candidates:
						out += EdgeContext(edge=candidate,at=0,parser=self.parser).all(**kargs)
						break # this is a kludge: there could be multiple alternate parses: we pick one at random here

		return out
	
	
	def test(self,name=NODEFAULT,value=NODEFAULT):
		""" Test for a match against query criteria (used for up/down/all methods) """

		if name is not NODEFAULT and not self.symbol.name == name:
			return False
		if value is not NODEFAULT and not self.token.value == value:
			return False
			
		return True
	
	
	def __repr__(self):
		return '<EdgeContext edge@%d=%r>'%(self.at,self.edge)

	
	def __eq__(self,other):
		if self.edge == other.edge and self.at == other.at:
			return True

	def __ne__(self,other):
		if self.edge == other.edge and self.at == other.at:
			return False
		else:
			return True



class Edge(object):
	"""
	Class representing an edge in the chart
	This is a generic chart-parsing data type but includes information on the edge's children which is part
	of what defines uniqueness for an edge.
	"""

	def __init__(self,start,end,label,found,remainder):
		self.start = start
		self.end = end
		self.label = label
		self.found = found
		self.remainder = remainder
		self.children = []
		self.parent = None


	@property
	def active(self):
		if self.remainder:
			return True
		else:
			return False


	@property
	def next(self):
		if self.remainder:
			return self.remainder[0]
		else:
			return None


	@property
	def rule(self):
		return self.found + self.remainder


	def __eq__(self,other):
		if not isinstance(other,Edge): return False
		return (self.start,self.end,self.label,self.found,self.remainder,self.children) == (other.start,other.end,other.label,other.found,other.remainder,other.children)


	def __ne__(self,other):
		return not self.__eq__(other)


	def __hash__(self):
		return hash((self.start,self.end,self.label,tuple(self.found),tuple(self.remainder),tuple(self.children)))


	def pp(self,withParent=False):
		found = ' '.join([i.pp() for i in self.found])
		if found:
			found += ' '
		remainder = ' '.join([i.pp() for i in self.remainder])
		if withParent and self.children is not None:
			return '<%s %s-%s %s => %s. %s> (children = %r)'%(self.__class__.__name__,self.start,self.end,self.label.pp(),found,remainder,self.children)
		else:
			return '<%s %s-%s %s => %s. %s>'%(self.__class__.__name__,self.start,self.end,self.label.pp(),found,remainder)


	def __repr__(self):
		return self.pp()



class ParseNode(object):
	""" A node in a parse tree """

	def __init__(self,symbol,rule=None,token=None):
		self.symbol = symbol
		self.rule = rule
		self.token = token
		
		self.children = []
		self.parent = None


	@property
	def terminal(self):
		return isinstance(self.symbol,Terminal)
	
	@property
	def complete(self):
		if isT(self.symbol):
			return True
		return len(self.children) == len(self.rule)
	

	def pp(self,indent=''):
		complete = '$' if self.complete else ''
		if self.token is None:
			s = indent + '%s%s -> %s\n'%(complete,self.symbol.pp(),' '.join([i.pp() for i in self.rule]))
		else:
			s = indent + '%s%s matched %r\n'%(complete,self.symbol.pp(),self.token)
		for child in self.children:
			s += child.pp(indent=indent+'  ')
		return s

	def __repr__(self):
		return f'<ParseNode token={self.token} symbol={self.symbol} rule={self.rule} children={len(self.children)}>'



class Parser(object):
	"""	Generic chart parser class with specific initialization/steering/completion functions to implement an Earley parser """
	
	def __init__(self,grammar,session=None):
		self.grammar = grammar
		self.session = session
		self.chart = set()
		self.agenda = list()
		self.tokens = list()

		self.doInitialization()
		self.closure()


	def find(self,start=None,end=None,label=None,active=None,next=None,parent=None,longest=False):
		""" Find an existing edge in the chart """
		# This could potentially be speeded up with a dict of sets of edges for one or more of the search criteria (<end> would be a good candidate)
		out = []


		for edge in self.chart:
			if start is not None and start != edge.start: continue
			if end is not None and end != edge.end: continue
			if label is not None and label != edge.label: continue
			if active is not None and active != edge.active: continue
			if next is not None and next != edge.next: continue
			if parent is not None and parent != edge.parent: continue
			out.append(edge)

		if longest:
			# this flag excludes edges that are less fully parsed versions of other edges in the output list
			new = []
			for edge in out:
				if edge.active and [e for e in out if e is not edge and e.start == edge.start and e.label == edge.label and e.rule == edge.rule and len(e.found) > len(edge.found)]:
					continue
				else:
					new.append(edge)
			return new
		else:
			return out


		
	def parse(self,tokens,ignoreErrors=False):
		""" Parse a list of tokens """

		tokens = list(tokens)
		contexts = []
		try:
			while tokens:
				token = tokens.pop(0)
				contexts.append(self.parseOne(token))
		except ParseError:
			if ignoreErrors:
				return contexts
			else:
				raise

		return contexts
			
		

	def parseOne(self,token,symbol=None):
		""" 
		Parse a token 
		
		If we already know what symbol in the grammar it should be parsed with we use that. This is useful when are 
		building expressions via a UI and the user has chosen a specific symbol to add. It is parsed by adding a 
		single token to the token list and updating the parse tree.
		
		If we don't know the next symbol the parse tries to find a matching symbol and raises a ParseError if no
		matching symbol exists at this point in the grammar.
		"""
		
		ec = None

		if not symbol:
			symbols = self.autocomplete()
			matches = [i for i in symbols if i.match(token)]
			if not matches:
				raise ParseError('Unexpected token %r at index %d (expected one of %r)'%(token,len(self.tokens),symbols))
			symbol = matches[0]
			
		self.tokens.append(token)
		for edge in self.find(active=True,end=len(self.tokens)-1,next=symbol):
			added = self.doSteering(edge)
			if added:
				ec = EdgeContext(edge=added[0],at=len(added[0].found)-1,parser=self)
		self.closure()
		
		if not ec:
			raise ParseError('Attempt to parse token %r at index %d with supplied symbol %r failed'%(token,len(self.tokens),symbol))
		
		return ec
		
	
	def closure(self):
		""" Execute a transitive closure on the existing edges in the chart """

		while self.agenda:
			edge = self.agenda.pop(0)
			
			if edge in self.chart:
				# this is never reached in this modified form of Earley because the edge.children is used to evaluate uniqueness
				# (this defeats some of Early's memoization but is necessary for the way we will use the chart in future)
				continue

			self.doCompletion(edge)
			self.doSteering(edge)

			self.chart.add(edge)
			

	def doInitialization(self):
		""" Load initial edges based on the root node of the grammar """
		for production in self.grammar['ROOT']:
			self.agenda.append(Edge(0,0,NonTerminal('ROOT'),[],production))


	def doSteering(self,added):
		""" 
		Complete the added edge by adding edges to its end position based on grammar rules 
		Look for rules that *start* with the first Terminals/NonTerminals that appears at in the *remainder* of the added edge 
		"""
		
		done = []
		
		if not added.active:
			return done

		if isT(added.next):
			if added.end < len(self.tokens) and added.next.match(self.tokens[added.end]):
				edge = Edge(added.start,added.end+1,added.label,added.found + added.remainder[0:1],added.remainder[1:])
				edge.parent = added.parent # (used to support up/down/all methods on edges for conditionalization etc.)
				edge.children = added.children + [self.tokens[added.end]] # (used to support up/down/all methods on edges for conditionalization etc.)
				if hasattr(added.next,'condition'):
					if not added.next.condition(self.session,EdgeContext(edge,len(edge.children)-1,parser=self)):
						return done
				self.agenda.append(edge)
				done.append(edge)
		else:
			for production in self.grammar[added.next.name]:
				edge = Edge(added.end,added.end,added.next,[],production)
				edge.parent = added # (used to support up/down/all methods on edges for conditionalization etc.)
				if hasattr(added.next,'condition'):
					if not added.next.condition(self.session,EdgeContext(added,len(added.children),parser=self)):
						continue
				self.agenda.append(edge)
				done.append(edge)
				
		return done


	def doCompletion(self,added):
		""" Do transitive closure/completion (execute the 'fundamental rule' of chart parsing) """
		if added.active:
			return
		for edge in self.find(active=True,end=added.start,next=added.label):
			newEdge = Edge(edge.start,added.end,edge.label,edge.found + edge.remainder[0:1],edge.remainder[1:])
			newEdge.children = edge.children + [added] # this line is critical to our modification of Earley
			newEdge.parent = edge.parent # (used to support up/down/all methods on edges for conditionalization etc.)
			for child in newEdge.children: # (used to support up/down/all methods on edges for conditionalization etc.)
				child.parent = newEdge  # (used to support up/down/all methods on edges for conditionalization etc.)
			self.agenda.append(newEdge)


	#
	# UTILITY FUNCTIONS
	#

	# These functions are not used by the main parsing process but are designed to help applications examine the parse chart in various ways.


	def autocomplete(self):
		""" 
		Find edges ending at the end of the string 
		Returns a list of lists of terminals
		"""
		done = set()
		out = list()
		edges = self.find(active=True,end=len(self.tokens))
		for edge in edges:
			if edge.remainder and isT(edge.remainder[0]):
				if edge.remainder[0] not in done:
					if hasattr(edge.remainder[0],'condition'):
						if not edge.remainder[0].condition(self.session,EdgeContext(edge,len(edge.children),parser=self)):
							continue
					done.add(edge.remainder[0])
					out.append(edge.remainder[0])

		return out


	def isComplete(self):
		""" Return True if the input represents a complete parsed sentence """
		if self.find(active=False,label=NonTerminal('ROOT'),start=0,end=len(self.tokens)):
			return True
		else:
			return False


	def getParseTrees(self,limit=None):
		""" 
		Reconstruct all complete parse tree for a parsed string using the edges in the chart 
		N.B. that there is no requirement on grammars that each expression can only be parsed one way. This module supports grammars that 
		are ambiguous as to how an expression should be parsed by being able to maintain and return a set of complete parse trees.
		"""

		# There will be exactly one distinct parse tree for each inactive edge that starts with ROOT and spans the whole string 
		rootEdges = self.find(active=False,label=NonTerminal('ROOT'),start=0,end=len(self.tokens))

		def buildTree(node,edge,tokenIndex=0):
			for symbol,child in zip(edge.found,edge.children):
				if isT(symbol):
					newNode = ParseNode(symbol=symbol,token=child)
					tokenIndex += 1
					node.children.append(newNode)
				else:
					newEdge = child
					newNode = ParseNode(symbol=symbol,rule=newEdge.found + newEdge.remainder)
					node.children.append(newNode)
					buildTree(newNode,edge=newEdge,tokenIndex=tokenIndex)


		trees = []
		for e in rootEdges:
			node = ParseNode(symbol=e.label,rule=e.found + e.remainder)
			trees.append(node)
			buildTree(node,e)
			if limit and limit >= len(trees):
				break

		return trees

