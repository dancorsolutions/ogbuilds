from . parser import *


class ScanningParser(Parser):
	"""
	A parser with context-sensitive in-built tokenizing

	This parser depends on grammar.py and friendly grammars including canonical terminals with the .original attribute
	and friendly terminals with a .scan method.
	"""

	def scan(self,s):

		if not s:
			return [],''

		scanned = 0
		matchedScanned = 0
		contexts = []

		while scanned < len(s):

			# find any possible terminals in the grammar
			terminals = super(ScanningParser,self).autocomplete()
			matched = []
			for terminal in terminals:
				if not isT(terminal):
					continue
				token,count = terminal.original.scan(s[scanned:])
				if not count:
					continue
				matched.append((token,terminal,count))

			if not matched:
				break

			# keep only the longest matching tokens
			maxLength = max([i[2] for i in matched])
			found = {i[0].name:i for i in matched if i[2] == maxLength}

			if len(found) > 1:
				raise ParseError(
					'Ambiguity found while scanning %s|%s %r'%(s[:scanned], s[scanned:], found)
				)

			v = list(found.values())[0]
			context = self.parseOne(v[0],v[1])
			context.token.characters = (scanned,scanned+v[2])
			contexts.append(context)

			scanned += v[2]
			matchedScanned = scanned

			while scanned < len(s) and s[scanned] == ' ':
				scanned += 1

		return contexts,s[matchedScanned:]


	def getParseTrees(self,limit=None):
		"""
		Reconstruct all complete parse tree for a parsed string using the edges in the chart
		N.B. that there is no requirement on grammars that each expression can only be parsed one way. This module supports grammars that
		are ambiguous as to how an expression should be parsed by being able to maintain and return a set of complete parse trees.
		"""

		# There will be exactly one distinct parse tree for each inactive edge that starts with ROOT and spans the whole string
		rootEdges = self.find(active=False,label=NonTerminal('ROOT'),start=0,end=len(self.tokens))

		def buildTree(node,edge,tokenIndex=0):
			for symbol,child in zip(edge.found,edge.children):
				if isT(symbol):
					newNode = ParseNode(symbol=symbol,token=child)
					tokenIndex += 1
					node.children.append(newNode)
				else:
					newEdge = child
					newNode = ParseNode(symbol=symbol,rule=newEdge.found + newEdge.remainder)
					node.children.append(newNode)
					buildTree(newNode,edge=newEdge,tokenIndex=tokenIndex)


		trees = []
		for e in rootEdges:
			node = ParseNode(symbol=e.label,rule=e.found + e.remainder)
			trees.append(node)
			buildTree(node,e)
			if limit >= len(trees):
				break

		return trees

