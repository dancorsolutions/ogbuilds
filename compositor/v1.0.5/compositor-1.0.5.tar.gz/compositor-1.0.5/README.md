compositor2
===========

Compositor quasi-natural-language UX element
