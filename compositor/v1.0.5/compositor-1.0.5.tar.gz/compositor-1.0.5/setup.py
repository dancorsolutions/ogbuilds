from setuptools import setup, find_packages
import os

f = open(os.path.join(os.path.dirname(__file__), 'README.md'))
long_description = f.read()
f.close()

setup(
    name='compositor',
    version='1.0.1',
    description='partial parsing for rule-based and dialogue systems',
    long_description=long_description,
    author='Oren Goldschmidt',
    author_email='oren@andalso.net',
    url='http://og200.github.io/compositor2/',
    packages=find_packages(),
)
