"""
Cryptographically secure long-lived login tokens (for use in long-lived tokens).
"""

import datetime

from roundtrip.scaffolding.utils.crypto import crypto
from roundtrip.scaffolding.config.config import config


def make_token(user):
    return crypto.encrypt(str(user.id) + "|" + datetime.datetime.now(datetime.UTC).isoformat())


def check_token(enc_token):
    try:
        [user_id, created] = crypto.decrypt(enc_token).split("|")
        if datetime.datetime.now(datetime.UTC) - datetime.datetime.fromisoformat(created) < datetime.timedelta(
            hours=config.login_token_expiry
        ):
            return user_id
    except:
        return None
