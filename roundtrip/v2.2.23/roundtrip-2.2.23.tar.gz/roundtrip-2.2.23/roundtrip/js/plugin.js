import { Application } from "./application"

export var rt_call_server_method = function ({
    name,
    data,
    spinner,
    throttle,
    cancelable,
}) {
    let e = {
        name: name,
        target: this.$rtIsLinked ? this._uid.toString() : null,
        className: this.$options.name,
        origin: this,
    }
    if (data !== undefined) e.data = data
    if (spinner) e.spinner = spinner
    if (throttle) e.throttle = throttle
    if (cancelable) {
        e.cancelable = cancelable
    }
    return this.$rt.onevent(e)
}

export var RTLinkedMixin = {
    created() {
        this.$rtIsLinked = true
        this.$rt.componentCreated(this)
    },
    beforeUnmount() {
        this.$rt.componentUnmounted(this)
    },
}

export var RTRootMixin = {
    created() {
        this.$rtIsLinked = true
        this.$rt.componentCreated(this, true)
    },
    beforeUnmount() {
        this.$rt.componentUnmounted(this)
    },
    mounted() {
        this.$rt.syncManager.markClean()
    },
}

export var RTPlugin = {
    install(app, options) {
        app.config.globalProperties.$rt = new Application(app, options)
        app.config.globalProperties.$rt_call_server_method =
            rt_call_server_method
    },
}
