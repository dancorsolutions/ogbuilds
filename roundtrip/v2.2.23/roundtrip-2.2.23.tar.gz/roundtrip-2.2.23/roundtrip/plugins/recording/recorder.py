"""
Session recording for automated test creation

These classes are used by applications to record sessions and turn them into automated tests.
The tests can be used to test backend-only, frontend-only, and both together.
"""

import datetime
import weakref
import pprint
import os.path


class SimpleRecordingManager(object):
    def __init__(self, path):
        self.path = path

    def attach(self, connection):
        connectionRecorder = SimpleConnectionRecorder(connection=connection, path=self.path)
        connection.recorder = connectionRecorder


class SimpleConnectionRecorder(object):
    def __init__(self, connection, path):
        self.connection = weakref.proxy(connection)
        self.path = path
        self.events = []

        self.file = os.path.join(path, "%s" % connection.connectionId, "wt")

    def asServerTest(self, indent=""):
        s = ""
        for event in self.events:
            if isinstance(event, C2S):
                s += indent + "rc = app.handleEvent(%s)\n" % event.asCode()
            elif isinstance(event, S2C):
                s += indent + "assert(rc == %s)\n" % event.asCode()
        return s

    def asClientTest(self, indent=""):
        pass

    def asUnifiedTest(self, indent=""):
        s = ""
        lastEvent = None
        for event in self.events:
            if isinstance(event, C2S):
                if lastEvent:
                    s += "gen.sleep(%r)" % ((event.time - lastEvent.time).total_seconds())
                s += indent + "payload = app.handleEvent(%s)\n" % event.asCode()
                s += indent + "handler.write_message(payload.encode())\n"
        return s

    def c2s(self, event):
        self.events.append(C2S(event))
        print(self.events[-1].asCode(), end="")

    def s2c(self, payload):
        self.events.append(S2C(payload))
        print(self.events[-1].asCode(), end="")


class C2S(object):
    def __init__(self, event, time=None):
        if time is None:
            time = datetime.datetime.now()
        self.time = time
        self.event = event

    def asCode(self):
        s = "    C2S(time=%r, event=%s),\n" % (self.time, pprint.pformat(self.event))
        return s

    def __repr__(self):
        return "<C->S>\n%s\n" % (pprint.pformat(self.event, indent=2))


class S2C(object):
    def __init__(self, message, time=None):
        if time is None:
            time = datetime.datetime.now()
        self.time = time
        self.message = message

    def asCode(self):
        s = "    S2C(time=%r, message=%s),\n" % (self.time, pprint.pformat(self.message.__dict__))
        return s

    def __repr__(self):
        return (
            "<S->C>\n  kind=%(kind)s\n  exception=%(exception)s\n  payload=%(payload)s\n  stateDeltas=%(stateDeltas)s\n"
            % dict(
                kind=self.message.kind,
                payload=self.message.payload,
                exception=self.message.exception,
                stateDeltas=pprint.pformat(self.message.stateDeltas, indent=2),
            )
        )


class Runner(object):
    def __init__(self):
        pass

    def run(self):
        pass
