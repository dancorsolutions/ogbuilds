import logging
import os

import mongoengine

from roundtrip.scaffolding.config import config
from roundtrip.scaffolding.utils.crypto import crypto

import venia
from venia.models import all as m

__all__ = ["m", "connect", "config", "logger"]

path = None
logger = None


def connect():
    global path, logger

    logging.basicConfig(level=logging.WARNING)

    logging.getLogger("root").setLevel(logging.DEBUG)
    logging.getLogger("script").setLevel(logging.DEBUG)
    logger = logging.getLogger("script")

    path = os.path.split(venia.__file__)[0]

    if os.path.exists("/var/venia/etc"):
        config._setup("/var/venia/etc", schema_path=path + "/config/config_schema.yaml", use_args=False)
    else:
        config._setup(path + "/config", use_args=False)

    mongoengine.connect(host=config.mongo.uri)

    crypto.setup(config.crypto_password)


if __name__ == "__main__":
    connect()
