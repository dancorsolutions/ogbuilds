import os
import sys
import logging
import warnings


def install(logger):
    def showwarning(message, category, filename, lineno, file=None, line=None):
        if file:
            print(f"WARNING: {message}", file=sys.stderr)
            return
        message = warnings.formatwarning(message, category, filename, lineno, line)
        logger.warning(message)

    warnings.showwarning = showwarning
