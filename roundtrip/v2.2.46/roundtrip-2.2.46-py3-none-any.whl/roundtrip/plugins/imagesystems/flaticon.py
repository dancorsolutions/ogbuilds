"""
An ImageSystem that fetches icons from flaticon.com automatically and stores them locally given an icon id
"""

import requests
from . import imagesystem
import os.path

__all__ = ["ImageSystem"]


class ImageSystem(imagesystem.ImageSystem):
    def __init__(self, *args, **kargs):
        super(ImageSystem, self).__init__(*args, **kargs)
        self.api_key = "b34e0f3d1c05c37d8f57caf6566044808358618a"
        self.token = None

    def ensure(self, iconId):
        iconId = str(iconId)
        key = "flaticon-%s" % iconId
        fName = os.path.join(self.fsPath, key) + ".svg"
        self.images[fName] = key
        if os.path.exists(fName):
            return key
        if self.token is None:
            r = requests.post("https://api.flaticon.com/v2/app/authentication", data=dict(apikey=self.api_key))
            self.token = "Bearer " + r.json()["data"]["token"]
        r = requests.get(
            "https://api.flaticon.com/v2/item/icon/download/%s/svg" % iconId,
            data=dict(format="svg"),
            headers=dict(Authorization=self.token),
        )
        assert r.status_code == 200
        open(fName, "wb").write(r.text.encode("latin-1"))
        return key

    def svg(self, iconId):
        key = self.ensure(iconId)
        return imagesystem.ImageReference("app.images[%r]" % key)
