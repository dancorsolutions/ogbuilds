"""
Roundtrip base classes

"""
import weakref

__all__ = ["RoundtripError", "proxy"]


class RoundtripError(Exception):
    """Base exception"""

    pass


class TemplateError(Exception):
    """Error in use of a template"""

    pass


def proxy(o):
    if isinstance(o, weakref.ProxyType):
        return o
    else:
        return weakref.proxy(o)


class OutOfSyncError(RoundtripError):
    """Server out of sync with client"""

    pass
