__all__ = ["StatsProvider"]

from .base import *
from ....server import stats


class StatsProvider(Provider):
    ident = "stats"

    statsData = ConfigItem(object, required=True)

    def handlers(self):
        return [
            (
                "/stats",
                stats.StatsHandler,
                dict(connectionManager=self.server.connectionManager, **self.server.config.stats),
            )
        ]
