from pathlib import Path
import warnings
import re

from .component import kebabToPascal, pascalToKebab, ExternalMetaclass, External

__all__ = ["CoreUIResolver", "DevExtremeResolver"]


def tag_to_file_names(tag_name):
    candidates = {tag_name}
    if "-" in tag_name:
        candidates.add(kebabToPascal(tag_name))
        candidates.add(tag_name.replace("-", ""))
        candidates.add(tag_name.replace("-", "").lower())
    else:
        candidates.add(pascalToKebab(tag_name))
        candidates.add(kebabToPascal(tag_name))
        candidates.add(tag_name.lower())
    return candidates


class BaseResolver:
    """
    Resolver for a collections of components
    """

    def __init__(self, node_modules: str or Path):
        self.node_modules = Path(node_modules) if isinstance(node_modules, str) else node_modules
        self.read()

    def read(self):
        return

    def make_class(self, component_name: str, file: Path):
        import_path = file.relative_to(self.node_modules)
        ExternalMetaclass.__new__(
            ExternalMetaclass,
            component_name,
            (External,),
            dict(imports={f"import {{ {component_name} }} from '{import_path}'"}),
        )


class DevExtremeResolver(BaseResolver):
    """
    Resolver for DevExtreme components
    """

    PAT_EXPORTS = re.compile(r"export \{(.*)}")

    def __init__(self, node_modules: str or Path):
        super().__init__(node_modules)
        self.components = dict()

    def read(self):
        for file in list(self.node_modules.glob("devextreme-vue/esm/**/*.js")):
            text = file.open("rt").read()
            for i in self.PAT_EXPORTS.findall(text):
                for component in [x.strip() for x in i.split(",")]:
                    cn = component.lower()
                    if not cn.startswith("dx") or "_" in cn:
                        # an export of something other than a component
                        continue
                    if cn in self.components:
                        # the component name already exists (this is an ambiguous name that appears in different .js files so we will add a prefix)
                        old_component, old_file = self.components[cn]
                        old_prefix = "Dx" + kebabToPascal(old_file.stem)
                        new_prefix = "Dx" + kebabToPascal(file.stem)
                        if old_component != old_prefix:
                            # the old component is not the canonical one, add a prefix to its entry in self.components
                            del self.components[cn]
                            self.components[old_prefix.lower() + old_component[2:].lower()] = (
                                old_prefix + old_component[2:],
                                old_file,
                            )
                        if component != new_prefix:
                            # the new component is not the canonical one, add a prefix to its entry in self.components
                            self.components[new_prefix.lower() + component[2:].lower()] = (component, file)
                        else:
                            # the new component *is* the canonical one so it gets to replace the old one as the one accessed with no prefix
                            self.components[cn] = (component, file)
                    else:
                        self.components[cn] = (component, file)

            for cn, (component, file) in self.components.items():
                self.make_class(cn, file)

    def make_class(self, component_name: str, file: Path):
        import_path = file.relative_to(self.node_modules)
        ExternalMetaclass.__new__(
            ExternalMetaclass,
            component_name,
            (External,),
            dict(imports={f"import {component_name} from '{import_path}'"}),
        )


class CoreUIResolver(BaseResolver):
    """
    Resolver for CoreUI Vue components
    """

    def read(self):
        if not self.node_modules.exists():
            raise RuntimeError(f"{self.node_modules} does not exist")
        location = self.node_modules / "@coreui/vue-pro/dist/esm/components"
        found = list(location.glob("**/C*.js"))
        if not found:
            raise RuntimeError(f"{self.node_modules} does not exist")
        for file in found:
            self.make_class(file.stem, file)
