#!/usr/bin/env python
import os

from setuptools import setup, find_packages


def package_files(directory):
    paths = []
    for path, directories, filenames in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.join(path, filename))
    return paths


f = open(os.path.join(os.path.dirname(__file__), "README.md"))
long_description = f.read()
f.close()

setup(
    name="{{ system_name }}",
    version="0.0.1",
    description="{{ system_name }} system",
    long_description=long_description,
    author="{{ company_name }}",
    author_email="oren@andalso.net",
    url="http://{{ company_name }}.github.io/{{ system_name }}/",
    packages=find_packages(),
    package_data={
        "": ["config/config_schema.yaml", "assets/*", "assets/*/*", "assets/*/*/*", "assets/*/*/*/*"],
    },
    install_requires=[],
)
