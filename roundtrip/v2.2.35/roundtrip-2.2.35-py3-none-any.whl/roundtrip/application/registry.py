"""
The registry module provides a global registry for objects and classes.

This is primarily useful for elements of pre-client customization.
"""
import threading

from ..core.base import RoundtripError

__all__ = ["register", "find", "OnePerThread", "InstantiateOnDemand", "RegistryException"]


class RegistryException(RoundtripError):
    """Registry error"""

    pass


class InstantiateOnDemand:
    def __init__(self, klass, *args, **kwargs):
        self.klass = klass
        self.args = args
        self.kwargs = kwargs

    def instantiate(self):
        return self.klass(*self.args, **self.kwargs)


class OnePerThread:
    def __init__(self, klass, *args, **kwargs):
        self.klass = klass
        self.args = args
        self.kwargs = kwargs
        self.byThread = {}

    def get(self):
        # Using C{threading.getCurrentThread().ident} is not ideal as these can be recycled once a thread exits
        k = threading.current_thread().ident
        if k not in self.byThread:
            self.byThread[k] = self.klass(*self.args, **self.kwargs)
        return self.byThread[k]


class Registry:
    """
    Global object/class registry
    """

    def __init__(self):
        self.byPath = dict()

    def register(self, obj, path=None):
        if path is None:
            path = obj._registry
        else:
            obj._registry = path

        if not path.startswith("/"):
            raise RegistryException("Invalid path %s" % path)

        self.byPath[path] = obj

    def registerOnePerThread(self, klass, *args, **kwargs):
        if "path" in kwargs:
            path = klass._registry
            del kwargs["path"]
        opt = OnePerThread(klass, *args, **kwargs)
        self.register(opt, path=kwargs["path"])

    def list(self, path_prefix):
        out = []
        for path, obj in self.byPath:
            if path.startswith(path_prefix):
                out.append(path)
        return out

    def find(self, path):
        o = self.byPath[path]
        if isinstance(o, InstantiateOnDemand):
            self.byPath[path] = o.instantiate()
            return self.byPath[path]
        if isinstance(o, OnePerThread):
            return o.get()
        else:
            return o

    def has(self, path):
        return path in self.byPath


registry = Registry()

find = registry.find
register = registry.register
has = registry.has
