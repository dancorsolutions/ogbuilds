from ..core import javascript

__all__ = ["method", "lifecycle", "spinner", "throttle", "cancelable", "during"]


def method(_method=None, **kwargs):
    """
    Decorates component methods to indicate this should be linked to client-side methods list on the component
    """

    if _method is not None:
        _method.isMethod = True
        return _method

    def fn(g):
        g.isMethod = True
        g.methodArguments = kwargs
        return g

    return fn


def lifecycle(methodOrName=None):
    """
    Decorates component methods to indicate this should be linked to a lifecycle method
    """

    if methodOrName and type(methodOrName is not str):
        f = methodOrName
        f.isLifecycle = True
        return f

    def fn(g):
        g.isLifecycle = True
        g.jsName = methodOrName
        return g

    return fn


def throttle(time):
    """
    Decorates component methods to attach throttling
    """

    if type(time) not in (int, float):
        raise TypeError("Throttle time must be an integer or float")

    def fn(f):
        f.throttle = time
        return f

    return fn


def spinner(time):
    """
    Decorates component methods to attach spinner
    """

    if type(time) not in (int, float):
        raise TypeError("Spinner time must be an integer or float")

    def fn(f):
        f.spinner = time
        return f

    return fn


def cancelable(f):
    """
    Decorates component methods to allow them to be cancelled by future events
    """

    f.cancelable = True
    return f


def during(time, before_or_attribute, after=None):
    """
    Methods decorated with this will:
     - if only <before_or_attribute> is supplied, set <before_or_attribute> to true if executing this function takes more than <time> milliseconds
     - otherwise, set <before_or_attribute> to true before executing the function and to false after it finishes
    """

    def fn(f):
        nonlocal after
        if after is None:
            before = f"(cmp) => cmp.{before_or_attribute} = true"
            after = f"(cmp) => cmp.{before_or_attribute} = false"
        else:
            before = before_or_attribute
        f.during = dict(
            time=time,
            before=javascript.js(before) if isinstance(before, str) else before,
            after=javascript.js(after) if isinstance(after, str) else after,
        )
        return f

    return fn
