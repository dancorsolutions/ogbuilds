"""
Efficient, secure, and DoS-protected upload management
"""
import logging
import time
import json
import base64

import mongoengine
from mongoengine.fields import GridFSProxy
import bson
import tornado.web
from tornado import gen

from ...utils.exceptions import SecurityError
from ...utils.crypto import crypto

from .base import Provider

__all__ = ["UploadHandler", "UploadManager", "UploadProvider", "FileHandler"]


class UploadProvider(Provider):
    ident = "upload"

    def __init__(self, server, file_model, max_file_size=1024 * 1024 * 50):
        super().__init__(server=server)
        self.file_model = file_model
        self.max_file_size = max_file_size

    def initialize(self):
        self.upload_manager = UploadManager(self.file_model)

    def handlers(self):
        return [
            ("/upload", UploadHandler, dict(uploadManager=self.upload_manager, maxFileSize=self.max_file_size)),
            ("/file", FileHandler, dict()),
        ]

    def get_handlers(self, server):
        pass


class UploadManager(object):
    """
    Handles the notion of an upload token and a related set of files
    """

    def __init__(self, fileModel):
        """
        :param fileModel: A mongoengine document class used to store file metadata
        """

        self.fileModel = fileModel

    def ensure(self, token):
        if not self.fileModel.objects(token=token).count():
            raise SecurityError("token not found in upload tokens - security exception or too many concurrent uploads")
        return self.fileModel.objects(token=token).first()

    def newToken(self, model=None, **kwargs):
        if model is None:
            model = self.fileModel
        file = model(**kwargs)
        file.save()
        return file.token

    def get(self, token, peek=True):
        file = self.fileModel.objects(token=token).first()
        if file is None:
            return None
        if not peek:
            file.delete()
        return file

    def clear(self, token):
        file = self.fileModel.objects(token=token).first()
        if file:
            file.delete()

    def getStats(self):
        return dict(totalFiles=self.fileModel.object().count())


class UploadHandler(tornado.web.RequestHandler):
    """
    Handle HTTP file uploads via POST requests
    """

    CHUNK_SIZE = 261120

    # instance attribute defaults
    uploadManager = None
    maxFileSize = None

    async def post(self):
        start = time.time()
        token = self.get_argument("token")
        model = self.uploadManager.ensure(token)

        count = 0
        totalBytes = 0
        for name, files in self.request.files.items():
            for item in files:
                if len(item.body) > self.maxFileSize:
                    self.send_error(500, text="File too large (%d byte limit)" % self.maxFileSize)
                    return

                count += 1
                totalBytes += len(item.body)

                proxy = GridFSProxy()
                proxy.new_file(
                    content_type=item.content_type, filename=item.filename, metadata=dict(parent=model._data["_parent"])
                )

                at = 0
                while 1:
                    chunk = item.body[at : at + self.CHUNK_SIZE]
                    if not chunk:
                        break
                    proxy.write(chunk)
                    at += self.CHUNK_SIZE
                    await gen.sleep(0.0000000001)
                proxy.close()
                model.files.append(proxy)
        model.save()

        logging.getLogger("file.upload").debug(
            "%d files, %d bytes [%.1fms]" % (count, totalBytes, (time.time() - start) * 1000)
        )

        await self.finish(token)

    def initialize(self, uploadManager=None, maxFileSize=1024 * 1024 * 50, **kwargs):
        self.uploadManager = uploadManager
        self.maxFileSize = maxFileSize
        super(UploadHandler, self).initialize()


class FileHandler(tornado.web.RequestHandler):
    """
    Serves up files from Tornado GridFS
    """

    async def get(self):
        token = self.get_argument("token")

        try:
            data = json.loads(base64.b64decode(token))
        except json.JSONDecodeError:
            raise SecurityError("Failed decrypting/decoding file access token %r" % token)

        if crypto.ehash(data["id"].encode("latin-1")) != data["signature"].encode("latin-1"):
            raise SecurityError("Non-matching signatures")

        grid_id = data["id"]

        f = mongoengine.GridFSProxy(grid_id=bson.ObjectId(grid_id))

        if getattr(f, "content_type", None):
            self.set_header("content-type", f.content_type)
            self.set_header("content-disposition", f'inline; filename="{f.filename}"')

        while 1:
            chunk = f.read(500 * 1024)
            if not chunk:
                break
            self.write(chunk)
            await self.flush()

        return self.finish()
