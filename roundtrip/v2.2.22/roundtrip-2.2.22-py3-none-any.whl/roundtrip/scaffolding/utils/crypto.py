import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto import Random


class CryptoError(Exception):
    pass


class CryptoManager:
    BS = 16
    key = None
    password = None

    def setup(self, password):
        self.password = password.encode()

        # constants
        self.key = SHA256.new(self.password).digest()

    def pad(self, s):
        return s + (self.BS - len(s) % self.BS) * chr(self.BS - len(s) % self.BS).encode("latin-1")

    @staticmethod
    def unpad(s):
        return s[0 : -s[-1]]

    def encrypt(self, raw):
        if self.password is None:
            raise CryptoError("Cryptography manager not initialized")
        if type(raw) is str:
            raw = raw.encode("latin-1")
        raw = self.pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        encoded = base64.b64encode(iv + cipher.encrypt(raw))
        return encoded.decode("latin-1")

    def decrypt(self, enc):
        if self.password is None:
            raise CryptoError("Cryptography manager not initialized")
        enc = base64.b64decode(enc)
        iv = enc[: AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        final = self.unpad(cipher.decrypt(enc[AES.block_size :])).decode("latin-1")
        return final

    def hash(self, s):
        if self.password is None:
            raise CryptoError("Cryptography manager not initialized")
        assert type(s) is bytes
        return SHA256.new(self.password + s).digest()

    def ehash(self, s):
        assert type(s) is bytes
        return base64.b64encode(self.hash(s))


crypto = CryptoManager()
