import typing as t_

from ..core import javascript

__all__ = ["method", "lifecycle", "spinner", "throttle", "cancelable", "during"]


P = t_.ParamSpec("P")
R = t_.TypeVar("R")


def method(
    method_or_none: t_.Callable[P, R] | None = None, **kwargs
) -> t_.Callable[[t_.Callable[P, R]], t_.Callable[P, R]] | t_.Callable[P, R]:
    """
    Decorates component methods to indicate this should be linked to client-side methods list on the component
    """

    if method_or_none is not None:
        method_or_none.isMethod = True
        return method_or_none

    def fn(g: t_.Callable[P, R]) -> t_.Callable[P, R]:
        g.isMethod = True
        g.methodArguments = kwargs
        return g

    return fn


P = t_.ParamSpec("P")
R = t_.TypeVar("R")


def lifecycle(
    method_or_name: t_.Callable[P, R] | str | None = None
) -> t_.Callable[[t_.Callable[P, R]], t_.Callable[P, R]] | t_.Callable[P, R]:
    """
    Decorates component methods to indicate this should be linked to a lifecycle method
    """

    if method_or_name and type(method_or_name is not str):
        f = method_or_name
        f.isLifecycle = True
        return f

    def fn(g: t_.Callable[P, R]) -> t_.Callable[P, R]:
        g.isLifecycle = True
        g.jsName = method_or_name
        return g

    return fn


def throttle(time) -> t_.Callable[[t_.Callable[P, R]], t_.Callable[P, R]]:
    """
    Decorates component methods to attach throttling
    """

    if type(time) not in (int, float):
        raise TypeError("Throttle time must be an integer or float")

    def fn(f: t_.Callable[P, R]) -> t_.Callable[P, R]:
        f.throttle = time
        return f

    return fn


P = t_.ParamSpec("P")
R = t_.TypeVar("R")


def spinner(time) -> t_.Callable[[t_.Callable[P, R]], t_.Callable[P, R]]:
    """
    Decorates component methods to attach spinner
    """

    if type(time) not in (int, float):
        raise TypeError("Spinner time must be an integer or float")

    def fn(f: t_.Callable[P, R]) -> t_.Callable[P, R]:
        f.spinner = time
        return f

    return fn


P = t_.ParamSpec("P")
R = t_.TypeVar("R")


def cancelable(f: t_.Callable[P, R]) -> t_.Callable[P, R]:
    """
    Decorates component methods to allow them to be cancelled by future events
    """

    f.cancelable = True
    return f


def during(time, before_or_attribute, after=None) -> t_.Callable[[t_.Callable[P, R]], t_.Callable[P, R]]:
    """
    Methods decorated with this will:
     - if only <before_or_attribute> is supplied, set <before_or_attribute> to true if executing this function takes more than <time> milliseconds
     - otherwise, set <before_or_attribute> to true before executing the function and to false after it finishes
    """

    def fn(f: t_.Callable[P, R]) -> t_.Callable[P, R]:
        nonlocal after
        if after is None:
            before = f"(cmp) => cmp.{before_or_attribute} = true"
            after = f"(cmp) => cmp.{before_or_attribute} = false"
        else:
            before = before_or_attribute
        f.during = dict(
            time=time,
            before=javascript.js(before) if isinstance(before, str) else before,
            after=javascript.js(after) if isinstance(after, str) else after,
        )
        return f

    return fn
