import os
import struct
import imghdr

from ...component import Component
from ...core.javascript import js, dumps


class BaseSprite(Component):
    _properties = []  #: list of ids of attributes that form the Ext.js configuration for this object
    _events = []  #: list of ids of event names that this component may generate
    _jsClass = None

    def _isStateful(self):
        return False

    def _getDefinition(self, platform):
        return self.value


class ImageReference(object):
    def __init__(self, code):
        self.code = code

    def __str__(self):
        return self.code

    def _as_javascript(self):
        return self.code


registry = dict()


class ImageSystemBase(object):
    """
    Used to collect references to image resources from Python code and build them into the generated
    React Native code via require statements etc.
    """

    def __init__(self, fsPath):
        registry[id(self)] = self
        self.fsPath = fsPath


class ImageSystem(ImageSystemBase):
    def __init__(self, fsPath):
        super(ImageSystem, self).__init__(fsPath)
        self.images = {}

    def require(self, image, **kargs):
        fn = os.path.join(self.fsPath, image)
        prefix = os.path.commonprefix([self.fsPath, fn])

        if not os.path.exists(fn):
            raise ValueError("%s not found at %s" % (image, fn))

        ident = fn[len(prefix) :]

        if kargs:
            self.images[(fn, tuple(kargs.items()))] = ident
        else:
            self.images[fn] = ident

        if image.endswith(".js"):

            class Sprite(BaseSprite):
                value = "app.images[%r]" % ident

            return Sprite
        else:
            return ImageReference("app.images[%r]" % ident)

    def asDict(self):
        """
        Generate dict to later to require all images in the fsPath (recursively)

        The code needs to be generated into (and included in) the static react-native javascript code
        """
        out = dict()
        for imagePath, imageName in self.images.items():
            if type(imagePath) is tuple:
                imagePath, kargs = imagePath
                kargs = dict(kargs)
                assert imagePath.endswith(".js")
                out[imageName] = js('require("%s").default(%s)' % (imagePath, dumps(kargs)))
            elif imagePath.endswith(".js"):
                out[imageName] = js('require("%s").default()' % imagePath)
            else:
                out[imageName] = js('require("%s").default' % imagePath)
        return out
