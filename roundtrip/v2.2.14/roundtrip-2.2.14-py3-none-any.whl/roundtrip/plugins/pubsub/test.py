import sys

import tornado.ioloop

from roundtrip.plugins.pubsub import *

c = Channel()


def f(*args, **kargs):
    print("f", args, kargs)


# c.sub(key='1234',query={},callback=f)
c.pub(sys.argv[1], dict(x=1))

# ioloop = tornado.ioloop.IOLoop.current()
# ioloop.add_callback(c.start)
# ioloop.start()
