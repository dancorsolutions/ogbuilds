import inspect

from . import javascript

__all__ = ["callableAsEventConfig", "getJavascriptArguments"]


def callableAsEventConfig(fn, component=None, method=None):
    # language=rst
    """
    Inspects a callable (method or function) and uses explicit/implicit context extraction to build a dict suitable for
    passing to ``app.onevent``

    Also handles other decorators like ``@throttle`` and ``@showSpinner``.

    :param fn: the method to analyze
    :param component: the parent component (used for error reporting)
    :param method: the method name on the parent component (used for error reporting)
    """
    config = dict()
    data = getJavascriptArguments(fn=fn, component=component, method=method)
    if data:
        config["data"] = javascript.js(data)
    if hasattr(fn, "throttle"):
        config["throttle"] = fn.throttle
    if hasattr(fn, "cancelable"):
        config["cancelable"] = fn.cancelable
    if hasattr(fn, "showSpinner"):
        config["showSpinner"] = fn.showSpinner

    return config


def getJavascriptArguments(fn: callable, component=None, method=None, fixed=set()):
    # language=rst
    """
    Return a JavaScript (`roundtrip.js`) object used to gather client-side arguments to pass to a server-side
    method.

    Server-side methods can, in certain places in roundtrip, be called from client-side code. These methods can
    often tell roundtrip to collect client-side context and pass it into the method as arguments.

    This is done as follows:

    .. code-block:: python

       def myMethod(currentTitle=js.state.title):
           if currentTitle == 'something':
               doSomething()

    You can also use explicit context like this:

    .. code-block:: python

       @context(currentTitle=js.state.title)
       def myMethod(currentTitle):
           if currentTitle == 'something':
               doSomething()

    :param fn: the method to analyze
    :param component: the parent component (used for error reporting)
    :param method: the method name on the parent component (used for error reporting)
    :return: a `javascript.js` object or None if there is no javascript context on `fn`
    """
    if hasattr(fn, "context"):
        items = ["%s:%s" % (k, v) for (k, v) in fn.context.items()]
    else:
        items = []
        try:
            spec = inspect.signature(fn)
        except TypeError:
            if component and method:
                raise ValueError(
                    "Can't create event config for %s.%s %r (%s):"
                    " it is not a Python function" % (component.uid, method, fn, type(fn))
                )
            else:
                raise ValueError(
                    "Can't create event config for %r (%s):" " it is not a Python function" % (fn, type(fn))
                )
        for name, param in spec.parameters.items():
            if name in fixed:
                continue
            if param.default is not param.empty:
                if not getattr(param.default, "_is_javascript_op", None):
                    raise ValueError(f"Keyword arguments on event handlers can only take js.xxx as defaults {fn!r}")
                items.append(f"%s:%s" % (param.name, param.default._as_javascript()))
            else:
                items.append("%s" % param.name)
    if items:
        return "{%s}" % (",".join(items))
