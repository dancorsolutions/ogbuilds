from html import escape
import os
from pstats import SortKey


from roundtrip.server.connection import ConnectionManager
from roundtrip.component import Component, method, lifecycle
from roundtrip.core.javascript import js

__all__ = ["RTProfiler"]


class IcicleCall(Component):
    props = ["node"]

    # language=Vue
    template = r"""
    <div 
        class="rt-profiler-ic-node"
        :style="{'background-color': node.color, 'flex-grow': (node.value * 1000).toFixed(1), 'z-index': node.depth}"
        @click.stop="do_click($event)"        
    >
        <div class="rt-profiler-ic-details">
            <div class="-rt-name -rt-function">
                <span class="-rt-label">Function: </span><span class="-rt-value">{{ node.key.function }}</span>
            </div>
            <div class="-rt-name -rt-file">
                <span class="-rt-label">File: </span><span class="-rt-value">{{ node.key.filename }} @ {{ node.key.line }}</span>
            </div>
            <div class="-rt-name -rt-package">
                <span class="-rt-label">Package: </span><span class="-rt-value">{{ node.package }}</span>
            </div>
            <div class="-rt-path">
                <span class="-rt-label">Path: </span><span class="-rt-value">{{ node.key.path }}</span>
            </div>
            <div class="-rt-time" v-if="node.selftime">
                <span class="-rt-label">Time (self): </span><span class="-rt-value">{{ (node.selftime * 1000).toFixed(3) }}ms</span>
            </div>
            <div class="-rt-time" v-if="node.cumtime">
                <span class="-rt-label">Time (cum): </span><span class="-rt-value">{{ (node.cumtime * 1000).toFixed(3) }}ms</span>
            </div>
            <div class="-rt-calls" v-if="node.total_calls">
                <span class="-rt-label">Calls (total): </span><span class="-rt-value">{{ node.total_calls }}</span>
            </div>
            <div class="-rt-calls" v-if="node.prim_calls">
                <span class="-rt-label">Calls (primitive): </span><span class="-rt-value">{{ node.prim_calls }}</span>
            </div>
        </div>
        <div class="rt-profiler-ic-children">
            <IcicleCall
                v-for="child of node.children"
                :node="child"
                @node="$emit('node', $event)"
            >
        </IcicleCall>
        </div>
    </div>
    """

    methods = dict(
        do_click=js(
            """
        function(e) {
            this.$emit('node', this.node);
        }
        """
        )
    )


class IcicleChart(Component):
    props = ["node"]

    # language=Vue
    template = r"""
    <div 
        class="rt-profiler-ic"
    >
        <IcicleCall 
            :node="currentNode || node"
            @node="go_node($event)"
       />
    </div>
    """

    initialData = dict(currentNode=None)

    methods = dict(
        go_node=js(
            """
        function(e) {
            if(this.currentNode == e)
                this.currentNode = null;
            else
                this.currentNode = e;
        }
        """
        )
    )


class RTProfiler(Component):
    linked = True

    # language=VUE
    template = r"""
    <div class="rt-profiler-container">
        <div v-if="view==='connections'" class="rt-profiler-connections">
            <div class="rt-profiler-header">
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Connection time</th>
                        <th>Connection id</th>
                        <th># requests profiled</th>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="i in connections">
                        <td>{{ i.date.toLocaleTimeString() }}</td>
                        <td>{{ i.connectionId }}</td>
                        <td>{{ i.numberOfProfiles }}</td>
                        <td><button @click="do_open_connection(i.connectionId)">Open</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div v-if="view==='connection'" class="rt-profiler-requests">
            <div class="rt-profiler-header">
                <button @click="go_connections()" class="-rt-back">Back</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <template
                            v-for="column in [
                                ['date', 'Date'],
                                [null, 'Message Number'],
                                [null, 'Target'],
                                [null, 'Function'],
                                [null, 'Data returned'],
                                [null, 'Tree changes'],
                                ['total_tt', 'Total time'],
                                ['total_calls', 'Total calls'],
                                [null, 'Action'],
                            ]"
                        > 
                        <th 
                            v-if="column[0]"
                            @click="sort_requests(column[0])"
                            class="-rt-sortable"
                        >
                            {{ column[1] }}
                            {{ requests_sort_column === column[0] ? (requests_sort_desc ? '\u2191' : '\u2193') : '\u21c5' }}
                        </th>
                        <th v-else>
                            {{ column[1] }}
                        </th>
                        </template>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="i in requests">
                        <td>{{ i.date.toLocaleTimeString() + ' + ' + i.date.getMilliseconds() + 'ms' }}</td>
                        <td>{{ i.request.index }}</td>
                        <td>{{ i.request.target }}</td>
                        <td>{{ i.request.name }}</td>
                        <td>{{ i.request.data }}</td>
                        <td>{{ i.request.treeChanges ? i.request.treeChanges.length : 'None' }}</td>
                        <td>{{ (i.total_tt * 1000).toFixed(2) }}ms</td>
                        <td>{{ i.total_calls }}</td>
                        <td><button @click="do_open_request({connectionId, index: i.index})">Open</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div v-if="view==='request'" class="rt-profiler-request">
            <div class="rt-profiler-header">
                <button class="-rt-back" @click="go_requests()">Back</button>
            </div>
            <IcicleChart :node="profile"></IcicleChart>
            <table>
                <thead>
                    <tr>
                        <template
                            v-for="column in [
                                ['package', 'Package'],
                                ['name', 'Function'],
                                [null, 'Total calls'],
                                ['cum_time', 'Cumilative'],
                                ['cum_time_per', 'Cumulative (per call)'],
                                ['tot_time', 'Total time'],
                                ['tot_time_per', 'Total time (per call)'],
                            ]"
                        > 
                        <th 
                            v-if="column[0]"
                            @click="sort_calls(column[0])"
                            class="-rt-sortable"
                        >
                            {{ column[1] }}
                            {{ requests_sort_column === column[0] ? (requests_sort_desc ? '\u2191' : '\u2193') : '\u21c5' }}
                        </th>
                        <th v-else>
                            {{ column[1] }}
                        </th>
                        </template>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="i in table">
                        <td>{{ i.package }}</td>
                        <td class="-rt-hover-cell">
                            {{ i.flf }}
                            <div class="-rt-hover" v-if="i.flf != i.name">{{ i.name }}</div>
                        </td>
                        <td>{{ i.item[0] }}</td>
                        <td>{{ (i.cum_time * 1000).toFixed(3) }}ms</td>
                        <td>{{ (i.cum_time_per * 1000).toFixed(3) }}ms</td>
                        <td>{{ (i.tot_time * 1000).toFixed(3) }}ms</td>
                        <td>{{ (i.tot_time_per * 1000).toFixed(3) }}ms</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    """

    initialData = dict(
        view="connections",
        connectionId=None,
        requestIndex=None,
        connections=[],
        requests_sort_column=None,
        requests_sort_desc=None,
        calls_sort_column=None,
        calls_sort_desc=None,
        requests=[],
        profile=dict(),
        table=[],
    )

    @lifecycle
    def mounted(self):
        out = []
        for desc in self.app.server.connectionManager.all:
            c = desc["connection"]
            date = desc["date"]
            if c.profileResults:
                out.append(dict(connectionId=c.connectionId, date=date, numberOfProfiles=len(c.profileResults)))
        self.data.connections = out

    @method
    def go_connections(self):
        self.data.view = "connections"

    @method
    def go_requests(self):
        self.data.view = "connection"

    @method
    def sort_requests(self, id):
        if self.data.requests_sort_column == id:
            self.data.requests_sort_desc = not self.data.requests_sort_desc
        else:
            self.data.requests_sort_desc = False

        def sorter(o):
            if "." in id:
                [a, b] = id.split(".")
                return getattr(o, a)[b]
            else:
                return getattr(o, id)

        l = sorted(self.data.requests, key=sorter)
        if self.data.requests_sort_desc:
            l.reverse()
        self.data.requests = l
        self.data.requests_sort_column = id

    @method
    def sort_calls(self, id):
        if self.data.calls_sort_column == id:
            self.data.calls_sort_desc = not self.data.calls_sort_desc
        else:
            self.data.calls_sort_desc = False

        def sorter(o):
            return getattr(o, id)

        l = sorted(self.data.table, key=sorter)
        if self.data.calls_sort_desc:
            l.reverse()
        self.data.table = l
        self.data.calls_sort_column = id

    @method
    def do_open_connection(self, connectionId):
        self.data.view = "connection"
        self.data.connectionId = connectionId
        connection = self.app.server.connectionManager.connections[connectionId]["connection"]
        out = []
        for o in connection.profileResults:
            item = dict()
            item["date"] = o.date
            item["index"] = o.request["index"]
            item["request"] = o.request
            item["response"] = o.response
            item["total_tt"] = o.profile.total_tt
            item["total_calls"] = o.profile.total_calls
            out.append(item)
        self.data.requests = out

    @method
    def do_open_request(self, connectionId, index):
        self.data.view = "request"
        self.data.requestIndex = index
        connection = self.app.server.connectionManager.connections[connectionId]["connection"]
        r = [o for o in connection.profileResults if o.request["index"] == index][0]
        self.data.profile = read_runtime_profile(r.profile)
        self.data.table = table_rows(r.profile)


def guess_package(key):
    if key[2].startswith("<"):
        return "<builtin>"
    path = key[0]
    if "site-packages" in path:
        package = path.split("site-packages")[1].split("/")[1]
    else:
        package = "-"
    return package


def table_rows(stats):
    """
    Generate a list of stats info lists for the snakeviz stats table.
    Each list will be a series of strings of:
    calls tot_time tot_time_per_call cum_time cum_time_per_call file_line_func
    """
    rows = []

    for k, v in stats.stats.items():
        flf = "{2}@{0}:{1}".format(os.path.basename(k[0]), k[1], k[2])
        name = "{2}@{0}:{1}".format(*k)

        if v[0] == v[1]:
            calls = str(v[0])
        else:
            calls = "{1}/{0}".format(v[0], v[1])

        tot_time_per = v[2] / v[0] if v[0] > 0 else 0
        cum_time_per = v[3] / v[0] if v[0] > 0 else 0
        tot_time = v[2]
        cum_time = v[3]

        rows.append(
            dict(
                item=[calls, v[1]],
                cum_time=cum_time,
                cum_time_per=cum_time_per,
                tot_time=tot_time,
                tot_time_per=tot_time_per,
                flf=flf,
                name=name,
                package=guess_package(k),
            )
        )

        rows.sort(key=lambda i: -i["cum_time"])

    return rows


def read_runtime_profile(stats):
    colors = [
        "#feff8e",
        "#f8fd94",
        "#f3fb9b",
        "#edf8a1",
        "#e7f6a7",
        "#e1f4ad",
        "#dbf2b2",
        "#d4f0b8",
        "#cdeebe",
        "#c6ebc4",
        "#bfe9c9",
        "#b7e7cf",
        "#afe5d4",
        "#a6e3da",
        "#9de1df",
        "#93dfe4",
        "#88ddea",
        "#7cdbef",
        "#6ed9f4",
        "#5ed7fa",
        "#51d5f7",
        "#57d5ef",
        "#5cd5e7",
        "#61d5df",
        "#65d5d7",
        "#68d5d0",
        "#6bd5c8",
        "#6dd5c0",
        "#6fd5b8",
        "#71d5b0",
        "#72d5a8",
        "#73d5a0",
        "#74d598",
        "#74d590",
        "#75d688",
        "#75d680",
        "#74d677",
        "#74d66f",
        "#73d666",
        "#72d65d",
    ]
    color_index = -1

    def get_color():
        nonlocal color_index
        color_index += 1
        return colors[color_index % len(colors)]

    # One way of picking the root nodes would be to search through stats.stats.items()
    # and check which don't have parents. This, however, doesn't work if there are loops
    # in the graph which happens, for example, if exec() is called somewhere in the
    # program. For this reason, find all nodes without parents _and_ simply hardcode
    # `<built-in method builtins.exec>`.
    roots = set()
    for key, value in stats.stats.items():
        # The object {('~', 0, "<method 'disable' of '_lsprof.Profiler' objects>")}
        # is part of the profile and a root node. Its runtime is usually miniscule and
        # doesn't appear the the final output. Hence, only consider root nodes with a
        # cumtime larger than a threshold.
        # If there is only one remaining root (which is most often the case), one can
        # cut of the artificial "root" node. See below.
        if not value[4] and value[3] > 1.0e-5:
            roots.add(key)

    default_roots = [
        ("~", 0, "<built-in method builtins.exec>"),
        ("~", 0, "<built-in method exec>"),
    ]
    for default_root in default_roots:
        if default_root in stats.stats:
            roots.add(default_root)
    roots = list(roots)

    # Collect children
    children = {key: [] for key in stats.stats.keys()}
    for key, value in stats.stats.items():
        _, _, _, _, parents = value
        for parent in parents:
            children[parent].append(key)

    def populate(key, parent, all_ancestors, depth):
        # stats.stats[key] returns a tuple of length 5 with the following data:
        # [0]: total calls
        # [1]: prim calls
        # [2]: selftime
        # [3]: cumtime
        # [4]: a dictionary of callers

        display_key = dict(
            filename=key[0].split("/")[-1] if "/" in key[0] else key[0],
            path="/".join(key[0].split("/")[:-1]) if "/" in key[0] else "",
            line=key[1],
            function=key[2],
        )

        if parent is None:
            parent_times = {}
            prim_calls, total_calls, selftime, cumtime, _ = stats.stats[key]
        else:
            prim_calls, total_calls, _, _, parent_times = stats.stats[key]
            _, _, selftime, cumtime = parent_times[parent]

        # Convert the tuple key into a string
        name = "{}::{}::{}".format(*key)

        if key in all_ancestors:
            # avoid loops
            return {}

        if len(parent_times) <= 1:
            # Handle children
            c = [populate(child, key, all_ancestors + [key], depth + 1) for child in children[key]]
            c.append(
                {
                    "key": display_key,
                    "type": "self",
                    "cumtime": cumtime,
                    "selftime": selftime,
                    "text": [name + "::self", f"{selftime:.3} s"],
                    "color": get_color(),
                    "value": selftime * 1000000,
                    "total_calls": total_calls,
                    "prim_calls": prim_calls,
                    "package": guess_package(key),
                    "depth": depth + 1,
                }
            )
            return {
                "key": display_key,
                "text": [name],
                "cumtime": cumtime,
                "selftime": selftime,
                "color": get_color(),
                "children": c,
                "value": cumtime * 1000000,
                "total_calls": total_calls,
                "prim_calls": prim_calls,
                "package": guess_package(key),
                "depth": depth,
            }

        # More than one parent; we cannot further determine the call times.
        # Terminate the tree here.
        if children[key]:
            c = [
                {
                    "key": display_key,
                    "type": "possible",
                    "cumtime": cumtime,
                    "selftime": selftime,
                    "text": [
                        "Possible calls of",
                        ", ".join("{}::{}::{}".format(*child) for child in children[key]),
                    ],
                    "color": get_color(),
                    "value": cumtime * 1000000,
                    "total_calls": total_calls,
                    "prim_calls": prim_calls,
                    "package": guess_package(key),
                    "depth": depth + 1,
                }
            ]
            return {
                "key": display_key,
                "text": [name],
                "color": get_color(),
                "cumtime": cumtime,
                "selftime": selftime,
                "children": c,
                "value": cumtime * 1000000,
                "total_calls": total_calls,
                "prim_calls": prim_calls,
                "package": guess_package(key),
                "depth": depth,
            }

        return {
            "key": display_key,
            "text": [name, f"{selftime:.3f}"],
            "color": get_color(),
            "cumtime": cumtime,
            "selftime": selftime,
            "value": selftime * 1000000,
            "total_calls": total_calls,
            "prim_calls": prim_calls,
            "package": guess_package(key),
            "depth": depth,
        }

    if len(roots) == 1:
        data = populate(roots[0], None, [], depth=0)
    else:
        # If there is more than one root, add an artificial "main root" item that is
        # parent to all roots.
        assert len(roots) > 1
        data = {
            "key": display_key,
            "type": "root",
            "text": ["root"],
            "color": get_color(),
            "cumtime": cumtime,
            "selftime": selftime,
            "total_calls": 0,
            "prim_calls": 0,
            "children": [populate(root, None, []) for root in roots],
            "value": 1,
            "package": "",
            "depth": depth,
        }
    return data
