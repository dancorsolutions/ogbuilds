from ...core import message
import websocket
import time


class IntegrationTest(object):
    def __init__(self):
        self.steps = []

    def testServer(self):
        tLast = self.steps[0][1]["t"]

        websocket.setdefaulttimeout(10)
        ws = websocket.WebSocket()
        ws.connect("ws://localhost:8001/websocket?roundtripId=1234&platform=web")
        ws.recv()
        for kind, kargs in self.steps:
            if kind == "s2c":
                payload = message.MessagePayload(**kargs)
                ws.send(payload.encode())
                ws.recv()
            else:
                pass
            delta = (kargs["t"] - tLast).total_seconds()
            time.sleep(delta)

    def c2s(self, **kargs):
        self.steps.append(("c2s", kargs))

    def s2c(self, **kargs):
        self.steps.append(("s2c", kargs))
