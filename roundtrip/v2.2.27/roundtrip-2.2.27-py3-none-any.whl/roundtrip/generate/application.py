import os
import filecmp
import shutil
import re
import sys
import json
import warnings

from ..core import version
from .component import *
from ..component import ComponentMetaclass
from .code import *
from ..core.javascript import js, dumps

__all__ = ["ApplicationGenerator"]


DEBUG_DIFFS = False


class ApplicationGenerator:
    """
    Class to generate all files needed to run the application

    This takes care of setting up the roundrip plugin as well as building the main Vue instance and attaching
    it to the DOM.
    """

    def __init__(self, component, path, options, globalComponents=True):
        """
        :arg component: the application component instance for which we're generating code
        :arg path: target path into which to generate the code
        :arg options: roundtrip ApplicationOptions object for the application
        :arg globalComponents: set to True to have all components generated globally rather than import individual
            components in each .vue file (use this if you're going to switch of loadAsync to avoid issues with
            import loops)
        """
        self.app = component
        self.path = path + "/generated"
        self.options = options
        self.globalComponents = globalComponents

        self.filesWritten = set()
        self.rtPath = os.path.realpath(os.path.split(__file__)[0] + "/..")

    def write(self, gFile, ifNotExists=False):
        s = gFile._as_javascript()
        target = self.path + "/" + gFile.name
        self.filesWritten.add(os.path.realpath(target))
        if os.path.exists(target):
            current = open(target, "rt").read()
            if current == s:
                return target
            elif DEBUG_DIFFS:
                i = 0
                while i < len(current) and i < len(s):
                    if current[i] != s[i]:
                        print("different", target)
                        print("<<<" + repr(s[i - 20 : i + 20]))
                        print(">>>" + repr(current[i - 20 : i + 20]))
                        print()
                        break
                        i += 40
                    i += 1
                if len(current) != len(s):
                    print("different lengths", target)

        f = open(target, "wt")
        f.write(s)

    def generateStaticJavascript(self):
        if not os.path.exists(self.path):
            os.makedirs(self.path)

        appGen = AGFile(ag=self)
        self.write(appGen.gen())

        components = self.getDeclarations(recurse=True)

        indexGen = IndexFile(ag=self, components=components)
        self.write(indexGen.gen())

        for component in components:
            cFile = CGFile(ag=self, component=component)
            self.write(cFile.gen())

        for item in os.listdir(self.path):
            item = os.path.realpath(os.path.join(self.path, item))
            if item not in self.filesWritten:
                os.remove(item)

    def getDeclarations(self, root=None, recurse=False, components=None):
        if root is None:
            root = self.app
        if components is None:
            components = set()

        for className in root.children:
            cmp = ComponentMetaclass.use(className)
            if cmp in components:
                continue
            components.add(cmp)
            if recurse:
                components.update(self.getDeclarations(cmp, recurse=recurse, components=components))

        for className in root.components or []:
            if className in ComponentMetaclass.byClassName:
                cmp = ComponentMetaclass.use(className)
                if cmp in components:
                    continue
                components.add(cmp)
                if recurse:
                    components.update(self.getDeclarations(cmp, recurse=recurse, components=components))

        return components


class AGFile(CGFile):
    """
    Class to handle generating
    """

    def __init__(self, ag):
        super().__init__(ag=ag, component=ag.app)
        self.ag = ag

    def buildOptions(self):
        opt, imports = super().buildOptions()
        opt["name"] = self.c.className
        mixins = set([i._as_javascript() for i in (opt.get("mixins", None) or [])])
        mixins.add(js("RTRootMixin"))
        opt["mixins"] = list(mixins)
        imports.append("import { RTRootMixin } from '%s'" % (self.ag.rtPath + "/js/" + "plugin"))
        if not opt.get("props", None):
            opt["props"] = dict()
        return opt, imports


class IndexFile:
    """
    Class to handle generating the main application file
    """

    def __init__(self, ag, components):
        self.ag = ag
        self.components = components

    def buildRoundtripOptions(self):
        return dict(sessionTimeout=self.ag.options.sessionTimeout, webSocketURL=self.ag.options.webSocketURL)

    def gen(self):
        if self.ag.app.propsData:
            raise ValueError("Application props is no longer supported")

        routerImports = None
        routerStatement = None

        if self.ag.app.router:
            routerImports, routerStatement = self.ag.app.router.generateJS()

        out = File(name="index.js")
        out += Statement("import { createApp } from 'vue'")

        out += Statement("import App from './%s.vue'" % self.ag.app.className)
        if self.ag.options.debugLevel > 0:
            jsPath = self.ag.rtPath + "/js"
        else:
            jsPath = "roundtrip"
        out += Statement("import {RTPlugin} from '%s/plugin'" % jsPath)

        if self.ag.globalComponents:
            out += Spacer()
            for component in sorted(self.components, key=lambda c: c.className):
                if not component.loadAsync:
                    out += Statement(f"import {component.className} from './{component.className}.vue'")
            out += Spacer()

        if routerImports:
            for routerImport in routerImports:
                out += Statement(routerImport)
            out += Spacer()

        out += Statement("const app = createApp(App)")
        out += Spacer()
        out += Statement(f"app.use(RTPlugin, {dumps(self.ag.options.toDict())})")

        if self.ag.globalComponents:
            out += Spacer()
            for component in sorted(self.components, key=lambda c: c.className):
                if component.loadAsync:
                    out += Statement(
                        f'app.component("{component.className}", '
                        f"defineAsyncComponent(() => import('./{component.className}.vue'))"
                    )
                else:
                    out += Statement(f'app.component("{component.className}", {component.className})')
            out += Spacer()

        if routerStatement:
            out += Statement(routerStatement)

        for plugin in self.ag.app.plugins:
            for imp in plugin.imports:
                out += Statement(imp)
            if plugin.arguments:
                out += Statement("app.use(%s,...%s)" % (plugin.js._as_javascript(), dumps(plugin.arguments)))
                js
            else:
                out += Statement("app.use(%s)" % plugin.js._as_javascript())

        for directive in self.ag.app.directives:
            for imp in directive.imports:
                out += Statement(imp)
            out += Statement("app.directive(%r, ...%s)" % (directive.name, dumps(directive.arguments)))

        out += Spacer()
        out += Statement('export const application = app.mount("#rtApplicationRoot")')

        return out


class JSONConfigFile:
    def __init__(self, name):
        self.__dict__["d"] = {}
        self.__dict__["name"] = name

    def __setattr__(self, k, v):
        self.d[k] = v

    def __getattr__(self, k):
        try:
            return self.d[k]
        except KeyError:
            raise AttributeError(k)

    def _as_javascript(self):
        return dumps(self.d)
