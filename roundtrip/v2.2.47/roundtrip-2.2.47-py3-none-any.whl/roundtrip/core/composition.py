from ..component import decorators, ComponentMetaclass
from ..application import application


def method(name, arg=None, **kwargs):
    if callable(name):
        return decorators.method(name)
    assert not (arg and kwargs)
    ComponentMetaclass.composition("methods", name, arg or kwargs)


def prop(name, arg=None, **kwargs):
    assert not (arg and kwargs)
    ComponentMetaclass.composition("props", name, arg or kwargs)


def props(*args, **kwargs):
    assert not (args and kwargs)
    if args:
        if len(args) != 1:
            raise ValueError(
                "props() takes 1 optional positional argument that must be a list of strings but >1 was given"
            )
        for i in args[0]:
            ComponentMetaclass.composition("props", i, None)
    else:
        for k, v in kwargs.items():
            ComponentMetaclass.composition("props", k, v)


def ref(name, arg):
    ComponentMetaclass.composition("initialData", name, arg)


def reactive(**kwargs):
    for k, v in kwargs.items():
        ComponentMetaclass.composition("initialData", k, v)


def lifecycle(name, arg=None, **kwargs):
    if callable(name):
        return decorators.method(name)
    assert not (arg and kwargs)
    ComponentMetaclass.composition("lifecycle", name, arg or kwargs)


def provide(name=None, arg=None, **kwargs):
    assert not (arg and kwargs)
    if name:
        ComponentMetaclass.composition("provide", name, arg or kwargs)
    else:
        for k, v in kwargs.items():
            ComponentMetaclass.composition("provide", k, v)


def inject(name=None, arg=None, **kwargs):
    assert not (arg and kwargs)
    if name:
        if type(name) is not list:
            name = [name]
        for i in name:
            ComponentMetaclass.composition("inject", i, arg or kwargs)
    else:
        for k, v in kwargs.items():
            ComponentMetaclass.composition("inject", k, v)


def mixin(name):
    ComponentMetaclass.composition("mixins", name, None)


def plugin(*args, **kwargs):
    ComponentMetaclass.composition("plugins", application.Plugin(*args, **kwargs), {})


def imports(arg):
    if type(arg) is not str:
        for i in arg:
            ComponentMetaclass.composition("imports", None, i)
    else:
        ComponentMetaclass.composition("imports", None, arg)


def watch(name, arg=None, **kwargs):
    assert not (arg and kwargs)
    ComponentMetaclass.composition("watch", name, arg or kwargs)


def computed(name, arg=None, **kwargs):
    assert not (arg and kwargs)
    ComponentMetaclass.composition("computed", name, arg or kwargs)


def emits(*args):
    for arg in args:
        ComponentMetaclass.composition("emits", arg, None)
