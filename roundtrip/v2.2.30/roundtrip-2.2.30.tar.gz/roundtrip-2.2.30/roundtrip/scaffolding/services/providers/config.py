__all__ = ["ConfigProvider"]

from ...config import config
from .base import *


class ConfigProvider(Provider):
    ident = "config"

    config = None

    def __init__(self, server, path):
        super().__init__(server=server)
        self.path = path

    def initialize(self):
        config._setup(base=self.path)
        self.config = config
