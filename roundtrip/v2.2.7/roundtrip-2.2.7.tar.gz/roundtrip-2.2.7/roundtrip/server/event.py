"""
roundtrip event classes

Classes to take care of managing the server side of handling roundtrip events (and generating the appropriate
client code to connect the events to React/RN components).
"""


class Event(object):
    """
    Represents client-generated event.

    Attributes:
        target: the component instance for the control which raised the event
        data: any additional data supplied with the event (unserialised)
        name: the name of the event, e.g. `"onclick"`
        deltas: deltas for one or more forms (mapping of form uid to form deltas)
    """

    def __init__(self, e=None):
        if e is None:
            self.target = None
            self.className = None
            self.data = None
            self.name = None
            self.stateDeltas = None
            self.treeChanges = None
        else:
            self.target = e.get("target", None)
            self.className = e.get("className", None)
            self.data = e.get("data", dict())
            self.name = e["name"]
            self.stateDeltas = e.get("stateDeltas", None)
            self.treeChanges = e.get("treeChanges", None)

    def __repr__(self):
        return "<Event %s[uid=%r].%s data=%r>" % (self.className, self.target, self.name, self.data)


class JSEventHandler(object):
    """
    Allows attaching client-side (javascript) event handling code from python component classes.
    """

    def __init__(self, code=None):
        self.code = code

    def _as_javascript(self):
        if not self.code:
            raise Exception("Attempting to write out a JSEventHandler with no code")
        if not self.code.strip().startswith("function"):
            raise Exception(
                "JSEvent handlers must be anonymous function declarations (starting with 'function') - got %r"
                % self.code
            )
        return self.code.strip()
