import bson
import base64
import json

from ...utils.crypto import crypto

__all__ = ["make_token", "make_url"]


def make_token(id):
    data = dict(id=id, signature=crypto.ehash(id.encode("latin-1")).decode("latin-1"))
    token = base64.b64encode(json.dumps(data).encode("latin-1"))
    return token.decode("latin-1")


def make_url(id):
    assert isinstance(id, bson.ObjectId)
    return "/file?token=%s" % make_token(str(id))
