import json
import logging
import tornado.web


__all__ = ["StatsHandler"]


class StatsHandler(tornado.web.RequestHandler):
    connectionManager = None
    kwargs: dict = None

    def initialize(self, connectionManager, **kwargs):
        self.connectionManager = connectionManager
        self.kwargs = kwargs

    def get(self):
        x_real_ip = self.request.headers.get("X-Real-IP")
        remote_ip = x_real_ip or self.request.remote_ip

        logging.debug("request for stats from IP: %s", remote_ip)

        if remote_ip == "127.0.0.1" or remote_ip == "::1":
            stats = dict(connections=self.connectionManager.getStats())
            stats.update(self.kwargs)
            self.finish(json.dumps(stats))
        else:
            logging.warning("attempt to access /stats from %s" % remote_ip)
            self.finish("")
