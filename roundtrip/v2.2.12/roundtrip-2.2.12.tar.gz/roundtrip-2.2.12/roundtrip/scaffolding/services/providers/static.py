"""
Tornado handler to allow serving static files from a fixed path

This is a thin wrapper around Tornado's StaticFileHandler that sets the X-Frame-Options header to DENY
"""

import tornado.web

from .base import *

__all__ = ["StaticProvider"]


class StaticFileHandler(tornado.web.StaticFileHandler):
    ident = "static"

    def initialize(self, path, default_filename=None):
        super().initialize(path, default_filename)

    def set_extra_headers(self, path):
        self.set_header("X-Frame-Options", "DENY")


class StaticProvider(Provider):
    staticDirectories = ConfigItem(object, required=True)

    def handlers(self):
        handlers = []
        for d in server.config.staticDirectories:
            handlers.append((r"/%s/(.*)" % d[0], tornado.web.StaticFileHandler, dict(path=d[1])))
        return handlers
