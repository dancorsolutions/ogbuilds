import functools

__all__ = ["method", "lifecycle", "spinner", "throttle", "cancelable"]


def method(methodOrName=None):
    """
    Decorates component methods to indicate this should be linked to client-side methods list on the component
    """

    if methodOrName and type(methodOrName is not str):
        f = methodOrName
        f.isMethod = True
        return f

    def fn(g):
        g.isMethod = True
        g.jsName = methodOrName
        return g

    return fn


def lifecycle(methodOrName=None):
    """
    Decorates component methods to indicate this should be linked to a lifecycle method
    """

    if methodOrName and type(methodOrName is not str):
        f = methodOrName
        f.isLifecycle = True
        return f

    def fn(g):
        g.isLifecycle = True
        g.jsName = methodOrName
        return g

    return fn


def throttle(time=None):
    """
    Decorates component methods to attach throttling
    """

    def fn(f):
        f.throttle = time
        return f

    return fn


def spinner(time=None):
    """
    Decorates component methods to attach spinner
    """

    def fn(f):
        f.spinner = time
        return f

    return fn


def cancelable(f):
    """
    Decorates component methods to allow them to be cancelled by future events
    """

    f.cancelable = True
    return f
