import copy
import inspect
import re
import typing
import types
import warnings
from html.parser import HTMLParser

import jinja2

from ..server import connection
from ..core import javascript
from ..core.classproperty import classproperty
from ..generate import code
from ..utils.html_and_view_tags import HTML_AND_VUE_TAGS

__all__ = ["ComponentMetaclass", "ExternalMetaclass", "Component", "External", "getComponentClass"]


PAT_C2K_1 = re.compile("(.)([A-Z][a-z]+)")  #: pascalToKebab pattern
PAT_C2K_2 = re.compile("([a-z0-9])([A-Z])")  #: pascalToKebab pattern


def pascalToKebab(name):
    """Convert from PascalCase or camelCase to kebab-case"""
    name = PAT_C2K_1.sub(r"\1-\2", name)
    return PAT_C2K_2.sub(r"\1-\2", name).lower()


def kebabToPascal(name):
    """Convert from kebab-case to PascalCase"""
    return "".join(word.title() for word in name.split("-"))


def kebabToCamel(name):
    """Convert from kebab-case to PascalCase"""
    s = kebabToPascal(name)
    return s[0].lower() + s[1:]


class ComponentError(ValueError):
    pass


class ComponentMetaclass(type):
    """
    Metaclass for components

    This makes it easier to work with nested classes by giving each nested class an C{_order} attribute automatically
    representing the order in which the class was declared
    """

    byTag = {}
    byClassName = {}
    instances = {}
    context = {}
    inReload = False

    def __new__(mcs, klassName, bases, klassDict):
        isUnlinked = "linked" in klassDict and not klassDict.get("linked", None)

        klass = type.__new__(mcs, klassName, bases, klassDict)

        if getattr(klass, "initialData", None):
            if isUnlinked:
                raise ValueError(f"Cannot set initialData on a linked=False class {klassName}")
            klass.linked = True
        elif getattr(klass, "syncProps", None):
            if isUnlinked:
                raise ValueError(f"Cannot use syncProps on a linked=False class {klassName}")
                klass.linked = True
        for i in inspect.getmembers(klass):
            klass.linked = True  # TODO: previous code was always making components linked and fixing it breaks
            # Semantik admin UIs -- the challenge is that components not explicitly marked as
            # linked that have linked children also need to be linked (linked-ness needs to
            # be contagious upwards through he component hierarchy)
            if i[0] == "jsExpression":
                continue
            if hasattr(i[1], "__call__") and (getattr(i[1], "isMethod", None) or getattr(i[1], "isLifecycle", None)):
                if isUnlinked:
                    raise ValueError(f"Cannot use @lifecycle/@method on a linked=False class {klassName}.{i}")
                klass.linked = True

        className = klass.className
        tag = klass.tagName

        if tag in mcs.byTag or tag in ExternalMetaclass.byTag:
            if not mcs.inReload:
                warnings.warn(
                    "Component tag names must be unique (%s in %r (%s) & %r (%s))"
                    % (tag, mcs.byTag[tag], mcs.byTag[tag].__module__, klass, klass.__module__)
                )

        mcs.byClassName[className] = klass
        mcs.byTag[pascalToKebab(className)] = klass

        return klass

    def __repr__(cls):
        return "|Component class %s %s|" % (cls.className, hex(id(cls))[-4:])

    @classmethod
    def reinstantiate(mcs):
        for className, klass in mcs.byClassName.items():
            if className in mcs.instances:
                instance = klass()
                mcs.instances[className] = instance

    @classmethod
    def use(mcs, className):
        if not isinstance(className, str):
            raise ValueError("className must be string not %r" % className)
        if className in mcs.instances:
            return mcs.instances[className]
        klass = mcs.byClassName[className]
        instance = klass()
        mcs.instances[className] = instance
        return instance

    @classmethod
    def getByClassname(mcs, item):
        return mcs.instances[item]

    @classmethod
    def getTemplateContext(mcs, component):
        out = dict()
        out["cmp"] = component
        out.update(mcs.context)
        return out


class ExternalMetaclass(ComponentMetaclass):
    """
    Metaclass for external components

    Keeps track of any component classes declared in the app by class name and by kebab-cased tag name
    """

    byTag = {}
    byClassName = {}

    def __new__(mcs, klassName, bases, klassDict):
        klass = type.__new__(mcs, klassName, bases, klassDict)

        tag = pascalToKebab(klassName)

        if tag in mcs.byTag or tag in ComponentMetaclass.byTag:
            if not ComponentMetaclass.inReload:
                warnings.warn("Component tag names must be unique (%s in %r & %r)" % (tag, mcs.byTag[tag], klass))

        mcs.byClassName[klassName] = klass
        mcs.byTag[pascalToKebab(klassName)] = klass

        return klass

    def __repr__(cls):
        return "|External class %s %s|" % (cls.className, hex(id(cls))[-4:])


def getComponentClass(name):
    if name in ComponentMetaclass.byClassName:
        return ComponentMetaclass.byClassName[name]
    if name in ComponentMetaclass.byTag:
        return ComponentMetaclass.byTag[name]
    if name in ExternalMetaclass.byClassName:
        return ExternalMetaclass.byClassName[name]
    if name in ExternalMetaclass.byTag:
        return ExternalMetaclass.byTag[name]
    return None


class Component(metaclass=ComponentMetaclass):
    """
    Base class for all components

    This class represents python-backed front-end vue components. Components created with this class have
    a variety of functionality baked in:

        - vue code generation
        - data syncing (keep component and server-side data in sync)
        - sever-side methods (call methods declared in python on the server and asynchronously handle return data)

    Class names and ids:

        - `self.className`: Python class name (must be unique across the application)
        - `self.tagName`: kebab-case version of `className`
    """

    #
    # CLASS ATTRIBUTES (overridden)
    #

    refs: object  #: set by the tree proxy to be a reference to the client-side $refs on the Vue component
    linked: bool = False  #: if true then there will be server-side instance (actually a component tree proxy) of this
    #: component available to server-side code, otherwise server-side code will not be able to access
    #: a specific instance of this class to communicate with client-side code
    imports: set | None = None  #: required imports
    isApplication: bool = False  #: True if this component is the root application object
    loadAsync: bool | dict = False  #: True if this component should be loaded asynchrnously wherever it is referenced
    ctMounted = None  #: hook after one of these components gets created client side
    ctUnmounted = None  #: hook after one of these components gets unmounted client side
    options: dict | None = None  #: specify any additional non-standard options to pass through to the Vue constructor
    style: str | None = None  #: specify a CSS/SCSS string to render within <style> tags
    scopedStyle: str | None = None  #: specify a CSS/SCSS string to render within <style scoped> tags
    connection = None  #: set tb tree proxy, points to the connection with the client

    @classproperty
    def className(self):
        """The Python class name for this component (also used to attach instances to parents)"""
        return self.__name__

    @classproperty
    def tagName(self):
        """The name of this component in kebab-case as used in HTML tags in a vue template"""
        return pascalToKebab(self.className)

    @classproperty
    def synced(self):
        """Server-side for this component is synchronized with client-side data"""
        return self.initialData is not None

    @property
    def session(self):
        """
        TODO: Replace with a set of common imports for often-used singletons (like threadPool, session, connection)
        """
        return self.connection.session

    @property
    def threadPool(self):
        """
        TODO: Replace with a set of common imports for often-used singletons (like threadPool, session, connection)
        """
        return self.connection.handler.threadPool

    @classproperty
    def jsExpression(self):
        return javascript.js(self.className)

    #
    # INSTANCE ATTRIBUTES
    #

    controller = None  #: instance of the controller class
    initialData = None  #: initial vue data to sync with client
    template = None  #: template string
    props = None  #: props set by developer for this component
    methods = None  #: list of javascript methods (python methods get pulled in via inspection)
    computed = None  #: list of vue computed properties
    mixins = None  #: vue mixins
    provide = None  #: vue provides
    inject = None  #: vue injects
    components = None  #: set of component `className`s that this component may need to use
    referencedComponents = None  #: internally generated list of components used but not to be instantiated
    # used for external components and components that are *not linked*
    # N.B. for now this is a list of External component classes, we may do something for unlinked comps later
    children = None  #: list of components mentioned in the template (and therefore components that
    # need to be included in the components attribute in vue for local component registration
    lifecycle = None  #: dict of lifecycle methods to attach to the component
    watch = None  #: dict of watchers
    syncProps = None  #: list of props to bring in from client side so they can be referenced in python code
    # (w/out needing to send them through event arguments)

    #
    # PROXY ATTRIBUTES AND METHODS
    #

    data = None  #: masked by proxy to provide synced access to data
    client = None  #: masked by proxy to provide access to js client calls
    parent = None  #: masked by proxy to provide access to the parent item
    attrs = None  #: masked by proxy to automatically synchronized IN (not out) attributes / props
    isProxied = False  #: shadowed by proxy to indicate we're in a proxy

    def up(self, className=None) -> typing.ForwardRef("Component"):
        """Masked by proxy to provide access to components higher up the hierarchy"""
        raise RuntimeError(f"Cannot call {self!r}.app({className!r}) on an unlinked class (try setting linked=True)")

    def down(self, className=None) -> typing.ForwardRef("Component"):
        """Masked by proxy to provide access to components lower down the hierarchy"""
        raise RuntimeError(f"Cannot call {self!r}.app({className!r}) on an unlinked class (try setting linked=True)")

    @property
    def app(self) -> typing.Any:
        """Masked by proxy to provide access to the root component"""
        raise AttributeError(f"Cannot acceess {self!r}.app() on an unlinked class (try setting linked=True)")

    #
    # INSTANCE METHODS
    #

    def __init__(self):
        if self.template:
            self.children, self.processedTemplate = self.processTemplate()
        else:
            self.children = []
            self.processedTemplate = ""
            self.referencedComponents = []

        for className in self.components or []:
            if className in ComponentMetaclass.byClassName:
                self.children.add(className)
            elif className in ExternalMetaclass.byClassName:
                self.referencedComponents.add(ExternalMetaclass.byClassName[className])

        if self.isApplication:
            ComponentMetaclass.instances[self.className] = self

    def getData(self):
        if self.initialData:
            if hasattr(self.initialData, "__call__"):
                return self.initialData()
            if isinstance(self.initialData, dict):
                return self.initialData
            else:
                raise TypeError("data attribute must be a function or a dict")
        else:
            return None

    def processTemplate(self):
        p = ModifyingTemplateParser(parent=self)
        p.feed(self.template)
        p.close()
        self.referencedComponents = p.referencedComponents
        env = jinja2.Environment(
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
            variable_start_string="{&",
            variable_end_string="&}",
            extensions=["jinja2.ext.i18n"],
        )
        template = jinja2.Template.from_code(
            env, env.compile(self.template, filename=inspect.getfile(self.__class__)), None, None
        )
        rendered = template.render(ComponentMetaclass.getTemplateContext(self))

        return p.components, rendered

    @classmethod
    def _as_javascript(cls):
        return "() => import('./%s.vue')" % cls.className

    def __repr__(self):
        return "<Component %s %s>" % (self.className, hex(id(self))[-4:])


class External(metaclass=ExternalMetaclass):
    """
    A convenient way to refer to an external component that we need to import and refer to by a class name

    Once an external component is created it is registered with the component metaclass and can be found by
    id etc. External components are referenced and create imports but never generate an actual .vue file.

    :var imports: list of js import statements
    :var className: the name of the imported javascript class (defaults to the python class name)
    :var tagName: the name of the tag (kebab-case version of className)
    """

    imports = None  #: required imports
    notInComponents = False  #: set to true to stop this being added to the component list (useful for globals/plugins)

    @classproperty
    def className(self):
        """The Python class name for this component (also used to attach instances to parents)"""
        return self.__name__

    @classproperty
    def tagName(self):
        """The name of this component in kebab-case as used in HTML tags in a vue template"""
        return pascalToKebab(self.className)

    @classproperty
    def jsExpression(self):
        return javascript.js(self.className)

    def getComponents(self, root=None):
        if root is not None and root is not self:
            raise ValueError("External can only get components for itself")
        return []


class ModifyingTemplateParser(HTMLParser):
    """
    Template parser that finds all components used in the template so we can import them and include them in .components
    """

    def __init__(self, *args, parent=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.referencedComponents = set()  #: list of all external components referenced by the template
        self.components = set()  #: list of all internal components referenced by the template
        self.refs = dict()  #: dict of ref name => component instance
        self.parent = parent  #: parent component used for error reporting

    def error(self, message):
        raise ComponentError("Error parsing template for %r: %s" % (self.parent, message))

    def handle_starttag(self, tag, attrs):
        raw = self.get_starttag_text()
        tag = raw[1 : 1 + len(tag)]  # we get the tag directly from raw to retain capitalization

        if tag.lower() in [
            "template",
            "component",
            "transition",
            "transition-group",
            "keep-alive",
            "slot",
            "transitiongroup",
            "keepalive",
        ]:
            return

        if tag in ComponentMetaclass.byClassName:
            self.components.add(tag)
        elif tag in ComponentMetaclass.byTag:
            self.components.add(ComponentMetaclass.byTag[tag].className)
        elif tag in ExternalMetaclass.byClassName:
            self.referencedComponents.add(ExternalMetaclass.byClassName[tag])
        elif tag in ExternalMetaclass.byTag:
            self.referencedComponents.add(ExternalMetaclass.byTag[tag])
        elif tag and tag not in HTML_AND_VUE_TAGS:
            warnings.warn("Unknown tag %s found in template on %r" % (tag, self.parent))
