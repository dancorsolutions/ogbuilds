export function execExpr(expr, vars) {
	var keys = Object.keys(vars);
	var exprFunc = Function.apply(null,keys.concat([expr]));
	var args = keys.map(function (key) { return vars[key] });
	return exprFunc.apply(null, args);
}

export function evalExpr(expr, vars) {
	var keys = Object.keys(vars);
	var exprFunc = Function.apply(null,keys.concat(["return "+expr]));
	var args = keys.map(function (key) { return vars[key] });
	return exprFunc.apply(null, args);
}

export function evalWithThis(o,expr,vars) {
	var keys = Object.keys(vars);
	var exprFunc = Function.apply(null,keys.concat(["return "+expr]));
	var args = keys.map(function (key) { return vars[key] });
	return exprFunc.bind(o).apply(null, args);
}

export function isTRUE(x) {
	if(typeof(x) == 'undefined')
		return false;
	if(x)
		return true;
	else
		return false;
}

export function isNULL(x) {
	return x === null;
}

export function isUD(x) {
	return (typeof(x) == 'undefined');
}

export function isEMPTY(x) {
	if(isUD(x))
		return true;
	if(isNULL(x))
		return true;
	if(x.__count__ === 0)
		return true;
	if(x === "")
		return true;
	return false;
}

/**
 * UUID string generator
 * @return returns true if this is an array (i.e. [] rather than {})
 * @type bool
 */
export function newUID() {
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, _newUID);
}
export function _newUID(cc) {
	var rr = Math.random() * 16 | 0; return (cc === 'x' ? rr : (rr & 0x3 | 0x8)).toString(16);
}

/**
 * Check if an object is an array
 * @return returns true if this is an array (i.e. [] rather than {})
 * @type bool
 */
export function isArray(array) {
	return array instanceof Array;
}

/**
 * Check if an object is a date
 * @return returns true if this is a date
 * @type bool
 */
export function isDate(o) {
	return o instanceof Date;
}
/**
 * Escape an HTML string
 * @return returns an escaped string
 * @type String
 */
export function escapeHTML(str) {
	return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 * Compare two objects (recursively)
 * @return returns -1, 0 or 1
 * @type int
 */
export function compare(o1,o2) {
	if (typeof(o1) > typeof(o2)) {
		return 1;
	} else if (typeof(o1) < typeof(o2)) {
		return -1;
	} else if (isUD(o1) && !isUD(o2)) {
		return 1;
	} else if (!isUD(o1) && isUD(o2)) {
		return -1;
	} else if (isNULL(o1) && !isNULL(o2)) {
		return 1;
	} else if (!isNULL(o1) && isNULL(o2)) {
		return -1;
	} else {
		if (isDate(o1) && !isDate(o2)) {
			return 1;
		} else if (!isDate(o1) && isDate(o2)) {
			return 1;
		} else if (isDate(o1) && isDate(o2)) {
			if (o1 > o2) {
				return 1;
			} else if (o1 < o2) {
				return -1;
			} else {
				return 0;
			}
		} else if (isArray(o1) && !isArray(o2)) {
			return 1;
		} else if (!isArray(o1) && isArray(o2)) {
			return -1;
		} else if (isArray(o1) && isArray(o2)) {
			if(o1.length > o2.length) {
				return 1;
			} else if(o1.length < o2.length) {
				return -1;
			} else {
				for(var i=0;i<o1.length;i++) {
					var rc = compare(o1[i],o2[i]);
					if(rc !== 0) {
						return rc;
					}
				}
				return 0;
			}
		} else if(typeof(o1) == "object") {
			if(typeof(o2) != "object") {
				return 1;
			}
			for(var k in o1) {
				if(!(k in o2)) {
					return -1;
				}
				var rc = compare(o1[k],o2[k]);
				if(rc!=0) {
					return rc;
				}
			}
			for(var k in o2) {
				if(!(k in o1)) {
					return 1;
				}
				var rc = compare(o1[k],o2[k]);
				if(rc!=0) {
					return rc;
				}
			}
			return 0;
		} else {
			if(o1 == o2) {
				return 0;
			} else if (o1>o2) {
				return 1;
			} else {
				return -1;
			}
		}
	}
}

/**
 * Simple comparison function for objects which compares each of their key/values <br/>
 * @return returns a new object with the latest values for all keys that are different
 * @type int
 */
export function deltaObjects(o1,o2) {
	var out = {};
	if(isUD(o1)) {
		return o2;
	}
	for(let k in o1) {
		if(!(k in o2)) {
			out[k] = undefined;
		}
	}
	for(let k in o2) {
		if((compare(o1[k],o2[k]) !== 0) ) {
			out[k] = o2[k];
		}
	}
	return out;
}

/**
 * Deep copy function
 */
export function clone(o) {
	if(o === undefined)
		return o;
	return JSON.parse(JSON.stringify(o));
}


export function arrayEquals(array1, array2) {
    var len1 = array1.length,
        len2 = array2.length,
        i;

    if (array1 === array2) {
        return true;
    }

    if (len1 !== len2) {
        return false;
    }

    for (i = 0; i < len1; ++i) {
        if (array1[i] !== array2[i]) {
            return false;
        }
    }

    return true;
}

export function setCookie(name, value, expires_seconds) {
  let s = name + "=" + value;
  if(expires_seconds)
    s += ";max-age=" + expires_seconds
  s += ";path=/";
  document.cookie = s;
}


export function deleteCookie(cname) {
  setCookie(cname, '', null);
}


export function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
