# roundtrip

An full-stack application framework for Python.

## What is roundtrip?

Roundtrip is a full-stack application framework for Python. It’s designed to make the process of connecting
front-end components with backend data and compute simple and intuitive.

## Why roundtrip?

We were building a high-value microservices-based application and we were spending a ton of time communicating back 
and forth and dealing with bugs and mismatches between backend and frontend teams. Building and debugging the 
boilerplate to pull data from a backend service and display it in the frontend was a huge time sink. We wanted to 
find a better way.

roundtrip's philosophy is to move away from the standard approach to web apps which is a front-end monolith that 
talks to a set of back-end services (often much more tightly coupled to the front-end than anyone is willing to 
admit).

Instead, we want developers to *compose* applications out of a set of loosely coupled components. Each component
is a self-contained unit of functionality that can be developed, tested, and deployed independently. Components
can include both front-end and back-end code.

Imagine you write a complex data-driven component that knows how to connect to the database, page in data, do searching
and filtering, update the database, etc. You've worked with a backed developer (or yourself) to craft just the right 
APIs so you can show what you want to show on screen and deal with the user interactions you need to handle.

Now you want another one that does something similar but with a different data source and slightly different behaviors
and constraints. We found we would be copying and pasting frontend and backend code and then modifying it to fit the
new use case. This was a huge time sink and a source of bugs.

With roundtrip, you can build a component that knows how to talk to the database and display the data in a table. You
write another class that inherits it, then override server-side methods and/or client-side templates as needed to
create your new functionality.

## How does roundtrip work?

You write roundtrip components in Python and Vue. You can choose to put all your Vue components in external Vue files
or in a separate Vue package, or you can write your Vue / HTML directly in your Python code.

A simple roundtrip component that combines backend and frontend functionality looks like this:

```python
from roundtrip.component.component import Component
from roundtrip.component.decorators import *

class MyComponent(Component):

    # language=Vue
    template = """
    <div>
        <h1>The button has been clicked {{ count }} times</h1>
        <button @click="do_add">Increment</button>
    </div>
    """

    initialData = dict(
        count=0
    )

    @method
    def do_add(self):
        self.data.count += 1
```

That's something you can readily do in Vue of course, but what if you wanted to put your counter in a database?

```python
from roundtrip.component.component import Component
from roundtrip.component.decorators import *

import pymongo

mongo_client = pymongo.MongoClient()

class MyComponent:

    # language=Vue
    template = """
    <div>
        <h1>The button has been clicked {{ count }} times</h1>
        <button @click="do_add">Increment</button>
    </div>
    """

    initialData = dict(
        count=None
    )

    @lifecycle
    def mounted(self):
        self.data.count = mongo_client.db.my_collection.fetch_one({})['count']
    
    @method
    def do_add(self):
        self.data.count += 1
        mongo_client.db.my_collection.update_one(dict(), dict(count=self.data.count))
```

Now we have a component that will fetch the current count from the database when it's mounted, and update the database
when the button is clicked. We didn't have to develop any backend boilerplate to interpret requests from the frontend
and send responses back. We didn't have to develop any frontend boilerplate to make requests to the backend and handle
responses.

## roundtrip's killer app: Semantik

roundtrip helped us write data driven single-page web and mobile apps faster. But it also enables a new way of coding
data-driven backoffice applications that we call Semantik.

Semantik lets us write fully-featured administrative and backoffice interfaces very quickly. We can build a full
application with a database, user authentication, and a full set of CRUD operations in less than an hour and this
means we can put a lot more functionality, and often a lot more flexibility and configuratbility in user's hands
without a blowing our project budgets.

roundtrip's way of letting us compose components that are backend-aware into complex applications is critical to 
building Semantik and we think it's a great way to build applications in general.


