from . import javascript
import inspect
import copy
import weakref

from ..server import connection

SEND_DEBUG_DATA_WITH_UPDATES = False

__all__ = ["State", "unwrap"]


class NODEFAULT(object):
    pass


class bulk:
    """
    bulk data speficier: don't bother unwrapping
    """

    def __init__(self, data):
        self.data = data

    def __deepcopy__(self, memo):
        memo[id(self)] = self.data
        return self.data


def unwrap(item):
    """
    Remove any persistence wrappers from the item

    E.g. if item is a PersistentList, return a plain old list. Do this recursively.
    """
    if isinstance(item, PersistentDict):
        return unwrap(item._b)
    elif isinstance(item, PersistentList):
        return unwrap(item._b)
    elif isinstance(item, dict):
        return {k: unwrap(v) for k, v in item.items()}
    elif isinstance(item, list):
        return [unwrap(i) for i in item]
    elif isinstance(item, bulk):
        return item
    else:
        return item


class PersistentBase(object):
    # defaults to help dev tools
    _parent = None
    _k = None
    _b = None

    def __init__(self, parent, k):
        self.__dict__["_parent"] = parent
        self.__dict__["_k"] = k
        self.__dict__["_b"] = None

    def _wrap(self, k, v):
        """
        Wrap an item to ensure changes on it can be observed

        When adding a list/dict onto a PersistentList / PersistentDict we need to make sure the item is itself a
        PersistentList / PersistentDict (or it won't register changes) and that it's linked to the same underlying
        connection etc.
        """
        if isinstance(v, dict):
            if len(v):
                a_key = next(iter(v.keys()))
                if type(a_key) is not str:
                    raise ValueError(f"Cannot use {type(a_key)!r} as a key in state (only strings)")
            return PersistentDict(self, k, v)
        elif isinstance(v, list):
            return PersistentList(self, k, v)
        elif isinstance(v, PersistentList):
            return PersistentList(self, k, v._b)
        elif isinstance(v, PersistentDict):
            return PersistentDict(self, k, v._b)
        elif isinstance(v, tuple):
            raise ValueError(f"Cannot assign a tuple to a PersistentDict or PersistentList ({v!r})")
        elif isinstance(v, set):
            raise ValueError(f"Cannot assign a set to a PersistentDict or PersistentList ({v!r})")
        else:
            return v

    def _as_javascript(self):
        return javascript.dumps(self._b)

    def _rt_update(self, action, name=None):
        if name is None and SEND_DEBUG_DATA_WITH_UPDATES:
            name = self._rt_get_action_name()
        self._parent._rt_update(action={self._k: action}, name=name)

    def __eq__(self, other):
        if isinstance(other, PersistentBase):
            return self._b == other._b
        else:
            return self._b == other

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return "p" + repr(self._b)

    @staticmethod
    def _rt_get_action_name():
        stack = inspect.stack()
        frame, file, line, module, lines, index = stack[4]
        return "%s line %s" % (file, line)


class PersistentList(PersistentBase):
    def __init__(self, parent, k, b=None):
        super(PersistentList, self).__init__(parent=parent, k=k)
        self.__dict__["_b"] = [] if b is None else [self._wrap(index, i) for index, i in enumerate(b)]

    # Mutators

    def __setitem__(self, k, v):
        old = self._b[k]
        if old == v:
            return  # only process changes
        self._b.__setitem__(k, self._wrap(k, v))
        if not isinstance(k, int) or isinstance(k, slice):
            raise TypeError("Indices must be integers or slices")
        if isinstance(k, slice):
            assert not k.step
            self._rt_update({"$splice": [[k.start, (k.stop - k.start), v]]})
        else:
            if type(old) is str and old and type(v) is str and v.startswith(old):
                self._rt_update({k: {"$add": v[len(old) :]}})
            else:
                self._rt_update({"$splice": [[k, 1, v]]})

    def __delitem__(self, k):
        self._b.__delitem__(k)
        if isinstance(k, slice):
            assert not k.step
            if k.stop and k.start:
                self._rt_update({"$splice": [[k.start, k.stop - k.start]]})
            elif k.start:
                self._rt_update({"$splice": [[k.start]]})
            elif k.stop:
                self._rt_update({"$splice": [[0, k.stop]]})
            else:
                self._rt_update({"$splice": [[0]]})
        else:
            if k == -1:
                k = len(self._b) - 1
            self._rt_update({"$splice": [[k, 1]]})
        self.__renumber()

    def __renumber(self):
        for i in range(len(self._b)):
            self._b[i].__dict__["_k"] = i

    def __iadd__(self, other):
        if isinstance(other, PersistentList):
            other = other._b
        self._b += [self._wrap(index, i) for index, i in enumerate(other)]
        self._rt_update({"$push": other})
        self.__renumber()
        return self

    def __add__(self, other):
        if isinstance(other, PersistentList):
            return self._b + other._b
        else:
            return self._b + other

    def __radd__(self, other):
        if isinstance(other, PersistentList):
            return other._b + self._b
        else:
            return other + self._b

    def append(self, i):
        rc = self._b.append(self._wrap(len(self._b), i))
        self._rt_update({"$push": [i]})
        return rc

    def extend(self, lst):
        self._b.extend([self._wrap(i + len(self._b), v) for i, v in enumerate(lst)])
        self._rt_update({"$push": lst})

    def insert(self, i, v):
        if i == -1:
            i = len(self._b)
        rc = self._b.insert(i, self._wrap(i, v))
        self._rt_update({"$splice": [[i, 0, v]]})
        self.__renumber()
        return rc

    def pop(self, i=-1):
        rc = self._b[i]
        del self[i]
        self.__renumber()
        return rc

    def push(self, v):
        self.insert(-1, v)
        self.__renumber()

    def clear(self):
        self._rt_update({"$splice": [[0, -1]]})
        self._b.clear()

    # Non-mutators

    def __getitem__(self, k):
        return self._b.__getitem__(k)

    def __iter__(self):
        return self._b.__iter__()

    def __len__(self):
        return self._b.__len__()

    def __contains__(self, v):
        return self._b.__contains__(v)


class PersistentDict(PersistentBase):
    def __init__(self, parent, k, b=None):
        super(PersistentDict, self).__init__(parent=parent, k=k)
        self.__dict__["_b"] = dict() if b is None else {k: self._wrap(k, v) for k, v in b.items()}

    def __setitem__(self, k, v):
        old = self._b.get(k, NODEFAULT)
        if (old == v) is True:
            return  # only process changes
        if type(old) is str and old and type(v) is str and v.startswith(old):
            self._b.__setitem__(k, self._wrap(k, v))
            self._rt_update({k: {"$add": v[len(old) :]}})
        else:
            self._b.__setitem__(k, self._wrap(k, v))
            self._rt_update({k: {"$set": v}})

    def __delitem__(self, k):
        del self._b[k]
        self._rt_update({"$unset": [k]})

    def update(self, d):
        if not d:
            return
        d = {k: v for k, v in d.items() if self._b.get(k, NODEFAULT) != v}  # only changes
        if not d:
            return
        self._b.update({k: self._wrap(k, v) for k, v in d.items()})
        self._rt_update({"$merge": d})

    # Non-mutators

    def __getitem__(self, k):
        return self._b.__getitem__(k)

    def __len__(self):
        return self._b.__len__()

    def __contains__(self, i):
        return self._b.__contains__(i)

    def get(self, *args):
        return self._b.get(*args)

    def items(self):
        return self._b.items()

    def __iter__(self):
        return self._b.__iter__()

    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError:
            if self._k == "state":
                raise AttributeError("state.%s" % item)
            else:
                raise AttributeError("state...%s.%s" % (self._k, item))

    def __setattr__(self, item, value):
        self[item] = self._wrap(item, value)

    def __repr__(self):
        return "p" + repr(self._b)

    def _rt_update_all(self):
        self._rt_update({"$merge": self._b})


class State(PersistentDict):
    def __init__(self, connectionRef, uid, initial):
        super(State, self).__init__(parent=self, k=uid, b=initial)
        self.__dict__["_connection"] = connectionRef
        self.__dict__["_uid"] = uid

    def _rt_update(self, action, name=None):
        # we deepcopy whatever update is being made because we want to update with what the data was at the time
        # the state was updated in the Python code, not at the point we send data to the server at the end of the
        # request handler
        unwrapped = unwrap(action)
        try:
            copied = copy.deepcopy(unwrapped)
        except KeyError as e:
            if e.args[0] == "__deepcopy__":
                raise ValueError(
                    f"Assigning to state {self._uid!r} failed because it contains a "
                    f"non-deep-copyable object {action!r}"
                )
            else:
                raise e
        self._connection().remoteCallQueue.append(dict(update={self._uid: copied}, name=name))

    def __repr__(self):
        return "<State uid=%s %r>" % (self._uid, self._b)
