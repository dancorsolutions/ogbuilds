import logging
import argparse
import pprint
import secrets
from pathlib import Path
import re

import jinja2
import jsonschema
import yaml

import roundtrip

config_schema = dict(
    type="object",
    properties=dict(
        system_name=dict(type="string"),
        company_name=dict(type="string", default="my_company_name"),
        applications=dict(
            type="object",
            additioanlProperties=dict(
                type="object",
                properties=dict(
                    with_semantik=dict(type="boolean", default=False),
                    with_mongo=dict(type="boolean", default=False),
                    with_tinymce=dict(type="boolean", default=False),
                ),
            ),
        ),
    ),
)


def extend_with_default(validator_class):
    validate_properties = validator_class.VALIDATORS["properties"]

    def set_defaults(validator, properties, instance, schema):
        for property, subschema in properties.items():
            if "default" in subschema:
                instance.setdefault(property, subschema["default"])

        for error in validate_properties(
            validator,
            properties,
            instance,
            schema,
        ):
            yield error

    return jsonschema.validators.extend(
        validator_class,
        {"properties": set_defaults},
    )


DefaultingValidator = extend_with_default(jsonschema.Draft7Validator)


class Config(dict):
    def __getattr__(self, item):
        if item not in self:
            raise AttributeError(item)
        return self[item]


def dict_to_config(config):
    if type(config) is not dict:
        return config
    out = Config()
    for k, v in config.items():
        if type(v) is dict:
            out[k] = dict_to_config(v)
        elif type(v) is list:
            out[k] = [dict_to_config(i) for i in v]
        else:
            out[k] = v
    return out


class ApplicationGenerator:
    """
    Process templates to generate an application skeleton
    """

    def __init__(self, config, target_path, template_name="basic", dry_run=True):
        self.logger = logging.getLogger("roundtrip-cli")
        self.config = config
        self.target_path = target_path
        self.dry_run = dry_run
        self.path = Path(roundtrip.__file__).parent
        self.template_path = self.path / "cli" / "templates" / template_name

        self.context = dict(**self.config)
        self.context["target_path"] = str(target_path)
        self.context["roundtrip_path"] = str(self.path)
        self.context["enumerate"] = enumerate
        try:
            import semantik
        except:
            self.logger.error("cannot load semantik")
        else:
            self.context["semantik_path"] = str(Path(semantik.__file__).parent)
        self.context["secrets"] = secrets

    def render_template(self, template, additional_context):
        env = jinja2.Environment(autoescape=False)
        compiled_template = jinja2.Template.from_code(env, env.compile(template, filename=template), None, None)
        if additional_context:
            context = dict(**self.context)
            context.update(additional_context)
        else:
            context = self.context
        rendered = compiled_template.render(context)
        return rendered

    def generate(self):
        self.logger.info("generating project files")

        for template_file in self.template_path.rglob("*"):
            if not template_file.is_file():
                continue

            if template_file.name == ".DS_Store":
                continue

            relative_path = str(template_file.relative_to(self.template_path))

            if "==system_name==" in relative_path:
                relative_path = relative_path.replace("==system_name==", self.config.system_name)

            if "==application_name==" in relative_path:
                for application_name, application_config in self.config.applications.items():
                    application_config["application_name"] = application_name
                    if application_config.with_semantik:
                        application_config.with_mongo = True
                    relative_path = relative_path.replace("==application_name==", application_name)

                    if "-raw-" in relative_path:
                        relative_path = relative_path.replace("-raw-", "")
                        self.generate_one(
                            template_file,
                            relative_path=Path(relative_path),
                            additional_context=application_config,
                            raw=True,
                        )
                    elif "-if-" in relative_path:
                        m = re.search("-if-(.*?)-", relative_path)
                        condition = m.group(1)
                        if eval(condition, self.context | application_config):
                            relative_path = relative_path.replace(m.group(0), "")
                            self.generate_one(
                                template_file, relative_path=Path(relative_path), additional_context=application_config
                            )
                    else:
                        self.generate_one(
                            template_file, relative_path=Path(relative_path), additional_context=application_config
                        )

            else:
                self.generate_one(template_file, relative_path=Path(relative_path))

    def generate_one(self, template_file, relative_path, additional_context=None, raw=False):
        # render template
        template = template_file.read_text("latin-1")

        if template_file.suffix in [".png", ".svg", ".jpg", ".jpeg", ".ico"] or raw:
            rendered = template
        else:
            try:
                rendered = self.render_template(template, additional_context)
            except:
                print(f"compiling {template_file}")
                raise

        target = self.target_path / relative_path

        # write template
        exists = target.exists()
        if exists and target.read_text("latin-1") == rendered:
            if target.stat().st_mode != template_file.stat().st_mode:
                self.logger.debug(f" = {relative_path}: chmod change only")
                target.chmod(template_file.stat().st_mode)
            else:
                self.logger.debug(f" = {relative_path}: no change")
        else:
            if not self.dry_run:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(rendered, "latin-1")
                target.chmod(template_file.stat().st_mode)
            if exists:
                self.logger.debug(f" - {relative_path}: updated")
            else:
                self.logger.debug(f" + {relative_path}: created")


def go():
    # logging
    logging.basicConfig(level=logging.WARNING)
    logging.getLogger("roundtrip-cli").setLevel(logging.DEBUG)

    # command line arguments
    path = Path(roundtrip.__file__).parent
    schema_path = path / "cli" / "schema.yaml"
    parser = argparse.ArgumentParser(description="Build a new system skeleton.")
    parser.add_argument("--config", dest="config", help="Path to the application configuration file", required=True)
    parser.add_argument(
        "--dest", dest="destination", help="Path where this tool should place the system skeleton", required=True
    )
    parser.add_argument(
        "--dry_run",
        dest="dry_run",
        action="store_true",
        default=False,
        help="Do not create or update files, just print actions that would be taken",
    )
    parser.add_argument(
        "--template",
        dest="template",
        default="basic",
        help="The template set to use to generate the application (basic or advanced)",
    )
    args = parser.parse_args()

    # config file
    config = yaml.load(Path(args.config).read_text("latin-1"), Loader=yaml.Loader)
    DefaultingValidator(config_schema).validate(config)
    config = dict_to_config(config)

    # generate templates
    target_path = Path(args.destination)
    gen = ApplicationGenerator(
        config=config, target_path=target_path, template_name=args.template, dry_run=args.dry_run
    )
    gen.generate()
