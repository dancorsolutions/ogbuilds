import types
import time
import weakref
import uuid

__all__ = ["callbacks"]


class CallbackRegister(object):
    """
    Temporary place to store (weak) references to callback functions that have been passed in to the Javascript side
    """

    def __init__(self):
        self.callbacks = dict()
        self.lastCleanup = time.time()

    def register(self, ob):
        self.cleanup()
        uid = str(uuid.uuid4())
        if isinstance(ob, types.MethodType):
            self.callbacks[uid] = ob.__func__, weakref.ref(ob.__self__), ob.__self__.__class__
        else:
            self.callbacks[uid] = weakref.ref(ob)
        return uid

    def cleanup(self):
        if time.time() - self.lastCleanup < 10.0:
            return
        to_del = set()
        for k, v in self.callbacks.items():
            if type(v) is tuple:
                if v[1]() is None:
                    to_del.add(self.callbacks[k])
            elif v() is None:
                to_del.add(self.callbacks[k])
        for k in to_del:
            del self.callbacks[k]
        self.lastCleanup = time.time()

    def get(self, ident):
        if str(ident) not in self.callbacks:
            return None
        ob = self.callbacks[str(ident)]
        if type(ob) is tuple:
            if ob[1]() is None:
                return None
            return types.MethodType(ob[0], ob[1]())
        else:
            return ob()


callbacks = CallbackRegister()
