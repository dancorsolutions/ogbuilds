import argparse

parser = argparse.ArgumentParser(description="Run a roundtrip server.")

parser.add_argument(
    "-c",
    "--config",
    dest="config_file",
    default=None,
    help="Load config from a specific location (instead of ./config.yaml)",
)

parser.add_argument(
    "-r",
    "--run-only",
    action="store_true",
    dest="run_only",
    default=None,
    help="Do not generate code, just run the server",
)

parser.add_argument(
    "-g",
    "--generate-only",
    action="store_true",
    dest="generate_only",
    default=None,
    help="Generate javascript code and exit",
)

parser.add_argument(
    "-u", "--url", dest="server_url", default=None, help="Generate code with the given server url (overrides config)"
)

parser.add_argument("-p", "--port", dest="port", default=None, help="Override the port # in config.yaml")

parser.add_argument("-d", "--debug", action="store_true", dest="debug_mode", default=None, help="Run in debug mode")


def update_config_from_args(config):
    args, _ = parser.parse_known_args()

    for k in ("generate_only", "debug_mode", "server_url", "port"):
        if getattr(args, k, None) is not None:
            print("overwriting config for %s with command line value %s" % (k, getattr(args, k)))
            setattr(config, k, getattr(args, k))
