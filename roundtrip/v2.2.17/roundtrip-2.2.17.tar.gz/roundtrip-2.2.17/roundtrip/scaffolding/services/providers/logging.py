__all__ = ["LoggingProvider"]

import logging
import logging.config

from ....server.connection import Connection
from .base import *


class PingFilter(logging.Filter):
    """
    Remove requests to /ping (keepalive handler) from logs (otherwise they'll fill up with this stuff)
    """

    def filter(self, record):
        if getattr(record, "module", None) == "web":
            args = getattr(record, "args")
            if type(args) is tuple and len(args) > 1 and type(args[1]) is str and "ping" in args[1]:
                return False
        return True


class RoundtripFilter(logging.Filter):
    """
    Add the current roundtrip connection id to the log for debugging
    """

    def filter(self, record):
        if hasattr(record, "rtid"):
            return True
        if Connection.current:
            record.rtid = getattr(Connection.current, "connectionId", "")
        else:
            record.rtid = ""
        return True


class LoggingProvider(Provider):
    ident = "logging"

    def initialize(self):
        logging.config.dictConfig(self.server.config.logging)
