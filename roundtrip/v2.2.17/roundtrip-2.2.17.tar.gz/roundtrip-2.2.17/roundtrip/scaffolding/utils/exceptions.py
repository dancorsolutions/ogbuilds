__all__ = ["RTError", "SecurityError"]


class RTError(Exception):
    pass


class SecurityError(RTError):
    pass
