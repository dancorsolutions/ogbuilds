import hashlib
import datetime

from mongoengine import *
import secrets

__all__ = ["SaltedPassword"]


class PasswordError(Exception):
    pass


class LockedError(PasswordError):
    pass


class SaltedPassword(EmbeddedDocument):
    """
    Salt/hashed password
    """

    max_tries = 5

    salt = BinaryField()
    hashed = BinaryField()
    date_set = DateTimeField()
    tries = IntField(default=0)
    locked = BooleanField(default=False)

    LockedError = LockedError

    @classmethod
    def new(cls, password):
        sp = cls()
        sp.set(password)
        return sp

    def set(self, password):
        self.salt = secrets.token_bytes(16).decode("utf-8", "replace").encode("ascii", "replace")
        self.hashed = hashlib.sha512(password.encode("ascii") + self.salt).hexdigest().encode("ascii", "replace")
        self.date_set = datetime.datetime.now()
        self.tries = 0
        self.locked = False
        return self

    def check(self, password, with_lockout=True):
        if self.locked:
            raise LockedError()
        if self.tries >= self.max_tries:
            self.lock()
            raise LockedError()
        if not self.hashed:
            return False
        hashed = hashlib.sha512(password.encode("ascii") + self.salt).hexdigest().encode("ascii", "replace")
        if hashed == self.hashed:
            self.tries = 0
            return True
        if with_lockout:
            self.tries += 1
        return False

    def reset(self):
        self.salt = None
        self.hashed = None
        self.date_set = None
        self.tries = 0

    def unlock(self):
        self.locked = False
        self.tries = 0

    def lock(self):
        self.locked = True
        self.tries = 0

    @property
    def is_set(self):
        return True if self.hashed else False

    @property
    def tries_remaining(self):
        return (self.max_tries + 1) - self.tries
