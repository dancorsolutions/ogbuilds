"""
An ImageSystem that fetches icons from thenounproject.com automatically and stores them locally given an icon id
"""

import requests
from requests_oauthlib import OAuth1
from . import imagesystem
import os.path
import pprint

__all__ = ["ImageSystem"]


class ImageSystem(imagesystem.ImageSystem):
    def __init__(self, *args, **kargs):
        super(ImageSystem, self).__init__(*args, **kargs)
        self.api_key = "e11c5993db8b4d1195c3180fdf2b82a4"
        self.api_secret = "2aa91a04b2b64f5bb0bc9c46947f5826"
        self.auth = None

    def ensure(self, iconId):
        iconId = str(iconId)
        key = "noun-%s" % iconId
        if not self.auth:
            self.auth = OAuth1(client_key=self.api_key, client_secret=self.api_secret)
            response = requests.get("http://api.thenounproject.com/icon/2909", auth=self.auth)
            pprint.pprint(response.json())

        fName = os.path.join(self.fsPath, key) + ".svg"
        self.images[fName] = key
        if os.path.exists(fName):
            return key

        response = requests.get("http://api.thenounproject.com/icon/%s" % iconId, auth=self.auth)
        icon = response.json()
        pprint.pprint(icon)
        print([i for i in icon["icon"]["icon_url"][0].keys()])
        url = icon["icon"]["collections"][0]["icon_url"]
        response = self.auth.get(url)

        assert response.status_code == 200
        open(fName, "wb").write(response.text.encode("latin-1"))
        return key

    def svg(self, iconId):
        key = self.ensure(iconId)
        return imagesystem.ImageReference("app.images[%r]" % key)
