"""
New pluggable server architecture


The core idea here is to properly decouple configuration, core server code, and variable server functionality
(like upload / download facilities).

We do this using a Provider plugin system.

You can add any number of providers to the server. Providers then *provide* various things to the server by
declaring methods that return the thing the server is looking for:
    - config(): returns a dict of ConfigItem definitions
    - handlers(): returns a list of Tornado handlers
    - ...

Providers are initialized (__init__) when they are added to an instance of Server but should not try to access the
server or the server's config until their provide-methods are called.

"""

__all__ = ["Server"]

import sys
import logging
import logging.config
import typing
import concurrent.futures
import dataclasses
import concurrent.futures
import subprocess
import time

import tornado.web
import tornado.ioloop

from .providers.base import Provider
from .providers.stats import StatsProvider
from ...server import dispatcher
from ...server import connection
from ...application import ApplicationOptions
from . import showwarning


class Object:
    threads = None
    connectionTimeout = None
    debugLevel = None
    port = None

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class SimpleConfig(Provider):
    def __init__(self, server, **kwargs):
        super().__init__(server)
        self.c = Object(**kwargs)

    def config(self):
        return self.c


@dataclasses.dataclass(kw_only=True)
class ServerConfig:
    server_url: str = ""
    session_timeout: float = 60.0 * 60.0
    debug_level: int = 10
    generate_only: bool = False
    port: int = 8001
    secure_websocket = False
    thread_pool: int = 8
    connection_timeout: int = 60.0 * 59.0
    stats: {} = dataclasses.field(default_factory=lambda: dict())
    static_server_path: str = None
    logging: dict or None = None


class Server:
    threadPool: concurrent.futures.ThreadPoolExecutor = None

    connectionManager: connection.ConnectionManager = None
    application = None
    applicationClass = None
    current = None  #: currently running Server object
    out_of_sync: bool = False  #: a flag that indicates we've regenerated frontend code but haven't restarted the
    #: backend server so we're using different versions for front- vs back-end code

    def __init__(self, applicationClass, path, config, vueSources=None, autoreload=None):
        self.initialized = False
        self.applicationClass = applicationClass
        self.path = path
        self.config = config
        self.providers = dict()
        self.handlers = []
        self.vueSources = vueSources or []
        self.autoreload = autoreload
        self.addProvider(StatsProvider)
        self.log = logging.getLogger("roundtrip.event")
        showwarning.install(self.log)

        if config.logging:
            logging.config.dictConfig(config.logging)
            logging.captureWarnings(True)
        else:
            # default logging configuration
            try:
                import rich.logging
            except ModuleNotFoundError:
                return
            else:
                handlers = [rich.logging.RichHandler(rich_tracebacks=False)]

            logging.captureWarnings(True)
            logging.basicConfig(
                level=logging.DEBUG,
                format="[%(asctime)s,%(msecs)s] %(name)s %(levelname)s: %(message)s "
                "at line %(lineno)s %(filename)s in %(funcName)s",
                datefmt="%Y/%m/%d-%H:%M:%S",
                handlers=handlers or None,
            )

    def getProvider(self, ident):
        return self.providers[ident]

    def addProvider(self, providerClass: typing.Type[Provider], **kwargs):
        provider = providerClass(server=self, **kwargs)
        if provider.ident in self.providers:
            raise ValueError(
                f"Attempt to add duplicate provider ident={provider.ident}, "
                f"current={provider!r}, "
                f"added={self.providers[provider.ident]!r}"
            )
        self.providers[provider.ident] = provider

    def getProvidedHandlers(self):
        handlers = []
        for provider in self.providers.values():
            if hasattr(provider, "handlers"):
                handlers += provider.handlers()
        return handlers

    def initialize(self):
        if self.initialized:
            return

        self.application = self.applicationClass()

        for provider in self.providers.values():
            provider.initialize()

        self.initialized = True

    def generate(self, only=None):
        if self.config.server_url:
            if "websocket" in self.config.server_url or not self.config.server_url.endswith("/"):
                raise RuntimeError('server_url should not include "websocket" and must end with "/"')

        options = ApplicationOptions(
            sessionTimeout=self.config.session_timeout,
            debugLevel=self.config.debug_level,
            secureWebsocket=self.config.secure_websocket,
        )

        if self.config.server_url:
            options.webSocketURL = self.config.server_url + "websocket"

        self.application.generateStaticJavascript(options=options, path=self.path, vueSources=self.vueSources)
        self.log.info("generating code with url=%s" % self.path)

    def run(self, max_body_size=1024 * 1024 * 200, max_buffer_size=1024 * 1024 * 200):
        self.threadPool = concurrent.futures.ThreadPoolExecutor(self.config.thread_pool)
        self.connectionManager = connection.ConnectionManager(timeout=self.config.connection_timeout)
        connection.connectionManager = self.connectionManager
        self.application._debugLevel = self.config.debug_level
        self.application.server = self
        self.tornadoApplication = None

        handlers = [
            (
                r"/websocket",
                dispatcher.WebSocketHandler,
                dict(
                    threadPool=self.threadPool,
                    connectionManager=self.connectionManager,
                    app=self.application,
                ),
            ),
        ]

        handlers += self.getProvidedHandlers()

        if self.config.static_server_path:
            self.log.info(f"Serving static files from {self.config.static_server_path}")
            handlers += [
                # Serve static files if the request ends with a file extension
                (
                    r"/(.*\..*)",
                    tornado.web.StaticFileHandler,
                    dict(
                        path=self.config.static_server_path,
                        default_filename="index.html",
                    ),
                ),
                # Otherwise always serve index.html
                (
                    r"/[^.]*()",
                    tornado.web.StaticFileHandler,
                    dict(path=self.config.static_server_path + "/index.html"),
                ),
            ]

        if self.config.debug_level:
            self.log.error("running in debug mode (only do this on development servers)")

        if self.autoreload is not None:
            autoreload = self.autoreload
        else:
            autoreload = not not self.config.debug_level

        self.tornadoApplication = tornado.web.Application(
            handlers,
            debug=True if self.config.debug_level else False,
            autoreload=False,
            serve_traceback=True if self.config.debug_level else False,
            compress_response=True,
        )
        self.tornadoApplication.connectionManager = self.connectionManager

        if autoreload == "regenerate_only":
            from . import autoreload

            autoreload.start(self.onReload)
        elif autoreload:
            from tornado import autoreload

            autoreload.start()

        self.tornadoApplication.listen(
            self.config.port, "0.0.0.0", max_body_size=max_body_size, max_buffer_size=max_buffer_size
        )

        self.beforeStartLoop()

        self.log.info(f"start listening on {self.config.port}")

        loop = tornado.ioloop.IOLoop.instance()
        loop.start()

    def beforeStartLoop(self):
        return

    def onReload(self, path, module):
        self.out_of_sync = True
        t_start = time.time()
        self.log.info(f"regenerating HTML after {module} changed")
        subprocess.run([sys.executable] + sys.argv + ["--generate-only"], timeout=10.0)
        self.log.info(f"regeneration complete in {time.time() - t_start:.2f}s")

    def go(self):
        self.initialize()
        self.generate()
        if self.config.generate_only or "--generate-only" in sys.argv:
            return
        Server.current = self
        self.run()
