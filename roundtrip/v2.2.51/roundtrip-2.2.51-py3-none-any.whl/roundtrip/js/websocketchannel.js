/**
 * @fileoverview
 * roundtrip WebSocket stuff - classes to wrap a web socket channel speaking the roundtrip protocol
 */

import EJSON from "./ejson.js"

let FROM_SERVER = "\u2B05"
let TO_SERVER = "\u2B95"

export class WebSocketChannel {
    constructor(url, connectionId, sessionTimeout, debug) {
        this.debug = debug

        this.sessionTimeout = sessionTimeout

        this.index = 0

        this.sendQueue = []
        this.receiveQueue = {}

        this.connectTimeout = 2000
        this.retryWait = 3000
        this.notifyTimeout = 600
        this.maxReconnects = 5000

        this.url = url
        this.connectionId = connectionId
        this.queryString = null
        this.isReconnection = false

        this.recentConnectionFailures = 0

        this.handlers = {
            connectionStateChange: null,
            error: null,
            response: null,
            outOfBand: null,
            connectionExpired: null,
        }

        this.connect(false)
    }

    listen(event, handler) {
        this.handlers[event] = handler
    }

    clearTimers() {
        clearTimeout(this.tmConnect)
        clearTimeout(this.tmRetry)
        clearTimeout(this.tmNotify)
        clearInterval(this.pingInterval)
    }

    reconnect() {
        this.clearTimers()
        this.recentConnectionFailures = 0
        this.connect(true)
    }

    connect() {
        this.clearTimers()
        this.cancelInFlight()
        if (this.webSocket) {
            this.webSocket.close()
        }
        this.hadSocketError = false

        this.url.searchParams.set(
            "isReconnection",
            this.isReconnection ? "true" : "false"
        )

        this.connectionId =
            this.connectionId ||
            this.url.searchParams.get("roundtripId") ||
            sessionStorage.getItem("roundtripId")

        if (this.connectionId) {
            this.url.searchParams.set("roundtripId", this.connectionId)
        }

        if (this.recentConnectionFailures > this.maxReconnects) {
            this.fireLater("connectionStateChange", "failed")
            return
        }
        if (!!this.connectionId)
            this.fireLater("connectionStateChange", "connecting")
        else this.fireLater("connectionStateChange", "reconnecting")

        if (this.debug)
            console.log(
                "%c connect to url",
                "color: #666666; font-weight: bold;",
                this.url.toString()
            )

        this.webSocket = new WebSocket(this.url.toString())
        this.webSocket.onopen = this.onSocketOpen.bind(this)
        this.webSocket.onmessage = this.onSocketMessage.bind(this)
        this.webSocket.onclose = this.onSocketClose.bind(this)
        this.webSocket.onerror = this.onSocketError.bind(this)
        this.tmConnect = setTimeout(
            this.onTimeout.bind(this),
            this.connectTimeout
        )
    }

    onTimeout() {
        this.clearTimers()
        this.fireLater(
            "connectionStateChange",
            this.hadSocketError ? "retryWaitError" : "retryWaitClosed"
        )
        this.tmRetry = setTimeout(this.connect.bind(this), this.retryWait)
        this.recentConnectionFailures += 1
    }

    onSocketOpen() {
        this.isReconnection = true
        this.clearTimers()
        this.fire("connectionStateChange", "connected")
        this.recentConnectionFailures = 0
        this.fire("newConnection")
        this.processQueue()
        this.setupPing(60)
    }

    onSocketClose() {
        console.warn("Web socket to " + this.url.toString() + " closed")
        this.clearTimers()
        this.recentConnectionFailures += 1
        if (this.recentConnectionFailures > 1) {
            this.fireLater(
                "connectionStateChange",
                this.hadSocketError ? "retryWaitError" : "retryWaitClosed"
            )
            this.tmRetry = setTimeout(this.connect.bind(this), this.retryWait)
        } else {
            this.connect(true)
        }
    }

    cancelInFlight() {
        console.log("cancel in flight")
        for (let index in Object.keys(this.receiveQueue)) {
            console.log("cancel in flight", this.receiveQueue[index])
            this.receiveQueue[index].errorFunction()
        }
        this.receiveQueue = []
    }

    onSocketError() {
        console.warn("Web socket error connecting to " + this.url.toString())
        this.clearTimers()
        this.cancelInFlight()
        this.hadSocketError = true
    }

    onSocketMessage(event) {
        let messages, descriptor

        function logPayload(message) {
            if (message.payload) {
                console.log("%cpayload:", "font-size: 10px; line-height: 16px;")
                for (let item of message.payload)
                    console.log(
                        "%c%s",
                        "font-size: 10px; line-height: 16px;",
                        item
                    )
            }
        }

        try {
            messages = eval(event.data)
        } catch (e) {
            console.error("protocolError", e)
            this.fire("protocolError", event.data)
            return
        }

        // ensure id is stored in local storage
        if (this.connectionId)
            sessionStorage.setItem("roundtripId", this.connectionId)

        for (let message of messages) {
            switch (message.kind) {
                case "C":
                    // New connection (sending back an initial roundtrip id)

                    let isReconnection =
                        this.connectionId === message.connectionId

                    if (this.debug > 1) {
                        if (isReconnection) {
                            console.groupCollapsed(
                                "%s RECONNECTION",
                                FROM_SERVER
                            )
                            console.log(
                                "connectionId = %s (was %s)",
                                message.connectionId,
                                this.connectionId
                            )
                        } else {
                            console.groupCollapsed(
                                "%s NEW CONNECTION",
                                FROM_SERVER
                            )
                            console.log(
                                "connectionId = %s (was %s)",
                                message.connectionId,
                                this.connectionId
                            )
                        }
                        logPayload(message)
                        if (message.data !== undefined)
                            console.log("data: %s", message.data)
                        console.groupEnd()
                    }

                    if (this.connectionId !== message.connectionId) {
                        this.connectionId = message.connectionId
                        sessionStorage.setItem("roundtripId", this.connectionId)
                    }

                    this.fire("connectionResponse", message, isReconnection)
                    break
                case "O":
                    // Out-of-band event, not part of the normal queue of operations

                    if (this.debug > 1) {
                        console.groupCollapsed(FROM_SERVER + " OUT-OF-BAND")
                        logPayload(message)
                        if (message.data !== undefined)
                            console.log("data: %s", message.data)
                        console.groupEnd()
                    }

                    this.fire("outOfBand", message)
                    break
                case "X":
                    // In-band exception data
                    descriptor = this.receiveQueue[message.index]
                    delete this.receiveQueue[message.index]

                    if (this.debug > 1) {
                        console.groupCollapsed(
                            "%c%s EXCEPTION",
                            "color: red",
                            FROM_SERVER
                        )
                        console.log(message)
                        console.groupEnd()
                    }

                    this.fire("serverException", message.exception)
                    break
                case "Z":
                    // Out-of-band exception data

                    if (this.debug > 1) {
                        console.groupCollapsed(
                            FROM_SERVER + " OUT-OF-BAND EXCEPTION"
                        )
                        console.log(message)
                        console.groupEnd()
                    }

                    this.fire("serverExceptionOutOfBand", message.exception)
                    break
                case "N":
                    // Normal response to the oldest event in the receive queue

                    descriptor = this.receiveQueue[message.index]
                    delete this.receiveQueue[message.index]

                    if (this.debug > 1) {
                        let nullText =
                            message.payload || message.data ? "" : " \u2205"
                        console.groupCollapsed(
                            "#%s %c%s%s %s%s.%s",
                            descriptor.index,
                            "color: green",
                            FROM_SERVER,
                            nullText,
                            descriptor.className ? descriptor.className : "",
                            descriptor.event.target
                                ? "[uid=" +
                                      descriptor.event.target.toString() +
                                      "]"
                                : "",
                            descriptor.event.name
                        )
                        logPayload(message)
                        if (message.data !== undefined)
                            console.log(
                                "%cdata: %O",
                                "font-size: 10px; line-height: 16px;",
                                message.data
                            )
                        console.groupEnd()
                    }

                    this.fire("response", descriptor, message)
                    break
                case "S":
                    console.log("kind=S")
                    // Connection expired/missing error

                    if (this.debug > 1) {
                        console.groupCollapsed(
                            "%c%s CONNECTION EXPIRED",
                            "color: red",
                            FROM_SERVER
                        )
                        console.log(message)
                        console.groupEnd()
                    }

                    sessionStorage.removeItem("roundtripId")
                    descriptor = this.receiveQueue[message.index]
                    delete this.receiveQueue[message.index]
                    this.fire("connectionExpired", message)
                    break
                case "R":
                    // Connection missing - send state back to server

                    if (this.debug > 1) {
                        console.groupCollapsed(
                            "%c%s CONNECTION MISSING",
                            FROM_SERVER,
                            "color: red"
                        )
                        console.log(message)
                        console.groupEnd()
                    }

                    descriptor = this.receiveQueue[message.index]
                    delete this.receiveQueue[message.index]
                    this.fire("stateResend", message.exception)
                    break
                default:
                    this.fire("protocolError", message)
            }
        }
    }

    send(origin, event, successFunction, errorFunction, className) {
        var descriptor = {
            origin: origin,
            event: event,
            successFunction: successFunction,
            errorFunction: errorFunction,
            className: className,
            index: this.index++,
        }

        // Remove to enable cancelable events
        // Note this requires ONE AT A TIME MESSAGE SENDING (see processQueue)
        // this.sendQueue = this.sendQueue.filter( (e) => !e.event.cancelable);

        switch (this.webSocket.readyState) {
            case WebSocket.CONNECTING:
                this.sendQueue.push(descriptor)
                break
            case WebSocket.OPEN:
                this.sendQueue.push(descriptor)
                break
            case WebSocket.CLOSING:
            case WebSocket.CLOSED:
                this.sendQueue.push(descriptor)
                this.fireLater("connectionStateChange", "reconnecting")
                this.connect(true)
                break
            default:
                this.fireLater("connectionStateChange", "error")
        }
        return descriptor
    }

    processQueue() {
        if (this.webSocket.readyState !== WebSocket.OPEN) return

        let toSend = []

        if (!this.sendQueue.length) return

        // Uncomment this to enable ONE AT A TIME MESSAGE SENDING
        // Note: if an action creates multiple client-to-server events only one will be processed at a time
        //   this is required if cancelable events are supported
        //   this can cause deadlock when a contained component issues a mounted event
        // if(Object.keys(this.receiveQueue).length > 1) {
        // 	return;
        // }

        while (this.sendQueue.length) {
            let descriptor = this.sendQueue.shift()
            if (this.debug > 1) {
                console.groupCollapsed(
                    "#%s %c%s %s%s.%s%s%s%s",
                    descriptor.index,
                    "color: blue",
                    TO_SERVER,
                    descriptor.className ? descriptor.className : "",
                    descriptor.event.target
                        ? "[uid=" + descriptor.event.target.toString() + "]"
                        : "",
                    descriptor.event.name,
                    descriptor.event.stateDeltas ? "\u0394" : "",
                    this.sendQueue.length ? " (+)" : "",
                    Object.keys(this.receiveQueue).length
                        ? " (" +
                              Object.keys(this.receiveQueue).length.toString() +
                              " waiting)"
                        : ""
                )
                if (descriptor.event.data !== undefined)
                    console.log("data:", descriptor.event.data)
                if (descriptor.event.stateDeltas)
                    console.log("stateDeltas:", descriptor.event.stateDeltas)
                if (descriptor.event.treeChanges)
                    console.log("treeChanges:", descriptor.event.treeChanges)
                console.groupEnd()
            }
            descriptor.event.index = descriptor.index
            this.receiveQueue[descriptor.index] = descriptor
            toSend.push(descriptor.event)
        }
        let data = EJSON.stringify(toSend)
        this.webSocket.send(data)
    }

    fire(event, ...args) {
        if (this.handlers[event]) {
            this.handlers[event](...args)
        }
    }

    fireLater(event, data) {
        clearTimeout(this.tmNotify)
        if (this.handlers[event]) {
            this.tmNotify = setTimeout(
                () => this.handlers[event](data),
                this.notifyTimeout
            )
        }
    }

    /**
     * Setup an interval ping that sends every x seconds.
     */
    setupPing(sec) {
        clearInterval(this.pingInterval)
        this.pingInterval = setInterval(() => {
            if (this.debug) console.log("roundtrip ping sent")
            this.webSocket.send("ping")
        }, sec * 1000)
    }
}
