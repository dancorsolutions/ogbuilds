"""
A simple pub-sub plugin for roundtrip using RabbitMQ as the message broker
"""

import threading
import uuid
import weakref
import warnings
import re
from hashlib import md5

import pika

from ...core import message
from ...core.version import BACKWARDS_COMPATIBLE
from ...core import connection


class NODEFAULT(object):
    pass


class Subscription(object):
    """
    An internal class representing a generic subscription
    """

    def __init__(self, key, query, alive, callback):
        self.key = key
        self.query = query
        self.alive = alive or (lambda: True)
        self.callback = callback

        self.uuid = uuid.uuid4()
        if self.key is None:
            self.keyRegex = None
        else:
            self.keyRegex = re.compile(re.escape(self.key).replace("*", "[~.]*").replace("#", ".*"))

    def match(self, key, msg):
        if self.key is not None and not self.keyRegex.match(key):
            return False
        if self.query is not None:
            for k, v in self.query:
                c = msg.get(k, NODEFAULT)
                if isinstance(v, dict) and len(v) == 1 and v.keys()[0].startswith("$"):
                    op, val = v.items()[0]
                    if op == "$gt":
                        if c <= val:
                            return False
                    elif op == "$lt":
                        if c >= val:
                            return False
                    elif op == "$gte":
                        if c < val:
                            return False
                    elif op == "$lte":
                        if c > val:
                            return False
                    elif op == "$startswith":
                        if not c.startswith(val):
                            return False
                    elif op == "$contains":
                        if not val in c:
                            return False
                    else:
                        raise ValueError("Invalid query operation %r" % v)
                elif msg[k] != v:
                    return False
        return True

    def __repr__(self):
        return "<Subscription key=%s alive=%r>" % (self.key, self.alive())


class ComponentSubscription(Subscription):
    """
    An internal class representing a subscription by a roundtrip component
    """

    def __init__(self, key, query, callback, track=None, alive=None):
        self.key = key
        self.query = query
        self._callback = callback
        if connection.Connection.current is None:
            raise ValueError("Can only create component subscriptions in the context of an active session/connection")
        self.connection = weakref.ref(connection.Connection.current)
        self.alive = alive or (lambda: self.connection())

        if BACKWARDS_COMPATIBLE:
            if not track._isApplication:
                warnings.warn("Can only track the main app (i.e. session), not %r" % track)
            self.trackUID = track.uid
            # for backwards compatibility use a key based on what we're tracking so that at least you can't
            # have multiple active trackers on same control (won't stop you having trackers on an invisible object
            # and that will cause errors if callbacks try to execute imperative JS on the non-visible components)
            self.uuid = md5(
                self.connection().connectionId + self.trackUID + (self.key or "") + (self.query or "")
            ).hexdigest()
        else:
            self.uuid = uuid.uuid4()

        if self.key is None:
            self.keyRegex = None
        else:
            self.keyRegex = re.compile(re.escape(self.key).replace("*", "[~.]*").replace("#", ".*"))

    def callback(self, *args, **kargs):
        if self.connection():
            self.connection().callInContext(self._callback, *args, **kargs)

    def __repr__(self):
        return "<ComponentSubscription key=%r tracking=%r alive=%r>" % (self.key, self.trackUID, self.alive())


class Channel(object):
    def __init__(self, routingKey="#", rabbitConfig={}):
        """
        Open a new channel to RabbitMQ

        Args:
            routingKey (str): a RabbitMQ routing key (selects which messages the overall channel receives). You should
                be careful about creating multiple channels to listen on different routing keys since **each channel
                creates a new thread to listen for events**. Future versions of this API may use async techniques in
                which case it will be cheaper to have multiple channels (but it's still better to design your app
                with one or two channels and the right kind of routing keys, then use :py:method:`sub` to further
                filter messages.
        """

        self.routingKey = routingKey
        self.rabbitConfig = rabbitConfig

        self.semaphore = threading.Semaphore()
        self.thread = None
        self.subs = dict()
        self.connection = None
        self.channel = None
        self.result = None
        self.queueName = None

        self._ensureChannel()

    def _ensureChannel(self):
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(**self.rabbitConfig))
        self.channel = self.connection.channel()
        self.channel.exchange_declare(exchange="logs", exchange_type="topic")
        self.result = self.channel.queue_declare(exclusive=True)
        self.queueName = self.result.method.queue
        self.channel.queue_bind(exchange="logs", queue=self.queueName, routing_key=self.routingKey)

    def sub(self, callback, key=None, query=None, alive=None, track=None):
        """
        Subscribe to messages on this channel

        Args:
            callback (callable): a function to call for each new message matching the criteria supplied
            key (str): a routing key to match against
            query (dict): a dict to match against incoming message bodies (assumes both the incoming messages and the
                query are dict objects)
            alive (callable): a function that returns true if the subscription should continue (used when you can't
                reliably unsub a subscription) -- this is called on every message so should not be expensive to compute
            track (roundtrip.core.component.Component): takes a **stateful** roundtrip ``Component``, if present this
                subscription will automatically unsubscribe when the Component's state is discared (e.g. when a user
                navigates to another part of the app) or when the underlying roundtrip connection expires.

        Returns:
            str: a unique id for the subscription (used to unsubscribe later)
        """
        self.cleanup()
        if track:
            sub = ComponentSubscription(key=key, query=query, track=track, callback=callback)
        else:
            sub = Subscription(key=key, query=query, callback=callback, alive=alive)

        with self.semaphore:
            self.subs[sub.uuid] = sub
        return sub.uuid

    def unsub(self, ident):
        """
        Unsubscribe a previous subscription using the unique id originally returned by ``sub``

        Args:
            ident (str): the unique id returned by ``sub``

        Returns:
            bool: True if a subscription was found and removed
        """
        with self.semaphore:
            if ident in self.subs:
                del self.subs[ident]
                return True
        return False

    def pub(self, key, data={}):
        """
        Publish a message onto a channel

        Args:
            key (str): the routing key for the message
            data (object): an EJSON-encodable (ejson encodable) object to use for the message body (use a dict if
                you intend to use the ``query`` parameter in ``sub``.

        Returns:
            str: a unique id for the subscription (used to unsubscribe later)
        """
        self.channel.basic_publish(exchange="logs", routing_key=key, body=message.dumps(data))

    def _onMessage(self, channel, method, properties, body):
        """
        Handle a received message
        """
        body = message.loads(body)
        for k, sub in self.subs.items():
            if sub.match(method.routing_key, body):
                if sub.alive():
                    sub.callback(method.routing_key, body)
                else:
                    del self.subs[k]

    def cleanup(self):
        for k, sub in self.subs.items():
            if not sub.alive():
                del self.subs[k]

    def go(self):
        """
        Start consuming messages (blocks)
        """
        self.channel.basic_consume(self._onMessage, queue=self.queueName, no_ack=True)
        self.channel.start_consuming()

    def start(self):
        """
        Start consuming messages in a separate thread
        """
        if self.thread:
            raise RuntimeError("Channel already started")
        self.thread = threading.Thread(target=self.go)
        self.thread.daemon = True
        self.thread.start()

    def repr(self, indent=""):
        s = ""
        s += indent + "<Channel key=%s>\n" % self.routingKey
        for sub in self.subs.values():
            s += indent + "  %r\n" % sub
        return s
