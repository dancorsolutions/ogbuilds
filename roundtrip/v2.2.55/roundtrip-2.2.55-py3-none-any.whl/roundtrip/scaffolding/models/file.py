import uuid
import datetime

from mongoengine import *

__all__ = ["File"]


class File(Document):
    meta = dict(
        allow_inheritance=True, indexes=[dict(fields=["token"]), dict(fields=["uploaded"], expireAfterSeconds=6000)]
    )

    will_delete = BooleanField()
    token = StringField(default=lambda: uuid.uuid4().hex)
    uploaded = DateTimeField(default=datetime.datetime.now())
    files = ListField(FileField())
    file_name = StringField()
    content_type = StringField()
