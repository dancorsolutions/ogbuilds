import inspect
import typing

__all__ = ["ConfigItem", "CONFIG_NO_DEFAULT", "Provider", "ConfigError"]


class _CONFIG_NO_DEFAULT:
    pass


CONFIG_NO_DEFAULT = _CONFIG_NO_DEFAULT()


class ConfigItem:
    """
    TODO: replace this with proper config schema item from yconfig.py!
    """

    def __init__(self, typ=None, default: typing.Any = CONFIG_NO_DEFAULT, required=False, help=None):
        self.typ = typ
        self.default = default
        self.required = required
        self.help = help
        self.children = dict()


class Provider:
    ident: str

    def __init__(self, server):
        self.server = server

    def initialize(self):
        return

    def configSchema(self):
        return [ci for ci in inspect.getmembers(self) if isinstance(ci, ConfigItem)]


class ConfigError(Exception):
    pass
