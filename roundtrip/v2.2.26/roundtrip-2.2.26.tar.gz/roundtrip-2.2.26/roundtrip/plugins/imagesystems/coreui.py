from ...component import ComponentMetaclass


class CoreUIImageSystem:
    def __init__(self, relativePath):
        self.relativePath = relativePath

    def svg(self, icon, slot=None, cls="c-icon"):
        base = r"""<svg class="%s"><use xlink:href="%s"/></svg>""" % (cls, self.relativePath + "#" + icon)
        if slot is not None:
            return "<template v-slot:%s>%s</template>" % (slot, base)
        else:
            return base


def setup(relativePath="../node_modules/@coreui/icons/sprites/free.svg"):
    ComponentMetaclass.context["coreui"] = CoreUIImageSystem(relativePath=relativePath)
