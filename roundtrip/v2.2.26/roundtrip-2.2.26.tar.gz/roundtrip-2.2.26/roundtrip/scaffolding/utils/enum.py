__all__ = ["ENUM", "OPTIONS"]


class ENUM(object):
    def __init__(self, **kargs):
        self._options = kargs

    def as_dict(self):
        return self._options

    def __getattr__(self, k):
        try:
            return self._options[k]
        except KeyError:
            raise AttributeError(k)

    def __getitem__(self, k):
        if type(k) is int:
            return sorted(self._options.keys())[k]
        return self._options[k]

    def __iter__(self):
        for i in sorted(self._options.values()):
            yield i

    def as_list(self):
        return self._options.values()

    def __contains__(self, k):
        return k in self._options

    def __repr__(self):
        l = list(self._options.items())
        l.sort(key=lambda a: a[1])
        sl = ["%s=%s" % (k, v) for k, v in l]
        return "<ENUM %s>" % (",".join(sl))


class OPTIONS(object):
    def __init__(self, *args):
        self._options = args

    def as_tuple(self):
        return self._options

    def __getattr__(self, k):
        if k in self._options:
            return k
        else:
            raise AttributeError(k)

    def __getitem__(self, k):
        return self._options[k]

    def __iter__(self):
        for i in self._options:
            yield i

    def __contains__(self, k):
        return k in self._options

    def __repr__(self):
        return "<OPTIONS %s>" % (",".join(self))
