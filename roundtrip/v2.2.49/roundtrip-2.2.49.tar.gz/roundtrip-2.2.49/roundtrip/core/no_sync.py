import typing as t_

__all__ = ["no_sync"]


class no_sync:
    def __init__(self, value: t_.Any):
        self.value = value
