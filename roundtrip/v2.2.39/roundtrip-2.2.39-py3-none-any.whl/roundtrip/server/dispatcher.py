import uuid
import logging
import time
import traceback

import tornado.websocket
from bson import json_util

from ..core.message import MessagePayload
from ..core import javascript
from ..core import message

dumps = javascript.dumps


ENABLE_WEBSOCKET_COMPRESSION = True


class WebSocketHandler(tornado.websocket.WebSocketHandler):
    id = None
    threadPool = None
    app = None
    connectionManager = None
    recordingManager = None

    def initialize(self, app, connectionManager, threadPool, recordingManager=None):
        super(WebSocketHandler, self).initialize()
        self.id = None
        self.threadPool = threadPool
        self.app = app
        self.connectionManager = connectionManager
        self.recordingManager = recordingManager

    def log_new_connection(self):
        logging.getLogger("roundtrip.event").info(
            "new connection user-agent=%s xff=%s rip=%s",
            "|".join(self.request.headers.get_list("user-agent")),
            "|".join(self.request.headers.get_list("x-forwarded-for")),
            "|".join(self.request.headers.get_list("x-real-ip")),
            extra=dict(rtid=self.id),
        )

    def get_compression_options(self):
        if ENABLE_WEBSOCKET_COMPRESSION:
            return {"compression_level": 5, "mem_level": 5}
        else:
            return None

    async def open(self, *args):
        self.id = self.get_argument("roundtripId", None)

        # reconnect defaults to True if roundtripSessionId is set but can be overridden with a parameter
        reconnect = not not self.get_argument("roundtripId", None)
        reconnectString = self.get_argument("isReconnection", None)
        if reconnectString:
            reconnect = reconnectString.lower() == "true"

        if not self.id:
            self.id = uuid.uuid4().hex

        self.set_nodelay(True)

        arguments = {k: (v[0] if len(v) == 1 else v) for k, v in self.request.arguments.items() if k != "roundtripId"}

        cookies = {k: v.value for k, v in self.cookies.items() if k != "roundtripId"}

        connection = self.connectionManager.get(self.id)

        if connection is None:
            if reconnect:
                logging.getLogger("roundtrip.event").info(
                    "connection missing or expired (when a client was reconnecting)", extra=dict(rtid=self.id)
                )
                await self.write_message(dumps([MessagePayload(kind=MessagePayload.NO_CONNECTION)]))
                return
            self.log_new_connection()

            connection = self.connectionManager.new(application=self.app, handler=self, connectionId=self.id)

            if self.recordingManager:
                self.recordingManager.attach(connection)

        connection.arguments = arguments
        connection.cookies = cookies
        connection.handler = self
        responses = await connection.handleEvent(eventList=[None], reconnect=reconnect)

        self.connectionManager.put(connection)

        try:
            with await connection.semaphore.acquire():
                await self.write_message(dumps(responses))
        except tornado.websocket.WebSocketClosedError:
            logging.getLogger("roundtrip.event").info("web socket closed by remote client", extra=dict(rtid=self.id))

    async def on_message(self, body):
        if body == "ping":
            return

        start = time.perf_counter()
        start_process = time.process_time()

        connection = self.connectionManager.get(self.id)

        if connection is None:
            # The connection has (probably) expired so send back a 'no connection' message and return
            logging.getLogger("roundtrip.event").info("connection expired", extra=dict(rtid=self.id))
            await self.write_message(dumps([MessagePayload(kind=MessagePayload.NO_CONNECTION)]))
            return

        data = json_util.loads(
            body, json_options=json_util.JSONOptions(json_mode=json_util.JSONMode.CANONICAL, tz_aware=True)
        )
        payload = await connection.handleEvent(eventList=data)
        self.connectionManager.touch(connection)

        for event in data:
            if event.get("target", None):
                node = connection.componentTree.getProxyByUID(event["target"])
                target = ""
                while node:
                    target = node._p_component.className + "." + target
                    node = node.parent
            else:
                target = event.get("target", "")

            logging.getLogger("roundtrip.event").debug(
                f"C->S {target}{event.get('name', '')} [{(time.perf_counter()-start)*1000:.1f}ms wall | "
                f"{(time.process_time()-start_process)*1000:.1f}ms CPU]",
                extra=dict(rtid=self.id),
            )
        with await connection.semaphore.acquire():
            await self.write_message(dumps(payload))

    def on_close(self):
        logging.getLogger("roundtrip.event").info("connection closed", extra=dict(rtid=self.id))

        connection = self.connectionManager.get(self.id)

        if not connection:
            return

        if hasattr(self.app, "didDisconnect"):
            connection.blindCallInContext(self.app.didDisconnect)

    def check_origin(self, origin):
        """
        Allow websocket connections come from a different origin

        Needed if we proxy through loadbalancer (which we always do for live)
        """
        return True
