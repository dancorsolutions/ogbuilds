import types
import weakref

from .. import component
from ..core import state
from ..core import javascript
import logging

__all__ = ["ComponentTree", "ComponentNode", "ComponentProxy", "ComponentGoneError"]


class ComponentGoneError(Exception):
    pass


class ComponentTree:
    """
    A tree of :class:`ComponentNode` objects representing components as created on the client-side UI.
    """

    _connection: weakref.ReferenceType

    def __init__(self, connection):
        self._connection = weakref.ref(connection)
        self.root = None
        self.byUID = dict()

    def connection(self):
        return self._connection()

    def add(self, className, uid, parentUID):
        if not parentUID:
            node = ComponentNode(connectionRef=self._connection, className=className, uid=uid)
            self.byUID[uid] = node
            self.root = node
            return node
        else:
            if parentUID not in self.byUID:
                logging.getLogger("roundtrip.event").error(
                    "cannot find parent uid %s for %s[uid=%s]" % (parentUID, className, uid)
                )
                return
            parent = self.byUID[parentUID]
            node = ComponentNode(connectionRef=self._connection, className=className, uid=uid, parent=parent)
            self.byUID[uid] = node
            parent.addChild(node)
            return node

    def delete(self, uid):
        node = self.byUID[uid]
        if node._proxy:
            node._proxy._clear_proxy()
        if node.parent:
            node.parent.removeChild(uid)
        del self.byUID[uid]

    def getProxyByUID(self, uid):
        if uid not in self.byUID:
            # the object was deleted before the event arrived
            # (e.g. rapid button clicking etc. on the client)
            return
        return self.byUID[uid].proxy


class ComponentNode:
    """
    A component node is an instance that represents a component that is present on the client-side UI.

    A :class:`ComponentNode` is only created for certain :class:`Component` s.
    """

    def __init__(self, connectionRef, className, uid, parent=None):
        self._connection = connectionRef
        self.component = component.ComponentMetaclass.getByClassname(className)
        self.uid = uid
        self.parent = parent
        self.children = []
        self._proxy = None
        self.attrs = ComponentProps()
        self.data = state.State(connectionRef, uid, self.component.getData())

    @property
    def connection(self):
        return self._connection()

    def removeChild(self, uid):
        for index, child in enumerate(self.children):
            if child.uid == uid:
                del self.children[index]
                break
        else:
            raise ValueError("No child found %s" % uid)

    def addChild(self, node):
        """
        Add a child component below this compoent

        :param node: the Componet to add below this node
        """
        self.children.append(node)

    @staticmethod
    def match(instance, className):
        """
        Internal method used to match a :class:`ComponetNode` instance against a class name.

        Matching is done by looking at the class's `__name__` attribute and the `__name__` attribute in every class
        of the instance's class's `__mro__` list.

        :param instance: the :class:`Component` instance to try to match again
        :param className: the class name to match
        :return: True if the `instance` matches the `className`
        """
        if className is None:
            return True
        return className in [instance.__class__.__name__] + [i.__name__ for i in instance.__class__.__mro__]

    def up(self, className=None):
        """
        Move up the component hierarchy looking for a component with a class name matching `className`.

        See :func:`ComponentNode.match` for details on how class names are matched.

        :param className: the name to search. If `None` is passed this will return the parent component.
        """
        at = self
        while 1:
            at = at.parent
            if at is None:
                return None
            elif self.match(at.component, className):
                return at

    def app(self):
        """
        Return the top-level component
        """
        at = self
        while 1:
            if at.parent is None:
                return at
            at = at.parent

    def down(self, className=None):
        """
        Move down through the component heirarchy looking for a component with a class name mathcing `className`.
        """
        for node in self.children:
            if self.match(node.component, className):
                return node
        for node in self.children:
            rc = node.down(className=className)
            if rc:
                return rc

    @property
    def proxy(self):
        if not self._proxy:
            self._proxy = ComponentProxy(self.component, self)
        return self._proxy

    def __repr__(self):
        return "<ComponentNode %s %s uid=%s>" % (self.component.__class__.__name__, hex(id(self))[-4:], self.uid)


class ComponentProps(dict):
    """
    Used to store properties on a component node
    """

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k)


class ComponentProxy:
    """
    Used to wrap a :class:`ComponentNode` *instance* togehter with a :class:`Component` *class*
    """

    CORE_ATTRIBUTES = {"_p_component", "_p_node", "uid", "client", "refs", "data", "attrs"}

    def __init__(self, component, node):
        self.__dict__["_p_component"] = component
        self.__dict__["_p_node"] = node
        self.__dict__["uid"] = node.uid
        self.__dict__["client"] = javascript.JSComponent(self)
        self.__dict__["refs"] = getattr(self.client, "$refs")
        self.__dict__["data"] = self._p_node.data
        self.__dict__["attrs"] = self._p_node.attrs

    def _clear_proxy(self):
        for k in self.CORE_ATTRIBUTES:
            del self.__dict__[k]

    def _is_gone(self):
        return self._p_component is None

    def __getattr__(self, item):
        if item in self.CORE_ATTRIBUTES:
            # this is looking for a core attribute that has been deleted because the proxy was cleared
            # raise a special exception to indicate the component has gone away in the client browser
            raise ComponentGoneError("The client component has gone away")
        if hasattr(self._p_component.__class__, item) and isinstance(
            getattr(self._p_component.__class__, item), property
        ):
            # if it's a property re-bind it to the proxy
            prop = getattr(self._p_component.__class__, item)
            return prop.fget(self)
        v = getattr(self._p_component, item)
        if isinstance(v, types.MethodType):
            # if it's a method re-bind it to the proxy
            return types.MethodType(v.__func__, self)
        else:
            return v

    def __setattr__(self, item, value):
        setattr(self._p_component, item, value)

    def __repr__(self):
        return "<ComponentProxy %s %s>" % (self._p_component.__class__.__name__, hex(id(self))[-4:])

    @property
    def connection(self):
        return self._p_node._connection()

    @property
    def app(self):
        return self._p_node.app().proxy

    def up(self, *args, **kwargs):
        node = self._p_node.up(*args, **kwargs)
        if node is None:
            return None
        return node.proxy

    def down(self, *args, **kwargs):
        node = self._p_node.down(*args, **kwargs)
        if node is None:
            return None
        return node.proxy

    @property
    def children(self):
        return [node.proxy for node in self._p_node.children]

    isProxied = True

    @property
    def parent(self, *args, **kwargs):
        parent = self._p_node.parent
        if parent is None:
            return None
        return parent.proxy
