/**
 * @fileoverview
 * Core application component which is responsible for instantiating the entire application
 */

import { WebSocketChannel } from "./websocketchannel.js"
import EJSON from "./ejson.js"
import { SyncManager } from "./syncmanager"
import { nextTick, getCurrentInstance } from "vue"


export function execExpr(expr, vars, here) {
    let keys = Object.keys(vars)
    let exprFunc = Function.apply(null, keys.concat([expr]))
    let args = keys.map(function (key) {
        return vars[key]
    })
    if (here) exprFunc.bind(here)
    return exprFunc.apply(null, args)
}

export class Application {
    constructor(app, options) {
        let wsURL

        this.nextUID = 1

        this.app = app
        this.rootComponent = null

        this.components = {}

        this.throttleTimeouts = {}
        this.spinnerTimeouts = {}
        this.duringTimeouts = {}
        this.nextTickPromise = null

        this.config = options

        let lsValue = sessionStorage.getItem(
            options.applicationName || "semantikApplication"
        )
        this.componentStates = lsValue ? JSON.parse(lsValue) : {}

        let thisURL = new URL(window.location.href)

        if (this.config.webSocketURL) {
            wsURL = new URL(this.config.webSocketURL)
            if (thisURL.search) wsURL.search = thisURL.search
        } else {
            wsURL = new URL(window.location.href)
            wsURL.hash = ""
            wsURL.pathname = "websocket"
            if (thisURL.search) wsURL.search = thisURL.search
            if (
                this.config.secureWebsocket === true ||
                thisURL.protocol === "https:"
            ) {
                wsURL.protocol = "wss:"
            } else {
                wsURL.protocol = "ws:"
            }
        }

        if (!this.config || this.config.debugLevel > 1) {
            console.groupCollapsed("roundtrip started")
            console.log("webSocketURL: %s", wsURL)
            console.log("sessionTimeout: %s", this.config.sessionTimeout)
            console.log("debugLevel: %s", this.config.debugLevel)
            console.groupEnd()
        }

        this.syncManager = new SyncManager(this)

        this.webSocketChannel = new WebSocketChannel(
            wsURL,
            this.roundtripId,
            this.config.sessionTimeout,
            this.config.debugLevel
        )

        this.console = console

        this.webSocketChannel.listen(
            "response",
            this.onServerResponse.bind(this)
        )
        this.webSocketChannel.listen("outOfBand", this.onOutOfBand.bind(this))
        this.webSocketChannel.listen(
            "connectionResponse",
            this.onConnectionResponse.bind(this)
        )
        this.webSocketChannel.listen(
            "newConnection",
            this.onNewConnection.bind(this)
        )
        this.webSocketChannel.listen("stateResend", () =>
            alert("don't know how to handle state resends")
        )

        window.addEventListener("error", this.onJavascriptError.bind(this))
    }

    setCookie(cookie) {
        document.cookie = cookie
    }

    connectAllEvents(cmp) {
        let here = this
        let handler = function (k, ...args) {
            if (cmp[k]) return cmp[k](...args)
        }.bind(cmp)

        for (let k of [
            "connectionExpired",
            "connectionStateChange",
            "protocolError",
            "serverException",
            "serverExceptionOutOfBand",
        ])
            this.webSocketChannel.listen(
                k,
                function () {
                    Object.keys(here.spinnerTimeouts).forEach((i) => {
                        clearTimeout(i)
                    })
                    here.spinnerTimeouts = {}
                    return handler(k, ...arguments)
                }.bind(cmp)
            )

        this.config.onShowSpinner = function () {
            return handler("showSpinner", ...arguments)
        }.bind(cmp)
        this.config.onHideSpinner = function () {
            return handler("hideSpinner", ...arguments)
        }.bind(cmp)
        this.config.onSessionTimeout = function () {
            return handler("sessionTimeout", ...arguments)
        }.bind(cmp)
        this.config.onJavascriptError = function () {
            return handler("javascriptError", ...arguments)
        }.bind(cmp)

        this.resetSessionTimeout()
    }

    getComponentState(id) {
        if (!this.componentStates[id]) {
            this.componentStates[id] = {}
        }
        return this.componentStates[id]
    }

    setComponentState(id, value, path) {
        let at = this.componentStates[id]
        if (path) {
            for (let i of path.slice(0, -1)) {
                at = at[i]
            }
            at[path[path.length - 1]] = value
        } else {
            this.componentStates[id] = value
        }
        sessionStorage.setItem(
            this.config.applicationName || "semantikApplication",
            JSON.stringify(this.componentStates)
        )
        return value
    }

    onJavascriptError(e) {
        this.config.onJavascriptError({
            message: e.message,
            source: e.source,
            lineno: e.lineno,
            colno: e.colno,
            debugLevel: this.config.debugLevel,
        })
    }

    componentCreated(cmp, isRoot) {
        cmp._uid = (this.nextUID++).toString()
        if (isRoot) this.rootComponent = cmp
        this.components[cmp._uid] = cmp
        if (!this.syncManager.checkSyncable(cmp)) return
        this.syncManager.syncCreation(cmp)
    }

    componentUnmounted(cmp) {
        if (!this.syncManager.checkSyncable(cmp)) return
        this.syncManager.syncDestruction(cmp)
    }

    /**
     * Handle a response to an event from the server
     */
    onServerResponse(descriptor, msg) {
        let here = this
        this.executePayload(descriptor, msg, false).then(function () {
            here.hideSpinner()
            if (descriptor.successFunction) {
                descriptor.successFunction(msg.data)
            }
        })
    }

    /**
     * Handle an out-of-band message from the server
     */
    onOutOfBand(msg) {
        this.executePayload(null, msg, true)
    }

    /**
     * Handle a connection response from the server
     */
    onConnectionResponse(msg, isReconnection) {
        this.executePayload(null, msg, false)
        if (this.rootComponent.didConnect)
            this.rootComponent.didConnect(isReconnection)
    }

    onNewConnection() {}

    showSpinner() {
        if (this.config.onShowSpinner) this.config.onShowSpinner()
    }

    hideSpinner() {
        if (Object.entries(this.spinnerTimeouts).length === 0)
            if (this.config.onHideSpinner) this.config.onHideSpinner()
    }

    getContext(o) {
        return {
            console: console,
            window: window,
            location: location,
            app: this,
            ac: this.syncManager.applyChange.bind(this.syncManager),
            append: (a, b) => a.push(...b),
            cp: EJSON.clone,
            c: this.components,
            nextTick: nextTick,
            getCurrentInstance: getCurrentInstance,
            ...this.required,
            ...o,
        }
    }

    /**
     * Handle an event by sending it to the server via a websocket message
     *
     * Will also send any changes that have been made to states (deltas) along to the server as part of the event
     * @param {VueCompoment} cmp the component that is sending the event
     * @param {Object} e the event to send (should have target, name, and data attributes)
     */
    onevent(e) {
        this.resetSessionTimeout()

        if (e.throttle) {
            // Deal with this event some time in the future
            // (Useful for rapidly repeating events where we only want to send the most recent to the server
            // but at most one every x (milli)seconds)

            let lastStart = null
            let time = e.throttle
            delete e.throttle

            if (
                this.throttleTimeouts[e.target] &&
                this.throttleTimeouts[e.target][e.name]
            ) {
                let o = this.throttleTimeouts[e.target][e.name]
                clearTimeout(o.timeout)
                time = time - (new Date().getTime() - o.start)
                lastStart = o.start
            }

            if (time > 0) {
                if (!this.throttleTimeouts[e.target])
                    this.throttleTimeouts[e.target] = {}

                let action = function () {
                    if (
                        this.throttleTimeouts[e.target] &&
                        this.throttleTimeouts[e.target][e.name]
                    ) {
                        delete this.throttleTimeouts[e.target][e.name]
                    }
                    this.onevent(e)
                }.bind(this)

                let o = (this.throttleTimeouts[e.target][e.name] = {})
                o.start = lastStart || new Date().getTime()
                o.timeout = setTimeout(action, time)

                return
            } else {
                delete this.throttleTimeouts[e.target][e.name]
            }
        }

        let event = {}
        let targetComponent

        event.target = e.target
        if (!e.target) event.className = e.className
        event.name = e.name
        event.cancelable = e.cancelable

        if (e.data !== undefined) event.data = e.data

        // add any changes to state
        let stateDeltas = this.syncManager.getStateDeltas(false)
        if (Object.keys(stateDeltas).length) event.stateDeltas = stateDeltas

        // add any component creations / destructions
        let treeChanges = this.syncManager.getTreeChanges(false)
        if (Object.keys(treeChanges).length) event.treeChanges = treeChanges

        function executor(resolve, reject) {
            let descriptor = this.webSocketChannel.send(
                e.origin,
                event,
                undefined,
                undefined,
                e.className
            )
            descriptor.successFunction = resolve
            descriptor.errorFunciton = reject
        }
        let promise = new Promise(executor.bind(this))

        if (e.spinner) {
            let spinnerTimeout = setTimeout(
                this.showSpinner.bind(this),
                e.spinner
            )
            this.spinnerTimeouts[spinnerTimeout] = null
            promise.then(
                function () {
                    clearTimeout(spinnerTimeout)
                    delete this.spinnerTimeouts[spinnerTimeout]
                    this.hideSpinner()
                }.bind(this)
            )
        }

        if (e.during) {
            if (e.during.time) {
                let duringKey = e.target + "|" + e.during.name
                let duringTimeout = setTimeout(
                    () => e.during.before(e.origin),
                    e.during.time
                )
                if (this.duringTimeouts[duringKey])
                    clearTimeout(this.duringTimeouts[duringKey])
                this.duringTimeouts[duringKey] = duringTimeout
                promise.then(() => {
                    if (this.duringTimeouts[duringKey])
                        clearTimeout(this.duringTimeouts[duringKey])
                    e.during.after(e.origin)
                })
            } else {
                e.during.before(e.origin)
                promise.then(() => {
                    e.during.after(e.origin)
                })
            }
        }

        if (!this.nextTickPromise)
            this.nextTickPromise = nextTick(() => {
                this.webSocketChannel.processQueue.bind(this.webSocketChannel)()
                this.nextTickPromise = null
            })

        return promise
    }

    /**
     * Execute a server-supplied javascript code snippet in the right environment and with the right error checking etc.
     */
    executePayload(descriptor, msg, isOutOfBand) {
        let context = this.getContext({
            msg,
            cmp: descriptor ? descriptor.origin : undefined,
        })
        if (descriptor) context["cmp"] = descriptor.origin
        if (msg.payload) {
            return this.executePayloadItems(msg.payload, context, descriptor)
        }
        return new Promise((r) => r())
    }

    executePayloadItems(items, context, descriptor) {
        while (items.length) {
            let item = items.shift()
            if (item === "$$nextTick$$") {
                let promise = nextTick()
                promise.then(() =>
                    this.executePayloadItems(items, context, descriptor)
                )
                return promise
            } else if (this.config.debugLevel) {
                execExpr(
                    item,
                    context,
                    descriptor ? descriptor.origin : this.app
                )
            } else {
                try {
                    execExpr(
                        item,
                        context,
                        descriptor ? descriptor.origin : this.app
                    )
                } catch (e) {
                    this.config.eventHandler("errorStateChanged", {
                        name: e.name,
                        message: e.message,
                        stack: e.stack,
                    })
                    console.error("Payload error", e)
                }
            }
        }
        return new Promise((r) => r())
    }

    setComponent(id, component) {
        this.components[id] = component
    }

    clearComponent(id) {
        // Remove the component reference
        delete this.components[id]

        // Remove any pending timeouts
        if (this.throttleTimeouts[id])
            for (let k in this.throttleTimeouts[id])
                clearTimeout(this.throttleTimeouts[id][k].timeout)
    }

    reconnect() {
        this.webSocketChannel.reconnect()
    }

    reload() {
        location.reload()
    }

    resetSessionTimeout() {
        if (this.config.sessionTimeout === 0) return
        if (this.sessionTimeout) clearTimeout(this.sessionTimeout)
        if (this.config.sessionTimeout && this.config.onSessionTimeout) {
            this.sessionTimeout = setTimeout(
                this.config.onSessionTimeout,
                this.config.sessionTimeout * 1000
            )
        }
    }

    getChildContext() {
        return { app: this }
    }
}
