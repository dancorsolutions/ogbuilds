import sys


def error():
    print('needs a command string, one of "init"', file=sys.stderr)
    sys.exit(8)


def main():
    if len(sys.argv) < 2:
        error()
    command = sys.argv[1]
    del sys.argv[1]
    if command == "init":
        from roundtrip.cli import init

        init.go()
    else:
        error()
