from ...component import External

__all__ = []


class RouterView(External):
    notInComponents = True
    tag = "router-view"
    imports = []


class RouterLink(External):
    notInComponents = True
    tag = "router-link"
    imports = []
