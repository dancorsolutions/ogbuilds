"""
Efficient, secure, and DoS-protected upload management
"""
import logging
import time
import json
import base64
import tempfile
import traceback
from pathlib import Path

import mongoengine
from mongoengine.fields import GridFSProxy
import bson
import tornado.web
from tornado import gen
from ....scaffolding.config import config
from ....server import connection
from ....core import javascript


from ...utils.exceptions import SecurityError
from ...utils.crypto import crypto

from .base import Provider

__all__ = ["SimpleUploadHandler", "SimpleUploadProvider"]


class SimpleUploadProvider(Provider):
    ident = "simple_upload"

    def handlers(self):
        return [
            ("/simple_upload", SimpleUploadHandler, dict()),
        ]


class SimpleUploadHandler(tornado.web.RequestHandler):
    """
    Handle HTTP file uploads via POST requests
    """

    async def post(self):
        try:
            rtId = self.get_argument("roundtripId", None)
            target = self.get_argument("cmp", None)
            con = connection.connectionManager.get(rtId)
            if con is None:
                logging.getLogger("roundtrip.event").exception(f"Could not find connection for rtId={rtId!r}")
                self.send_error(500, text=f"No connection for roundtripId={rtId!r}")
                return
            con.registerThread()
            node = con.componentTree.getProxyByUID(target)
            if node is None:
                logging.getLogger("roundtrip.event").exception(f"Could not find component uid={target!r}")
                self.send_error(500, text=f"Could not find component uid={target!r}")
                return

            all_files = []
            for name, files in self.request.files.items():
                for item in files:
                    if hasattr(node, "onUpload"):
                        node.onUpload(item)
                        con.pushUpdate()

                    all_files.append(item)

            if hasattr(node, "onUploads"):
                node.onUploads(all_files)
                con.pushUpdate()

            self.set_status(200)
            await self.finish("")

        except Exception:
            logging.getLogger("roundtrip.event").exception("Error processing upload")
            if config.debug_level:
                self.send_error(500, text=traceback.format_exc())
            else:
                self.send_error(500, text="Server error")
