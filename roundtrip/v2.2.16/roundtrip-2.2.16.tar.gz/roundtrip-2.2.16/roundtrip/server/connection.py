"""
Classes for managing server-side connections (sessions)

These are primarily used to hold the server's representation of the state of the component tree and are a useful
place from which to hang ``.js`` used for calling imperative methods on the client.
"""

import typing
import datetime
import sys
import traceback
import logging
import weakref
import threading
import inspect
import cProfile  # for profiling
import pstats  # for profiling
import io  # for profiling
import hashlib
import asyncio
import warnings

from tornado import locks
import tornado.ioloop
import tornado.websocket

from ..core import message
from ..core.callbacks import callbacks
from ..core import javascript
from . import event
from .event import Event
from ..core.classproperty import classproperty
from ..core.base import proxy, OutOfSyncError
from .componenttree import *
from .. import component


class ConnectionManager(object):
    """
    This simple connection manager stores connections in memory

    More advanced connection managers will persist state to a clustered in-memory store like Redis

    Attributes:
        connections (dict): dict of rountripId -> ``Connection`` instance
        lastCleanup: datetime for the last time the manager tried to clean up expired connections (used to
            throttle cleanup runs)
    """

    def __init__(self, timeout=60.0 * 10, cleanupFrequency=10.0):
        """
        Args:
             timeout (float): connection timeout (in seconds)
             cleanupFrequency: time (in seconds) between runs of the connection expiry checking code (it's a little
                 expensive so keep this over a few seconds)
        """
        self.connections = {}
        self.timeout = timeout
        self.cleanupFrequency = cleanupFrequency
        self.lastCleanup = datetime.datetime.now()
        self.semaphore = threading.RLock()

    @property
    def all(self):
        for i in self.connections.values():
            yield i

    def new(self, application, handler, connectionId):
        """
        Create a new connection

        Args:
            application (roundtrip.app.application.Application): the top-level app class
            connectionId: the ``connectionId`` GUID for the connection
        """
        connection = Connection(application, handler=handler, connectionId=connectionId)
        with self.semaphore:
            self.connections[connectionId] = dict(connection=connection, date=datetime.datetime.now())
        return connection

    def get(self, connectionId):
        """
        Return the connection matching the given ``connectionId`` or ``None`` if no such connection exists

        Returns:
            Connection: the matching connection
            None if no matching connection exists
        """
        self.cleanup()
        with self.semaphore:
            rc = self.connections.get(connectionId, None)
            if rc is not None:
                return rc["connection"]

    def delete(self, connectionId):
        """
        Return the connection matching the given ``connectionId`` or ``None`` if no such connection exists

        Returns:
            Connection: the matching connection
            None if no matching connection exists
        """
        with self.semaphore:
            if connectionId in self.connections:
                del self.connections[connectionId]

    def put(self, connection):
        with self.semaphore:
            if connection.connectionId in self.connections:
                self.connections[connection.connectionId]["date"] = datetime.datetime.now()
            else:
                self.connections[connection.connectionId] = dict(connection=connection, date=datetime.datetime.now())

    def touch(self, connection):
        with self.semaphore:
            if connection.connectionId in self.connections:
                self.connections[connection.connectionId]["date"] = datetime.datetime.now()

    def cleanup(self):
        """
        Look for any expired connections and all their ``destroy()`` methods after removing them from the
        session dict.

        Warning:
            This assumes that calling destroy on an Application object won't invoke any long-running processes
            test this assumption or have the dispatcher do cleanup so it can push ``app.destroy()`` to
            the threadpool.
        """

        now = datetime.datetime.now()

        if self.diff(self.lastCleanup, now) < self.cleanupFrequency:
            return

        with self.semaphore:
            toDelete = {}
            for key, item in self.connections.items():
                diff = self.diff(item["date"], now)
                if diff > self.timeout:
                    toDelete[key] = item

            for k, v in toDelete.items():
                del self.connections[k]

        for k, v in toDelete.items():
            v["connection"].destroy()

        self.lastCleanup = datetime.datetime.now()

    def getStats(self):
        details = []
        for rtId, data in self.connections.items():
            details.append(
                dict(
                    rtIdHash=hashlib.sha256(rtId.encode("latin-1")).hexdigest(),
                    lastActivity=data["date"].isoformat(),
                    age=(datetime.datetime.now() - data["date"]).seconds,
                )
            )
        return dict(
            connectionCount=len(self.connections),
            lastCleanup=(datetime.datetime.now() - self.lastCleanup).total_seconds(),
            connections=details,
        )

    @classmethod
    def diff(cls, d1, d2):
        """
        Utility method to return a time difference in seconds between two datetimes
        """
        return (d2 - d1).total_seconds()


class Connection(object):
    """
    A client connection object used to store state specific to a particular client.
    """

    byThreadId = weakref.WeakValueDictionary()  #: class attribute that stores connection instances by thread id
    mockConnection = None

    # instance defaults
    arguments: typing.Optional[dict] = None

    PROFILE_CACHE_SIZE = None

    def registerThread(self):
        self.byThreadId[threading.get_ident()] = self

    # noinspection PyMethodParameters
    @classproperty
    def current(cls):
        if cls.mockConnection is not None:
            return cls.mockConnection
        rc = cls.byThreadId.get(threading.get_ident(), None)
        return rc

    @classmethod
    def attachMock(cls, connection):
        cls.mockConnection = connection

    @classmethod
    def detachMock(cls):
        cls.mockConnection = None

    def __init__(self, application, handler, connectionId):
        """
        Arguments:
            application (roundtrip.app.application.Application): the top-level app class
            handler: the Tornado ``WebSocketHandler`` instance that's managing the client connection
        """
        self.app = application
        self.handler = weakref.proxy(handler)
        self.connectionId = connectionId

        self.recorder = None
        self.remoteCallQueue = []
        self.profileResults = []
        self.semaphore = locks.Lock()
        self.state = None
        self.session = None
        self.componentTree = None
        self.ioloop = tornado.ioloop.IOLoop.current()

    def destroy(self):
        self.remoteCallQueue = []
        self.state = None
        self.handler = None
        self.app = None

    def __getstate__(self):
        """
        Make Connections serializable (via pickle) so we can store them in a shared database/distributed cache
        """
        if self.recorder:
            raise ValueError("Recorders are not supported with db-stored sessions")
        return dict(
            connectionId=self.connectionId,
            state=self.state,
            session=self.session,
        )

    def initialize(self):
        """
        Set up the connection

        Primarily involves initializing the component tree and setting up a session if there is one configured
        on the application. Also calls the `didOpen` on all children.
        """

        self.componentTree = ComponentTree(connection=self)

        if hasattr(self.app, "sessionClass"):
            try:
                self.session = self.app.sessionClass(connection=proxy(self))
            except:
                logging.getLogger("tornado.application").error("Exception trying to create session class")
                raise

    async def handleEvent(self, eventList=None, reconnect=False):
        """
        Handle a json encoded roundtrip event (sent via WebSockets)

        Returns:
             str: an encoded payload string
        """
        responses = []

        for data in eventList:
            self.recordC2S(data)

            try:
                if data is None:
                    # A new app was loaded: we need to send back the initial definition

                    if not reconnect:
                        self.initialize()

                    payload = self.getPayload(
                        kind=message.MessagePayload.NEW_CONNECTION, connectionId=self.connectionId
                    )
                    self.recordS2C(payload)

                else:
                    self.clearCallQueue()
                    responseData = await self.onClientEvent(data)
                    payload = self.getPayload(
                        responseData=responseData, kind=message.MessagePayload.NORMAL, index=data["index"]
                    )
                    self.recordS2C(payload)

                responses.append(payload)

            except Exception as e:
                # Look for a didRaise handler on the component tree
                # (starting with the target if we know it, otherwise with the app)

                self.clearCallQueue()

                didRaise = None

                if data and data.get("target", None) and data["target"] != "__callback__":
                    if data["target"]:
                        # get linked target by uid
                        target = self.componentTree.getProxyByUID(data["target"])
                    else:
                        # get unlinked target by class name
                        target = component.ComponentMetaclass.getByClassname(data["className"])
                    while target:
                        if hasattr(target, "didRaise"):
                            didRaise = target.didRaise
                            break
                        target = target.up()

                elif hasattr(self.app, "didRaise"):
                    didRaise = self.app.didRaise

                eType, eValue, tb = sys.exc_info()
                tbs = "".join(traceback.format_exc())

                log_preamble = (
                    f"{data.get('name', None)}{'->didRaise' if didRaise else '' } on "
                    f"component uid={data.get('target', None)}"
                )

                if didRaise:
                    try:
                        if asyncio.iscoroutinefunction(didRaise):
                            responseData = await didRaise(eValue, tb)
                        else:
                            responseData = await asyncio.wrap_future(
                                self.handler.threadPool.submit(didRaise, eValue, tb)
                            )

                        payload = self.getPayload(
                            responseData=responseData, kind=message.MessagePayload.NORMAL, index=data["index"]
                        )
                        self.recordS2C(payload)
                        responses.append(payload)
                    except Exception as e:
                        logging.getLogger("roundtrip.event").exception(f"Error running didRaise {log_preamble}")
                        logging.getLogger("roundtrip.event").error(
                            f"didRaise was triggered by the following error {log_preamble}\n{''.join(traceback.format_exception(eType, eValue, tb))}"
                        )
                    else:
                        continue

                if self.app._debugLevel:
                    exception = dict(traceback=tbs, exceptionType=str(eType), exceptionValue=repr(eValue))
                else:
                    exception = dict(traceback="", exceptionType="", exceptionValue="Server Error")

                payload = message.MessagePayload(kind=message.MessagePayload.EXCEPTION, exception=exception)
                responses.append(payload)

                self.recordS2C(payload)

        return responses

    def callHandler(self, event, cb, *args, **kwargs):
        self.registerThread()

        try:
            if self.PROFILE_CACHE_SIZE:
                pr = cProfile.Profile()
                pr.enable()
                responseData = cb(*args, **kwargs)
                pr.disable()
                s = io.StringIO()
                ps = pstats.Stats(pr, stream=s)
                self.addProfileResult(
                    RequestProfile(date=datetime.datetime.now(), request=event, response=responseData, profile=ps)
                )
                return responseData
            else:
                return cb(*args, **kwargs)

        except StopIteration:
            raise RuntimeError("Handler raise StopIteration")

    async def onClientEvent(self, eventData):
        """
        Handle events sent over from the client app

        Args:
            e (dict): a dictionary of event data (client event data after JSON un-encoding)
        """
        e = Event(eventData)

        if e.treeChanges is not None:
            await self.applyTreeChanges(e.treeChanges)

        if e.stateDeltas is not None:
            self.applyStateDeltas(e.stateDeltas)

        # handle callbacks
        if e.target == "__callback__":
            cb = callbacks.get(e.name)
            if cb is None:
                logging.getLogger("roundtrip.event").debug("callback target went away")
                return  # weakref died
            logging.getLogger("roundtrip.event").debug(
                "callback to %s.%s" % (cb.__module__, cb.__name__), extra=dict(rtid=self.connectionId)
            )
            kwargs = e.data if e.data is not None else {}
            if type(kwargs) is dict:
                for k, v in inspect.signature(cb).parameters.items():
                    if k not in kwargs:
                        if k in ("self", "cls"):
                            continue
                        kwargs[k] = None
                if asyncio.iscoroutinefunction(cb):
                    return await cb(self, **kwargs)
                else:
                    return await asyncio.wrap_future(
                        self.handler.threadPool.submit(self.callHandler, eventData, cb, **kwargs)
                    )
            else:
                if asyncio.iscoroutinefunction(cb):
                    return await cb(self, kwargs)
                else:
                    return await asyncio.wrap_future(
                        self.handler.threadPool.submit(self.callHandler, eventData, cb, kwargs)
                    )

        if e.target:
            # get linked target by uid
            target = self.componentTree.getProxyByUID(e.target)
            if not target:
                # target was deleted before the event arrived
                # can happen with multiple rapid clicks, etc. on the client side
                return
        else:
            # get unlinked target by class name
            target = component.ComponentMetaclass.getByClassname(e.className)

        handlerMethodId = e.name

        if not hasattr(target, handlerMethodId):
            raise ValueError("Missing event handler for %s %r" % (handlerMethodId, e))

        if isinstance(getattr(target, handlerMethodId), event.JSEventHandler):
            raise RuntimeError("JSEventHandler is deprecated, use vue.method")

        # If there's a methodGuard set on the target component we need to run that to see if we should continue
        guard = getattr(target, "methodGuard", None)
        if guard:
            if asyncio.iscoroutinefunction(guard):
                if not await guard(self, e):
                    return None
            else:
                if not await asyncio.wrap_future(self.handler.threadPool.submit(self.callHandler, eventData, guard, e)):
                    return None

        # Now handle any event handlers (we can have both a binding and an event handler for the same event)
        cb = getattr(target, handlerMethodId)
        data = e.data
        signature = inspect.signature(getattr(cb, "_rt_original_function", cb))
        parameters = list(signature.parameters.values())
        if parameters and parameters[0].name in {"self", "cls"}:
            del parameters[0]

        if asyncio.iscoroutinefunction(cb):
            if not parameters or not parameters[0].name == "connection":
                warnings.warn(f"First parameter of async event handler should be 'connection' for {cb}")
            else:
                del parameters[0]

        args = ()
        kwargs = {}
        if len(parameters) == 1 and parameters[0].name == "_data":
            # just _data means give me raw data
            args = (data,)
        elif type(data) is dict and [i for i in parameters if i.kind == 4]:
            # there's a **kwargs
            kwargs = data
        elif type(data) is dict:
            # no **kwargs
            for parameter in parameters:
                if parameter.name not in data:
                    kwargs[parameter.name] = None
                else:
                    kwargs[parameter.name] = data[parameter.name]
        else:
            # not passed a dict
            args = (data,)

        if asyncio.iscoroutinefunction(cb):
            return await cb(self, *args, **kwargs)
        else:
            return await asyncio.wrap_future(
                self.handler.threadPool.submit(self.callHandler, eventData, cb, *args, **kwargs)
            )

    def getPayload(self, responseData=None, **kwargs):
        """
        Package up the current RPC call queue and any state deltas as a :class:`MessagePayload` payload object.

        Returns:
            :class:`message.MessagePayload`: the packaged payload
        """
        payload = self.renderCallPayload()
        return message.MessagePayload(data=responseData, payload=payload, **kwargs)

    def applyStateDeltas(self, delta):
        """
        Apply a set of incoming component state deltas from the client

        Args:
            delta (dict): a dict of component UID -> state delta dict (the state delta dict contains keys and values
                for all changed elements of the state, it is *not* the current state in full)
        """
        for deltaLine in delta:
            originalPath = list(deltaLine["path"])
            path = deltaLine["path"]
            op = deltaLine["type"]
            vals = deltaLine.get("vals", None)
            val = deltaLine.get("val", None)
            num = deltaLine.get("num", None)
            index = deltaLine.get("index", None)

            at = self.componentTree.byUID

            if len(path) > 1:
                at_component = at[path.pop(0)]

                if "__props" in path:
                    at = at_component.attrs
                    path.pop(0)
                    while path[:-1]:
                        ident = path.pop(0)
                        at = at[ident]

                    item = path.pop(0)

                    if op == "set":
                        if not hasattr(at, "__setitem__"):
                            raise ValueError(
                                f"Could not alter index on server state for {originalPath}: {at!r} (a {type(at)}) does not support setitme"
                            )
                        try:
                            at[item] = val
                        except KeyError as e:
                            pass
                    elif op == "unset":
                        if not hasattr(at, "__delitem__"):
                            raise ValueError(
                                f"Could not remove server state for {originalPath}: {at!r} (a {type(at)}) does not support delitem"
                            )
                        del at[item]
                    elif op == "add":
                        if not hasattr(at[item], "__getslice__"):
                            raise ValueError(
                                f"Could not insert into server state for {originalPath}: {at[item]!r} does not support slicing"
                            )
                        at[item] = (at[item][:index] + vals + at[item][index:],)
                    elif op == "rm":
                        at[item] = at[item][:index] + at[item][index + (num or len(vals)) :]
                    else:
                        raise ValueError("invalid operation %r" % op)

                else:
                    at = at_component.data
                    while path[:-1]:
                        ident = path.pop(0)
                        if type(at._b) is list and not isinstance(ident, int):
                            raise ValueError(
                                f"Could not update server state for {originalPath}: {ident!r} is not an integer "
                                f"(Javascript doesn't support non-integer keys for Objects)"
                            )
                        at = at._b[ident]

                    item = path.pop(0)

                    if op == "set":
                        at._b[item] = at._wrap(item, val)
                    elif op == "unset":
                        if item in at._b:
                            del at._b[item]
                        else:
                            logging.getLogger("roundtrip").warning(f"unset on non-existent item {item!r} in {at!r}")
                    elif op == "add":
                        at._b[item] = at._wrap(
                            item,
                            at[item][:index] + [at._wrap(index + i, v) for i, v in enumerate(vals)] + at[item][index:],
                        )
                    elif op == "rm":
                        at._b[item] = at._wrap(
                            item, at._b[item]._b[:index] + at._b[item]._b[index + (num or len(vals)) :]
                        )
                    else:
                        raise ValueError("invalid operation %r" % op)

    async def applyTreeChanges(self, changes):
        """
        Apply a set of incoming component tree deletions / insertions from client
        """
        for change in changes:
            if change[0] == "c":
                [className, uid, parentUID] = change[1:4]
                node = self.componentTree.add(className=className, uid=uid, parentUID=parentUID)
                if not node:
                    continue
                if change[4]:
                    node.attrs.update(change[4])
                if node.component.ctMounted:
                    await self.callInContext(node.proxy.ctMounted)

            elif change[0] == "d":
                uid = change[1]
                if uid not in self.componentTree.byUID:
                    raise OutOfSyncError("Client uid %r not found on server" % uid)
                node = self.componentTree.byUID[uid]
                if node.component.ctUnmounted:
                    await self.callInContext(node.proxy.ctUnmounted)
                self.componentTree.delete(uid=uid)
            else:
                raise ValueError("unknown change type %s" % change[0])

    def markClean(self, uid=None):
        """
        Clear out any setState calls in the current call queue

        Args:
            uid (Optional[str]): the uid of a component to reset a single component only
        """
        newCallQueue = []
        for item in self.remoteCallQueue:
            if "state" in item and (uid is not None or uid == item["target"]):
                continue
            else:
                newCallQueue.append(item)
        self.remoteCallQueue = newCallQueue

    #
    # Remote call
    #

    def queueRemoteCall(self, call):
        """
        Queue up a remote call

        Queued calls will be passed on to the client browser and executed when the form is first rendered (if it
        hasn't been rendered yet), when the current event has completed (if we're currently handling an event).

        Args:
            call: the call to queue up
        """
        self.remoteCallQueue.append(dict(code=call))

    def unqueueRemoteCall(self, call):
        """
        Remove a queued remote call

        Args:
            call (:class:`roudntrip.base.RPCCall`): the call originally ququed
        """
        self.remoteCallQueue = [i for i in self.remoteCallQueue if not i.get("code", None) is call]

    def renderCallPayload(self, queue=None):
        """
        Pops any pending RPC calls off the remote call queue and renders them as a Javascript block which can
        be sent back to the client for exec'ing.

        Returns:
            list: list of Javascript strings or dicts of the form
            :code:`{'code':<JS Code string>}` or `{'target':<component UID>, 'state':<setState dict>}`
        """

        # TODO: intelligent batching of updates

        if queue is None:
            queue = self.remoteCallQueue[:]

        payload = []

        for index, item in enumerate(queue):
            if isinstance(item, dict) and "update" in item:
                payload.append("ac(%s);" % javascript.dumps(item["update"]))  # payload += self.renderUpdate(item)
            elif isinstance(item, dict) and "nextTick" in item:
                payload.append("$$nextTick$$")
            else:
                payload.append(javascript.dumps(item["code"]))

        self.remoteCallQueue = []

        return payload

    @staticmethod
    def renderUpdate(at):
        at = at["update"]
        assert len(at) == 1
        componentId = [i for i in at][0]
        at = at[componentId]
        js = "c[%s].$data" % javascript.dumps(componentId)
        deltaJS = "sms[%s]" % javascript.dumps(componentId)
        history = [(js, None)]
        historyDeltaJS = [(deltaJS, None)]
        while 1:
            assert len(at) == 1
            op = [i for i in at][0]
            if isinstance(op, str) and op.startswith("$"):
                if op == "$push":
                    js += ".push(...%s)" % javascript.dumps(at[op])
                    deltaJS += ".push(...%s)" % javascript.dumps(at[op])
                elif op == "$set":
                    js = "%s[%s] = %s" % (history[-2][0], javascript.dumps(history[-1][1]), javascript.dumps(at[op]))
                    deltaJS = "%s[%s] = %s" % (
                        historyDeltaJS[-2][0],
                        javascript.dumps(historyDeltaJS[-1][1]),
                        javascript.dumps(at[op]),
                    )
                elif op == "$unset":
                    assert len(at[op]) == 1
                    js = "delete(%s[%s])" % (js, javascript.dumps(at[op][0]))
                    deltaJS = "delete(%s[%s])" % (deltaJS, javascript.dumps(at[op][0]))
                elif op == "$merge":
                    js = "%s = Object.assign({}, %s, %s)" % (js, js, javascript.dumps(at[op]))
                    deltaJS = "%s = Object.assign({}, %s, %s)" % (deltaJS, deltaJS, javascript.dumps(at[op]))
                elif op == "$splice":
                    js += ".splice(%s)" % ", ".join(javascript.dumps(i) for i in at[op][0])
                    deltaJS += ".splice(%s)" % ", ".join(javascript.dumps(i) for i in at[op][0])
                else:
                    raise ValueError("unsupported operator %s" % op)
                break
            else:
                if isinstance(op, str) and op.isalnum():
                    js += ".%s" % op
                    deltaJS += ".%s" % op
                else:
                    js += "[%s]" % javascript.dumps(op)
                    deltaJS += "[%s]" % javascript.dumps(op)
                at = at[op]
            history.append((js, op))
            historyDeltaJS.append((deltaJS, op))

        return [js + ";", deltaJS + ";"]

    def clearCallQueue(self):
        """
        Clears any pending RPC calls made through ``.js``
        """
        self.remoteCallQueue = []

    #
    # Out-of-band operations
    #

    async def callInContext(self, fn, *args, **kwargs):
        """
        Calls fn on a thread in the context of a connection (and does this asynchronously via the ioloop)

        Packages up the response and sends it back to the client
        """

        def _do_call():
            self.registerThread()
            fn(*args, **kwargs)
            return self.calcUpdate()

        payload = await asyncio.wrap_future(self.handler.threadPool.submit(_do_call))
        if payload.payload:
            async with self.semaphore:
                try:
                    await self.handler.write_message(javascript.dumps([payload]))
                except tornado.websocket.WebSocketClosedError:
                    # disconnected client is OK, we still want to do everything but send the message in case
                    #  the client reconnects (we'll keep their state up to date even if they've disconnected)
                    pass

    async def blindCallInContext(self, fn, *args, **kwargs):
        """
        Calls fn on a thread in the context of a connection (and does this asynchronously via the ioloop)

        Packages up the response and sends it back to the client
        """

        def _do_call():
            self.registerThread()
            fn(*args, **kwargs)

        await asyncio.wrap_future(self.handler.threadPool.submit(_do_call))

    def syncCallInContext(self, fn, *args, **kwargs):
        """
        Calls fn on a thread in the context of a connection

        Packages up the response and sends it back to the client
        """

        def assignThreadIdAndCall():
            self.registerThread()
            fn(*args, **kwargs)
            return self.calcUpdate()

        async def asyncCallback():
            # We do this without acquiring the semaphore (otherwise the bg process would stop all work on the
            # connection)
            payload = await self.ioloop.run_in_executor(self.handler.threadPool, assignThreadIdAndCall)
            if payload.payload:
                async with self.semaphore:
                    try:
                        await self.handler.write_message(javascript.dumps([payload]))
                    except tornado.websocket.WebSocketClosedError:
                        # disconnected client is OK, we still want to do everything but send the message in case
                        #  the client reconnects (we'll keep their state up to date even if they've disconnected)
                        pass

        self.ioloop.add_callback(asyncCallback)

    def calcUpdate(self):
        """
        Calculate an asynchronous update to push to the client

        This will push any state deltas as well as any remote calls made through ``.js``
        """
        return self.getPayload(kind=message.MessagePayload.OUTOFBAND)

    def pushUpdate(self):
        """
        Push an asynchronous update to the client

        This will push any state deltas as well as any remote calls made through ``.client``
        """
        self.ioloop.call_later(0.0, self.aPushUpdate)

    async def aPushUpdate(self):
        try:
            payload = self.calcUpdate()
            if not (payload.payload or payload.data or payload.stateDeltas):
                return
            async with self.semaphore:
                try:
                    await self.handler.write_message(javascript.dumps([payload]))
                except tornado.websocket.WebSocketClosedError:
                    # disconnected client is OK, we still want to do everything but send the message in case
                    #  the client reconnects (we'll keep their state up to date even if they've disconnected)
                    pass
        except Exception:
            logging.getLogger("roundtrip").exception("Error pushing update to client")
            raise

    #
    # Recording
    #

    def recordS2C(self, d):
        if self.recorder is not None:
            self.recorder.s2c(d)

    def recordC2S(self, d):
        if self.recorder is not None:
            self.recorder.c2s(d)

    #
    # Profiling
    #

    def addProfileResult(self, result):
        if not self.PROFILE_CACHE_SIZE:
            return
        if len(self.profileResults) > (self.PROFILE_CACHE_SIZE - 1):
            self.profileResults = self.profileResults[len(self.profileResults) - (self.PROFILE_CACHE_SIZE - 1) :]
        self.profileResults.append(result)


class RequestProfile:
    __slots__ = ["date", "request", "response", "profile"]

    def __init__(self, date, request, response, profile):
        self.date = date
        self.request = request
        self.response = response
        self.profile = profile


connectionManager: ConnectionManager | None = None
