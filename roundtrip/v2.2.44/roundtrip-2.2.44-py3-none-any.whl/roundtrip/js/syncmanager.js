/**
 * @fileoverview
 * Manage synchronization of the view model between client and server
 */

import EJSON from "./ejson.js"
import { odiff } from "./odiff.js"

const USE_LIVE_PROPS = true
const WARNING_ON_LINKED_WITHOUT_PARENT = true

export class SyncManager {
    constructor(application) {
        this.application = application

        this.state = {}
        this.treeChanges = []

        return this
    }

    checkSyncable(cmp) {
        // Return true if this component has a parent within the tree and thus can be sync'd / linked
        if (cmp._uid !== "1" && !this.getLinkedParentUID(cmp)) {
            if (WARNING_ON_LINKED_WITHOUT_PARENT) {
                console.warn(
                    "Non-root rt component has no linked parent (linked but cannot traverse hierarchy)",
                    cmp._uid,
                    cmp.$options.name,
                    cmp
                )
            }
            return false
        }
        return true
    }

    syncCreation(cmp) {
        this.treeChanges.push([
            "c",
            cmp.$options.name,
            cmp._uid.toString(),
            this.getLinkedParentUID(cmp),
            this.getComponentProps(cmp),
        ])
        if (Object.keys(cmp.$data).length) this.markClean(cmp._uid.toString())
    }

    syncDestruction(cmp) {
        let componentId = cmp._uid.toString()
        this.treeChanges.push(["d", componentId])
        delete this.state[componentId]
        delete this.application.components[componentId]
    }

    getTreeChanges(peek) {
        let tc = this.treeChanges
        if (!peek) this.treeChanges = []
        return tc
    }

    getLinkedParentUID(cmp) {
        return cmp._rt_parent && cmp._rt_parent._uid
    }

    markClean(componentId) {
        if (componentId) {
            let cmp = this.application.components[componentId]
            this.state[componentId] = this.getComponentState(cmp)
        } else {
            this.state = this.getState()
        }
    }

    getState() {
        let state = {}
        for (let [k, cmp] of Object.entries(this.application.components)) {
            if (!cmp.$rtIsLinked) continue
            if (!Object.keys(cmp.$data).length) continue
            state[k] = this.getComponentState(cmp)
        }
        return state
    }

    getComponentState(cmp) {
        let state = {}
        state = this.clone(cmp.$data)
        if (cmp.$options.rtSyncProps && USE_LIVE_PROPS) {
            let props = this.getComponentProps(cmp)
            if (Object.keys(props).length) {
                state["__props"] = props
            }
        }
        return state
    }

    getComponentProps(cmp) {
        let props = {}
        if (cmp.$options.rtSyncProps) {
            for (let [prop, fn] of Object.entries(cmp.$options.rtSyncProps)) {
                props[prop] = this.clone(fn.bind(cmp)())
            }
        }
        return props
    }

    clone(o) {
        return EJSON.clone(o)
    }

    markDirty() {
        this.state = {}
    }

    applyChange(change) {
        try {
            let head, nChange, nHead, at, atS
            at = this.application.components
            atS = this.state
            ;[[head, change]] = Object.entries(change)
            head = Number.parseInt(head)
            while (true) {
                ;[[nHead, nChange]] = Object.entries(change)
                switch (nHead) {
                    case "$add":
                        at[head] += nChange
                        atS[head] += this.clone(nChange)
                        return
                    case "$set":
                        if (at === undefined) return
                        at[head] = nChange
                        atS[head] = this.clone(nChange)
                        return
                    case "$push":
                        at[head] = [...at[head], ...nChange]
                        atS[head] = [...atS[head], ...this.clone(nChange)]
                        return
                    case "$unset":
                        if (at === undefined) return
                        delete at[head][nChange[0]]
                        delete atS[head][nChange[0]]
                        return
                    case "$merge":
                        at[head] = Object.assign(at[head], nChange)
                        atS[head] = Object.assign(
                            atS[head],
                            this.clone(nChange)
                        )
                        return
                    case "$splice":
                        at[head].splice(...nChange[0])
                        atS[head].splice(...nChange[0])
                        return
                    default:
                        at = at[head]
                        atS = atS[head]
                        head = nHead
                        change = nChange
                }
            }
        } catch (e) {
            console.error("Apply change failed", change, e)
        }
    }

    /**
     * Returns a mapping of component id -> delta for any components with states with changed data values
     * @type Object
     * @return mapping of component id -> delta
     */
    getStateDeltas(peek) {
        let newState = this.getState()
        let deltas = []
        for (let componentId of Object.keys(newState)) {
            let d = odiff(this.state[componentId], newState[componentId])
            for (let i = 0; i < d.length; i++) {
                d[i].path = [componentId].concat(d[i].path)
                if (d[i].type === "rm") delete d[i].vals
            }
            deltas = deltas.concat(d)
        }
        if (!peek) this.state = newState
        return deltas
    }
}
