from roundtrip.component import Component, method
from roundtrip.core.javascript import js


class AppError(Component):
    graphics_path = "../assets/graphics/apperror"

    # language=VUE
    template = r"""
        <transition name="rt-error-fade" v-if="!online"
        >
            <div class="rt-overlay">
                <div class="rt-error-container">
                    <img src="{&cmp.graphics_path&}/reconnect.svg" width="50%" style="padding-bottom: 20px;"/>
                    <h1>Connecting to the server.</h1>
                    <button class="rt-error-button" @click="$rt.reload()">RESTART</button>
                </div>
            </div>
        </transition>
        <transition name="rt-error-fade" v-else-if="(
            connection_state == 'connecting' | 
            connection_state == 'retryWait' |
            connection_state == 'reconnecting' | 
            connection_state == 'retryWaitError')"
        >
            <div class="rt-overlay">
                <div class="rt-error-container">
                    <img src="{&cmp.graphics_path&}/reconnect.svg" width="50%" style="padding-bottom: 20px;"/>
                    <h1>Connecting to the server.</h1>
                    <button class="rt-error-button" @click="$rt.reload()">RESTART</button>
                </div>
            </div>
        </transition>
        <transition name="rt-error-fade" v-else-if="connection_state != 'connected'">
            <div class="rt-overlay">
                <div class="rt-error-container">
                    <img src="{&cmp.graphics_path&}/disconnect.svg" width="50%" style="padding-bottom: 20px;"/>
                    <h1>There was an error connecting to our servers.</h1>
                    <div class="rt-button-container">
                        <button class="rt-error-button" @click="$rt.reconnect()">RECONNECT</button>
                        <button class="rt-error-button" @click="$rt.reload()">RESTART</button>
                    </div>
                </div>
            </div>
        </transition>
        <transition name="rt-error-fade" v-else-if="(connection_state == 'connected') & connection_expired">
            <div class="rt-overlay">
                <div class="rt-error-container">
                    <img src="{&cmp.graphics_path&}/session-error.svg" width="50%" style="padding-bottom: 20px;"/>
                    <h1>Session has expired.</h1>
                    <button class="rt-error-button" @click="$rt.reload()">RESTART</button>
                </div>                
            </div>            
        </transition>
        <transition name="rt-error-fade" v-else-if="error">
            <div class="rt-overlay">
                <div class="rt-error-window">
                    <div class="rt-error-title"><h1>An error occured on our servers.</h1></div>
                    <img src="{&cmp.graphics_path&}/code-error.svg" width="50%" style="padding-bottom: 20px;"/>
                    <pre v-if="error && error.traceback">{{ error && error.traceback }}</pre>
                    <div class="rt-button-container">
                        <button class="rt-error-button" @click="$rt.reload()">RESTART</button>
                        <button class="rt-error-button" @click="error=null">IGNORE</button>
                    </div>
                </div>
            </div>
        </transition>
        <transition name="rt-error-fade" v-else-if="javascript_error">
            <div class="rt-overlay">
                <div class="rt-error-window">
                    <div class="rt-error-title"><h1>An error occured in the application.</h1></div>
                    <img src="{&cmp.graphics_path&}/code-error.svg" width="50%" style="padding-bottom: 20px;"/>
                    <pre v-if="javascript_error">{{ javascript_error.message }}</pre>
                    <div class="rt-button-container">
                        <button class="rt-error-button" @click="$rt.reload()">RESTART</button>
                        <button class="rt-error-button" @click="javascript_error=null">IGNORE</button>
                    </div>
                </div>
            </div>
        </transition>
        <transition name="rt-error-fade" v-else-if="spinner">
            <div class="rt-overlay rt-spinner-overlay">
                <div class="rt-spinner"/>
            </div>
        </transition>
    """

    initialData = dict(
        connection_state="connected",
        error=None,
        spinner=False,
        connection_expired=False,
        online=js(r"""navigator.onLine"""),
        javascript_error=None,
    )

    methods = dict(
        connectionExpired="function(e) { return window.location.reload() }",
        connectionStateChange="function(e) { return this.$data.connection_state = e }",
        protocolError="function(e) { return this.$data.error = e }",
        serverException="function(e) { return this.$data.error = e }",
        serverExceptionOutOfBand="function(e) { return this.$data.error = e }",
        showSpinner="function(e) { return this.$data.spinner = true }",
        hideSpinner="function(e) { return this.$data.spinner = false }",
        sessionTimeout="function(e) { return this.$data.connection_expired = true }",
        javascriptError="function(e) { return e.debugLevel > 1 ? this.$data.javascript_error = e : null }",
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        created=js(
            r"""function() {
            this.$rt.connectAllEvents(this);
            this.go_offline = (function() { this.$data.online=false; }).bind(this);
            this.go_online = (function() { this.$data.online=true; }).bind(this);
            window.addEventListener('offline', this.go_offline);
            window.addEventListener('online', this.go_online);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        unmounted=js(
            r"""function() {
            window.removeEventListener('offline', this.go_offline);
            window.removeEventListener('online', this.go_online);
        }"""
        ),
    )
