from pathlib import Path
import warnings

from .. import component
from ..component.component import ExternalMetaclass, External, ComponentMetaclass
from ..component.decorators import *
from ..core.javascript import js
from ..generate.application import ApplicationGenerator


__all__ = ["BaseApplication", "ApplicationOptions", "Plugin"]


class ApplicationOptions:
    """
    Used to pass startup options to the application (these get passed to the frontend to configure the JS side).
    """

    webSocketURL = None
    sessionTimeout = 6000
    debugLevel = 3
    secureWebsocket = None

    def __init__(self, **kargs):
        self.__dict__.update(kargs)

    def toDict(self):
        return self.__dict__


class Plugin:
    """
    Support for Vue plugins
    """

    def __init__(self, js, imports, arguments=None):
        self.js = js
        self.imports = imports
        self.arguments = arguments


class BaseApplication(component.Component):
    """
    A base application that adds support for plugins and automatic inclusion of external Vue components.
    """

    propsData = None
    plugins = []
    server = None  #: the server that created this application
    router = None  #: optional router object from router.py if a Vue router is used in this application

    def generateStaticJavascript(self, path, options, vueSources):
        pth = Path(path)

        for sourcePath in vueSources:
            sp = Path(sourcePath)
            importPath = (sp).relative_to(pth)
            for vueFile in sp.glob("*.vue"):
                name = vueFile.name
                stem = vueFile.stem
                ExternalMetaclass.__new__(
                    ExternalMetaclass, stem, (External,), dict(imports={f"import {stem} from '../{importPath}/{name}'"})
                )

        gen = ApplicationGenerator(component=self, options=options, path=path)

        gen.generateStaticJavascript()

        return True
