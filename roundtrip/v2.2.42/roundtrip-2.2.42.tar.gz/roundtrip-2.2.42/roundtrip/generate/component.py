import inspect
import types
import warnings
from collections import OrderedDict

from ..core.javascript import js, dumps, formatObject, stringOrJS
from .code import *
from ..component import External, ComponentMetaclass, ExternalMetaclass
from ..core.javascript import Op, NoOp

__all__ = ["CGComponent", "CGFile"]


def sortedDict(d):
    return {k: d[k] for k in sorted(d)}


class CGComponent:
    """
    Generate a component as a javascript class within a complete .vue file
    """

    def __init__(self, ag, component):
        self.ag = ag
        self.c = component

    @property
    def methods(self):
        return [i for i in inspect.getmembers(self.c) if inspect.ismethod(i[1])]

    def genJS(self):
        out = Fragment()

        opt, imports = self.buildOptions()

        for i in imports:
            out += Statement(i)

        if getattr(self.c, "bodyJS", None):
            out += Spacer()
            out += stringOrJS(self.c.bodyJS())

        out += Spacer()
        out += "export default " + formatObject(opt)

        return out

    def preprocessMethod(self, k, v):
        if isinstance(v, NoOp):
            return k, v
        elif isinstance(v, Op):
            jsc = v._as_javascript()
            v._unqueue()
            return k, js("function(e) { return (%s); }" % jsc)
        elif hasattr(v, "_as_javascript"):
            return k, v
        elif isinstance(v, str):
            if v.strip().startswith("function") or v.strip().startswith("async ") or " => " in v:
                return k, js(v)
            else:
                warnings.warn(
                    f"Deprecated js function expression {v!r} on {self.c.__class__.__name__}.{k} in: define a real "
                    f"function"
                )
                return k, js("function(e) { return %s; }" % v.strip())
        elif isinstance(v, types.MethodType):
            return self.buildOnEvent(k, v)
        else:
            raise ValueError("method must be a string, a javascript expression, or a js object")

    @staticmethod
    def buildOnEvent(name, method):
        jsName = getattr(method, "jsName", name)
        event = dict(name=jsName)
        if getattr(method, "spinner", None):
            event["spinner"] = method.spinner
        if getattr(method, "throttle", None):
            event["spinner"] = method.throttle
        if getattr(method, "cancelable", None):
            event["cancelable"] = method.cancelable
        if getattr(method, "during", None):
            event["during"] = method.during
        if getattr(method, "methodArguments", None):
            for k, v in method.methodArguments.items():
                if not hasattr(v, "_as_javascript"):
                    raise ValueError(f"methodArguments must be a dictionary of js objects, got {k!r}={v!r}")
            event["data"] = method.methodArguments
        else:
            event["data"] = js("data")
        fn = Function(args=["data"])
        fn += Statement("return this.$rt_call_server_method(%s)" % formatObject(event, nl=""))
        return jsName, fn

    def buildOptions(self):
        imports = [i for i in self.c.imports] if self.c.imports else []

        opt = dict()

        if self.c.options:
            opt.update(self.c.options)

        opt["name"] = self.c.className

        data = self.c.getData()
        if data is not None:
            opt["data"] = js("function($vm) { return %s; }" % dumps(sortedDict(data)))

        #
        # methods
        #
        methods = dict()

        # methods defined as javascript strings / objects
        if self.c.methods:
            for k, v in self.c.methods.items():
                k, v = self.preprocessMethod(k, v)
                methods[k] = v

        # methods defined with @method
        for name, method in self.methods:
            if not getattr(method, "isMethod", False):
                continue
            if name in methods:
                raise NameError("method %s defined twice in %r" % (name, self.c))
            k, v = self.buildOnEvent(name, method)
            methods[k] = v

        if methods:
            opt["methods"] = sortedDict(methods)

        #
        # components
        #

        components = dict()

        rtComponentsToLoad = []

        # components contained within this component (i.e. defined as nested classes)
        for className in self.c.children:
            if className == self.c.className:
                # ignore recursive references
                continue
            if not self.ag.globalComponents:
                rtComponentsToLoad.append(className)

        # components listed in referencedComponents (actual component classes are used not classNames)
        for componentClass in self.c.referencedComponents:
            imports += componentClass.imports
            if not componentClass.notInComponents:
                components[componentClass.className] = componentClass.jsExpression

        # components mentioned in the template
        if self.c.components:
            for className in self.c.components:
                if className in ComponentMetaclass.byClassName:
                    # rt component
                    if not self.ag.globalComponents:
                        rtComponentsToLoad.append(className)
                elif className in ExternalMetaclass.byClassName:
                    # external component
                    external = ExternalMetaclass.byClassName[className]
                    imports += external.imports
                    if not external.notInComponents:
                        components[className] = external.jsExpression
                else:
                    # unknown tag used
                    raise KeyError("component className=%s used in %r cannot be found" % (className, self.c))

        loadedAsync = False
        for className in rtComponentsToLoad:
            cmp = ComponentMetaclass.byClassName[className]
            if cmp.loadAsync:
                components[className] = js("defineAsyncComponent(() => import('./%s.vue'))" % className)
                loadedAsync = True
            else:
                imports.append(f"import {className} from './{className}.vue'")
                components[className] = js(f"{ className }")

        if loadedAsync:
            imports.insert(0, "import { defineAsyncComponent } from 'vue'")

        if components:
            opt["components"] = sortedDict(components)

        #
        # props
        #

        props = {}
        if self.c.props:
            if type(self.c.props) is list:
                props.update({k: {} for k in self.c.props})
            elif type(self.c.props) is dict:
                props.update(self.c.props)
            else:
                raise ValueError("props must be list or dict")
        if props:
            opt["props"] = sortedDict(props)

        #
        # emits
        #

        emits = {}
        if self.c.emits:
            if type(self.c.emits) is list:
                emits.update({k: {} for k in self.c.emits})
            elif type(self.c.emits) is dict:
                emits.update(self.c.emits)
            else:
                raise ValueError("emits must be list or dict")
        if emits:
            opt["emits"] = sortedDict(emits)

        #
        # mixins
        #

        mixins = set()
        if self.c.mixins:
            mixins.update(set(self.c.mixins))
        if not self.c.isApplication and self.c.linked:
            mixinName = "RTLinkedMixin"
            mixins.add(mixinName)
            imports.append("import { %s } from '%s'" % (mixinName, "roundtrip/plugin"))

        if mixins:
            opt["mixins"] = [js(i) for i in sorted(mixins)]

        #
        # computed
        #

        # computed defined as javascript strings / objects
        computed = dict()
        if self.c.computed:
            for k, v in self.c.computed.items():
                k, v = self.preprocessMethod(k, v)
                computed[k] = v

        if computed:
            opt["computed"] = sortedDict(computed)

        NAMES = [
            "beforeCreate",
            "created",
            "beforeMount",
            "mounted",
            "beforeUpdate",
            "updated",
            "activated",
            "deactivated",
            "beforeUnmount",
            "unmounted",
            "errorCaptured",
            "renderTracked",
            "renderTriggered",
        ]

        if self.c.lifecycle:
            for k, v in sorted(self.c.lifecycle.items()):
                if k not in NAMES:
                    raise ValueError("%s is not a valid lifecycle method name" % k)
                k, v = self.preprocessMethod(k, v)
                opt[k] = v

        for name, method in sorted(self.methods):
            if getattr(method, "isLifecycle", False):
                if name not in NAMES:
                    raise ValueError("%s is not a valid lifecycle method name" % name)
                k, v = self.buildOnEvent(name, method)
                if k in opt:
                    opt[k] = chainFunctions(v, opt[k])
                else:
                    opt[k] = v

        #
        # watch
        #

        # watch'es defined as javascript strings / objects
        watch = dict()
        if self.c.watch:
            for k, v in self.c.watch.items():
                if isinstance(v, dict):
                    out = dict()
                    out.update(v)
                    out["handler"] = self.preprocessMethod(k, out["handler"])[1]
                    watch[k] = out
                else:
                    k, v = self.preprocessMethod(k, v)
                    watch[k] = v

        if watch:
            opt["watch"] = sortedDict(watch)

        #
        # provide
        #
        provide = dict(_rt_parent=js("this"))
        if self.c.provide:
            for k, v in self.c.provide.items():
                provide[k] = v
        opt["provide"] = js(f"function() {{ return {formatObject(provide)} }}")

        #
        # inject
        #
        if self.c.isApplication:
            opt["inject"] = self.c.inject
        else:
            if isinstance(self.c.inject, list):
                opt["inject"] = ["_rt_parent"] + sorted(self.c.inject or [])
            else:
                opt["inject"] = (self.c.inject or {}) | {"_rt_parent": {"from": "_rt_parent"}}

        #
        # syncProps
        #
        syncProps = dict()
        if self.c.syncProps:
            if type(self.c.syncProps) in (list, set):
                syncProps.update({k: js("function() { return this.$props[%r]; }" % k) for k in self.c.syncProps})
            else:
                for k, v in self.c.syncProps.items():
                    if isinstance(v, str):
                        if v.strip().startswith("function(") or v.strip().startswith("()"):
                            syncProps[k] = js(v)
                        else:
                            syncProps[k] = js("function() { return this.$props[%r]; }" % v)
                    else:
                        syncProps[k] = v
        if syncProps:
            opt["rtSyncProps"] = sortedDict(syncProps)

        #
        # route guards
        #
        for k in ["beforeRouteEnter", "beforeRouteLeave", "beforeRouteUpdate"]:
            imports.append("import { application as app } from './index.js'")
            if hasattr(self.c, k):
                method = getattr(self.c, k)
                if isinstance(method, types.MethodType):
                    event = dict(name=k)
                    if getattr(method, "spinner", None):
                        raise ValueError("beforeRouteEnter cannot have a spinner")
                    if getattr(method, "throttle", None):
                        raise ValueError("beforeRouteEnter cannot have a throttle")
                    if getattr(method, "cancelable", None):
                        event["cancelable"] = method.cancelable
                    event["data"] = dict(to=js("to.path"), from_=js("from.path"))
                    fn = AsyncFunction(args=["to", "from", "next"])
                    if k == "beforeRouteEnter":
                        if not inspect.ismethod(method) and method.__self__ is self.c:
                            raise ValueError("beforeRouteEnter must be a @classmethod")
                        fn += Statement(
                            r"""next(await app.$rt.$rt_call_server_method(%s))"""
                            % formatObject(
                                dict(
                                    name="executeComponentClassMethod",
                                    data=dict(event=event, component=self.c.className),
                                ),
                                nl="",
                            )
                        )
                    else:
                        fn += Statement("next(await this.$rt_call_server_method(%s))" % formatObject(event, nl=""))
                    opt[k] = fn
                else:
                    opt[k] = self.preprocessMethod(k, method)[1]
        dedupe = []
        [dedupe.append(i) for i in imports if i not in dedupe]
        imports = sorted(dedupe)

        return opt, imports

    def gen(self):
        out = File(name=self.c.className + ".vue")
        out += "<template>\n"
        out += indentTo(self.c.processedTemplate.rstrip(), 4)
        out += "\n</template>\n"
        out += "\n"

        if self.c.style:
            out += "<style>\n"
            out += indentTo(self.c.style.rstrip(), 4)
            out += "\n</style>\n"
            out += "\n"

        if self.c.scopedStyle:
            out += "<style scoped>\n"
            out += indentTo(self.c.styleScoped.rstrip(), 4)
            out += "\n</style>\n"
            out += "\n"

        out += "<script>\n"
        out += self.genJS()._as_javascript().rstrip() + "\n\n"
        out += "</script>\n"
        if self.c.style:
            out += '<style lang="scss">\n'
            out += indent(self.c.style) + "\n\n"
            out += "</style>\n"
        return out


class CGFile(CGComponent):
    """
    Class to handle generating a component file
    """

    @property
    def name(self):
        return self.c.className
