import types
import time
import weakref
import uuid
from . import javascript

__all__ = ["MessagePayload"]


class MessagePayload(object):
    """
    Holds data to be sent in response to AJAX calls

    Our client-side libraries support a two-part response with JSON data plus separate Javascript.

    The format is as follows::

        <1-byte kind>[<length of JSON data as 10-digit int><JSON data>]<non-JSON payload - e.g. Javascript block>

    The integer (as 10-digits of ASCII padded with inital zeros) gives the length of the JSON data stream that will follow,
    then comes the json-encoded data, finally a non-encoded payload follows which may be any data the application wishes to send
    and which does not need encoding - e.g. a block of Javascript to be executed.
    """

    NORMAL = "N"  #: response kind - normal in-band response with or without data
    EXCEPTION = "X"  #: response kind - in-band exception response
    OOB_EXCEPTION = "Z"  #: response kind - out-of-band exception response
    OUTOFBAND = "O"  #: response kind - out-of-band event (executable payload only)
    NO_CONNECTION = "S"  #: response kind - connection missing (usually because it timed out)
    RESEND_STATE = "R"  #: response kind - no connection, resend
    NEW_CONNECTION = "C"  #: response kind = response to a new connection

    def __init__(
        self, data=None, payload=None, exception=None, kind="N", stateDeltas=None, connectionId=None, index=None
    ):
        self.data = data
        self.payload = payload
        self.kind = kind
        self.exception = exception
        self.stateDeltas = stateDeltas
        self.connectionId = connectionId
        self.index = index
        if kind not in [
            self.NORMAL,
            self.EXCEPTION,
            self.OOB_EXCEPTION,
            self.OUTOFBAND,
            self.NO_CONNECTION,
            self.RESEND_STATE,
            self.NEW_CONNECTION,
        ]:
            raise ValueError("Invalid kind %r" % self.kind)

    def encode(self):
        return javascript.dumps(self._as_javascript())

    def _as_javascript(self):
        d = dict()
        for k in ["kind", "data", "exception", "stateDeltas", "connectionId", "payload", "index"]:
            if getattr(self, k) is not None:
                d[k] = getattr(self, k)
        return javascript.dumps(d)

    def __repr__(self):
        return "<Message[%s] data=%r payload=%r deltas=%r>" % (self.kind, self.data, self.payload, self.stateDeltas)
