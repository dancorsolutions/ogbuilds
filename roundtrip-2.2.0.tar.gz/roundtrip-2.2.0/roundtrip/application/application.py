from pathlib import Path
import warnings

from .. import component
from ..component.component import ExternalMetaclass, External, ComponentMetaclass
from ..component.decorators import *
from ..core.javascript import js
from ..generate.application import ApplicationGenerator


__all__ = ["BaseApplication", "RouterApplication", "Route", "ApplicationOptions", "Plugin"]


class ApplicationOptions:
    webSocketURL = None
    sessionTimeout = 6000
    debugLevel = 3
    secureWebsocket = True

    def __init__(self, **kargs):
        self.__dict__.update(kargs)

    def toDict(self):
        return self.__dict__


class Plugin:
    def __init__(self, js, imports, arguments=None):
        self.js = js
        self.imports = imports
        self.arguments = arguments


class BaseApplication(component.Component):
    isApplication = True
    propsData = None
    plugins = []
    server = None  #: the server that created this application
    router = None  #: optional router object from router.py if a Vue router is used in this application

    def generateStaticJavascript(self, path, options, vueSources):
        pth = Path(path)

        for sourcePath in vueSources:
            sp = Path(sourcePath)
            importPath = (sp).relative_to(pth)
            for vueFile in sp.glob("*.vue"):
                name = vueFile.name
                stem = vueFile.stem
                ExternalMetaclass.__new__(
                    ExternalMetaclass, stem, (External,), dict(imports={f"import {stem} from '../{importPath}/{name}'"})
                )

        gen = ApplicationGenerator(component=self, options=options, path=path)

        gen.generateStaticJavascript()

        return True


class Route:
    def __init__(self, path: str, component: str or None = None, **kwargs):
        self.component = component
        self.data = kwargs
        self.args = []

        simple_path = []
        split_path = path.split("/")
        for i in split_path:
            if i.startswith(":"):
                self.args.append(i[1:])
            else:
                simple_path.append(i)

        self.path = "/".join(simple_path)

    def match(self, path):
        if not path:
            return False, None
        split_path = path.split("/")
        split_self = self.path.split("/")
        if split_self != split_path[: len(split_self)]:
            return False, None
        else:
            args = dict()
            rest = split_path[len(split_self) :]
            for k in self.args:
                if not rest:
                    break
                v = rest.pop(0)
                args[k] = v
            if len(args) != len(self.args) or rest:
                # not all arguments matched / leftover paths after all arguments matched
                return False, None
            return True, args


class RouterApplication(BaseApplication):
    routes = []

    # language=Vue
    template = r"""
    <MyAppError/>
    <component :is="current_screen" v-if="standalone"/>
    """

    initialData = dict(current_screen=None, current_screen_props=dict())

    methods = dict(
        # language=JavaScript prefix=[ suffix=]
        didConnect=js(
            """
            function(is_reconnection) {
                if(this.do_connect) 
                    this.do_connect({is_reconnection, path: window.location.pathname});
            }
        """
        ),
        # language=JavaScript prefix=[ suffix=]
        handlePopstate=js(
            """
        function(event) {
            event.preventDefault();
            this.doPopstate({state: event.state});
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        push=js(
            """
        function(location, data) {
            history.pushState(data, null, location);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        back=js(
            """
        function() {
            history.go(-1);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        forward=js(
            """
        function() {
            history.go(1);
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        replace=js(
            """
        function(location, data) {
            history.replaceState(data, null, location);
        }"""
        ),
    )

    lifecycle = dict(
        # language=JavaScript prefix=[ suffix=]
        beforeMount=js(
            """function() { 
            window.addEventListener('popstate', this.handlePopstate);
            window.addEventListener('load', this.handleLoad);            
        }"""
        ),
        # language=JavaScript prefix=[ suffix=]
        beforeUnmount=js(
            """function() { 
            window.removeEventListener('popstate', this.handlePopstate);
            window.removeEventListener('load', this.handleLoad);            
        }"""
        ),
    )

    def open(self, path=None, **kwargs):
        path = "/" + path if not path.startswith("/") else path

        self.showRoute(path=path, **kwargs)
        self.client.push(path, dict(path=path))

    def showRoute(self, path=None, **kwargs):
        path = "/" + path if not path.startswith("/") else path

        for route in self.routes:
            matched, route_kwargs = route.match(path)

            if not matched:
                continue

            self.data.current_screen_props = route_kwargs
            self.data.current_screen = route.component
            return route
        else:
            warnings.warn(f"No such route {path}")
            return None

    @method
    def doPopstate(self, state):
        self.app.go(state["path"], dont_push_route=True)
